// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.util;

/**
 * A simple time recorder.
 */
public class Timer {
	private long start, t;
	
	/**
	 * Full constructor, starts timer.
	 */
	public Timer() {
		start();
	}

	/**
	 * Restart timer.
	 */
	public void start() {
		start = t = System.currentTimeMillis();
	}
	
	/**
	 * @return time difference from last check to this check in milliseconds
	 */
	public long capture() {
		long last = t;
		t = System.currentTimeMillis();
		return t-last;
	}
	
	/**
	 * @return the total run time in milliseconds since this timer was created or restarted
	 */
	public long totalRuntime() {
		return System.currentTimeMillis() - start;
	}
}
