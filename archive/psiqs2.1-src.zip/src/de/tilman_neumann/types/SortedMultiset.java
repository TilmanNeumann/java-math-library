// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.types;

/**
 * A multiset with a sort relation between elements.<br>
 * 
 * The sorting of elements has the following consequences:
 * - elements must be Comparable
 * - SortedMaps are a bit slower than HashMaps
 * - output of sorted multisets looks nicer than that of unsorted multisets
 * - we could define a sorting on multisets as well
 * 
 * @param <T> value class
 */
public interface SortedMultiset<T extends Comparable<T>> extends Multiset<T> {

	/**
	 * @return The smallest element.
	 */
	T getSmallestElement();

	/**
	 * @return The biggest element.
	 */
	T getBiggestElement();

	/**
	 * Returns the multiset of elements contained in both this and in the other multiset.
	 * @param other
	 * @return
	 */
	@Override // declare exact result data type
	SortedMultiset<T> intersect(Multiset<T> other);
}