// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.base.bigint;

import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Arrays;

import org.apache.log4j.Logger;

import de.tilman_neumann.util.ConfigUtil;

import static de.tilman_neumann.math.base.bigint.BigIntConstants.*;
import static org.junit.Assert.*;

/**
 * A very limited unsigned big integer implementation.
 * Currently the only implemented methods are division and modulus of big integers by small integers.
 * These methods are notably faster than using BigInteger.divide(BigInteger),
 * like factor 2.5 for BigIntegers with 100 bit, factor 1.8 at 200 bit, factor 1.6 at 300 bit.
 */
public class UnsignedBigInt {
	private static final Logger LOG = Logger.getLogger(UnsignedBigInt.class);
	private static final boolean DEBUG = false;
	private static final SecureRandom RNG = new SecureRandom();
	
	private static final BigInteger UNSIGNED_INT_MASK_BIG = BigInteger.valueOf(0xFFFFFFFFL);

	private int intLength;
	private int[] intArray;

	/**
	 * Shortcut constructor for <code>new UnsignedBigInt(); set(N);</code>
	 * @param N
	 */
	public UnsignedBigInt(BigInteger N) {
		this();
		this.set(N);
	}

	/**
	 * Simple constructor. The intArray will be allocated for the N passed to the {@link #set(BigInteger)} method.
	 */
	public UnsignedBigInt() {
		intArray = null;
	}

	/**
	 * Constructor using the given buffer. The numbers to work on must be set using the
	 * {@link #set(BigInteger)} method.
	 * 
	 * @param buffer a buffer big enough to represent all numbers that will be set using {@link #set(BigInteger)}.
	 */
	public UnsignedBigInt(int[] buffer) {
		intArray = buffer;
	}

	/**
	 * Sets this to the given BigInteger N. This method must be called before any arithmetic operation.
	 * If a buffer has been passed to the constructor then it should be big enough to represent N.
	 * 
	 * @param N
	 */
	public void set(BigInteger N) {
		intLength = (N.bitLength()+31)>>5; // round up
		if (intLength > 0) {
			if (intArray == null || intArray.length < intLength) {
				// allocate new 0-initialized array
				intArray = new int[intLength];
			} else {
				// clear existing buffer
				for (int i=intLength-1; i>=0; i--) intArray[i] = 0; // TODO: use arrayCopy() ?
			}
			
			// bytes in big-endian order, i.e. the most significant byte is at index 0
			byte[] bytes = N.toByteArray();
			// convert byte[] to unsigned int[]
			//LOG.debug("#bytes = " + bytes.length + ", #ints = " + intLength);
			int i=0, j=0;
			for (int bPos=bytes.length-1; bPos>=0; bPos--) {
				int b = bytes[bPos] & 0xFF;
				intArray[i] |= b<<(j<<3);
				if (++j==4) {
					if (++i == intLength) {
						// The most significant byte of N.toByteArray() has a sign bit, which is 0 for unsigned integers.
						// But it may lead to another byte! -> skip that one...
						//LOG.debug("i has reached maximum value " + i);
						break;
					}
					j = 0;
				}
			}
		}
		
		if (DEBUG) {
			// compare with slower but safer implementation
			int[] intArrayFromNShifts = new int[intLength];
			for (int i2=0; i2<intLength; i2++) {
				intArrayFromNShifts[i2] = N.and(UNSIGNED_INT_MASK_BIG).intValue();
				N = N.shiftRight(32);
			}
			assertTrue(Arrays.equals(intArrayFromNShifts, intArray));
		}
	}

	/**
	 * Test for 1. The caller must make sure that {@link #set(BigInteger)} has been invoked before.
	 * 
	 * @return true if this==1, false else
	 */
	public boolean isOne() {
		if (intLength==0 || intArray[0]!=1) return false;
		for (int i=intLength-1; i>0; i--) {
			if (intArray[i]!=0) return false;
		}
		return true;
	}
	
    /**
     * Divide this by the given <code>divisor</code>, store the quotient in <code>quotient</code> and return the remainder.
     * The caller must make sure that {@link #set(BigInteger)} has been invoked before.
     * 
     * @param divisor
     * @param quotient output!
     * @return remainder
     */
    public int divideAndRemainder(final int divisor, UnsignedBigInt quotient) {
    	// A special treatment of intLength==1 is asymptotically bad
        long rem = 0;
        long divisor_long = divisor & 0xFFFFFFFFL;
        long currentDividend, quot;

        // loop that determines intLength by the way
        quotient.intLength = 0; // if this < divisor
        int i = intLength-1;
        for (; i >= 0; i--) {
            currentDividend = (rem << 32) | (intArray[i] & 0xFFFFFFFFL);
            quot = currentDividend / divisor_long;
    		// rem = currentDividend % divisor_long is faster than currentDividend - quot*divisor_long
            rem = currentDividend % divisor_long;
            //if (DEBUG) {
            //	assertTrue(currentDividend >= 0);
            //	assertTrue(quot <= 0xFFFFFFFFL);
            //}
            quotient.intArray[i] = (int) (quot & 0xFFFFFFFFL);
            if (quot>0) {
            	quotient.intLength = i+1;
            	i--; // loop "increment" will not be carried out after break
            	break; // go to loop without intLength-test
            }
        }
        
        // loop without intLength-test
        for (; i >= 0; i--) {
            currentDividend = (rem << 32) | (intArray[i] & 0xFFFFFFFFL);
            quot = currentDividend / divisor_long;
    		// rem = currentDividend % divisor_long is faster than currentDividend - quot*divisor_long
            rem = currentDividend % divisor_long;
            //if (DEBUG) {
            //	assertTrue(currentDividend >= 0);
            //	assertTrue(quot <= 0xFFFFFFFFL);
            //}
            quotient.intArray[i] = (int) (quot & 0xFFFFFFFFL);
        }
        
        return (int) rem;
    }
    
    /**
     * Compute the remainder of this modulo divisor.
     * The caller must make sure that {@link #set(BigInteger)} has been invoked before.
     * 
     * @param divisor
     * @return remainder
     */
    public int mod(final int divisor) {
    	// A special treatment of intLength==1 is asymptotically bad
        long rem = 0;
        long divisor_long = divisor & 0xFFFFFFFFL;
        long currentDividend;
        for (int i = intLength-1; i >= 0; i--) {
            currentDividend = (rem << 32) | (intArray[i] & 0xFFFFFFFFL);
    		// rem = currentDividend % divisor_long is faster than currentDividend - quot*divisor_long
            rem = currentDividend % divisor_long;
        }
        return (int) rem;
    }

    public boolean equals(Object o) {
    	if (o==null || !(o instanceof UnsignedBigInt)) return false;
    	UnsignedBigInt other = (UnsignedBigInt) o;
    	if (intLength!=other.intLength) return false;
    	for (int i=intLength-1; i>=0; i--) {
    		if (intArray[i]!=other.intArray[i]) return false;
    	}
    	return true;
    }
    
	public BigInteger toBigInteger() {
		//LOG.debug("intLength = " + intLength);
		if (intLength==0) return ZERO;
		if (intLength==1) return BigInteger.valueOf(intArray[0] & 0xFFFFFFFFL);
		// For intLength==2 we already need byte[], because intArray[1]<<32 could be a negative long
		int byteLength = intLength<<2;
		byte[] bytes = new byte[byteLength+1]; // add one extra-byte to assure that there is a zero sign-bit
		for (int i = 0; i < intLength; i++) {
			long digit = intArray[i] & 0xFFFFFFFFL; // the long mask avoids negative values
			int bPos = byteLength - (i<<2);
			bytes[bPos] = (byte) (digit & 0xFF);
			bytes[--bPos] = (byte) (digit / 0x100 & 0xFF);
			bytes[--bPos] = (byte) (digit / 0x10000 & 0xFF);
			bytes[--bPos] = (byte) (digit / 0x1000000 & 0xFF);
		}
		BigInteger N = new BigInteger(bytes);
		
		if (DEBUG) {
			// compare with slower but safer implementation
			BigInteger NfromShifts = BigInteger.valueOf(intArray[intLength-1] & 0xFFFFFFFFL);
			for (int i=intLength-2; i>=0; i--) {
				NfromShifts = NfromShifts.shiftLeft(32).add(BigInteger.valueOf(intArray[i] & 0xFFFFFFFFL));
			}
			assertEquals(NfromShifts, N);
		}
		return N;
	}

	public String toString() {
		return this.toBigInteger().toString();
	}
	
   	/**
   	 * create test set for performance test: random ints with random bit length < 1000
   	 * @param nCount
   	 * @return
   	 */
	private static ArrayList<BigInteger> createTestSet(int nCount, int bits) {
	   	ArrayList<BigInteger> testSet = new ArrayList<BigInteger>();
	   	for (int i=0; i<nCount;) {
	   		BigInteger testNum = new BigInteger(bits, RNG);
	   		if (testNum.equals(ZERO)) continue;
	   		testSet.add(testNum);
	   		i++;
	   	}
	   	return testSet;
	}
	
	private static void testCorrectness(int nCount) {
		// test conversion
		UnsignedBigInt int31 = new UnsignedBigInt();
		for (BigInteger N=ZERO; N.compareTo(THOUSAND)<=0; N=N.add(ONE)) {
			int31.set(N);
			BigInteger N2 = int31.toBigInteger();
			LOG.debug("N=" + N + ", N2=" + N2);
			assertEquals(N, N2);
		}

		// test division
		UnsignedBigInt quotient = new UnsignedBigInt(new int[32]); // buffer big enough for 1000 bits
		for (int bits = 100; bits<=1000; bits+=100) {
			ArrayList<BigInteger> testSet = createTestSet(nCount, bits);
		   	for (BigInteger testNum : testSet) {
		   		int divisor = Math.max(2, RNG.nextInt(Integer.MAX_VALUE-2));
		   		BigInteger[] referenceResult = testNum.divideAndRemainder(BigInteger.valueOf(divisor));
		   		int remainder = new UnsignedBigInt(testNum).divideAndRemainder(divisor, quotient);
		   		if (!quotient.toBigInteger().equals(referenceResult[0])) {
		   			LOG.error("ERROR: divide(" + testNum + ", " + divisor + "): correct quotient = " + referenceResult[0] + ", my result = " + quotient);
		   		}
		   		if (remainder != referenceResult[1].intValue()) {
		   			LOG.error("ERROR: divide(" + testNum + ", " + divisor + "): correct remainder = " + referenceResult[1] + ", my result = " + remainder);
		   		}
		   	}
		}
		
		// test modulus
		for (int bits = 100; bits<=1000; bits+=100) {
			ArrayList<BigInteger> testSet = createTestSet(nCount, bits);
		   	for (BigInteger testNum : testSet) {
		   		int divisor = Math.max(2, RNG.nextInt(Integer.MAX_VALUE-2));
		   		int correctRemainder = testNum.mod(BigInteger.valueOf(divisor)).intValue();
		   		int remainder = new UnsignedBigInt(testNum).mod(divisor);
		   		if (remainder != correctRemainder) {
		   			LOG.error("ERROR: mod(" + testNum + ", " + divisor + "): correct remainder = " + correctRemainder + ", my result = " + remainder);
		   		}
		   	}
		}
	}

	private static void testPerformance(int nCount) {
		// test division performance
		UnsignedBigInt quotient = new UnsignedBigInt(new int[32]); // buffer big enough for 1000 bits
		int[] divisors = new int[1000];
		BigInteger[] divisors_big = new BigInteger[1000];
		for (int i=0; i<1000; i++) {
	   		divisors[i] = Math.max(2, RNG.nextInt(Integer.MAX_VALUE-2));
	   		divisors_big[i] = BigInteger.valueOf(divisors[i]);
		}
		for (int bits = 100; bits<=1000; bits+=100) {
			ArrayList<BigInteger> testSet = createTestSet(nCount, bits);
			ArrayList<UnsignedBigInt> testSet_UBI = new ArrayList<UnsignedBigInt>();
			for (BigInteger testNum : testSet) {
				testSet_UBI.add(new UnsignedBigInt(testNum));
			}
			LOG.info("test division of " + bits + "-bit numbers:");
		   	long t0 = System.currentTimeMillis();
			for (BigInteger divisor_big : divisors_big) {
			   	for (BigInteger testNum : testSet) {
			   		testNum.divideAndRemainder(divisor_big);
			   	}
			}
		   	long t1 = System.currentTimeMillis();
			LOG.info("   Java's divide() with " + nCount + " numbers took " + (t1-t0) + " ms");
		   	t0 = System.currentTimeMillis();
			for (int divisor : divisors) {
			   	for (UnsignedBigInt testNum : testSet_UBI) {
			   		testNum.divideAndRemainder(divisor, quotient);
			   	}
			}
		   	t1 = System.currentTimeMillis();
			LOG.info("   my divide() with " + nCount + " numbers took " + (t1-t0) + " ms");
		}
	}
	
	/**
	 * Test.
	 * @param args ignored
	 */
	public static void main(String[] args) {
	   	ConfigUtil.initProject();

	   	testCorrectness(1000);
	   	testPerformance(10000);
	}
}
