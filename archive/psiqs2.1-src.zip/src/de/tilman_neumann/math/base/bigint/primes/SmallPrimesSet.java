// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.base.bigint.primes;

import java.math.BigInteger;
import java.util.HashSet;

import de.tilman_neumann.math.base.smallint.SmallPrimesGenerator31;

/**
 * Deterministic small primes test.
 */
public class SmallPrimesSet extends HashSet<Integer> {
	private static final long serialVersionUID = -75335169624758798L;

	public SmallPrimesSet(int max_smallPrime_bits) {
		super();
		int maxSmallPrime = (1<<max_smallPrime_bits) - 1; // the biggest prime that shall be contained in the set
		// hash all primes <= maxSmallPrime
		SmallPrimesGenerator31 primeSeq = new SmallPrimesGenerator31();
		int p;
		do {
			p = primeSeq.nextPrime();
			super.add(p);
		} while(p <= maxSmallPrime);
	}

	public boolean contains(BigInteger N) {
		return super.contains(N.intValue());
	}

	public boolean contains(Long N) {
		return super.contains(N.intValue());
	}

	public boolean contains(Integer N) {
		return super.contains(N);
	}
}
