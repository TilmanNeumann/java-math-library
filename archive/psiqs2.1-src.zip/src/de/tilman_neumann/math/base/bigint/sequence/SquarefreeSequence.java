// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.base.bigint.sequence;

import java.math.BigInteger;

import org.apache.log4j.Logger;

import de.tilman_neumann.math.base.bigint.primes.SmallPrimesGenerator;
import de.tilman_neumann.util.ConfigUtil;

import static de.tilman_neumann.math.base.bigint.BigIntConstants.*;

/**
 * Sequence of multiplier * {squarefree numbers 1,2,3,5,6,7,10,11,13,...}.
 */
public class SquarefreeSequence implements IntegerSequence<BigInteger> {
	private static final Logger LOG = Logger.getLogger(SquarefreeSequence.class);

	private BigInteger multiplier;
	private SmallPrimesGenerator primeBase;
	private BigInteger next;
	
	public SquarefreeSequence(long multiplier) {
		this.multiplier = BigInteger.valueOf(multiplier);
		this.primeBase = new SmallPrimesGenerator();
	}

	public SquarefreeSequence(BigInteger multiplier) {
		this.multiplier = multiplier;
		this.primeBase = new SmallPrimesGenerator();
	}
	
	@Override
	public String getName() {
		return multiplier + "*squarefree";
	}

	public void reset() {
		this.next = ONE;
	}
	
	@Override
	public void reset(BigInteger N) {
		this.next = ONE;
	}

	@Override
	public BigInteger next() {
		BigInteger ret = next;
		// compute next square free number
		while (true) {
			next = next.add(ONE);
			boolean isSquareFree = true;
			// next must not be divisible by any prime square p^2 <= next
			BigInteger pMax = primeBase.getMaxPrime();
			if (pMax.multiply(pMax).compareTo(next)<0) primeBase.expand(); // 1 new prime is sufficient
			BigInteger test = next;
			for (BigInteger p : primeBase.getPrimes()) {
				if (test.compareTo(p.multiply(p))<0) break;
				// test p
				BigInteger[] div = test.divideAndRemainder(p);
				if (div[1].equals(ZERO)) {
					test = div[0];
					BigInteger[] div2 = test.divideAndRemainder(p);
					if (div2[1].equals(ZERO)) {
						// next is not square free !
						isSquareFree = false;
						break;
					}
				}
			}
			if (isSquareFree) break; // found next square-free number
		}
		return ret.multiply(multiplier);
	}
	// standalone test
	public static void main(String[] args) {
	   	ConfigUtil.initProject();
	   	SquarefreeSequence seqGen = new SquarefreeSequence(ONE);
		seqGen.reset(ONE); // >1 required!
		for (int i=1; i<=1000; i++) {
			LOG.info("squarefree(" + i + ") = " + seqGen.next());
		}
	}
}
