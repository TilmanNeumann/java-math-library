// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.base.bigint.primes;

import java.math.BigInteger;

import de.tilman_neumann.math.base.bigint.BigIntConstants;

/**
 * A generator for "nontrivial" possible primes as BigInteger values, starting with 7. (2, 3 and 5 are considered trivial)
 * To exclude sure non-primes, the rests of primes modulo 30 are used.
 */
public class PPGen02 implements PPGen {

	private static BigInteger[] possiblePrimeMods = {BigIntConstants.ONE, BigIntConstants.SEVEN, BigIntConstants.ELEVEN, BigIntConstants.THIRTEEN, BigIntConstants.SEVENTEEN, BigIntConstants.NINETEEN, BigIntConstants.TWENTYTHREE, BigIntConstants.TWENTYNINE};

	private int primeDiffIdx = 0;
	private BigInteger base = BigIntConstants.ZERO;
	
	public BigInteger next() {
		primeDiffIdx++; // the first index is 1, which gives the prime 7
		if (primeDiffIdx == 8) {
			primeDiffIdx = 0;
			base = base.add(BigIntConstants.THIRTY);
		}
		return base.add(possiblePrimeMods[primeDiffIdx]);
	}
}
