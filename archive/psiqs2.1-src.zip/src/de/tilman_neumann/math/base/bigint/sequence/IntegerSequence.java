// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.base.bigint.sequence;

import java.math.BigInteger;

/**
 * Interface for integer sequence generators.
 * 
 * @param T sequence element type
 */
public interface IntegerSequence<T> {
	/** The name of this sequence generator */
	public String getName();
	
	/**
	 * Reset sequence so that it starts again with its first element.
	 * @param N the number to factor
	 */
	public void reset(BigInteger N);
	
	/** Return the next integer */
	public T next();
}
