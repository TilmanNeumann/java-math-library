// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.base.bigint.primes;

import java.math.BigInteger;

/**
 * Interface for generators of possible primes.
 */
public interface PPGen {
	
	/** Returns the next possible prime. */
	BigInteger next();
}
