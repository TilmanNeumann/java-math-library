// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.base.smallint;

/**
 * A generator for "nontrivial" possible primes as long values, starting with 7. (2, 3 and 5 are considered trivial)
 * To exclude sure non-primes, the rests of primes modulo 30 are used.
 * 
 * int version.
 */
public class PPGen31 {

	private static final int[] possiblePrimeMods = {1, 7, 11, 13, 17, 19, 23, 29};

	private int primeDiffIdx = 0;
	private int base = 0;
	
	public int next() {
		primeDiffIdx++; // the first index is 1, which gives the prime 7
		if (primeDiffIdx == 8) {
			primeDiffIdx = 0;
			base += 30;
		}
		return base + possiblePrimeMods[primeDiffIdx];
	}
}
