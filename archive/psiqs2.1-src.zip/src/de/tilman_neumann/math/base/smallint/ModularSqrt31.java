// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.base.smallint;

import java.math.BigInteger;

import org.apache.log4j.Logger;

import de.tilman_neumann.math.base.bigint.JacobiSymbol;
import de.tilman_neumann.math.base.bigint.ModularPower;

import static org.junit.Assert.*;

/**
 * Compute modular sqrts t with t^2 == a (mod p) and u with u^2 == a (mod p^e) using Tonelli-Shanks' algorithm.
 */
// TODO: Test until which p the simple computation is faster
// TODO: Compare Tonelli-Shanks and supposed faster solution for p == 5 (mod 8)
public class ModularSqrt31 {
	private static final Logger LOG = Logger.getLogger(ModularSqrt31.class);
	private static final boolean DEBUG = false;

	private ModularPower mpe = new ModularPower();
	private JacobiSymbol jacobiEngine = new JacobiSymbol();
	
	/**
	 * Tonelli-Shanks implementation for the modular sqrt t with t^2 == a (mod p).
	 * 
	 * @param a
	 * @param p
	 * @return t
	 */
	public int Tonelli_Shanks(int a, int p) {
		if (DEBUG) {
			BigInteger p_big = BigInteger.valueOf(p);
			assertTrue(p%2==1 && p_big.isProbablePrime(20)); // p odd prime
			// Tonelli_Shanks requires Legendre(a|p)==1, 0 is not ok. But this is easy to "heal":
			// Since p is prime, Legendre(a|p)==0 means that a is a multiple of p.
			// Thus a mod p == 0 and the square of this is 0, too.
			// So if the following assert fails, just test a mod p == 0 before calling this method.
			assertTrue(jacobiEngine.jacobiSymbol(a, p)==1);
		}
		int pMod8 = p&7;
		switch (pMod8) {
		case 1: 		
			return Tonelli_Shanks_internal(a, p);
		case 3: case 7: 
			return Lagrange(a, p);
		case 5:			
			return case5Mod8(a, p);
		default:
			LOG.warn("Tonelli_Shanks() has been called with even p=" + p + " -> brute force search required.");
			return bruteForce(a, p);
		}
	}
	
	/**
	 * Tonelli-Shanks algorithm for modular sqrt R^2 == n (mod p),
	 * following <link>en.wikipedia.org/wiki/Tonelli_Shanks_algorithm</link>.
	 * 
	 * This algorithm works for odd primes <code>p</code> and <code>n</code> with <code>Legendre(n|p)=1</code>,
	 * but usually it is applied only to p with p==1 (mod 8), because for p == 3, 5, 7 (mod 8) there are simpler and faster formulas.
	 * 
	 * @param n
	 * @param p
	 * @return
	 */
	private int Tonelli_Shanks_internal(int n, int p) {
		// factor out powers of 2 from p-1, defining Q and S as p-1 = Q*2^S with Q odd.
		int pm1 = p-1;
		int S = Integer.numberOfTrailingZeros(pm1); // lowest set bit (0 if pm1 were odd which is impossible because p is odd)
		if (DEBUG) {
			LOG.debug("n=" + n + ", p=" + p);
			assertEquals(1, jacobiEngine.jacobiSymbol(n, p));
			assertTrue(S > 1); // S=1 is the Lagrange case p == 3 (mod 4), but we check it nonetheless.
		}
		int Q = pm1>>S;
		// find some z with Legendre(z|p)==-1, i.e. z being a quadratic non-residue (mod p)
		int z;
		for (z=2; ; z++) {
			if (jacobiEngine.jacobiSymbol(z, p) == -1) break;
		}
		// now z is found -> set c == z^Q
		int c = mpe.modPow(z, Q, p);
		int R = mpe.modPow(n, (Q+1)>>1, p);
		int t = mpe.modPow(n, Q, p);
		int M = S;
		while (t!=1) { // if t=1 then R is the result
			// find the lowest i, 0<i<M, such that t^2^i == 1 (mod p)
			//LOG.debug("find i < M=" + M + "...");
			boolean foundI = false;
			int i;
			for (i=1; i<M; i++) {
				if (mpe.modPow(t, 1<<i, p)==1) { // t^(2^i)) == 1 (mod p) ?
					foundI = true;
					break;
				}
			}
			if (foundI==false) throw new IllegalStateException("Tonelli-Shanks did not find an 'i' < M=" + M);
			
			int b = mpe.modPow(c, 1<<(M-i-1), p); // c^(2^(M-i-1))
			R = (int) ((R*(long)b) % p);
			c = (int) ((b*(long)b) % p);
			t = (int) ((t*(long)c) % p);
			M = i;
		}
		if (DEBUG) assertEquals(BigInteger.valueOf(R).pow(2).mod(BigInteger.valueOf(p)), BigInteger.valueOf(n%p));
		return R;
	}

	/**
	 * Lagrange's formula for p == 3 (mod 4): t = a^k % p, k = (p+1)/4.
	 * @param a
	 * @param p
	 * @return sqrt of a modulo p
	 */
	private int Lagrange(int a, int p) {
		int modSqrt = mpe.modPow(a, (p+1)>>2, p); // TODO: here k = (p>>2) + 1 is correct as well and faster?
		if (DEBUG) assertEquals(BigInteger.valueOf(modSqrt).pow(2).mod(BigInteger.valueOf(p)), BigInteger.valueOf(a%p));
		return modSqrt;
	}
	
	/**
	 * The simpler formula for case p == 5 (mod 8), following <link>www.point-at-infinity.org/ecc/Algorithm_of_Shanks_&_Tonelli.html</link>.
	 * @param a
	 * @param p
	 * @return
	 */
	private int case5Mod8(int a, int p) {
		int k = p>>3; // for p == 5 (mod 8) we need k = (p-5)/8 = p>>3
		BigInteger a_big = BigInteger.valueOf(a); // TODO: use int
		BigInteger two_a = a_big.shiftLeft(1);
		int g = mpe.modPow(two_a, k, p);
		BigInteger gSquare = BigInteger.valueOf(g*(long)g);
		BigInteger p_big = BigInteger.valueOf(p);
		int i = two_a.multiply(gSquare).mod(p_big).intValue();
		int modSqrt = a_big.multiply(BigInteger.valueOf(g*(long)(i-1))).mod(p_big).intValue();
		if (DEBUG) assertEquals(BigInteger.valueOf(modSqrt).pow(2).mod(p_big), BigInteger.valueOf(a%p));
		return modSqrt;
	}

	/**
	 * Brute force implementation: Test all t from 0 to (p-1)/2.
	 * @param a
	 * @param p
	 * @return 
	 */
	private int bruteForce(int a, int p) {
		//boolean foundT = false;
		int aModP = a%p;
		int t;
		int tMax = (p-1)>>1; // (p-1)/2
		for (t=0; t<=tMax; t++) {
			long tt = t * (long)t;
			int ttModP = (int) (tt % p);
			if (ttModP == aModP) {
				// found t with t^2 == a (mod p)
				//LOG.debug("a=" + a + " == t^2 = " + t + "^2 (mod " + p + ")");
				//foundT = true;
				break;
			}
		}
		//if (!foundT) LOG.error("ERROR: Failed to find t with t^2==" + a + " (mod " + p + ") !");
		if (DEBUG) {
			BigInteger p_big = BigInteger.valueOf(p);
			assertEquals(BigInteger.valueOf(t).pow(2).mod(p_big), BigInteger.valueOf(a%p));
		}
		return t;
	}
	
	/**
	 * General solution of u^2 == a (mod p^exponent), well explained in
	 * [http://mathoverflow.net/questions/52081/is-there-an-efficient-algorithm-for-finding-a-square-root-modulo-a-prime-power, Gottfried Barthel].
	 * Works for any odd p with t^2 == a (mod p) having solution t>0.
	 * Implementation for arguments having int solutions.
	 * 
	 * @param a
	 * @param power p^exponent
	 * @param last_power p^(exponent-1)
	 * @param t solution of t^2 == a (mod p)
	 * 
	 * @return sqrt of a (modulo p^exponent)
	 */
	public int modularSqrtModPower(int a, int power, int last_power, int t) {
		// Barthel's e = (power - 2*last_power + 1)/2
		int f = (power - (last_power<<1) + 1)>>1;
		// square root == a (mod p^exponent)
		return (int) (mpe.modPow(t, last_power, power) * (long)mpe.modPow(a, f, power) % power);
	}
}
