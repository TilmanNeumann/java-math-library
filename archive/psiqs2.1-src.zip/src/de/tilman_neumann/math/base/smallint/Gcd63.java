// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.base.smallint;

import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import org.apache.log4j.Logger;

import de.tilman_neumann.util.ConfigUtil;

import static org.junit.Assert.*;

/**
 * GCD implementations for longs.
 * 
 * The binary gcd is much faster than the Euclidean, and also faster than the built-in BigInteger gcd().
 */
public class Gcd63 {
	private static final Logger LOG = Logger.getLogger(Gcd63.class);

	/**
	 * Greatest common divisor of the given two arguments.
	 * Euclid's algorithm implementation with division.
	 * @param m
	 * @param n
	 * @return
	 */
	// much slower than binary gcd !
	public long gcd_euclid_withDivision(long m, long n) {
		m = Math.abs(m);
		n = Math.abs(n);
		long mCmp1 = m-1;
		long nCmp1 = n-1;
		if (mCmp1>0 && nCmp1>0) {
			// initialize
			long g; // greater argument
			long s; // smaller argument
			if (m>n) {
				g = m;
				s = n;
			} else {
				g = n;
				s = m;
			}
			// iterate
			while (s>0) {
				long dv = g/s;
				long rem = g-dv*s;
				g = s;
				s = rem; // remainder
			}
			return g;
		}
		if (mCmp1<0) return n;
		if (nCmp1<0) return m;
		// else one argument is 1
		return 1;
	}
	
	/**
	 * Binary gcd implementation.
	 * @param m
	 * @param n
	 * @return gcd(m, n)
	 */
	public long gcd/*_binary*/(long m, long n) {
		m = Math.abs(m);
		n = Math.abs(n);
		long mCmp1 = m-1;
		long nCmp1 = n-1;
		if (mCmp1>0 && nCmp1>0) {
			int m_lsb = Long.numberOfTrailingZeros(m);
			int n_lsb = Long.numberOfTrailingZeros(n);
			int shifts = Math.min(m_lsb, n_lsb);
			m = m>>m_lsb;
			n = n>>n_lsb;
			// now m and n are odd
			//LOG.debug("m=" + m + ", n=" + n + ", g=" + g);
			while (m > 0) {
		    	long t = (m-n)>>1;
		        if (t<0) {
		        	n = -t;
		        	n = n>>Long.numberOfTrailingZeros(n);
		        } else {
		        	m = t>>Long.numberOfTrailingZeros(t);
		        }
				//LOG.debug("m=" + m + ", n=" + n);
			}
			long gcd = n<<shifts;
			//LOG.debug("gcd=" + gcd);
			return gcd;
		}
		if (mCmp1<0) return n;
		if (nCmp1<0) return m;
		// else one argument is 1
		return 1;
	}

	/**
	 * GCD of all arguments.
	 * @param arguments
	 * @return
	 */
	public Long gcd(Collection<Long> arguments) {
		if (arguments==null || arguments.size()==0) { 
			return null;
		}

		Iterator<Long> itr = arguments.iterator();
		long ret = itr.next();
		while(itr.hasNext()) {
			ret = gcd(ret, itr.next()); // fastest gcd
		}
		return ret;
	}

	// test ---------------------------------------------------------------------------------------------
	
	private static void testCorrectness(int a) {
		BigInteger aBig = BigInteger.valueOf(a);
		Gcd63 gcdEngine = new Gcd63();
		long gcd;
		for (int b=1; b<a; b++) {
			long correctResult = aBig.gcd(BigInteger.valueOf(b)).longValue();
			gcd = gcdEngine.gcd_euclid_withDivision(a, b);
			assertEquals(correctResult, gcd);
			gcd = gcdEngine.gcd/*_binary*/(a, b);
			assertEquals(correctResult, gcd);
		}
	}
	
	/**
	 * Test gcds of all pairs of elements in a test set with count elements of bits size.
	 * @param count
	 * @param bits
	 */
	private static void testPerformance(int count, int bits) {
		// create test set
		SecureRandom rng = new SecureRandom();
		ArrayList<Long> testSet = new ArrayList<Long>();
		for (int i=0; i<count; i++) {
			testSet.add(new BigInteger(bits, rng).longValue());
		}
		// test BigIntegers gcd
		long gcd;
		long startMillis = System.currentTimeMillis();
		for (long a : testSet) {
			for (long b : testSet) {
				gcd = BigInteger.valueOf(a).gcd(BigInteger.valueOf(b)).longValue();
			}
		}
		long duration = System.currentTimeMillis() - startMillis;
		LOG.info("BigInteger's gcd took " + duration + "ms");
		
		// test Euclidean gcd with division
		Gcd63 gcdEngine = new Gcd63();
		startMillis = System.currentTimeMillis();
		for (long a : testSet) {
			for (long b : testSet) {
				gcd = gcdEngine.gcd_euclid_withDivision(a, b);
			}
		}
		duration = System.currentTimeMillis() - startMillis;
		LOG.info("Euclidean gcd with division took " + duration + "ms");
		
		// test binary gcd
		startMillis = System.currentTimeMillis();
		for (long a : testSet) {
			for (long b : testSet) {
				gcd = gcdEngine.gcd/*_binary*/(a, b);
			}
		}
		duration = System.currentTimeMillis() - startMillis;
		LOG.info("Binary gcd took " + duration + "ms");
	}
	
	public static void main(String[] args) {
		ConfigUtil.initProject();
		testCorrectness(100000);
		testPerformance(1000, 63);
	}
}
