// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor.psiqs;

import java.math.BigInteger;
import java.util.List;

import de.tilman_neumann.math.factor.basics.congruence.AQPair;
import de.tilman_neumann.math.factor.siqs.AParamGenerator;
import de.tilman_neumann.math.factor.siqs.sieve.Sieve;
import de.tilman_neumann.math.factor.siqs.sieve.Sieve03g;
import de.tilman_neumann.math.factor.siqs.tdiv.TDiv_QS;
import de.tilman_neumann.math.factor.siqs.tdiv.TDiv_QS_2Large_UBI;

/**
 * A polynomial generation/sieve/trial division thread for the parallel SIQS implementation (PSIQS).
 */
public class PSIQSThread extends Thread {

	private PSIQSPolyBuilder polyBuilder;
	private Sieve sieve;
	private TDiv_QS auxFactorizer;
	private AQPairBuffer aqPairBuffer;
	private boolean finishNow = false;

	/**
	 * Create a sieve thread.
	 * @param N
	 * @param kN
	 * @param primeBaseSize
	 * @param primesArray
	 * @param tArray
	 * @param sieveArraySize
	 * @param maxRestExp_sieve
	 * @param maxRestExp_tDiv
	 * @param primeTestBits
	 * @param apg
	 * @param aqPairBuffer
	 * @param threadIndex
	 */
	public PSIQSThread(BigInteger N, BigInteger kN, int primeBaseSize, int[] primesArray, int[] tArray, int sieveArraySize, float maxRestExp_sieve,
					   float maxRestExp_tDiv, int primeTestBits, AParamGenerator apg, AQPairBuffer aqPairBuffer, int threadIndex) {
		
		// set thread name
		super("T-" + threadIndex);
		
		// create and initialize sub-algorithms:
		// apg is already initialized and the same object for all threads -> a-parameter generation is synchronized on it
		polyBuilder = new PSIQSPolyBuilder(apg);
		sieve = new Sieve03g(maxRestExp_sieve, 110, 1.4F);
		auxFactorizer = new TDiv_QS_2Large_UBI(primeTestBits, maxRestExp_tDiv);
		// Register sub-engines that shall be accessible to the polynomial generator.
		polyBuilder.setSubEngines(sieve, auxFactorizer);
		// initialize polynomial generator and sub-engines
		polyBuilder.initialize(N, kN, primeBaseSize, primesArray, tArray, sieveArraySize);
		// synchronized buffer to pass AQ-pairs to the main thread -> the same object for all threads
		this.aqPairBuffer = aqPairBuffer;
	}
	
	public void run() {
		while (!finishNow) {
			// create new polynomial Q(x)
			polyBuilder.nextPolynomial();
			
			// run sieve and get the sieve locations x where Q(x) is sufficiently smooth
			List<Integer> smoothXList = sieve.sieve();
			//LOG.debug("Sieve found " + smoothXList.size() + " Q(x) smooth enough to be passed to trial division.");

			// trial division stage: produce AQ-pairs
			List<AQPair> aqPairs = auxFactorizer.testList(smoothXList);
			//LOG.debug("Trial division found " + aqPairs.size() + " Q(x) smooth enough for a congruence.");

			if (aqPairs.size()>0) {
				// add all congruences synchronized and notify control thread
				aqPairBuffer.addAll(aqPairs);
			}
		}
	}
	
	public void setFinishNow() {
		finishNow = true;
	}
}
