// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor.psiqs;

import java.math.BigInteger;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import de.tilman_neumann.math.base.bigint.PurePowerTest;
import de.tilman_neumann.math.base.bigint.UnsignedBigInt;
import de.tilman_neumann.math.base.smallint.ModularSqrt31;
import de.tilman_neumann.math.factor.FactorAlgorithmBase;
import de.tilman_neumann.math.factor.FactorException;
import de.tilman_neumann.math.factor.basics.congruence.AQPair;
import de.tilman_neumann.math.factor.basics.congruence.CongruenceCollector;
import de.tilman_neumann.math.factor.basics.matrixSolver.FactorTest;
import de.tilman_neumann.math.factor.basics.matrixSolver.FactorTest01;
import de.tilman_neumann.math.factor.basics.matrixSolver.MatrixSolver;
import de.tilman_neumann.math.factor.basics.matrixSolver.SmoothSolverController;
import de.tilman_neumann.math.factor.basics.primeBase.PrimeBaseBuilder;
import de.tilman_neumann.math.factor.basics.primeBase.PrimeBaseBuilder02;
import de.tilman_neumann.math.factor.siqs.AParamGenerator;
import de.tilman_neumann.math.factor.siqs.AParamGenerator01;
import de.tilman_neumann.math.factor.siqs.MultiplierFinder;
import de.tilman_neumann.util.TimeUtil;

import static de.tilman_neumann.math.base.bigint.BigIntConstants.*;

/**
 * Multi-threaded SIQS.
 * 
 * This is the fastest factor algorithm in this package; hence it was stripped from all profiling and progress information gathering.
 */
public class PSIQS extends FactorAlgorithmBase {
	private static final Logger LOG = Logger.getLogger(PSIQS.class);
	private static final boolean DEBUG = false;

	private int primeTestBits;
	private int numberOfThreads;
	
	// pure power test
	private PurePowerTest powerTest = new PurePowerTest();

	// Knuth-Schroeppel algorithm
	private MultiplierFinder multiplierFinder = MultiplierFinder.KNUTH_SCHROEPPEL;

	// prime base configuration
	private PrimeBaseBuilder primeBaseBuilder = new PrimeBaseBuilder02();
	private float Cmult;

	// a-param generator configuration
	private Integer wantedQCount; // null -> automatic choice
	private int qCount; // the realized qCount

	// engine to compute the modular sqrt's t with t^2==kN (mod p) for all p
	private ModularSqrt31 modularSqrtEngine = new ModularSqrt31();

	// sieve configuration
	private float Mmult;
	private float maxRestExp_sieve;
	
	// tdiv configuration 
	private float maxRestExp_tDiv;
	
	// collects the congruences we find
	private CongruenceCollector congruenceCollector;
	// extra congruences to have a bigger chance that the equation system solves. the likelihood is >= 1-2^(extraCongruences+1)
	private int extraCongruences;
	// A controller for the solver used for smooth congruence equation systems
	private SmoothSolverController solverController;

	/**
	 * Standard constructor.
	 * @param primeTestBits
	 * @param Cmult multiplier for prime base size
	 * @param Mmult multiplier for sieve array size
	 * @param wantedQCount hypercube dimension (null for automatic selection)
	 * @param maxRestExp_sieve
	 * @param maxRestExp_tDiv
	 * @param numberOfThreads
	 * @param matrixSolver solver for smooth congruences matrix
	 */
	public PSIQS(int primeTestBits, float Cmult, float Mmult, Integer wantedQCount, float maxRestExp_sieve, float maxRestExp_tDiv, int numberOfThreads, MatrixSolver<Integer> matrixSolver) {
		super(primeTestBits);
		this.primeTestBits = primeTestBits;
		this.Cmult = Cmult;
		this.Mmult = Mmult;
		this.wantedQCount = wantedQCount;
		this.maxRestExp_sieve = maxRestExp_sieve;
		this.maxRestExp_tDiv = maxRestExp_tDiv;
		this.numberOfThreads = numberOfThreads;
		this.congruenceCollector = new CongruenceCollector();
		this.extraCongruences = 10;
		this.solverController = new SmoothSolverController(matrixSolver);
	}

	@Override
	public String getName() {
		return "PSIQS(Cmult=" + Cmult + ", Mmult=" + Mmult + ", qCount=" + qCount + ", maxRestExp_sieve=" + maxRestExp_sieve + ", maxRestExp_tDiv=" + maxRestExp_tDiv + ", " + solverController.getName() + ", " + numberOfThreads + " threads)";
	}
	
	/**
	 * Test the current N.
	 * @return factor, or null if no factor was found.
	 */
	public BigInteger findSingleFactor(BigInteger N) {
		long startTime = System.currentTimeMillis();
		// the quadratic sieve does not work for pure powers; check that first:
		PurePowerTest.Result purePower = powerTest.test(N);
		if (purePower!=null) {
			// N is indeed a pure power -> return a factor that is about sqrt(N)
			return purePower.base.pow(purePower.exponent>>1);
		}
		
		// no pure power, run quadratic sieve
		double N_dbl = N.doubleValue();
		// compute prime base size
		double lnN = Math.log(N_dbl);
		double lnlnN = Math.log(lnN);
		double lnNPow = 0.5; // heuristics for quadratic sieve
		double lnTerm = Math.pow(lnN, lnNPow) * Math.pow(lnlnN, 1-lnNPow); // we want that the exponents of lnN and lnlnN sum to 1
		double primeBaseSize_dbl = Math.exp(lnTerm * Cmult);
		if (primeBaseSize_dbl > Integer.MAX_VALUE) throw new IllegalStateException("primeBaseSize=" + primeBaseSize_dbl + " is too big for int!");
		int primeBaseSize = Math.max(10, (int) primeBaseSize_dbl); // min. size for very small N
		int[] primesArray = new int[primeBaseSize];

		// the number of congruences we need to find before we try to solve the smooth congruence equation system:
		// we want: #equations = #variables + some extra congruences
		int requiredSmoothCongruenceCount = primeBaseSize + extraCongruences;

		// compute multiplier k for N using Knuth-Schroeppel
		int k = multiplierFinder.computeMultiplier(N, primeBaseSize);
		BigInteger kN = BigInteger.valueOf(k).multiply(N);
		
		// Create the reduced prime base for kN:
		primeBaseBuilder.computeReducedPrimeBase(kN, primeBaseSize, primesArray);

		// compute sieve array size, a multiple of 256
		int pMax = primesArray[primeBaseSize-1];
		long proposedSieveArraySize = 6144 + (long) Math.exp(lnTerm * Mmult);
		long tooBig = proposedSieveArraySize+pMax - Integer.MAX_VALUE;
		if (tooBig > 0) proposedSieveArraySize -= tooBig;
		int adjustedSieveArraySize = (int) (proposedSieveArraySize & 0x7FFFFF00);
		if (DEBUG) LOG.debug("proposedSieveArraySize = " + (long)proposedSieveArraySize + ", pMax = " + pMax + ", adjusted sieveArraySize = " + adjustedSieveArraySize);

		// compute the modular sqrt's t with t^2 == kN (mod p) for all p
		int[] tArray = computeTArray(kN, primeBaseSize, primesArray);

		// initialize a-param generator
		if (DEBUG) LOG.debug("wantedQCount = " + wantedQCount);
		AParamGenerator apg = new AParamGenerator01(wantedQCount);
		apg.initialize(k, N, kN, primeBaseSize, primesArray, adjustedSieveArraySize);
		qCount = apg.getQCount();
		
		// initialize congruence collector and matrix solver
		FactorTest factorTest = new FactorTest01(N);
		this.congruenceCollector.initialize(N, factorTest, false);
		this.solverController.initialize(N, factorTest);

		// create empty synchronized AQ-pair buffer, used to pass AQ-pairs from "sieve threads" to the main thread
		AQPairBuffer aqPairBuffer = new AQPairBuffer();

		PSIQSThread[] threadArray = new PSIQSThread[numberOfThreads];
		// create and run threads
		for (int threadIndex=0; threadIndex<numberOfThreads; threadIndex++) {
			threadArray[threadIndex] = new PSIQSThread(N, kN, primeBaseSize, primesArray, tArray, adjustedSieveArraySize, maxRestExp_sieve, 
													   maxRestExp_tDiv, primeTestBits, apg, aqPairBuffer, threadIndex);
			threadArray[threadIndex].start();
		}

		try {
			while (true) { // as long as we didn't find a factor
				// wait for new data
				ArrayList<AQPair> newAQPairs;
				synchronized (aqPairBuffer) {
					while (true) {
						try {
							aqPairBuffer.wait(); // is woken up by notify() after new data has been added to the buffer
							//LOG.debug("Control thread got notified about new data");
							break;
						} catch (InterruptedException ie) {
							// ignore
						}
					}
					// get new data (must be synchronized)
					newAQPairs = aqPairBuffer.removeAll();
				}
				//LOG.debug("add " + newAQPairs.size() + " new AQ-pairs to CC");
				// Add new data to the congruenceCollector and eventually run the matrix solver.
				for (AQPair aqPair : newAQPairs) {
					boolean addedSmooth = congruenceCollector.add(aqPair);
					if (addedSmooth && congruenceCollector.getSmoothCongruenceCount() >= requiredSmoothCongruenceCount) {
						// try to solve equation system:
						// It seems to be a good idea to block the other threads while the solver is running...
						//LOG.debug("#smooths = " + congruenceCollector.getSmoothCongruenceCount() + ", #requiredSmooths = " + requiredSmoothCongruenceCount);
						synchronized (aqPairBuffer) {
							solverController.solve(congruenceCollector.getSmoothCongruences()); // throws FactorException
						}
						// no factor exception -> extend equation system and continue searching smooth congruences
						requiredSmoothCongruenceCount += extraCongruences;
					}
				}
			}
		} catch (FactorException fe) {
			// now we have found a factor.
			BigInteger factor = fe.getFactor();
			if (N.bitLength()>=250) {
				// the number is sufficiently big to assume it may be of some interest
				LOG.info(getName() + ": Found factor " + factor + " (" + factor.bitLength() + " bits) of N=" + N + " in " + TimeUtil.timeDiffStr(startTime, System.currentTimeMillis()));
			}
			// kill all threads & release memory
			// the latter improves the accuracy of timings when several algorithms are tested in parallel
			long killStart = System.currentTimeMillis();
			for (int threadIndex=0; threadIndex<numberOfThreads; threadIndex++) {
				killThread(threadArray[threadIndex]);
				threadArray[threadIndex] = null; // dropping the threads releases all data held be them
			}
			if (DEBUG) LOG.debug("Killing threads took " + (System.currentTimeMillis()-killStart) + "ms"); // usually 0-16 ms, no problem
			congruenceCollector.cleanUp();
			solverController.cleanUp();
			// done
			return factor;
		}
	}
	
	/**
	 * For all primes p in the prime base, find the modular sqrt's of kN (mod p), i.e. the t such that t^2 == kN (mod p).
	 */
	private int[] computeTArray(BigInteger kN, int primeBaseSize, int[] primesArray) {
		UnsignedBigInt kN_UBI = new UnsignedBigInt(kN);
		int[] tArray = new int[primeBaseSize]; // zero-initialized
		// special treatment for p[0]=2 (always contained in prime base)
		tArray[0] = kN.and(ONE).intValue();
		// odd primes
		for (int i = primeBaseSize-1; i>0; i--) {
			// Tonelli_Shanks requires Legendre(kN|p)==1, 0 is not ok. But this is easy to "heal":
			// Since p is prime, Legendre(kN|p)==0 means that kN is a multiple of p.
			// Thus t^2 == kN == 0 (mod p) and the modular sqrt t is 0, too.
			int p = primesArray[i];
			int kN_mod_p = kN_UBI.mod(p);
			if (kN_mod_p > 0) {
				tArray[i] = modularSqrtEngine.Tonelli_Shanks(kN_mod_p, p);
			} // else: we do not need to set tArray[i] = 0, because the array has already been initialized with zeros
		}
		return tArray;
	}

	private void killThread(PSIQSThread t) {
    	while (t.isAlive()) {
    		if (DEBUG) LOG.debug("request to kill thread " + t.getName() + " ...");
    		// Thread.interrupt() is unsafe, it may block the program when the thread is just aquiring a lock
    		// It is safer to set a flag and let the thread check it outside any locks.
			t.setFinishNow();
			if (DEBUG) {
				StackTraceElement[] stackTrace = t.getStackTrace();
				if (stackTrace.length>0) {
	    			LOG.debug("thread " + t.getName() + " is in");
					for (StackTraceElement elem : stackTrace) LOG.debug(elem.toString());
				} else {
	    			LOG.debug("thread " + t.getName() + " has empty stack trace");
				}
			}
    		try {
    			t.join();
    			if (DEBUG) LOG.debug("thread " + t.getName() + " joined");
    		} catch (InterruptedException e) {
    			if (DEBUG) LOG.debug("thread " + t.getName() + " interrupted main thread");
    		}
    		if (DEBUG) LOG.debug("thread " + t.getName() + " has been killed.");
    	}
	}
}
