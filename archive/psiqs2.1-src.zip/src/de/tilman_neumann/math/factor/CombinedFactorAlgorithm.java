// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigInteger;
import java.util.StringTokenizer;

import org.apache.log4j.Logger;

import de.tilman_neumann.math.factor.basics.matrixSolver.MatrixSolver01_Gauss;
import de.tilman_neumann.math.factor.basics.matrixSolver.MatrixSolver02_BlockLanczos;
import de.tilman_neumann.math.factor.psiqs.PSIQS;
import de.tilman_neumann.math.factor.siqs.SIQS;
import de.tilman_neumann.math.factor.siqs.SIQSPolyBuilder01;
import de.tilman_neumann.math.factor.siqs.sieve.Sieve03f;
import de.tilman_neumann.math.factor.siqs.tdiv.TDiv_QS_1Large_UBI;
import de.tilman_neumann.math.factor.squfof.SquFoF31;
import de.tilman_neumann.math.factor.squfof.SquFoF63;
import de.tilman_neumann.math.factor.tdiv.TDiv31Preload;
import de.tilman_neumann.types.SortedMultiset;
import de.tilman_neumann.util.ConfigUtil;
import de.tilman_neumann.util.TimeUtil;

import static de.tilman_neumann.math.base.bigint.BigIntConstants.*;

/**
 * Final combination of factor algorithms.
 */
public class CombinedFactorAlgorithm extends FactorAlgorithmBase {
	@SuppressWarnings("unused")
	private static final Logger LOG = Logger.getLogger(CombinedFactorAlgorithm.class);

	private static final String JAR_FILE = "psiqs02.01.jar";
	
	private TDiv31Preload tDiv31;
	private SquFoF31 squFoF31;
	private SquFoF63 squFoF63;
	private SIQS siqs_smallArgs;
	private PSIQS siqs_bigArgs;
	
	/**
	 * Complete constructor.
	 * 
	 * @param primeTestBits log of probability of predicting false primes
	 * @param numberOfThreads the number of parallel threads for PSIQS
	 */
	// TODO: timeout parameter?
	public CombinedFactorAlgorithm(int primeTestBits, int numberOfThreads) {
		super(primeTestBits);
		tDiv31 = new TDiv31Preload(primeTestBits);
		squFoF31 = new SquFoF31(primeTestBits);
		squFoF63 = new SquFoF63(primeTestBits);
		// SIQS tuned for small N
		siqs_smallArgs = new SIQS(primeTestBits, 0.32F, 0.42F, new SIQSPolyBuilder01(), new Sieve03f(0.16F, 110, 1.4F), new TDiv_QS_1Large_UBI(primeTestBits, 0.18F), 10, new MatrixSolver01_Gauss<Integer>(), false);
		// PSIQS for N > 115 bit
		siqs_bigArgs = new PSIQS(primeTestBits, 0.32F, 0.37F, null, 0.167F, 0.18F, numberOfThreads, new MatrixSolver02_BlockLanczos<Integer>());
	}

	@Override
	public String getName() {
		return "combi";
	}

	@Override
	public BigInteger findSingleFactor(BigInteger N) {
		int N_bits = N.bitLength();
		if (N_bits <= 27) return tDiv31.findSingleFactor(N);
		if (N_bits <= 42) return squFoF31.findSingleFactor(N);
		if (N_bits <= 67) return squFoF63.findSingleFactor(N);
		if (N_bits <= 115) return siqs_smallArgs.findSingleFactor(N);
		return siqs_bigArgs.findSingleFactor(N);
	}
	
	/**
	 * Run with command-line arguments or console input (if no command-line arguments are given).
	 * Usage for executable jar file:
	 * java -jar <jar_file> [[-t <numberOfThreads>] <numberToFactor>]
	 * 
	 * @param args [-t <numberOfThreads>] <numberToFactor>
	 */
	public static void main(String[] args) {
		ConfigUtil.verbose = false;
    	ConfigUtil.initProject();
    	
    	try {
	    	if (args.length==0) {
	    		// test standard input in a loop
	    		testInput();
	    	}
	    	
	    	// otherwise we have commandline arguments -> parse them
	    	testArgs(args);
    	} catch (Exception ite) {
    		// when the jar is shut down with Ctrl-C, an InvocationTargetException is thrown (log4j?).
    		// just suppress it and exit
    		System.exit(0);
    	}
	}
	
	private static int testInput() {
		while(true) {
			int numberOfThreads = 1;
			BigInteger N;
			String line = null;
			try {
				System.out.println("Please insert [-t <numberOfThreads>] <numberToFactor> :");
				BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
				line = in.readLine();
				String input = line.trim();
				if (input.startsWith("-t")) {
					input = input.substring(2).trim();
					StringTokenizer parser = new StringTokenizer(input);
					numberOfThreads = Integer.parseInt(parser.nextToken().trim());
					N = new BigInteger(parser.nextToken().trim());
				} else {
					N = new BigInteger(input);
				}
			} catch (IOException ioe) {
				System.err.println("IO-error occuring on input: " + ioe.getMessage());
				continue;
			} catch (NumberFormatException nfe) {
				System.err.println("Illegal input: " + line);
				continue;
			}
			test(numberOfThreads, N);
		} // next input...
	}

	private static void testArgs(String[] args) {
    	int numberOfThreads = 1;
    	BigInteger N = null;
    	if (args.length==1) {
    		try {
    			N = new BigInteger(args[0].trim());
    		} catch (NumberFormatException nfe) {
    			System.err.println("Invalid numberToFactor = " + args[0].trim());
    			System.exit(-1);
    		}
    	} else if (args.length==3) {
    		if (!args[0].trim().equals("-t")) {
    			System.err.println("Illegal option: '" + args[0] + "'. Usage: java -jar " + JAR_FILE + " [-t <numberOfThreads>] <numberToFactor>");
    			System.exit(-1);
    		}
    		try {
    			numberOfThreads = Integer.parseInt(args[1].trim());
    		} catch (NumberFormatException nfe) {
    			System.err.println("Invalid numberOfThreads = " + args[1].trim());
    			System.exit(-1);
    		}
    		try {
    			N = new BigInteger(args[2].trim());
    		} catch (NumberFormatException nfe) {
    			System.err.println("Invalid numberToFactor = " + args[2].trim());
    			System.exit(-1);
    		}
    	} else {
			System.err.println("Illegal number of arguments. Usage: java -jar " + JAR_FILE + " [-t <numberOfThreads>] <numberToFactor>");
			System.exit(-1);
    	}
    	// run
    	int exitCode = test(numberOfThreads, N);
		System.exit(exitCode);
	}
	
	private static int test(int numberOfThreads, BigInteger N) {
		if (numberOfThreads < 0) {
			System.err.println("numberOfThreads must be positive.");
			return -1;
		}
		if (numberOfThreads > ConfigUtil.NUMBER_OF_PROCESSORS) {
			System.err.println("Too big numberOfThreads = " + numberOfThreads + ": Your machine has only " + ConfigUtil.NUMBER_OF_PROCESSORS + " processors");
			return -1;
		}
    	
    	// size check
    	//LOG.debug("N = " + N);
		int N_bits = N.bitLength();
    	if (N.bitLength()>400) {
			System.err.println("Too big numberToFactor: Currently only inputs <= 400 bits are supported. (Everything else would take months or years)");
			return -1;
    	}
    	// run
    	long t0 = System.currentTimeMillis();
    	CombinedFactorAlgorithm factorizer = new CombinedFactorAlgorithm(20, numberOfThreads);
    	SortedMultiset<BigInteger> result = factorizer.factor(N);
		long duration = System.currentTimeMillis()-t0;
		String durationStr = TimeUtil.timeStr(duration);
		if (result.totalCount()==1) {
			BigInteger singleElement = result.keySet().iterator().next();
			if (singleElement.abs().compareTo(ONE)<=0) {
				System.out.println(N + " is trivial");
			} else {
				System.out.println(N + " is probable prime");
			}
		} else if (result.totalCount()==2 && result.keySet().contains(MINUS_ONE)) {
			System.out.println(N + " is probable prime");
		} else {
			System.out.println(N + " (" + N_bits + " bits) = " + factorizer.getPrettyFactorString(result) + " (factored in " + durationStr + ")");
		}
		return 0;
	}
}
