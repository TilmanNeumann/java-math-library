// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor.cfrac.tdiv;

import static org.junit.Assert.assertTrue;

import java.math.BigInteger;

import org.apache.log4j.Logger;

import de.tilman_neumann.math.base.bigint.primes.ProbablePrimeTest;
import de.tilman_neumann.math.base.bigint.primes.SmallPrimesSet;
import de.tilman_neumann.math.factor.basics.BinarySearch;
import de.tilman_neumann.math.factor.basics.SortedIntegerArray;
import de.tilman_neumann.math.factor.basics.SortedLongArray;
import de.tilman_neumann.math.factor.basics.congruence.AQPair;
import de.tilman_neumann.math.factor.basics.congruence.AQPairFactory;
import de.tilman_neumann.math.factor.basics.congruence.Smooth_Perfect;
import de.tilman_neumann.math.factor.basics.primeBase.PrimeBaseBuilder;
import de.tilman_neumann.math.factor.basics.primeBase.PrimeBaseBuilder02;
import de.tilman_neumann.math.factor.basics.primeBase.Primes;
import de.tilman_neumann.math.factor.squfof.SquFoF31;
import de.tilman_neumann.math.factor.squfof.SquFoF63;

/**
 * Auxiliary factor algorithm to find smooth decompositions of Q's.
 * 
 * Version 03:
 * Uses trial division first, complete factorization if Q is considered sufficiently smooth.
 * Use a _simple_ level2 prime base at end of factor recurrence.
 */
public class TDiv_CF63_03 implements TDiv_CF63 {
	private static final Logger LOG = Logger.getLogger(TDiv_CF63_03.class);
	private static final boolean DEBUG = false;

	private PrimeBaseBuilder primeBaseBuilder = new PrimeBaseBuilder02();
	private int primeBaseSize;
	private int[] primesArray;
	private int pMax;
	private long pMaxSquare;

	/** Q is sufficiently smooth if the unfactored Q_rest is smaller than this bound depending on N */
	private double maxSufficientSmoothRest;
	
	private int max_tDiv_bits;
	
	private int[] level2PrimesArray;
	private int level2PrimesArraySize;
	private int level2PrimeBaseMaxIndex;
	private int level2PrimeBaseStartIndex;
	private int level2TDivIndex;

	private SquFoF31 squFoF31; // used for 2^max_tDiv_bits < Q <= 2^42
	private SquFoF63 squFoF63; // used for 2^43 <= Q <= 2^77
	
	private BinarySearch binarySearch = new BinarySearch();

	private ProbablePrimeTest probablePrimeTest;
	private SmallPrimesSet smallPrimesSet;
	private int max_smallPrimes_bits;

	// result: two arrays that are reused, their content is _copied_ to AQ-pairs
	private SortedIntegerArray smallFactors = new SortedIntegerArray();
	private SortedLongArray bigFactors = new SortedLongArray();
	private AQPairFactory aqPairFactory = new AQPairFactory();

	public TDiv_CF63_03(int primeTestBits, int max_tDiv_bits) {
		this.probablePrimeTest = new ProbablePrimeTest(primeTestBits);
		this.squFoF31 = new SquFoF31(primeTestBits);
		this.squFoF63 = new SquFoF63(primeTestBits);
		this.max_smallPrimes_bits = 20; // TODO: pass in constructor
		this.smallPrimesSet = new SmallPrimesSet(max_smallPrimes_bits);
		this.max_tDiv_bits = max_tDiv_bits;
		// simple second-level prime base
		double max_tDiv_Q = (1L<<max_tDiv_bits) - 1; // the biggest Q for which trial division shall be applied
		int level2MaxPrimeBound = (int) Math.sqrt(max_tDiv_Q)+1; // the biggest prime in the level2 prime base required to factor any Q <= max_tDiv_Q
		Primes primes = primeBaseBuilder.getPrimesBelow(level2MaxPrimeBound);
		this.level2PrimesArray = primes.array;
		this.level2PrimesArraySize = primes.count;
		this.level2PrimeBaseMaxIndex = binarySearch.getFirstGreaterEntryIndex(level2PrimesArray, level2PrimesArraySize, level2MaxPrimeBound);
		if (DEBUG) assertTrue(level2PrimeBaseMaxIndex >= 0);
	}

	@Override
	public String getName() {
		return "TDiv63-03(" + max_tDiv_bits + ")";
	}

	public void initialize(BigInteger N, double maxSufficientSmoothRest) {
		this.maxSufficientSmoothRest = maxSufficientSmoothRest;
	}

	public void initialize(BigInteger kN, int primeBaseSize, int[] primesArray) {
		this.primeBaseSize = primeBaseSize;
		this.primesArray = primesArray;
		this.pMax = primesArray[primeBaseSize-1];
		this.pMaxSquare = pMax * (long) pMax;
		// set start index for level 2 prime base
		this.level2PrimeBaseStartIndex = binarySearch.getFirstGreaterEntryIndex(level2PrimesArray, level2PrimesArraySize, pMax);
	}

	public AQPair test(BigInteger A, long Q) {
		smallFactors.reset();
		bigFactors.reset();
		
		// sign
		long Q_rest = Q;
		if (Q < 0) {
			smallFactors.add(-1);
			Q_rest = -Q;
		}
		// Remove multiples of 2
		while (Q_rest%2==0) {
			smallFactors.add(2);
			Q_rest = Q_rest>>1;
		}

		// Trial division chain:
		// -> first do it in long, then in int.
		// -> (small or probabilistic) prime tests during trial division just slow it down.
		// -> running indices bottom-up is faster because small dividends are more likely to reduce the size of Q_rest.
		int trialDivIndex = 1; // p[0]=2 has already been tested
		int Q_rest_bits = 64 - Long.numberOfLeadingZeros(Q_rest);
		if (Q_rest_bits>31) {
			// do trial division in long
			while (trialDivIndex < primeBaseSize) {
				int p = primesArray[trialDivIndex];
				if (Q_rest % p == 0) {
					// no remainder -> exact division -> small factor
					smallFactors.add(p);
					Q_rest /= p;
					// After division by a prime base element (typically < 20 bit), Q_rest is 12..61 bits.
					Q_rest_bits = 64 - Long.numberOfLeadingZeros(Q_rest);
					if (Q_rest_bits<32) break; // continue with int
					// trialDivIndex must remain as it is to find the same p more than once
				} else {
					trialDivIndex++;
				}
			} // end while (trialDivIndex < primeBaseSize)
		}
		if (DEBUG) assertTrue(Q_rest>1);
		if (Q_rest_bits<32) {
			int Q_rest_int = (int) Q_rest;
			while (trialDivIndex < primeBaseSize) {
				// continue trial division in int
				int p = primesArray[trialDivIndex];
				while (Q_rest_int % p == 0) { // in the last loop, a while pays out!
					// no remainder -> exact division -> small factor
					smallFactors.add(p);
					Q_rest_int /= p;
				}
				trialDivIndex++;
			} // end while (trialDivIndex < primeBaseSize)
			if (Q_rest_int==1) return new Smooth_Perfect(A, smallFactors);
			Q_rest = (long) Q_rest_int; // keep Q_rest up-to-date
		}

		// trial division was not sufficient to factor Q completely.
		// the remaining Q is either a prime > pMax, or a composite > pMax^2.
		if (Q_rest > maxSufficientSmoothRest) return null; // Q is not sufficiently smooth
		
		// now we consider Q as sufficiently smooth. then we want to know all prime factors!
		//LOG.debug("before factor_recurrent()");
		factor_recurrent(Q_rest);
		if (DEBUG) if (bigFactors.size()>1) LOG.debug("Found " + bigFactors.size() + " distinct big factors: " + bigFactors);
		return aqPairFactory.create(A, smallFactors, bigFactors);
	}

	private void factor_recurrent(long Q_rest) {
		if (Q_rest < pMaxSquare) {
			// we divided Q_rest by all primes <= pMax and the rest is < pMax^2 -> it must be prime
			if (DEBUG) assertTrue(probablePrimeTest.isProbablePrime(Q_rest));
			bigFactors.add(Q_rest);
			return;
		}
		// here we can not do without isProbablePrime(), because calling findSingleFactor() may not return when called with a prime argument
		int Q_rest_bits = 64 - Long.numberOfLeadingZeros(Q_rest);
		if ((Q_rest_bits<=max_smallPrimes_bits && smallPrimesSet.contains(Q_rest)) || probablePrimeTest.isProbablePrime(Q_rest)) {
			// Q_rest is (probable) prime -> end of recurrence
			bigFactors.add(Q_rest);
			return;
		} // else: Q_rest is surely not prime

		// Q_rest is pMax < Q_rest <= maxSufficientSmoothRest, composite and odd.
		if (Q_rest_bits <= max_tDiv_bits) {
			// Q_rest can surely be factored with the second level prime base -> end of recurrence
			finalTDiv(Q_rest, Q_rest_bits);
			return;
		}
		
		// the expensive part: find a factor of Q_rest, where Q_rest is composite and odd
		long factor1;
		if (Q_rest_bits < 43) {
			factor1 = squFoF31.findSingleFactor(Q_rest);
		} else { // max Q_rest_bits is 63
			factor1 = squFoF63.findSingleFactor(Q_rest);
		}
		// Recurrence: Is it possible to further decompose the parts?
		factor_recurrent(factor1);
		factor_recurrent(Q_rest/factor1);
		return;
	}

	private void finalTDiv(long Q_rest, int Q_rest_bits) {
		this.level2TDivIndex = level2PrimeBaseStartIndex;
		if (Q_rest_bits < 32) {
			finalTDiv_int( (int) Q_rest);
			return;
		}
		while (level2TDivIndex < level2PrimeBaseMaxIndex) {
			int p = level2PrimesArray[level2TDivIndex];
			if (Q_rest % p == 0) {
				// no remainder, exact division!
				bigFactors.add(p);
				Q_rest /= p;
				// quick return possible? (in final tDiv this is a big speed-up)
				Q_rest_bits = 64 - Long.numberOfLeadingZeros(Q_rest);
				if (Q_rest_bits<=max_smallPrimes_bits && smallPrimesSet.contains(Q_rest)) {
					bigFactors.add(Q_rest);
					return;
				}
				if (Q_rest_bits < 32) {
					finalTDiv_int( (int) Q_rest);
					return;
				}
				// level2TDivIndex must remain as it is to find primes with exponent > 1, too
			} else {
				level2TDivIndex++;
			}
		} // end while (level2TDivIndex < level2PrimeBaseSize)
		throw new IllegalStateException("Q_rest = " + Q_rest + " has not been factored completely! Q_rest = " + Q_rest);
	}

	private void finalTDiv_int(int Q_rest) {
		while (level2TDivIndex < level2PrimeBaseMaxIndex) {
			int p = level2PrimesArray[level2TDivIndex];
			if (Q_rest % p == 0) {
				// no remainder, exact division!
				bigFactors.add(p);
				Q_rest /= p;
				// quick return possible? (in final tDiv this is a big speed-up)
				if (Q_rest==1) return;
				if (smallPrimesSet.contains(Q_rest)) {
					bigFactors.add(Q_rest);
					return;
				}
				// level2TDivIndex must remain as it is to find primes with exponent > 1, too
			} else {
				level2TDivIndex++;
			}
		} // end while (level2TDivIndex < level2PrimeBaseSize)
		throw new IllegalStateException("Q_rest = " + Q_rest + " has not been factored completely! Q_rest = " + Q_rest);
	}
}
