// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor.cfrac.tdiv;

import java.math.BigInteger;

import de.tilman_neumann.math.factor.FactorException;
import de.tilman_neumann.math.factor.basics.congruence.AQPair;

/**
 * Interface for auxiliary factor algorithms to find smooth decompositions of Q's.
 */
public interface TDiv_CF63 {
	
	/**
	 * @return the name of this algorithm
	 */
	public String getName();

	/**
	 * Initialize for a new N.
	 * @param N
	 * @param maxSufficientSmoothRest
	 */
	public void initialize(BigInteger N, double maxSufficientSmoothRest);

	/**
	 * Initialize this factorizer for a new k; in particular set the prime base to be used for trial division.
	 * @param kN
	 * @param primeBaseSize the true prime base size (the arrays are preallocated with a bigger length)
	 * @param primesArray prime base in ints
	 * @throws FactorException 
	 */
	public void initialize(BigInteger kN, int primeBaseSize, int[] primesArray) throws FactorException;
	
	/**
	 * Check if Q is smooth (factors completely over the prime base) or "sufficiently smooth" (factors almost over the prime base).
	 *
	 * @param A
	 * @param Q
	 * @return an AQ-pair if Q is at least "sufficiently smooth", null else
	 */
	public AQPair test(BigInteger A, long Q);
}
