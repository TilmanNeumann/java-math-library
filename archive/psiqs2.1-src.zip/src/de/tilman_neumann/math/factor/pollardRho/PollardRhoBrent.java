// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor.pollardRho;

import java.math.BigInteger;
import java.security.SecureRandom;

import org.apache.log4j.Logger;

import de.tilman_neumann.math.factor.FactorAlgorithmBase;

import static de.tilman_neumann.math.base.bigint.BigIntConstants.*;

/**
 * Brents's improvement of Pollard's Rho algorithm, following [Richard P. Brent: An improved Monte Carlo Factorization Algorithm, 1980].
 */
// TODO: [http://projecteuler.chat/viewtopic.php?t=3776], [http://coliru.stacked-crooked.com/a/f57f11426d06acd8]:
// Montgomery multiplication suits well, could give factor 4 improvement
public class PollardRhoBrent extends FactorAlgorithmBase {
	@SuppressWarnings("unused")
	private static final Logger LOG = Logger.getLogger(PollardRhoBrent.class);
	private static final SecureRandom RNG = new SecureRandom();

	private BigInteger N;
	
	/**
	 * Complete constructor.
	 * 
	 * @param primeTestBits log of probability of predicting false primes
	 */
	public PollardRhoBrent(int primeTestBits) {
		super(primeTestBits);
	}

	@Override
	public String getName() {
		return "PollardRhoBrent";
	}
	
	@Override
	public BigInteger findSingleFactor(BigInteger N) {
		this.N = N;
		int bitLength = N.bitLength();
        BigInteger G, x, ys;
        do {
	        // start with random x0, c from [0, N-1]
        	BigInteger c = new BigInteger(bitLength, RNG);
            if (c.compareTo(N)>=0) c = c.subtract(N);
            BigInteger x0 = new BigInteger(bitLength, RNG);
            if (x0.compareTo(N)>=0) x0 = x0.subtract(N);
            BigInteger y = x0;

            // Brent: "The probability of the algorithm failing because q_i=0 increases, so it is best not to choose m too large"
        	final int m = 100;
        	int r = 1;
        	BigInteger q = ONE;
        	do {
	    	    x = y;
	    	    for (int i=1; i<=r; i++) {
	    	        y = addModN(y.multiply(y).mod(N), c);
	    	    }
	    	    int k = 0;
	    	    do {
	    	        ys = y;
	    	        final int iMax = Math.min(m, r-k);
	    	        for (int i=1; i<=iMax; i++) {
	    	            y = addModN(y.multiply(y).mod(N), c);
	    	            q = x.subtract(y).abs().multiply(q).mod(N);
	    	        }
	    	        G = q.gcd(N);
	    	        // if q==0 then G==N -> the loop will be left and restarted with new x0, c
	    	        k += m;
		    	    //LOG.info("r = " + r + ", k = " + k);
	    	    } while (k<r && G.equals(ONE));
	    	    r <<= 1;
	    	    //LOG.info("r = " + r + ", G = " + G);
	    	} while (G.equals(ONE));
	    	if (G.equals(N)) {
	    	    do {
	    	        ys = addModN(ys.multiply(ys).mod(N), c);
	    	        G = x.subtract(ys).abs().gcd(N);
	    	    } while (G.equals(ONE));
	    	    //LOG.info("G = " + G);
	    	}
        } while (G.equals(N));
		//LOG.debug("Found factor of " + N + " = " + factor);
        return G;
	}

	/**
	 * Addition modulo N, with <code>a, b < N</code>.
	 * @param a
	 * @param b
	 * @return (a+b) mod N
	 */
	private BigInteger addModN(BigInteger a, BigInteger b) {
		BigInteger sum = a.add(b);
		return sum.compareTo(N)<0 ? sum : sum.subtract(N);
	}
}
