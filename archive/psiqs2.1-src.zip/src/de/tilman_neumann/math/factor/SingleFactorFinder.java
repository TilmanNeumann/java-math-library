// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor;

import java.math.BigInteger;

/**
 * Interface for factor algorithms that also expose a method to find a single factor only.
 */
public interface SingleFactorFinder extends FactorAlgorithm {
	
	/**
	 * Find a single factor of the given N, which is composite and odd.
	 * @param N
	 * @return factor
	 */
	public BigInteger findSingleFactor(BigInteger N);
}
