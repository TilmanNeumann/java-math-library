// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor;

import java.math.BigInteger;

import de.tilman_neumann.types.SortedMultiset;

/**
 * Interface for factoring algorithms that deliver a full prime factorization.
 */
public interface FactorAlgorithm {
	
	/** The best available single-threaded factor algorithm. (multi-threading may not always be wanted) */
	public static FactorAlgorithm DEFAULT = new CombinedFactorAlgorithm(20, 1);

	/**
	 * Decomposes the argument N into prime factors.
	 * The result is formally a multiset of BigIntegers, sorted bottom-up.
	 * @param N Number to factor.
	 * @return factors
	 */
	public SortedMultiset<BigInteger> factor(BigInteger N);
	
	public String getName();
}
