// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

import org.apache.log4j.Logger;

import de.tilman_neumann.math.factor.basics.congruence.*;
import de.tilman_neumann.math.factor.basics.matrixSolver.*;
import de.tilman_neumann.math.factor.cfrac.*;
import de.tilman_neumann.math.factor.cfrac.tdiv.*;
import de.tilman_neumann.math.factor.pollardRho.*;
import de.tilman_neumann.math.factor.psiqs.*;
import de.tilman_neumann.math.factor.siqs.*;
import de.tilman_neumann.math.factor.siqs.sieve.*;
import de.tilman_neumann.math.factor.siqs.tdiv.*;
import de.tilman_neumann.math.factor.squfof.*;
import de.tilman_neumann.math.factor.tdiv.*;
import de.tilman_neumann.math.factor.psiqs.PSIQS;
import de.tilman_neumann.math.base.bigint.sequence.*;
import de.tilman_neumann.util.ConfigUtil;
import de.tilman_neumann.util.TimeUtil;

import static de.tilman_neumann.math.base.bigint.BigIntConstants.*;

/**
 * Main class to compare the performance of factor algorithms.
 */
public class FactorizerTest {
	private static final Logger LOG = Logger.getLogger(FactorizerTest.class);

	// algorithm options
	/** number of test numbers */
	private static final int N_COUNT = 1;
	/** the bit size of N to start with */
	private static final int START_BITS = 70;
	/** the increment in bit size from test set to test set */
	private static final int INCR_BITS = 10;
	/** maximum number of bits to test (no maximum if null) */
	private static final Integer MAX_BITS = null;
	/** each algorithm is run REPEATS times for each input in order to reduce GC influence on timings */
	private static final int REPEATS = 1;

	/** 
	 * Algorithms to compare. Non-static to permit to use Loggers in the algorithm constructors.
	 */
	private SingleFactorFinder[] algorithms;
	
	public FactorizerTest() {
		algorithms = new SingleFactorFinder[] {

			// Trial division:
			// * TDiv31Preload is the best algorithm overall for N <= 2^27
			// * TDiv_PPGen2 is the best BigInteger version
//			new TDiv_PPGen2(20),
//			new TDiv63(20),
//			new TDiv31(20),
//			new TDiv31Preload(20),

			// PollardRho:
			// * never the best algorithm
			// * Best BigInteger version is PollardRhoBrent
			//new PollardRho(20),
			//new PollardRho_ProductGcd(20),
//			new PollardRhoBrent(20),
			//new PollardRho31(20),

			// SquFoF variants
			// * SquFoF31 is the best algorithm overall for N = 2^28...2^42, SquFoF63 for N = 2^43...2^67
			// * SquFoF01_maxI is the best BigInteger version
			// * best multiplier sequence = 1680 * {squarefree sequence}
			// * best stopping criterion = O(5.th root(N))
//			new SquFoF01_maxI(20, new SquarefreeSequence(1), 4, 5.65685425F), // standard configuration, with stopping criterion from [Gower/Wagstaff]
//			new SquFoF01_maxI(20, new SquarefreeSequence(1680), 4, 5.65685425F), // better multiplier
//			new SquFoF01_maxI(20, new SquarefreeSequence(1), 5, 1), // better stopping criterion
//			new SquFoF01_maxI(20, new SquarefreeSequence(1680), 5, 1), // best configuration
//			new SquFoF03_maxI(20, new SquarefreeSequence(1680), 5, 1), // with queue
//			new SquFoF(20),
//			new SquFoF63_02(20, 1, 4, 5.65685425F),
//			new SquFoF63_02(20, 1680, 4, 5.65685425F),
//			new SquFoF63_02(20, 1, 5, 1.5F),
//			new SquFoF63_02(20, 1680, 5, 1.5F),
//			new SquFoF63_02(20, ExplicitMultipliers.GW, 4, 5.65685425F),
//			new SquFoF63_02(20, ExplicitMultipliers.EVEN_AND_GW, 4, 5.65685425F),
//			new SquFoF63_02(20, ExplicitMultipliers.GW, 5, 1.5F),
//			new SquFoF63_02(20, ExplicitMultipliers.EVEN_AND_GW, 5, 1.5F),
//			new SquFoF63(20), // best algorithm for N = 2^43...2^67 (freezes at some N > 2^90)
//			new SquFoF31(20), // best algorithm for N = 2^28...2^42 (freezes at bigger arguments)
			
			// CFrac
			// * never the best algorithm: SquFoF63 is better for N <= 70 bit, SIQS is better for N >= 65 bits
			// * the best multiplier is 1 here
			// * stopRoot, stopMult: if big enough, then a second k is rarely needed; (5, 1.5) is good
			// * TDiv_CF01, cc01 is best for N < 80 bits
//			/* very small N */ new CFrac(20, new SquarefreeSequence(1), true, 5, 2, 0.294F, 0.215F, new TDiv_CF01(20), 10, new MatrixSolver01_Gauss<Integer>()),
//			/* small N */ new CFrac(20, new SquarefreeSequence(1), true, 5, 1.5F, 0.294F, 0.215F, new TDiv_CF01(20), 10, new MatrixSolver01_Gauss<Integer>()),
//			/* big N */ new CFrac(20, new SquarefreeSequence(1), true, 5, 1.5F, 0.255F, 0.253F, new TDiv_CF03(20, 28), 10, new MatrixSolver01_Gauss<Integer>()),
//			new CFrac63(20, new SquarefreeSequence(1), true, 5, 1.5F, 0.275F, 0.22F, new TDiv_CF63_01(20), 10, new MatrixSolver01_Gauss<Integer>()),
//			new CFrac63(20, new SquarefreeSequence(1), true, 5, 1.5F, 0.25F, 0.25F, new TDiv_CF63_03(20, 28), 10, new MatrixSolver01_Gauss<Integer>()),
	
			// SIQS:
			// * TDiv: UBI-variants are better than BigInteger-variants; nLarge is better than 1Large for N >= 200 bit
			// * sieve: T > 0.18 gives a heavy work load for TDiv
			// * sieve: InitializerCalculator.SMALL is best
			// * BlockLanczos is better than Gauss for about N>200 bit
//			new SIQS(20, 0.32F, 0.37F, new SIQSPolyBuilder01(), new Sieve03f(0.16F, 110, 1.4F), new TDiv_QS_nLarge_UBI(20, 0.18F), 10, new MatrixSolver02_BlockLanczos<Integer>(), true),
//			new SIQS(20, 0.32F, 0.37F, new SIQSPolyBuilder01(), new Sieve03g(0.16F, 110, 1.4F), new TDiv_QS_nLarge_UBI(20, 0.18F), 10, new MatrixSolver02_BlockLanczos<Integer>(), true),

			// sieving with prime powers
//			new SIQS(20, 0.32F, 0.37F, new SIQSPolyBuilderWithPowers(), new SieveWithPowers(0.16F, 110, 1.4F), new TDiv_QS_nLarge_UBI(20, 0.18F), 10, new MatrixSolver02_BlockLanczos<Integer>(), true),
	
			// segmented sieve: slower
//			new SIQS(20, 0.32F, 0.41F, new SIQSPolyBuilder01(), new SingleBlockSieve(0.16F, 110, 1.4F, 256*1024), new TDiv_QS_nLarge_UBI(20, 0.18F), 10, new MatrixSolver02_BlockLanczos<Integer>(), false),
//			new SIQS(20, 0.32F, 0.41F, new SIQSPolyBuilder01(), new DoubleBlockSieve(0.16F, 110, 1.4F, 32*1024, 256*1024), new TDiv_QS_nLarge_UBI(20, 0.18F), 10, new MatrixSolver02_BlockLanczos<Integer>(), false),

			// Multi-threaded SIQS:
			// * faster than single-threaded SIQS for N >= 97 bits
			// * may need a lot of memory with big numberOfThreads
			// * The bigger maxRestExp_sieve and maxRestExp_tdiv are, the more partials are collected.
			//   This is good as long as enough memory is available and TDiv doesn't get too busy.
			new PSIQS(20, 0.32F, 0.37F, null, 0.167F, 0.18F, 4, new MatrixSolver02_BlockLanczos<Integer>()),
	
			// Combination of best algorithms for all factor argument sizes
//			new CombinedFactorAlgorithm(20, 4),
		};
	}
	
	private void testRange(int bits) {
		BigInteger N_min = ONE.shiftLeft(bits-1);
		// find N-set for square tests
		//ArrayList NSet = TestsetGenerator.generate(bits, N_COUNT);
		ArrayList<BigInteger> NSet = TestsetGenerator.generate(bits, N_COUNT);
		LOG.info("Test N with " + bits + " bits, i.e. N >= " + N_min);
		
		// take 3 timings for each algorithm to be quite sure that one timing is not falsified by garbage collection
		TreeMap<Long, List<SingleFactorFinder>> ms_2_algorithms = new TreeMap<Long, List<SingleFactorFinder>>();
		for (int i=0; i<REPEATS; i++) {
			for (SingleFactorFinder algorithm : algorithms) {
				// exclude special size implementations
				String algName = algorithm.getName();
				if (bits<45 && algName.startsWith("SIQS")) continue; // unstable for smaller N
				if (bits<65 && algName.startsWith("PSIQS")) continue; // unstable for smaller N
				if (bits>63 && algName.startsWith("TDiv63")) continue; // long implementation
				if (bits>42 && algName.equals("SquFoF31")) continue; // int implementation
				if (bits>31 && algName.startsWith("TDiv31")) continue; // int implementation
				if (bits>31 && algName.startsWith("PollardRho31")) continue; // long implementation
				
				System.gc(); // create equal conditions for all algorithms

				int failCount = 0;
				long startTimeMillis = System.currentTimeMillis();
				for (BigInteger N : NSet) {
					BigInteger factor = algorithm.findSingleFactor(N);
					// test correctness
					if (factor==null || factor.equals(ZERO) || factor.equals(ONE) || factor.mod(N).equals(ZERO)) {
						//LOG.error("FactorAlgorithm " + algorithm.getName() + " did not find a factor of N=" + N + ", it returned " + factor);
						failCount++;
					} else {
						// not null, not trivial -> test division
						BigInteger[] test = N.divideAndRemainder(factor);
						if (!test[1].equals(ZERO)) {
							//LOG.error("FactorAlgorithm " + algorithm.getName() + " returned " + factor + ", but this is not a factor of N=" + N);
							failCount++;
						}
					}
				}
				long endTimeMillis = System.currentTimeMillis();
				long duration = endTimeMillis - startTimeMillis; // duration in ms
				//LOG.debug("algorithm " + algName + " finished test set with " + bits + " bits");
				List<SingleFactorFinder> algList = ms_2_algorithms.get(duration);
				if (algList==null) algList = new ArrayList<SingleFactorFinder>();
				algList.add(algorithm);
				ms_2_algorithms.put(duration, algList);
				if (failCount>0) {
					LOG.error("FactorAlgorithm " + algorithm.getName() + " failed at " + failCount + "/" + N_COUNT + " test numbers...");
				}
			}
		}
		
		// log best algorithms first
		int rank=1;
		for (long ms : ms_2_algorithms.keySet()) {
			List<SingleFactorFinder> algList = ms_2_algorithms.get(ms);
			int j=0;
			for (SingleFactorFinder algorithm : algList) {
				String durationStr = TimeUtil.timeStr(ms);
				LOG.info("#" + rank + ": Algorithm " + algorithm.getName() + " took " + durationStr);
				j++;
			}
			rank += j;
		}
	}

	/**
	 * Test factor algorithms for sets of factor arguments of growing size and report timings after each set.
	 * @param args ignored
	 */
	public static void main(String[] args) {
    	ConfigUtil.initProject();
    	FactorizerTest testEngine = new FactorizerTest();
		int bits = START_BITS;
		while (true) {
			// test N with the given number of bits, i.e. 2^(bits-1) <= N <= (2^bits)-1
			testEngine.testRange(bits);
			bits += INCR_BITS;
			if (MAX_BITS!=null && bits > MAX_BITS) break;
		}
	}
}
