// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor.tdiv;

import java.math.BigInteger;

import de.tilman_neumann.math.base.bigint.primes.SmallPrimesGenerator;
import de.tilman_neumann.math.factor.FactorAlgorithmBase;

/**
 * Trial division factor algorithm preloading all primes <= sqrt(Integer.MAX_VALUE).
 * 
 * sqrt(Integer.MAX_VALUE) = sqrt(2^32 - 1) = sqrt(2147483647) = 46340.95
 * -> we need to preload all primes < 46340.
 * -> there are 4793 such primes...
 */
public class TDiv31Preload extends FactorAlgorithmBase {
	private static final int NUM_PRIMES = 4793;
	
	private int[] primes;

	public TDiv31Preload(int primeTestPrecisionBits) {
		super(primeTestPrecisionBits);
		// preload primes
		primes = new int[NUM_PRIMES];
		SmallPrimesGenerator smallPrimeGen = new SmallPrimesGenerator();
		int count = 0;
		int p;
		do {
			p = smallPrimeGen.nextPrime().intValue();
			primes[count++] = p;
		} while (p<46340);
	}

	@Override
	public String getName() {
		return "TDiv31Preload";
	}

	@Override
	public BigInteger findSingleFactor(BigInteger N) {
		return BigInteger.valueOf(findSingleFactor(N.intValue()));
	}
	
	public long findSingleFactor(long N) {
		return (long) findSingleFactor( (int) N);
	}
	
	public int findSingleFactor(int N) {
		// if N is odd and composite then the loop runs maximally up to test = floor(sqrt(N))
		for (int i=0; i<NUM_PRIMES; i++) {
			if (N%primes[i]==0) return primes[i];
		}
		// otherwise N is prime!
		throw new IllegalArgumentException("N = " + N + " is prime!");
	}
	
	/**
	 * Test if N has a factor <= maxTestNumber.
	 * @param N
	 * @param maxTestNumber
	 * @return small factor, or null if N has no factor <= maxTestNumber
	 */
	public BigInteger findSmallFactor(BigInteger N, BigInteger maxTestNumber) {
		int n = N.intValue();
		int maxTestNumberL = maxTestNumber.intValue();
		// test until maxTestNumber or until a factor is found
		for (int i=0; i<NUM_PRIMES; i++) {
			int p = primes[i];
			if (p>maxTestNumberL) return null;
			if (n%p==0) return BigInteger.valueOf(p);
		}
		return null;
	}
}
