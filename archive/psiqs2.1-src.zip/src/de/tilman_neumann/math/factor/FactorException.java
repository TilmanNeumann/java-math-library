// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor;

import java.math.BigInteger;

/**
 * An exception indicating that a factor was found.
 */
public class FactorException extends Exception {
	private static final long serialVersionUID = -6623862851940555652L;
	
	private BigInteger factor = null;
	
	/**
	 * Complete constructor.
	 * @param factor
	 */
	public FactorException(BigInteger factor) {
		this.factor = factor;
	}
	
	/**
	 * @return factor
	 */
	public BigInteger getFactor() {
		return this.factor;
	}
}
