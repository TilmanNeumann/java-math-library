// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor.siqs.sieve;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import de.tilman_neumann.math.factor.basics.BinarySearch;
import de.tilman_neumann.math.factor.siqs.PolySolutions;
import de.tilman_neumann.util.Timer;

/**
 * Single block sieve implementation, essentially following [Wambach, Wettig 1995].
 */
public class SingleBlockSieve implements Sieve {
	private static final Logger LOG = Logger.getLogger(SingleBlockSieve.class);
	private static final boolean DEBUG = false;
	
	// factor argument data
	private float lnN;
	private double lnkN;

	// prime base
	private int primeBaseSize;
	private int[] primesArray;
	private float pMinMult; // multiplier to compute pMinIndex
	private int pMinIndex;
	private float lnPMultiplier;

	private PolySolutions primeSolutions;

	// sieve
	/** Algorithm to compute the logPSum threshold value */
	private SieveBoundCalculator sieveBoundCalculator = SieveBoundCalculator.N_BASED;
	/** Algorithm to compute the initializer value */
	private InitializerCalculator initializerCalculator = InitializerCalculator.SMALL;
	private float T;
	private int sieveArraySize;
	private int wantedMinLogPSum;
	private byte[] sieve_logPSumArray;
	/** sieve block size */
	private int B;
	/** number of complete blocks */
	private int k;
	private byte[] initializedBlock;
	
	private int[] selectedPrimes;
	private byte[] selectedLogP;
	private int[] selectedX1;
	private int[] selectedX1Neg;
	private int[] selectedD1;
	private int[] selectedD1Neg;

	private BinarySearch binarySearch = new BinarySearch();

	// timings
	private boolean profile;
	private Timer timer = new Timer();
	private long initDuration, sieveDuration, collectDuration;

	/**
	 * Full constructor.
	 * @param T the T parameter: reasonable values are T ~ 0.16 for SieveBoundCalculator.N_BASED, T ~ 2.0 for SieveBoundCalculator.PMAX_BASED
	 * @param wantedMinLogPSum values between 70..120 seem best (experimental results)
	 * @param pMinMult a multiplier to compute the smallest prime in the prime base to be used for sieving
	 * @param blockSize size of a sieve segment
	 */
	public SingleBlockSieve(float T, int wantedMinLogPSum, float pMinMult, int blockSize) {
		this.T = T;
		this.wantedMinLogPSum = wantedMinLogPSum;
		this.pMinMult = pMinMult;
		this.B = blockSize;
	}
	
	@Override
	public String getName() {
		return "singleBlock(" + T + ", " + + wantedMinLogPSum + ", " + pMinMult + ", " + B + ")";
	}
	
	@Override
	public void initialize(double N_dbl, BigInteger kN, int unfilteredPrimeBaseSize, int[] unfilteredPrimesArray, int[] unfilteredTArray, int sieveArraySize, boolean profile) {
		this.lnN = (float) Math.log(N_dbl);
		lnkN = Math.log(kN.doubleValue());

		this.pMinIndex = Math.max(1, (int) (pMinMult * Math.log(unfilteredPrimeBaseSize))); // avoid p[0]==2 which is not used in several sieves
		this.sieveArraySize = sieveArraySize;
		if (DEBUG) LOG.debug("sieveArraySize = " + sieveArraySize);

		// Compute sieve bound in natural logarithm & convert to the actual logBase; then compute initializer.
		int pMax = unfilteredPrimesArray[unfilteredPrimeBaseSize-1];
		double minLnPSum = sieveBoundCalculator.computeSieveBound(T, lnN, lnkN, pMax, sieveArraySize);
		float lnLogBase = (float) (minLnPSum / wantedMinLogPSum);
		int minLogPSum = (int) (minLnPSum / lnLogBase); // floor, result should be ~wantedMinLogPSum
		if (DEBUG) {
			float logBase = (float) Math.exp(lnLogBase);
			LOG.debug("logBase=" + logBase + ", lnLogBase=" + lnLogBase + ", minLnPSum = " + minLnPSum + ", minLogPSum = " + minLogPSum);
		}
		byte[] initializer = initializerCalculator.compute(unfilteredPrimesArray, pMinIndex, minLogPSum, lnLogBase);
		lnPMultiplier = 1.0F/lnLogBase;

		// create initialized block
		int effectiveSieveArraySize = Math.min(sieveArraySize, B);
		initializedBlock = new byte[effectiveSieveArraySize];
		int filled = Math.min(256, effectiveSieveArraySize);
		System.arraycopy(initializer, 0, initializedBlock, 0, filled);
		int unfilled = effectiveSieveArraySize-filled;
		while (unfilled>0) {
			int fillNext = Math.min(unfilled, filled);
			System.arraycopy(initializedBlock, 0, initializedBlock, filled, fillNext);
			filled += fillNext;
			unfilled = effectiveSieveArraySize-filled;
		}
		
		// allocate sieve block
		sieve_logPSumArray = new byte[effectiveSieveArraySize];
		// number of complete blocks
		k = sieveArraySize / B;
		if (DEBUG) LOG.debug("#complete blocks k = " + k);

		selectedPrimes = new int[unfilteredPrimeBaseSize];
		selectedLogP = new byte[unfilteredPrimeBaseSize];
		selectedX1 = new int[unfilteredPrimeBaseSize];
		selectedX1Neg = new int[unfilteredPrimeBaseSize];
		selectedD1 = new int[unfilteredPrimeBaseSize];
		selectedD1Neg = new int[unfilteredPrimeBaseSize];

		// profiling
		this.profile = profile;
		initDuration = sieveDuration = collectDuration = 0;
	}

	@Override
	public float getLnPMultiplier() {
		return lnPMultiplier;
	}

	@Override
	public void setPrimeSolutions(PolySolutions primeSolutions) {
		this.primeSolutions = primeSolutions;
		this.primesArray = primeSolutions.primesOrPowers;
		this.primeBaseSize = primesArray.length;
	}

	@Override
	public List<Integer> sieve() {
		if (profile) timer.capture();

		// preprocessing
		int[] x1Array = primeSolutions.x1Array;
		int[] x2Array = primeSolutions.x2Array;
		byte[] logPArray = primeSolutions.logPArray;
		int selectionCount = 0;
		int x1, x2;
		for (int i=pMinIndex; i<primeBaseSize; i++) {
			x1 = x1Array[i];
			final int p = selectedPrimes[selectionCount] = primesArray[i];
			selectedLogP[selectionCount] = logPArray[i];
			x2 = x2Array[i];
			if (x1<x2) {
				selectedX1[selectionCount] = x1;
				selectedX1Neg[selectionCount] = p - x2;
				selectedD1Neg[selectionCount] = selectedD1[selectionCount] = x2 - x1;
			} else {
				selectedX1[selectionCount] = x2;
				selectedX1Neg[selectionCount] = p - x1;
				selectedD1Neg[selectionCount] = selectedD1[selectionCount] = x1 - x2;
			}
			selectionCount++;
		}

		int r_s = binarySearch.getFirstGreaterEntryIndex(selectedPrimes, selectionCount, B);
		if (r_s < 0) {
			// B > pMax -> all primes have two roots inside a block
			r_s = selectionCount;
		}
		
		List<Integer> smoothXList = new ArrayList<Integer>();
		for (int b=0; b<k; b++) { // bottom-up order is required because in each block, the data for the next block is adjusted
			// positive x: initialize block
			System.arraycopy(initializedBlock, 0, sieve_logPSumArray, 0, B);
			if (profile) initDuration += timer.capture();
			
			// positive x: sieve block [b*B, (b+1)*B] with prime index ranges 0...r_s-1 and r_s...max
			sievePositiveXBlock(B, 0, r_s, selectionCount);
			if (profile) sieveDuration += timer.capture();
			
			// collect block
			// let the sieve entry counter x run down to 0 is much faster because of the simpler exit condition
			final int blockOffset1 = b*B+1;
			final int blockOffset2 = blockOffset1+1;
			final int blockOffset3 = blockOffset2+1;
			final int blockOffset4 = blockOffset3+1;
			for (int x=B-1; x>=0; ) {
				// Unfortunately, in Java we can not cast byte[] to int[] or long[].
				// So we have to use 'or'. More than 4 'or's do not pay out.
				if (((sieve_logPSumArray[x--] | sieve_logPSumArray[x--] | sieve_logPSumArray[x--] | sieve_logPSumArray[x--]) & 0x80) != 0) {
					// at least one of the tested Q(x) is sufficiently smooth to be passed to trial division!
					if (sieve_logPSumArray[x+1] < 0) smoothXList.add(x+blockOffset1);
					if (sieve_logPSumArray[x+2] < 0) smoothXList.add(x+blockOffset2);
					if (sieve_logPSumArray[x+3] < 0) smoothXList.add(x+blockOffset3);
					if (sieve_logPSumArray[x+4] < 0) smoothXList.add(x+blockOffset4);
				}
			} // end for (x)
			if (profile) collectDuration += timer.capture();
			
			// negative x: initialize block
			System.arraycopy(initializedBlock, 0, sieve_logPSumArray, 0, B);
			if (profile) initDuration += timer.capture();
			
			// sieve block [b*B, (b+1)*B] with prime index ranges 0...r_s-1 and r_s...max
			sieveNegativeXBlock(B, 0, r_s, selectionCount);
			if (profile) sieveDuration += timer.capture();
			
			// collect block
			// let the sieve entry counter x run down to 0 is much faster because of the simpler exit condition
			for (int x=B-1; x>=0; ) {
				// Unfortunately, in Java we can not cast byte[] to int[] or long[].
				// So we have to use 'or'. More than 4 'or's do not pay out.
				if (((sieve_logPSumArray[x--] | sieve_logPSumArray[x--] | sieve_logPSumArray[x--] | sieve_logPSumArray[x--]) & 0x80) != 0) {
					// at least one of the tested Q(-x) is sufficiently smooth to be passed to trial division!
					if (sieve_logPSumArray[x+1] < 0) smoothXList.add(-(x+blockOffset1));
					if (sieve_logPSumArray[x+2] < 0) smoothXList.add(-(x+blockOffset2));
					if (sieve_logPSumArray[x+3] < 0) smoothXList.add(-(x+blockOffset3));
					if (sieve_logPSumArray[x+4] < 0) smoothXList.add(-(x+blockOffset4));
				}
			} // end for (x)
			if (profile) collectDuration += timer.capture();
		}
		
		// sieve last, incomplete block (with b=k)
		int B_incomplete = sieveArraySize % B;
		//LOG.debug("db: last block -> B_incomplete=" + B_incomplete);
		if (B_incomplete>0) {
			// positive x: initialize(S, B)
			System.arraycopy(initializedBlock, 0, sieve_logPSumArray, 0, B_incomplete);
			if (profile) initDuration += timer.capture();
			
			// sieve block [b*B, (b+1)*B] with prime index ranges 0...r_s-1 and r_s...max
			sievePositiveXBlock(B_incomplete, 0, r_s, selectionCount);
			if (profile) sieveDuration += timer.capture();

			// evaluate(S, B), collect results
			// let the sieve entry counter x run down to 0 is much faster because of the simpler exit condition
			final int blockOffset1 = k*B+1;
			final int blockOffset2 = blockOffset1+1;
			final int blockOffset3 = blockOffset2+1;
			final int blockOffset4 = blockOffset3+1;
			//LOG.debug("db: blockOffset = " + blockOffset);
			for (int x=B_incomplete-1; x>=0; ) {
				// Unfortunately, in Java we can not cast byte[] to int[] or long[].
				// So we have to use 'or'. More than 4 'or's do not pay out.
				if (((sieve_logPSumArray[x--] | sieve_logPSumArray[x--] | sieve_logPSumArray[x--] | sieve_logPSumArray[x--]) & 0x80) != 0) {
					// at least one of the tested Q(x) is sufficiently smooth to be passed to trial division!
					if (sieve_logPSumArray[x+1] < 0) smoothXList.add(x+blockOffset1);
					if (sieve_logPSumArray[x+2] < 0) smoothXList.add(x+blockOffset2);
					if (sieve_logPSumArray[x+3] < 0) smoothXList.add(x+blockOffset3);
					if (sieve_logPSumArray[x+4] < 0) smoothXList.add(x+blockOffset4);
				}
			} // end for (x)
			if (profile) collectDuration += timer.capture();
			
			// negative x
			// initialize(S, B)
			System.arraycopy(initializedBlock, 0, sieve_logPSumArray, 0, B_incomplete);
			if (profile) initDuration += timer.capture();
			
			// sieve block [b*B, (b+1)*B] with prime index ranges 0...r_s-1 and r_s...max
			sieveNegativeXBlock(B_incomplete, 0, r_s, selectionCount);
			if (profile) sieveDuration += timer.capture();

			// evaluate(S, B), collect results
			// let the sieve entry counter x run down to 0 is much faster because of the simpler exit condition
			for (int x=B_incomplete-1; x>=0; ) {
				// Unfortunately, in Java we can not cast byte[] to int[] or long[].
				// So we have to use 'or'. More than 4 'or's do not pay out.
				if (((sieve_logPSumArray[x--] | sieve_logPSumArray[x--] | sieve_logPSumArray[x--] | sieve_logPSumArray[x--]) & 0x80) != 0) {
					// at least one of the tested Q(-x) is sufficiently smooth to be passed to trial division!
					if (sieve_logPSumArray[x+1] < 0) smoothXList.add(-(x+blockOffset1));
					if (sieve_logPSumArray[x+2] < 0) smoothXList.add(-(x+blockOffset2));
					if (sieve_logPSumArray[x+3] < 0) smoothXList.add(-(x+blockOffset3));
					if (sieve_logPSumArray[x+4] < 0) smoothXList.add(-(x+blockOffset4));
				}
			} // end for (x)
			if (profile) collectDuration += timer.capture();
		}
		return smoothXList;
	}
	
	private void sievePositiveXBlock(final int B, final int r_start, final int r_medium, final int r_max) {
		int r, x, d1;
		// positive x, large primes
		for (r=r_max-1; r>=r_medium; r--) {
			x = selectedX1[r];
			final byte logP = selectedLogP[r];
			// solution x2: x1 == x2 happens in any of (basic QS, MPQS, SIQS) if p divides k, which implies t=0
			if ((d1 = selectedD1[r]) != 0) { // two x-solutions
				//LOG.debug("p=" + p + ", x1=" + x + ", d1=" + d1);
				if (x<B) {
					sieve_logPSumArray[x] += logP;
					x += d1;
					final int d2 = selectedPrimes[r] - d1;
					if (x<B) {
						sieve_logPSumArray[x] += logP;
						x += d2;
						// the difference is still correct
					} else {
						selectedD1[r] = d2;
					}
				}
			} else {
				// only one x-solution
				//LOG.debug("p=" + p + ", x1=" + x);
				if (x<B) {
					sieve_logPSumArray[x] += logP;
					x += selectedPrimes[r];
				}
			} // end if (x2 == x1)
			selectedX1[r] = x-B;
		}
		// positive x, small primes
		for (; r>=r_start; r--) {
			x = selectedX1[r];
			final byte logP = selectedLogP[r];
			// solution x2: x1 == x2 happens in any of (basic QS, MPQS, SIQS) if p divides k, which implies t=0
			if ((d1 = selectedD1[r]) != 0) { // two x-solutions
				//LOG.debug("p=" + p + ", x1=" + x + ", d1=" + d1);
				final int d2 = selectedPrimes[r]-d1;
				final int M_d = B - d1;
				for ( ; x<M_d; ) {
					sieve_logPSumArray[x] += logP;
					x += d1;
					sieve_logPSumArray[x] += logP;
					x += d2;
				}
				// sieve last location
				if (x<B) {
					sieve_logPSumArray[x] += logP;
					x += d1;
					selectedD1[r] = d2;
				} // else: the difference is still correct
			} else {
				// only one x-solution
				//LOG.debug("p=" + p + ", x1=" + x);
				final int p = selectedPrimes[r];
				for ( ; x<B; x+=p) {
					sieve_logPSumArray[x] += logP;
				}
			} // end if (x2 == x1)
			selectedX1[r] = x-B;
		}
	}
	
	private void sieveNegativeXBlock(final int B, final int r_start, final int r_medium, final int r_max) {
		int r, x, d1;
		// negative x, large primes
		for (r=r_max-1; r>=r_medium; r--) {
			final byte logP = selectedLogP[r];
			x = selectedX1Neg[r];
			// solution x2: x1 == x2 happens in any of (basic QS, MPQS, SIQS) if p divides k, which implies t=0
			if ((d1 = selectedD1Neg[r]) != 0) { // two x-solutions
				//LOG.debug("p=" + p + ", x1=" + x + ", d1=" + d1);
				if (x<B) {
					sieve_logPSumArray[x] += logP;
					x += d1;
					final int d2 = selectedPrimes[r] - d1;
					if (x<B) {
						sieve_logPSumArray[x] += logP;
						x += d2;
						// the difference is still correct
					} else {
						selectedD1Neg[r] = d2;
					}
				}
			} else {
				// only one x-solution
				//LOG.debug("p=" + p + ", x1=" + x);
				if (x<B) {
					sieve_logPSumArray[x] += logP;
					x += selectedPrimes[r];
				}
			} // end if (x2 == x1)
			selectedX1Neg[r] = x-B;
		}
		// negative x, small primes
		for (; r>=r_start; r--) {
			final byte logP = selectedLogP[r];
			x = selectedX1Neg[r];
			// solution x2: x1 == x2 happens in any of (basic QS, MPQS, SIQS) if p divides k, which implies t=0
			if ((d1 = selectedD1Neg[r]) != 0) { // two x-solutions
				//LOG.debug("p=" + p + ", x1=" + x + ", d1=" + d1);
				final int d2 = selectedPrimes[r]-d1;
				final int M_d = B - d1;
				for ( ; x<M_d; ) {
					sieve_logPSumArray[x] += logP;
					// d1 = (p-x2)-(p-x1) = x1-x2
					x += d1;
					sieve_logPSumArray[x] += logP;
					// d2 = p + (p-x1)-(p-x2) = p+x2-x1
					x += d2;
				}
				// sieve last locations
				if (x<B) {
					sieve_logPSumArray[x] += logP;
					x += d1;
					selectedD1Neg[r] = d2;
				} // else: the difference is still correct
			} else {
				// only one x-solution
				//LOG.debug("p=" + p + ", x1=" + x);
				final int p = selectedPrimes[r];
				for ( ; x<B; x+=p) {
					sieve_logPSumArray[x] += logP;
				}
			} // end if (x2 == x1)
			selectedX1Neg[r] = x-B;
		}
	}
	
	@Override
	public String getProfilingReport() {
		return "init=" + initDuration + "ms, sieve=" + sieveDuration + "ms, collect=" + collectDuration + "ms";
	}
	
	@Override
	public void cleanUp() {
		primesArray = null;
		sieve_logPSumArray = null;
		initializedBlock = null;
		selectedPrimes = null;
		selectedLogP = null;
		selectedX1 = null;
		selectedX1Neg = null;
		selectedD1 = null;
		selectedD1Neg = null;
	}
}
