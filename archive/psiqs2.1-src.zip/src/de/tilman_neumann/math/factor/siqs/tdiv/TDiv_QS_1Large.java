// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor.siqs.tdiv;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import de.tilman_neumann.math.factor.basics.SortedIntegerArray;
import de.tilman_neumann.math.factor.basics.SortedLongArray;
import de.tilman_neumann.math.factor.basics.congruence.AQPair;
import de.tilman_neumann.math.factor.basics.congruence.Partial_1Large;
import de.tilman_neumann.math.factor.basics.congruence.Smooth_Perfect;
import de.tilman_neumann.math.factor.siqs.PolySolutions;

import static de.tilman_neumann.math.base.bigint.BigIntConstants.*;
import static org.junit.Assert.*;

/**
 * A trial division engine where partials can only have 1 large factor.
 * Uses standard BigIntegers division.
 */
public class TDiv_QS_1Large implements TDiv_QS {
	private static final Logger LOG = Logger.getLogger(TDiv_QS_1Large.class);
	private static final boolean DEBUG = false;

	// factor argument and polynomial parameters
	private BigInteger kN;
	private BigInteger aParam, bParam;
	
	private float T;
	/** Q is sufficiently smooth if the unfactored Q_rest is smaller than this bound depending on N */
	private double maxUnfactoredRest;

	// prime base
	private int[] primesArray;
	private int primeBaseSize;
	private int[] unsievedPrimeBaseElements;
	/** the indices of the primes found to divide Q in pass 1 */
	private int[] pass2Primes = new int[100];

	private PolySolutions primeSolutions;

	 // smallest solutions of Q(x) == A(x)^2 (mod p)
	private int[] x1Array, x2Array;
	
	// result: two arrays that are reused, their content is _copied_ to AQ-pairs
	private SortedIntegerArray smallFactors = new SortedIntegerArray();
	private SortedLongArray bigFactors = new SortedLongArray();
	
	// statistics
	private long testCount, sufficientSmoothCount;
	
	public TDiv_QS_1Large(int primeTestBits, float T) {
		this.T = T;
	}

	@Override
	public String getName() {
		return "TDiv_1L(" + T + ")";
	}

	@Override
	public void initialize(double N_dbl, BigInteger kN) {
		// compute the biggest unfactored rest where some Q is considered smooth enough for a congruence.
		this.maxUnfactoredRest = Math.pow(N_dbl, T);
		if (DEBUG) LOG.debug("maxUnfactoredRest = " + maxUnfactoredRest + " (" + (64-Long.numberOfLeadingZeros((long)maxUnfactoredRest)) + " bits)");
		this.kN = kN;
		// statistics
		this.testCount = 0;
		this.sufficientSmoothCount = 0;
	}

	@Override
	public void setPrimeSolutions(BigInteger a, BigInteger b, PolySolutions primeSolutions, int[] unsievedPrimeBaseElements) {
		this.aParam = a;
		this.bParam = b;
		this.primeSolutions = primeSolutions;
		this.primesArray = primeSolutions.primesOrPowers;
		this.primeBaseSize = primesArray.length;
		this.unsievedPrimeBaseElements = unsievedPrimeBaseElements;
	}

	@Override
	public void setBParameter(BigInteger b) {
		this.bParam = b;
	}

	@Override
	public List<AQPair> testList(List<Integer> xList) {
		// initialize some variables
		x1Array = primeSolutions.x1Array;
		x2Array = primeSolutions.x2Array;

		// do trial division with sieve result
		ArrayList<AQPair> aqPairs = new ArrayList<AQPair>();
		for (int x : xList) {
			smallFactors.reset();
			bigFactors.reset();
			testCount++;
			BigInteger A = aParam.multiply(BigInteger.valueOf(x)).add(bParam); // A(x) = a*x+b
			BigInteger Q = A.multiply(A).subtract(kN); // Q(x) = A(x)^2 - kN
			AQPair aqPair = test(A, Q, x);
			if (aqPair != null) {
				// Q(x) was found sufficiently smooth to be considered a (partial) congruence
				aqPairs.add(aqPair);
				sufficientSmoothCount++;
				if (DEBUG) {
					LOG.debug("Found congruence " + aqPair);
					assertEquals(A.multiply(A).mod(kN), Q.mod(kN));
				}
			}
		}
		return aqPairs;
	}
	
	private AQPair test(BigInteger A, BigInteger Q, int x) {
		// sign
		BigInteger Q_rest = Q;
		if (Q.signum() < 0) {
			smallFactors.add(-1);
			Q_rest = Q.negate();
		}
		
		// Remove multiples of 2
		int lsb = Q_rest.getLowestSetBit();
		if (lsb > 0) {
			smallFactors.add(2, (short)lsb);
			Q_rest = Q_rest.shiftRight(lsb);
		}

		// Unsieved prime base elements are added directly to pass 2.
		int pass2Count = unsievedPrimeBaseElements!=null ? unsievedPrimeBaseElements.length : 0;
		if (pass2Count>0) {
			System.arraycopy(unsievedPrimeBaseElements, 0, pass2Primes, 0, pass2Count);
		}
		
		// Pass 1: test solution arrays.
		// Starting at the biggest prime base elements is faster because then Q_rest is reduced quicker in pass2.
		for (int pIndex = primeBaseSize-1; pIndex > 0; pIndex--) { // p[0]=2 was already tested
			int p = primesArray[pIndex];
			int xModP = x % p;
			if (xModP<0) xModP += p; // make remainder non-negative for negative x
			if (DEBUG) {
				if (xModP<0) LOG.debug("x=" + x + ", p=" + p + " -> x % p = " + xModP + ", x1 = " + x1Array[pIndex] + ", x2 = " + x2Array[pIndex]);
				assertTrue(0<=xModP && xModP<p);
			}
			if (xModP==x1Array[pIndex] || xModP==x2Array[pIndex]) {
				pass2Primes[pass2Count++] = p;
			}
		}
	
		// Pass 2: remove further occurrences of the p_i that were found to divide Q
		BigInteger div[];
		for (int pass2Index = 0; pass2Index < pass2Count; pass2Index++) {
			int p = pass2Primes[pass2Index];
			BigInteger pBig = BigInteger.valueOf(p);
			while (true) {
				div = Q_rest.divideAndRemainder(pBig);
				if (div[1].compareTo(ZERO)>0) break;
				smallFactors.add(p);
				Q_rest = div[0];
			}
		}
		if (Q_rest.equals(ONE)) return new Smooth_Perfect(A, smallFactors);
		
		// Division by all p<=pMax was not sufficient to factor Q completely.
		// The remaining Q_rest is either a prime > pMax, or a composite > pMax^2.
		if (Q_rest.doubleValue() >= maxUnfactoredRest) return null; // Q is not sufficiently smooth
		// Note: We could as well use pMax^c with c~1.75 as threshold. Larger factors do not help to find smooth congruences.
	
		// Q is sufficiently smooth
		if (DEBUG) LOG.debug("Sufficient smooth big factor = " + Q_rest);
		return new Partial_1Large(A, smallFactors, Q_rest.longValue());
	}
	
	@Override
	public String getReportString() {
		float percentage = ((int) (0.5F + sufficientSmoothCount*10000 / (float) testCount)) / 100F; // 2 after-comma digits
		return "tested " + testCount + " smooth-candidates and let " + sufficientSmoothCount + " (" + percentage + "%) pass";
	}
	
	@Override
	public void cleanUp() {
		primesArray = null;
		unsievedPrimeBaseElements = null;
		x1Array = null;
		x2Array = null;
	}
}
