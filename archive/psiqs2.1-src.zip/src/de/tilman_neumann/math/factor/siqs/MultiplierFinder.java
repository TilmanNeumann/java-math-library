// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor.siqs;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;

import org.apache.log4j.Logger;

import de.tilman_neumann.math.base.bigint.JacobiSymbol;
import de.tilman_neumann.math.base.bigint.sequence.SquarefreeSequence;
import de.tilman_neumann.math.factor.basics.primeBase.PrimeBaseBuilder02;
import de.tilman_neumann.math.factor.basics.primeBase.Primes;

import static de.tilman_neumann.math.base.bigint.BigIntConstants.*;

/**
 * Computation of the multiplier k. The best choice is the Knuth-Schroeppel algorithm.
 */
public enum MultiplierFinder {
	/** no multiplier, use k==1 always */
	ONE {
		@Override
		public int computeMultiplier(BigInteger N, int primeBaseSize) {
			return 1;
		}
	},
	
	/**
	 * Use the first odd, square-free k with kN == 1 (mod 4).
	 * This is the basic suggestion from [Silverman 87].
	 */
	FIRST_SQUAREFREE_MOD4 {
		@Override
		public int computeMultiplier(BigInteger N, int primeBaseSize) {
			SquarefreeSequence seq = new SquarefreeSequence(1);
			seq.reset();
			while (true) {
				BigInteger k = seq.next();
				if (k.testBit(0)) {
					// k is odd -> test kN
					int kN_mod4 = k.multiply(N).and(THREE).intValue();
					if (kN_mod4==1) return k.intValue();
				}
			}
		}
	},
	
	/**
	 * Use the first odd, square-free k with kN == 1 (mod 8).
	 * This is preferable according to [Silverman 87].
	 */
	FIRST_SQUAREFREE_MOD8 {
		@Override
		public int computeMultiplier(BigInteger N, int primeBaseSize) {
			SquarefreeSequence seq = new SquarefreeSequence(1);
			seq.reset();
			while (true) {
				BigInteger k = seq.next();
				if (k.testBit(0)) {
					// k is odd -> test kN
					int kN_mod8 = k.multiply(N).and(SEVEN).intValue();
					if (kN_mod8==1) return k.intValue();
				}
			}
		}
	},
	
	/** Knuth-Schroeppel algorithm */
	KNUTH_SCHROEPPEL {
		@Override
		public int computeMultiplier(BigInteger N, int primeBaseSize) {
			// The parameters have been chosen experimentally as a tradeoff between the runtime
			// of the Knuth-Schroeppel algorithm and the quality of the k-evaluation.
			int NBits = N.bitLength();
			int k = KnuthSchroeppelForQS(N, 2*NBits, 2*NBits, 0.35); // 0.35 is better than 0.5 proposed by literature
			//LOG.debug("Knuth-Schroeppel multiplier k = " + k);
			return k;
		}
	};
	
	private static final Logger LOG = Logger.getLogger(MultiplierFinder.class);
	private final static boolean DEBUG = false;
	
	private static final double HALF_LN2 = 0.5 * Math.log(2);
	private static final double LN2      = 1.0 * Math.log(2);
	private static final double TWO_LN2  = 2.0 * Math.log(2);
	
	private Primes primes = new PrimeBaseBuilder02().getPrimes(10000); // more than enough
	private SquarefreeSequence squareFreeSequence = new SquarefreeSequence(1);

	private int[] kArray = new int[10000];
	private BigInteger[] kNArray = new BigInteger[10000];
	private double[] fArray = new double[10000];
	private int[] primeCountArray = new int[10000];

	private JacobiSymbol jacobiEngine = new JacobiSymbol();

	/**
	 * Compute a multiplier k for N using the algorithm determined by multiplierStyle.
	 * @param N
	 * @param primeBaseSize
	 * @return k
	 */
	abstract public int computeMultiplier(BigInteger N, int primeBaseSize);

	/**
	 * Knuth-Schroeppel algorithm to choose a multiplier for quadratic sieves.
	 * 
	 * Most often the algorithm finds k with kN == 1 (mod 8), but kN == 3,5,7 (mod 8) are possible, too.
	 * Most "best k" are prime, but we also find composite and 1.
	 * 
	 * @see [Pomerance 1985: "The Quadratic Sieve Factoring Algorithm"].
	 * @see [Silverman 1987: "The Multiple Polynomial Quadratic Sieve", page 335].
	 * @see [Pomerance, Wagstaff 1983: "The Continued Fraction Factoring Algorithm"] for multipliers appropriate for CFRAC.
	 * 
	 * @param N
	 * @param wantedPrimeCount the number of primes, which would be part of the prime base, that shall be tested
	 * @param kMax the maximum value of k to consider
	 * @param penaltyMult
	 * @return best k
	 */
	public int KnuthSchroeppelForQS(BigInteger N, int wantedPrimeCount, int kMax, double penaltyMult) {
		squareFreeSequence.reset(); // start at k=1
		int kCount = 0;		
		while (true) {
			BigInteger k_big = squareFreeSequence.next();
			int k = k_big.intValue();
			if (k%2==0) continue;
			if (k>kMax) break;
			// now k is odd and square-free and not too big
			BigInteger kN = N.multiply(k_big);
			int kNMod8 = kN.and(SEVEN).intValue();
			
			// f(k, N) is the score for k that we wish to maximize.
			// initialize f(k, N) with the p=2 case and a bad penalty for big k:
			double f;
			if (kNMod8==1) {
				f =  TWO_LN2 - penaltyMult * Math.log(k);
			} else if (kNMod8==5) {
				f =      LN2 - penaltyMult * Math.log(k);
			} else { // kN == 3, 7 (mod 8)
				f = HALF_LN2 - penaltyMult * Math.log(k);
			}
			// store
			kArray[kCount] = k;
			kNArray[kCount] = kN;
			fArray[kCount] = f;
			primeCountArray[kCount++] = 1; // p=2
		}
		// Analysis: kCount ~ 0.406 * kMax
		
		// From the following list we will remove the indices of any k that have been completely evaluated.
		// ArrayList performs better than LinkedList, even with that many remove() operations.
		ArrayList<Integer> kIndexList = new ArrayList<Integer>(kCount);
		for (int kIndex=0; kIndex<kCount; kIndex++) kIndexList.add(kIndex);
		
		// odd primes
		int i=1;
		for (; i<primes.count; i++) {
			int p = primes.array[i];
			double lnPTerm = Math.log(p) / (double) (p-1); // p-1 is better than p
			int Legendre_N_p = jacobiEngine.jacobiSymbol(N, p);
			Iterator<Integer> kIndexIter = kIndexList.iterator();
			while (kIndexIter.hasNext()) {
				int kIndex = kIndexIter.next();
				int k = kArray[kIndex];
            	if (k % p == 0) {
            		// p divides k -> only one x-solution
            		fArray[kIndex] += lnPTerm;
            		primeCountArray[kIndex]++;
            	} else if (jacobiEngine.jacobiSymbol(k, p) * Legendre_N_p == 1) {
            		// kN is quadratic residue (mod p) -> 2 x-solutions.
            		// The cost of computing Legendre(kN|p) dominates the algorithm.
            		// Here we use Legendre(kN|p) = Legendre(k|p)*Legendre(N|p) with precomputed Legendre(N|p) to improve performance
            		fArray[kIndex] += 2*lnPTerm;
            		primeCountArray[kIndex]++;
            	} // else: p is not part of the resulting prime base -> skip
            	
            	// if we are done with some k then remove its kIndex from the list
				if (primeCountArray[kIndex] == wantedPrimeCount) kIndexIter.remove();
	        } // end for (k)
			
			// are we done with all k ?
			if (kIndexList.isEmpty()) break;
		} // end for (odd primes)
		if (DEBUG) LOG.debug("kCount = " + kCount + ": required number of primes = " + (i+1));
		// Analysis: required number of primes < 6*kCount
		
		// now we have evaluated f(k, N) for all k. pick the one that maximizes f [Pomerance 1985]
		int best_k = 1;
		double best_f = Double.MIN_VALUE;
		for (int kIndex=0; kIndex<kCount; kIndex++) {
			if (fArray[kIndex] > best_f) {
				best_f = fArray[kIndex];
				best_k = kArray[kIndex];
	        }
			//LOG.debug("f(k=" + k + ") = " + f + ", best f = " + best_f + " at k=" + best_k);
	    }
		return best_k;
	}
}
