// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor.siqs;

import static org.junit.Assert.assertTrue;

import java.math.BigInteger;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import de.tilman_neumann.math.base.bigint.JacobiSymbol;
import de.tilman_neumann.math.base.bigint.UnsignedBigInt;
import de.tilman_neumann.math.base.smallint.ModularSqrt31;
import de.tilman_neumann.math.factor.basics.BinarySearch;

/**
 * Algorithm to identify the powers we want to sieve with.
 */
public class PowerFinder {
	private static final Logger LOG = Logger.getLogger(PowerFinder.class);
	private static final boolean DEBUG = false;

	private BinarySearch binarySearch = new BinarySearch();
	private ModularSqrt31 modularSqrtEngine = new ModularSqrt31();
	
	/**
	 * Auxiliary class that allows to get the powers sorted bottom-up by the power value.
	 */
	public class PowerEntry implements Comparable<PowerEntry> {
		public int p;
		public int power;
		public int t;
		public byte logPower;
		
		public PowerEntry(int p, int power, int t, byte logPower) {
			this.p = p;
			this.power = power;
			this.t = t;
			this.logPower = logPower;
		}
		
		@Override
		public boolean equals(Object o) {
			if (o==null || !(o instanceof PowerEntry)) return false;
			return power == ((PowerEntry)o).power;
		}
		
		@Override
		public int compareTo(PowerEntry other) {
			return power - other.power;
		}
	}
	
	/**
	 * For all p<pMin having 2 x-solutions, find the first powers>pMin. These are the only powers that add log(power) to the logPSum.
	 * We collect them in a List sorted bottom-up by their base primes p.
	 * 
	 * @param kN
	 * @param filteredPrimeBase
	 * @param filteredTArray
	 * @param solutionCount
	 * @param pMinIndex
	 * @param pMin
	 * @param pMax
	 * @param lnPMultiplier
	 * @return powers sorted bottom-up by p
	 */
	public ArrayList<PowerEntry> findPowers(BigInteger kN, int[] filteredPrimeBase, int[] filteredTArray, int solutionCount, int pMinIndex, int pMin, int pMax, float lnPMultiplier) {
		UnsignedBigInt kN_UBI = new UnsignedBigInt(kN);
		ArrayList<PowerEntry> powerEntries = new ArrayList<PowerEntry>();
		int maxSquareIndex = binarySearch.getFirstGreaterEntryIndex(filteredPrimeBase, solutionCount, (int)Math.sqrt(pMax));
		int maxIndex = Math.min(pMinIndex, maxSquareIndex);
		for (int pIndex=1; pIndex<maxIndex; pIndex++) { // p[0]==2 never has 2 x-solutions
			// [https://members.loria.fr/EThome/old/MPRI/cours_02.pdf, page 11]: Solutions of Q(x) == 0 (mod p^exponent), Q(x) = (a*x+b)^2-kN, exponent>1
			// exist only if Q(x) == 0 (mod p) has two distinct solutions. p must not divide disc(Q).
			if (filteredTArray[pIndex] != 0) {
				int p = filteredPrimeBase[pIndex];
				if (DEBUG) {
					// since we only use odd p with x1!=x2, t!=0, p not dividing k, we strictly have Legendre(kN|p) > 0
					int jacobi = new JacobiSymbol().jacobiSymbol(kN, p);
					assertTrue(jacobi>0);
				}
				long power_long = p; // long required to avoid int overflow before size check
				for (int exponent=2; ; exponent++) {
					int last_power = (int) power_long;
					power_long *= p;
					if (power_long>pMax) {
						if (DEBUG) LOG.debug("power = " + p + "^" + exponent + " = " + power_long + " > pMax=" + pMax + ", not added");
						break;
					}
					int power = (int) power_long;
					if (DEBUG) {
						// The powers strictly have Jacobi(kN|p) > 0, too
						int jacobi = new JacobiSymbol().jacobiSymbol(kN, (int)power);
						assertTrue(jacobi>0);
					}
					if (power>pMin) {
						if (DEBUG) LOG.debug("Add power = " + p + "^" + exponent + " = " + power);
						// We only sieve with powers that give the full contribution.
						// This needs InitializerCalculator.SPECIAL, where the p of these powers are not added to the initializer.
						byte logPower = (byte) (Math.log(power) * lnPMultiplier + 0.5F);
						// We need the solution t of t^2 == kN (mod p) to compute the solution u of u^2 == kN (mod p^exponent)
						int u = modularSqrtEngine.modularSqrtModPower(kN_UBI.mod(power), power, last_power, filteredTArray[pIndex]);
						powerEntries.add(new PowerEntry(p, power, u, logPower));
						// The next power of p would have contribution log(p) only
						break;
					} else {
						if (DEBUG) LOG.debug("power = " + p + "^" + exponent + " = " + power + " < pMin=" + pMin + ", not added");
					}
				}
			}
		}
		return powerEntries;
	}
}
