// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor.siqs.tdiv;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import de.tilman_neumann.math.base.bigint.UnsignedBigInt;
import de.tilman_neumann.math.base.bigint.primes.ProbablePrimeTest;
import de.tilman_neumann.math.factor.basics.SortedIntegerArray;
import de.tilman_neumann.math.factor.basics.congruence.AQPair;
import de.tilman_neumann.math.factor.basics.congruence.Partial_1Large;
import de.tilman_neumann.math.factor.basics.congruence.Partial_2Large;
import de.tilman_neumann.math.factor.basics.congruence.Smooth_1LargeSquare;
import de.tilman_neumann.math.factor.basics.congruence.Smooth_Perfect;
import de.tilman_neumann.math.factor.basics.matrixSolver.MatrixSolver01_Gauss;
import de.tilman_neumann.math.factor.siqs.PolySolutions;
import de.tilman_neumann.math.factor.siqs.SIQS;
import de.tilman_neumann.math.factor.siqs.SIQSPolyBuilder01;
import de.tilman_neumann.math.factor.siqs.sieve.Sieve03f;
import de.tilman_neumann.math.factor.squfof.SquFoF31;
import de.tilman_neumann.math.factor.squfof.SquFoF63;

import static org.junit.Assert.*;

/**
 * A trial division engine where partials can have up to 2 large factors.
 * This is absolutely adequate for the quadratic sieve, because we would hardly get 3 large factors for inputs < 400 bit.
 * 
 * Division is carried out using UnsignedBigInt; this way less intermediate objects are created.
 * 
 * Faster than 1Large for approximately N>=220 bit.
 */
public class TDiv_QS_2Large_UBI implements TDiv_QS {
	private static final Logger LOG = Logger.getLogger(TDiv_QS_2Large_UBI.class);
	private static final boolean DEBUG = false;
	
	// factor argument and polynomial parameters
	private BigInteger kN;
	private BigInteger aParam, bParam;

	private float T;
	/** Q is sufficiently smooth if the unfactored Q_rest is smaller than this bound depending on N */
	private double maxUnfactoredRest;

	// prime base
	private int[] primesArray;
	private int primeBaseSize;
	private int pMax;
	private BigInteger pMaxSquare;
	private int[] unsievedPrimeBaseElements;

	private PolySolutions primeSolutions;

	/** buffers for trial division engine. */
	private UnsignedBigInt Q_rest_UBI = new UnsignedBigInt(new int[50]);
	private UnsignedBigInt quotient_UBI = new UnsignedBigInt(new int[50]);

	/** the indices of the primes found to divide Q in pass 1 */
	private int[] pass2Primes = new int[100];

	private ProbablePrimeTest probablePrimeTest;
	/** Auxiliary factorizer for Q_rest <= 2^42 */
	private SquFoF31 squFoF31;
	/** Auxiliary factorizer for Q_rest in the range 2^43 <= Q_rest <= 2^67 */
	private SquFoF63 squFoF63;
	/** Nested SIQS for Q_rest >= 68 bit. Required only for approximately N>400 bit. */
	private SIQS qsInternal;
	                        
	// smallest solutions of Q(x) == A(x)^2 (mod p)
	private int[] x1Array, x2Array;

	// result: two arrays that are reused, their content is _copied_ to AQ-pairs
	private SortedIntegerArray smallFactors = new SortedIntegerArray();
	
	// statistics
	private long testCount, sufficientSmoothCount;

	public TDiv_QS_2Large_UBI(int primeTestBits, float T) {
		this.T = T;
		this.probablePrimeTest = new ProbablePrimeTest(primeTestBits);
		this.squFoF31 = new SquFoF31(primeTestBits);
		this.squFoF63 = new SquFoF63(primeTestBits);
		this.qsInternal = new SIQS(primeTestBits, 0.32F, 0.42F, new SIQSPolyBuilder01(), new Sieve03f(0.16F, 110, 1.4F), new TDiv_QS_1Large_UBI(primeTestBits, 0.18F), 10, new MatrixSolver01_Gauss<Integer>(), false);
	}

	@Override
	public String getName() {
		return "TDiv_2L_UBI(" + T + ")";
	}

	@Override
	public void initialize(double N_dbl, BigInteger kN) {
		// compute the biggest unfactored rest where some Q is considered smooth enough for a congruence.
		this.maxUnfactoredRest = Math.pow(N_dbl, T);
		if (DEBUG) LOG.debug("maxUnfactoredRest = " + maxUnfactoredRest + " (" + (64-Long.numberOfLeadingZeros((long)maxUnfactoredRest)) + " bits)");
		this.kN = kN;
		// statistics
		this.testCount = 0;
		this.sufficientSmoothCount = 0;
	}

	@Override
	public void setPrimeSolutions(BigInteger a, BigInteger b, PolySolutions primeSolutions, int[] unsievedPrimeBaseElements) {
		this.aParam = a;
		this.bParam = b;
		this.primeSolutions = primeSolutions;
		this.primesArray = primeSolutions.primesOrPowers;
		this.primeBaseSize = primesArray.length;
		this.pMax = primesArray[primeBaseSize-1];
		this.pMaxSquare = BigInteger.valueOf(pMax * (long) pMax);
		this.unsievedPrimeBaseElements = unsievedPrimeBaseElements;
	}

	@Override
	public void setBParameter(BigInteger b) {
		this.bParam = b;
	}

	@Override
	public List<AQPair> testList(List<Integer> xList) {
		// initialize some variables
		x1Array = primeSolutions.x1Array;
		x2Array = primeSolutions.x2Array;

		// do trial division with sieve result
		ArrayList<AQPair> aqPairs = new ArrayList<AQPair>();
		for (int x : xList) {
			smallFactors.reset();
			testCount++;
			BigInteger A = aParam.multiply(BigInteger.valueOf(x)).add(bParam); // A(x) = a*x+b
			BigInteger Q = A.multiply(A).subtract(kN); // Q(x) = A(x)^2 - kN
			AQPair aqPair = test(A, Q, x);
			if (aqPair != null) {
				// Q(x) was found sufficiently smooth to be considered a (partial) congruence
				aqPairs.add(aqPair);
				sufficientSmoothCount++;
				if (DEBUG) {
					LOG.debug("Found congruence " + aqPair);
					assertEquals(A.multiply(A).mod(kN), Q.mod(kN));
				}
			}
		}
		return aqPairs;
	}
	
	private AQPair test(BigInteger A, BigInteger Q, int x) {
		// sign
		BigInteger Q_rest = Q;
		if (Q.signum() < 0) {
			smallFactors.add(-1);
			Q_rest = Q.negate();
		}
		
		// Remove multiples of 2
		int lsb = Q_rest.getLowestSetBit();
		if (lsb > 0) {
			smallFactors.add(2, (short)lsb);
			Q_rest = Q_rest.shiftRight(lsb);
		}

		// Unsieved prime base elements are added directly to pass 2.
		int pass2Count = unsievedPrimeBaseElements!=null ? unsievedPrimeBaseElements.length : 0;
		if (pass2Count>0) {
			System.arraycopy(unsievedPrimeBaseElements, 0, pass2Primes, 0, pass2Count);
		}
		
		// Pass 1: test solution arrays
		for (int pIndex = primeBaseSize-1; pIndex > 0; pIndex--) { // p[0]=2 was already tested
			int p = primesArray[pIndex];
			int xModP = x % p;
			if (xModP<0) xModP += p; // make remainder non-negative for negative x
			if (DEBUG) {
				if (xModP<0) LOG.debug("x=" + x + ", p=" + p + " -> x % p = " + xModP + ", x1 = " + x1Array[pIndex] + ", x2 = " + x2Array[pIndex]);
				assertTrue(0<=xModP && xModP<p);
			}
			if (xModP==x1Array[pIndex] || xModP==x2Array[pIndex]) {
				pass2Primes[pass2Count++] = p;
			}
		}
	
		// Pass 2: remove further occurrences of the p_i that were found to divide Q
		Q_rest_UBI.set(Q_rest);
		for (int pass2Index = 0; pass2Index < pass2Count; pass2Index++) {
			int p = pass2Primes[pass2Index];
			while (true) {
				int rem = Q_rest_UBI.divideAndRemainder(p, quotient_UBI);
				if (rem>0) break;
				// remainder == 0 -> the division was exact. assign quotient to Q_rest and add p to factors
				UnsignedBigInt tmp = Q_rest_UBI;
				Q_rest_UBI = quotient_UBI;
				quotient_UBI = tmp;
				smallFactors.add(p);
				if (DEBUG) {
					BigInteger pBig = BigInteger.valueOf(p);
					BigInteger[] div = Q_rest.divideAndRemainder(pBig);
					assertEquals(div[1].intValue(), rem);
					Q_rest = div[0];
				}
			}
		}
		if (Q_rest_UBI.isOne()) return new Smooth_Perfect(A, smallFactors);
		Q_rest = Q_rest_UBI.toBigInteger();
		
		// Division by all p<=pMax was not sufficient to factor Q completely.
		// The remaining Q_rest is either a prime > pMax, or a composite > pMax^2.
		if (Q_rest.doubleValue() >= maxUnfactoredRest) return null; // Q is not sufficiently smooth
		
		// now we consider Q as sufficiently smooth. then we want to know all prime factors!
		if (DEBUG) LOG.debug("test(): pMax=" + pMax + " < Q_rest=" + Q_rest + " < maxUnfactoredRest=" + maxUnfactoredRest + " -> resolve all factors");
		if (Q_rest.compareTo(pMaxSquare)<0) {
			// we divided Q_rest by all primes <= pMax and we have Q_rest < pMax^2 -> it must be prime
			if (DEBUG) assertTrue(probablePrimeTest.isProbablePrime(Q_rest));
			return new Partial_1Large(A, smallFactors, Q_rest.longValue());
		}
		// now we need isProbablePrime(), because calling findSingleFactor() may not return when called with a prime argument
		if (probablePrimeTest.isProbablePrime(Q_rest)) {
			// Q_rest is a (probable) prime >= pMax^2. Such big factors do not help to find smooth congruences, so we ignore the partial.
			if (DEBUG) LOG.debug("factor_recurrent(): Q_rest = " + Q_rest + " is probable prime > pMax^2 -> ignore");
			return null;
		} // else: Q_rest is surely not prime
		
		// Q_rest is odd and has two factors, each greater than pMax
		BigInteger factor1;
		int Q_rest_bits = Q_rest.bitLength();
		if (Q_rest_bits < 43) {
			if (DEBUG) LOG.debug("test(): pMax^2 = " + pMaxSquare + ", Q_rest = " + Q_rest + " (" + Q_rest_bits + " bits) not prime -> use squFoF31");
			factor1 = squFoF31.findSingleFactor(Q_rest);
		} else if (Q_rest_bits < 68) {
			if (DEBUG) LOG.debug("test(): pMax^2 = " + pMaxSquare + ", Q_rest = " + Q_rest + " (" + Q_rest_bits + " bits) not prime -> use squFoF63");
			factor1 = squFoF63.findSingleFactor(Q_rest);
		} else {
			factor1 = qsInternal.findSingleFactor(Q_rest);
		}
		BigInteger factor2 = Q_rest.divide(factor1);
		if (DEBUG) LOG.debug("test(): Q_rest = " + Q_rest + " (" + Q_rest_bits + " bits) = " + factor1 + " * " + factor2);
		if (factor1.equals(factor2)) {
			return new Smooth_1LargeSquare(A, smallFactors, factor1.longValue());
		}
		return new Partial_2Large(A, smallFactors, factor1.longValue(), factor2.longValue());
	}

	@Override
	public String getReportString() {
		float percentage = ((int) (0.5F + sufficientSmoothCount*10000 / (float) testCount)) / 100F; // 2 after-comma digits
		return "tested " + testCount + " smooth-candidates and let " + sufficientSmoothCount + " (" + percentage + "%) pass";
	}
	
	@Override
	public void cleanUp() {
		primesArray = null;
		unsievedPrimeBaseElements = null;
		x1Array = null;
		x2Array = null;
		qsInternal.cleanUp();
	}
}
