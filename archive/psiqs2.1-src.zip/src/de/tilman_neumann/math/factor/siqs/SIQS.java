// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor.siqs;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import de.tilman_neumann.math.base.bigint.PurePowerTest;
import de.tilman_neumann.math.factor.FactorAlgorithmBase;
import de.tilman_neumann.math.factor.FactorException;
import de.tilman_neumann.math.factor.basics.congruence.AQPair;
import de.tilman_neumann.math.factor.basics.congruence.CongruenceCollector;
import de.tilman_neumann.math.factor.basics.congruence.Partial;
import de.tilman_neumann.math.factor.basics.congruence.Smooth;
import de.tilman_neumann.math.factor.basics.matrixSolver.FactorTest;
import de.tilman_neumann.math.factor.basics.matrixSolver.FactorTest01;
import de.tilman_neumann.math.factor.basics.matrixSolver.MatrixSolver;
import de.tilman_neumann.math.factor.basics.matrixSolver.MatrixSolver02_BlockLanczos;
import de.tilman_neumann.math.factor.basics.matrixSolver.SmoothSolverController;
import de.tilman_neumann.math.factor.basics.primeBase.PrimeBaseBuilder;
import de.tilman_neumann.math.factor.basics.primeBase.PrimeBaseBuilder02;
import de.tilman_neumann.math.factor.siqs.sieve.Sieve;
import de.tilman_neumann.math.factor.siqs.sieve.Sieve03f;
import de.tilman_neumann.math.factor.siqs.tdiv.TDiv_QS;
import de.tilman_neumann.math.factor.siqs.tdiv.TDiv_QS_nLarge_UBI;
import de.tilman_neumann.util.ConfigUtil;
import de.tilman_neumann.util.TimeUtil;
import de.tilman_neumann.util.Timer;

import static de.tilman_neumann.math.base.bigint.BigIntConstants.*;

/**
 * Main class for single-threaded SIQS implementations.
 */
public class SIQS extends FactorAlgorithmBase {
	private static final Logger LOG = Logger.getLogger(SIQS.class);
	private static final boolean DEBUG = false;
	private static final boolean TEST_SIEVE = false;
	
	/** use profile=true to generate timing informations */
	private boolean profile;
	
	// pure power test
	private PurePowerTest powerTest = new PurePowerTest();
	/** Algorithm to compute the multiplier k */
	private MultiplierFinder multiplierFinder = MultiplierFinder.KNUTH_SCHROEPPEL;
	// prime base
	private float Cmult;
	private PrimeBaseBuilder primeBaseBuilder = new PrimeBaseBuilder02();
	// polynomial builder
	private SIQSPolyBuilder polyBuilder;
	// sieve
	private float Mmult;
	private Sieve sieve;
	// trial division engine
	private TDiv_QS auxFactorizer;
	// collects the congruences we find
	private CongruenceCollector congruenceCollector;
	// extra congruences to have a bigger chance that the equation system solves. the likelihood is >= 1-2^(extraCongruences+1)
	private int extraCongruences;
	// A controller for the solver used for smooth congruence equation systems.
	private SmoothSolverController solverController;
	
	/**
	 * Standard constructor.
	 * @param primeTestBits
	 * @param Cmult multiplier for prime base size
	 * @param Mmult multiplier for sieve array size
	 * @param polyBuilder
	 * @param sieve the sieve algorithm
	 * @param auxFactorizer
	 * @param extraCongruences the number of surplus congruences we collect to have a greater chance that the equation system solves.
	 * @param matrixSolver matrix solver for the smooth congruence equation system
	 * @param profile use profile=true to generate timing informations
	 */
	public SIQS(int primeTestBits, float Cmult, float Mmult, SIQSPolyBuilder polyBuilder, Sieve sieve, TDiv_QS auxFactorizer, 
			  int extraCongruences, MatrixSolver<Integer> matrixSolver, boolean profile) {
		
		super(primeTestBits);
		this.Cmult = Cmult;
		this.Mmult = Mmult;
		this.polyBuilder = polyBuilder;
		this.sieve = sieve;
		this.congruenceCollector = new CongruenceCollector();
		this.auxFactorizer = auxFactorizer;
		this.extraCongruences = extraCongruences;
		this.solverController = new SmoothSolverController(matrixSolver);
		this.profile = profile;
		// Register sub-engines that shall be accessible to the polynomial generator.
		polyBuilder.setSubEngines(sieve, auxFactorizer);
	}

	@Override
	public String getName() {
		return "SIQS(Cmult=" + Cmult + ", Mmult=" + Mmult + ", " + polyBuilder.getName() + ", " + sieve.getName() + ", " + auxFactorizer.getName() + ", " + solverController.getName() + ")";
	}
	
	/**
	 * Test the current N.
	 * @return factor, or null if no factor was found.
	 */
	public BigInteger findSingleFactor(BigInteger N) {
		Timer timer = new Timer(); // start timer
		
		// the quadratic sieve does not work for pure powers; check that first:
		PurePowerTest.Result purePower = powerTest.test(N);
		if (purePower!=null) {
			// N is indeed a pure power -> return a factor that is about sqrt(N)
			return purePower.base.pow(purePower.exponent>>1);
		}
		
		// no pure power, run quadratic sieve
		long initNDuration = 0;
		long initPolyDuration = 0;
		long sieveDuration = 0;
		long tdivDuration = 0;
		long ccDuration = 0;
		long solverDuration = 0;
		long solverRunCount = 0;
		
		// compute prime base size
		double N_dbl = N.doubleValue();
		double lnN = Math.log(N_dbl);
		double lnlnN = Math.log(lnN);
		double lnNPow = 0.5; // heuristics for quadratic sieve
		double lnTerm = Math.pow(lnN, lnNPow) * Math.pow(lnlnN, 1-lnNPow); // we want that the exponents of lnN and lnlnN sum to 1
		double primeBaseSize_dbl = Math.exp(lnTerm * Cmult);
		if (primeBaseSize_dbl > Integer.MAX_VALUE) throw new IllegalStateException("primeBaseSize=" + primeBaseSize_dbl + " is too big for int!");
		int primeBaseSize = Math.max(10, (int) primeBaseSize_dbl); // min. size for very small N
		int[] primesArray = new int[primeBaseSize];

		// the number of congruences we need to find before we try to solve the smooth congruence equation system
		int requiredSmoothCongruenceCount = primeBaseSize + extraCongruences;

		// compute multiplier k for N according to the given style
		int k = multiplierFinder.computeMultiplier(N, primeBaseSize);
		BigInteger kN = BigInteger.valueOf(k).multiply(N);
		
		// Create the reduced prime base for kN:
		primeBaseBuilder.computeReducedPrimeBase(kN, primeBaseSize, primesArray);
		
		// compute sieve array size, a multiple of 256
		int pMax = primesArray[primeBaseSize-1];
		long proposedSieveArraySize = 6144 + (long) Math.exp(lnTerm * Mmult); // 6144 = best experimental result for small N
		long tooBig = proposedSieveArraySize+pMax - Integer.MAX_VALUE;
		if (tooBig > 0) proposedSieveArraySize -= tooBig;
		int adjustedSieveArraySize = (int) (proposedSieveArraySize & 0x7FFFFF00);
		//LOG.debug("N=" + N + ", k=" + k + ": pMax=" + pMax + ", sieve array size was adjusted from " + proposedSieveArraySize + " to " + adjustedSieveArraySize);

		// initialize sub-algorithms for new N
		int polyCount = 0;
		this.polyBuilder.initialize(k, N, kN, primeBaseSize, primesArray, adjustedSieveArraySize, profile);
		FactorTest factorTest = new FactorTest01(N);
		this.congruenceCollector.initialize(N, factorTest, profile);
		this.solverController.initialize(N, factorTest);
		if (profile) initNDuration += timer.capture();

		try {
			while (true) {
				// create new polynomial Q(x)
				polyBuilder.nextPolynomial(); // sets filtered prime base in SIQS
				polyCount++;
				if (profile) initPolyDuration += timer.capture();
	
				// run sieve and get the sieve locations x where Q(x) is sufficiently smooth
				List<Integer> smoothXList = sieve.sieve();
				if (profile) sieveDuration += timer.capture();
				//LOG.debug("Sieve found " + smoothXList.size() + " Q(x) smooth enough to be passed to trial division.");

				// trial division stage: produce AQ-pairs
				List<AQPair> aqPairs = this.auxFactorizer.testList(smoothXList);
				//LOG.debug("Trial division found " + aqPairs.size() + " Q(x) smooth enough for a congruence.");
				if (TEST_SIEVE) testSieve(aqPairs, adjustedSieveArraySize);
				if (profile) tdivDuration += timer.capture();

				// add all congruences
				for (AQPair aqPair : aqPairs) {
					boolean addedSmooth = congruenceCollector.add(aqPair);
					if (addedSmooth) {
						int smoothCongruenceCount = congruenceCollector.getSmoothCongruenceCount();
						if (smoothCongruenceCount >= requiredSmoothCongruenceCount) {
							// try to solve equation system
							if (profile) ccDuration += timer.capture();
							solverRunCount++;
							if (DEBUG) LOG.debug("run " + solverRunCount + ": #smooths = " + smoothCongruenceCount + ", #requiredSmooths = " + requiredSmoothCongruenceCount);
							solverController.solve(congruenceCollector.getSmoothCongruences()); // throws FactorException
							// if we get here then there was no FactorException
							if (profile) solverDuration += timer.capture();
							// Extend equation system and continue searching smooth congruences
							requiredSmoothCongruenceCount += extraCongruences;
						}
					}
				}
				if (profile) ccDuration += timer.capture();
				if (DEBUG) {
					LOG.debug(polyBuilder.getName() + " #" + polyCount + ": Sieve found " + smoothXList.size() + " smooth x, tDiv let " + aqPairs.size() + " pass.");
					LOG.debug("-> Now in total we have found " + congruenceCollector.getSmoothCongruenceCount() + " / " + requiredSmoothCongruenceCount + " smooth congruences and " + congruenceCollector.getPartialCongruenceCount() + " partials.");
				}
			} // end poly
		} catch (FactorException fe) {
			if (profile) {
				solverDuration += timer.capture();
				// add the last cc-timing that have not been added yet because of the FactorException 
				BigInteger factor = fe.getFactor();
				LOG.info(getName() + ": Found factor " + factor + " (" + factor.bitLength() + " bits) of N=" + N + " in " + TimeUtil.timeStr(timer.totalRuntime()));
				int pMaxBits = 32 - Integer.numberOfLeadingZeros(pMax);
				LOG.info("    multiplier k = " + k + ", primeBaseSize = " + primeBaseSize + ", pMax = " + pMax + " (" + pMaxBits + " bits), sieveArraySize = " + adjustedSieveArraySize + ", #processed polynomials = " + polyCount);
				LOG.info("    tDiv " + auxFactorizer.getReportString());
				LOG.info("    cc " + congruenceCollector.getReportString());
				LOG.info("    #solverRuns = " + solverRunCount + ", #tested null vectors = " + solverController.getTestedNullVectorCount());
				LOG.info("    Phase timings: initN=" + initNDuration + "ms, initPoly=" + initPolyDuration + "ms, sieve=" + sieveDuration + "ms, tdiv=" + tdivDuration + "ms, cc=" + ccDuration + "ms, solver=" + solverDuration + "ms");
				String polyInitSubTimings = polyBuilder.getProfilingReport();
				if (polyInitSubTimings!=null) LOG.info("    -> initPoly sub-timings: " + polyInitSubTimings);
				String sieveSubTimings = sieve.getProfilingReport();
				if (sieveSubTimings!=null) LOG.info("    -> sieve sub-timings: " + sieveSubTimings);
			} else {
				if (solverRunCount>1) LOG.info(getName() + ": Factoring N="+N + " required " + solverRunCount + " solverRuns and " + solverController.getTestedNullVectorCount() + " tested null vectors");
			}
			// release memory after a factorization; this improves the accuracy of timings when several algorithms are tested in parallel
			this.cleanUp();
			// return factor
			return fe.getFactor();
		}
	}

	public void cleanUp() {
		polyBuilder.cleanUp();
		sieve.cleanUp();
		auxFactorizer.cleanUp();
		congruenceCollector.cleanUp();
		solverController.cleanUp();
	}
	
	private void testSieve(List<AQPair> foundAQPairs, int sieveArraySize) {
		int foundPerfectSmoothCount = 0;
		for (AQPair aqPair : foundAQPairs) {
			if ((aqPair instanceof Smooth) || (aqPair instanceof Partial && ((Partial)aqPair).getMatrixElements().length==0)) foundPerfectSmoothCount++;
		}
		int allPerfectSmoothCount = 0;
		ArrayList<Integer> allXList = new ArrayList<Integer>();
		allXList.add(0);
		for (int x=1; x<sieveArraySize; x++) {
			allXList.add(x);
			allXList.add(-x);
		}
		List<AQPair> allAQPairs = this.auxFactorizer.testList(allXList);
		for (AQPair aqPair : allAQPairs) {
			if ((aqPair instanceof Smooth) || (aqPair instanceof Partial && ((Partial)aqPair).getMatrixElements().length==0)) allPerfectSmoothCount++;
		}
		float perfectSmoothPercentage = foundPerfectSmoothCount*100 / (float) allPerfectSmoothCount;
		float partialPercentage = (foundAQPairs.size()-foundPerfectSmoothCount)*100 / (float) (allAQPairs.size()-allPerfectSmoothCount);
		LOG.debug("sieve found " + perfectSmoothPercentage + " % of perfectly smooth and " + partialPercentage + " % of partial congruences");
	}

	// Standalone test --------------------------------------------------------------------------------------------------
	
	private static final BigInteger N_MAX = THOUSAND;
	private static final boolean RUN_FOREVER = false;

	/**
	 * Test numbers:
	 * 11111111111111111111111111
	 * 5679148659138759837165981543
	 * 11111111111111111111111111155555555555111111111111111
	 */
	private static void testInput() {
		while(true) {
			try {
				LOG.info("Please insert the number to factor:");
				BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
				String input = in.readLine().trim();
				//LOG.debug("input = >" + input + "<");
				BigInteger N = new BigInteger(input);
				LOG.info("Factoring " + N + " ...");
				SIQS qs = new SIQS(20, 0.32F, 0.37F, new SIQSPolyBuilder01(), new Sieve03f(0.16F, 110, 1.4F), new TDiv_QS_nLarge_UBI(20, 0.18F), 10, new MatrixSolver02_BlockLanczos<Integer>(), true);
				BigInteger factor = qs.findSingleFactor(N);
				if (factor != null) {
					LOG.info("Found factor " + factor);
				} else {
					LOG.info("No factor found, another k is recommended.");
				}
			} catch (Exception ex) {
				LOG.error("Error " + ex, ex);
			}
		}
	}
	
	@SuppressWarnings("unused")
	private static void testSmall() {
		BigInteger testCount = ZERO;
		BigInteger factorCount = ZERO;
		for (BigInteger N = THREE; ; N=N.add(TWO)) {
			if (N.compareTo(N_MAX)>0 && !RUN_FOREVER) break;
			// we do not want to test primes...
			if (N.isProbablePrime(20)) continue;
			
			// now N is ok
			LOG.info("Factoring " + N + " ...");
			try {
				SIQS qs = new SIQS(20, 0.32F, 0.37F, new SIQSPolyBuilder01(null), new Sieve03f(0.16F, 110, 1.4F), new TDiv_QS_nLarge_UBI(20, 0.18F), 10, new MatrixSolver02_BlockLanczos<Integer>(), true);
				BigInteger factor = qs.findSingleFactor(N);
				if (factor != null) {
					LOG.info("Found factor " + factor);
					factorCount = factorCount.add(ONE);
				} else {
					LOG.info("No factor found, another k is recommended.");
				}
			} catch (Exception ex) {
				LOG.error("Error " + ex, ex);
			}
			testCount = testCount.add(ONE);
		}
		LOG.info("#(factored N): " + factorCount + " of " + testCount);
	}
	
	/**
	 * Test of input k, N and #iterations.
	 * @param args ignored
	 */
	public static void main(String[] args) {
    	ConfigUtil.initProject();
    	testInput();
    	//testSmall();
	}
}
