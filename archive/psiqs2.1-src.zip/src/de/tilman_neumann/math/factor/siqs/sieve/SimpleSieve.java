// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor.siqs.sieve;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import de.tilman_neumann.math.factor.siqs.PolySolutions;
import de.tilman_neumann.util.Timer;

/**
 * Simple non-segmented sieve.
 */
public class SimpleSieve implements Sieve {
	private static final Logger LOG = Logger.getLogger(SimpleSieve.class);
	private static final boolean DEBUG = false;

	/** basic building block for fast zero-initialization of sieve array */
	private static final byte[] ZERO_ARRAY_256 = new byte[256];
	
	// factor argument data
	private float lnN;
	private double lnkN;

	// prime base
	private int primeBaseSize;
	private int[] primesArray;
	private float lnPMultiplier;
	
	private PolySolutions primeSolutions;

	// sieve
	/** Algorithm to compute the logPSum threshold value */
	private SieveBoundCalculator sieveBoundCalculator = SieveBoundCalculator.N_BASED;
	private float T;
	private int sieveArraySize;
	private int wantedMinLogPSum, minLogPSum;
	private byte[] sieve_logPSumArray = null; // null indicates that allocation is required
	private byte[] sieve_logPSumArray_neg;
	
	// timings
	private boolean profile;
	private Timer timer = new Timer();
	private long initDuration, sieveDuration, collectDuration;
	
	/**
	 * Full constructor.
	 * @param T the T parameter: reasonable values are T ~ 0.16 for SieveBoundCalculator.N_BASED, T ~ 2.0 for SieveBoundCalculator.PMAX_BASED
	 * @param wantedMinLogPSum values between 70..120 seem best (experimental results)
	 */
	public SimpleSieve(float T, int wantedMinLogPSum) {
		this.T = T;
		this.wantedMinLogPSum = wantedMinLogPSum;
	}
	
	@Override
	public String getName() {
		return "simpleSieve(" + T + ", " + wantedMinLogPSum + ")";
	}
	
	@Override
	public void initialize(double N_dbl, BigInteger kN, int unfilteredPrimeBaseSize, int[] unfilteredPrimesArray, int[] unfilteredTArray, int sieveArraySize, boolean profile) {
		this.lnN = (float) Math.log(N_dbl);
		lnkN = Math.log(kN.doubleValue());

		this.sieveArraySize = sieveArraySize;
		
		// Compute sieve bound in natural logarithm & convert to the actual logBase:
		int pMax = unfilteredPrimesArray[unfilteredPrimeBaseSize-1];
		double minLnPSum = sieveBoundCalculator.computeSieveBound(T, lnN, lnkN, pMax, sieveArraySize);
		float lnLogBase = (float) (minLnPSum / wantedMinLogPSum);
		minLogPSum = (int) (minLnPSum / lnLogBase); // floor, result should be ~wantedMinLogPSum
		if (DEBUG) {
			float logBase = (float) Math.exp(lnLogBase);
			LOG.debug("logBase=" + logBase + ", lnLogBase=" + lnLogBase + ", minLnPSum = " + minLnPSum + ", minLogPSum = " + minLogPSum);
		}
		lnPMultiplier = 1.0F/lnLogBase;

		// profiling
		this.profile = profile;
		initDuration = sieveDuration = collectDuration = 0;
	}

	@Override
	public float getLnPMultiplier() {
		return lnPMultiplier;
	}

	@Override
	public void setPrimeSolutions(PolySolutions primeSolutions) {
		this.primeSolutions = primeSolutions;
		this.primesArray = primeSolutions.primesOrPowers;
		this.primeBaseSize = primesArray.length;
	}

	@Override
	public List<Integer> sieve() {
		if (profile) timer.capture();
		this.initializeSieveArray(sieveArraySize);
		if (profile) initDuration += timer.capture();

		int[] x1Array = primeSolutions.x1Array;
		int[] x2Array = primeSolutions.x2Array;
		byte[] logPArray = primeSolutions.logPArray;

		// sieve with p[0]=2: here we use only solution x1
		//assertEquals(1, ldPArray[0]);
		int x1min = x1Array[0];
		byte logP = logPArray[0];
		for (int x1=x1min; x1<sieveArraySize; x1+=2) {
			sieve_logPSumArray[x1] += logP;
		}
		// same for the neg.x array
		for (int x1_neg=2-x1min; x1_neg<sieveArraySize; x1_neg+=2) {
			sieve_logPSumArray_neg[x1_neg] += logP;
		}
		// sieve with odd primes
		for (int i=1; i<primeBaseSize; i++) {
			// solution x1
			x1min = x1Array[i];
			int p = primesArray[i];
			logP = logPArray[i];
			for (int x1=x1min; x1<sieveArraySize; x1+=p) {
				sieve_logPSumArray[x1] += logP;
			}
			for (int x1_neg=p-x1min; x1_neg<sieveArraySize; x1_neg+=p) {
				sieve_logPSumArray_neg[x1_neg] += logP;
			}
			// solution x2: x1 == x2 happens in any of (basic QS, MPQS, SIQS) if p divides k, which implies t=0
			int x2min = x2Array[i];
			if (x2min != x1min) {
				for (int x2=x2min; x2<sieveArraySize; x2+=p) {
					sieve_logPSumArray[x2] += logP;
				}
				for (int x2_neg=p-x2min; x2_neg<sieveArraySize; x2_neg+=p) {
					sieve_logPSumArray_neg[x2_neg] += logP;
				}
			} // else x2min==x1min -> do not sieve with the same x twice
		}
		if (profile) sieveDuration += timer.capture();

		// collect results
		List<Integer> smoothXList = new ArrayList<Integer>();
		// let the sieve entry counter x run down to 0 is much faster because of the simpler exit condition
		for (int x=sieveArraySize-1; x>=0; x--) {
			if (sieve_logPSumArray[x] >= minLogPSum) { // x is positive
				// Q is sufficiently smooth to be passed to trial division!
				smoothXList.add(x);
			}
			if (sieve_logPSumArray_neg[x] >= minLogPSum) {
				// Q(-x) is sufficiently smooth to be passed to trial division!
				smoothXList.add(-x);
			}
		} // end for (x)
		if (profile) collectDuration += timer.capture();
		return smoothXList;
	}

	/**
	 * Initialize the sieve array(s) with zeros.
	 * @param sieveArraySize
	 */
	private void initializeSieveArray(int sieveArraySize) {
		// On the first initialization the array is allocated.
		// The next initializations use System.arraycopy(), which is much faster.
		// The copying procedure requires that sieveArraySize is a multiple of 256.
		if (sieve_logPSumArray==null) {
			sieve_logPSumArray = new byte[sieveArraySize];
			sieve_logPSumArray_neg = new byte[sieveArraySize];
		} else {
			// overwrite existing arrays with zeros. we know that sieve array size is a multiple of 256
			System.arraycopy(ZERO_ARRAY_256, 0, sieve_logPSumArray, 0, 256);
			int filled = 256;
			int unfilled = sieveArraySize-filled;
			while (unfilled>0) {
				int fillNext = Math.min(unfilled, filled);
				System.arraycopy(sieve_logPSumArray, 0, sieve_logPSumArray, filled, fillNext);
				filled += fillNext;
				unfilled = sieveArraySize-filled;
			}
			System.arraycopy(sieve_logPSumArray, 0, sieve_logPSumArray_neg, 0, sieveArraySize);
		}
	}

	@Override
	public String getProfilingReport() {
		return "init=" + initDuration + "ms, sieve=" + sieveDuration + "ms, collect=" + collectDuration + "ms";
	}
	
	@Override
	public void cleanUp() {
		primesArray = null;
		sieve_logPSumArray = null;
		sieve_logPSumArray_neg = null;
	}
}
