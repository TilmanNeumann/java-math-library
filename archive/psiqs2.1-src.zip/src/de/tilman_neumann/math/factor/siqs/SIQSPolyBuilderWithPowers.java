// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor.siqs;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.TreeSet;

import org.apache.log4j.Logger;

import de.tilman_neumann.math.base.bigint.ModularSqrt;
import de.tilman_neumann.math.base.bigint.UnsignedBigInt;
import de.tilman_neumann.math.base.smallint.EEA31;
import de.tilman_neumann.math.base.smallint.ModularSqrt31;
import de.tilman_neumann.math.factor.siqs.PowerFinder.PowerEntry;
import de.tilman_neumann.math.factor.siqs.sieve.Sieve;
import de.tilman_neumann.math.factor.siqs.sieve.SieveWithPowers;
import de.tilman_neumann.math.factor.siqs.tdiv.TDiv_QS;
import de.tilman_neumann.util.Timer;

import static de.tilman_neumann.math.base.bigint.BigIntConstants.*;
import static org.junit.Assert.*;

/**
 * A SIQS polynomial builder that also creates solutions of Q(x) == 0 (mod p^exponent), exponent>1, which allows to sieve with prime powers.
 * Works only in combination with class SieveWithPowers.
 */
public class SIQSPolyBuilderWithPowers implements SIQSPolyBuilder {
	private static final Logger LOG = Logger.getLogger(SIQSPolyBuilderWithPowers.class);
	private static final boolean DEBUG = false;

	private BigInteger a;
	private UnsignedBigInt a_UBI;
	private BigInteger b;
	private UnsignedBigInt b_UBI;
	private BigInteger kN;
	private UnsignedBigInt kN_UBI;

	// prime base
	private int primeBaseSize;
	private int[] primesArray;
	private byte[] logPArray;
	private int pMinIndex, pMin, pMax;
	private float lnPMultiplier;
	
	/** the modular sqrt's t with t^2==kN (mod p) for all p */
	private int[] tArray;

	/** generator for a-parameters */
	private AParamGenerator aParamGenerator;
	
	/** the actual number of factors of the a-parameter for given kN */
	private int qCount;
	/** indices of the prime base elements that are the factors of a */
	private int[] qIndexArray;
	/** and the factors themselves */
	private int[] qArray;
	/** the number of b-values we can have for one a */
	private int maxBIndex;
	/** the number of b-values already used */
	private int bIndex;
	/** basic Bl required to compute b */
	private BigInteger[] B2Array;
	private UnsignedBigInt[] B2Array_UBI;
	
	// solution arrays
	private int primeSolutionsCount;
	private PolySolutions primeSolutions;
	/** unfiltered powers sorted bottom-up by p */
	private ArrayList<PowerEntry> powerEntries;
	/** filtered powers sorted bottom-up by power value */
	private TreeSet<PowerEntry> filteredPowerEntries;
	private int powerSolutionsCount;
	private PolySolutions powerSolutions;
	
	private ModularSqrt31 modularSqrtEngine = new ModularSqrt31();
	private EEA31 eea = new EEA31();

	private SieveWithPowers sieveEngine;
	private TDiv_QS tDivEngine;

	private PowerFinder powerFinder = new PowerFinder();
	
	// profiling
	private boolean profile;
	private Timer timer = new Timer();
	private long aDuration, firstBDuration, filterPBDuration, firstXArrayDuration, nextBDuration, nextXArrayDuration;

	/**
	 * Constructor for automatic qCount selection.
	 * @param wanted_qCount
	 */
	public SIQSPolyBuilderWithPowers() {
		this(null);
	}

	/**
	 * Full constructor.
	 * @param wanted_qCount
	 */
	public SIQSPolyBuilderWithPowers(Integer wanted_qCount) {
		this.aParamGenerator = new AParamGenerator01(wanted_qCount);
	}
	
	@Override
	public String getName() {
		return "SIQSPolyWithPowers";
	}

	@Override
	public void setSubEngines(Sieve sieveEngine, TDiv_QS tDivEngine) {
		if (!(sieveEngine instanceof SieveWithPowers)) {
			String requiredSieveClass = SieveWithPowers.class.getSimpleName();
			LOG.error(getName() + " works only in combination with class " + SieveWithPowers.class.getSimpleName());
			throw new IllegalStateException(getName() + " works only in combination with class " + requiredSieveClass);
		}
		this.sieveEngine = (SieveWithPowers) sieveEngine;
		this.tDivEngine = tDivEngine;
	}

	@Override
	public void initialize(int k, BigInteger N, BigInteger kN, int primeBaseSize, int[] primesArray, int sieveArraySize, boolean profile) {
		this.kN = kN;
		this.kN_UBI = new UnsignedBigInt(kN);
		this.primeBaseSize = primeBaseSize;
		this.primesArray = primesArray;
		this.pMax = primesArray[primeBaseSize-1];
		// compute the t with t^2 == kN (mod p) for all p
		this.tArray = computeTArray();
		
		// initialize sieve and tDiv engines
		double N_dbl = N.doubleValue();
		sieveEngine.initialize(N_dbl, kN, primeBaseSize, primesArray, tArray, sieveArraySize, profile);
		pMinIndex = sieveEngine.getPMinIndex();
		pMin = primesArray[pMinIndex]; // the smallest prime used for sieving
		tDivEngine.initialize(N_dbl, kN);

		// compute logPArray
		this.lnPMultiplier = sieveEngine.getLnPMultiplier();
		computeLogPArray();

		// For all p<pMin having 2 x-solutions, find the first powers>pMin. These are the only powers that add log(power) to the logPSum.
		// At first we collect them in a List sorted bottom up by primes p.
		powerEntries = powerFinder.findPowers(kN, primesArray, tArray, primeBaseSize, pMinIndex, pMin, pMax, lnPMultiplier);

		// initialize aParamGenerator for a new N; this includes the final determination of qCount
		this.aParamGenerator.initialize(k, N, kN, primeBaseSize, primesArray, sieveArraySize);
		this.qCount = aParamGenerator.getQCount();

		// B2: the array needs one more element because used indices start at 1.
		// the B2 entries are non-negative, so we can use UnsignedBigInt.mod(int), which is much faster than BigInteger.mod(BigInteger).
		// TODO: implement the UnsignedBigInt operations necessary to get rid of BigInteger[] B2Array
		this.B2Array = new BigInteger[qCount+1];
		this.B2Array_UBI = new UnsignedBigInt[qCount+1];
		// set bIndex=maxBIndex=0 to indicate that the first polynomial is wanted
		this.bIndex = this.maxBIndex = 0;
		
		// allocate filtered prime base and solution arrays
		this.primeSolutionsCount = primeBaseSize - qCount;
		primeSolutions = new PolySolutions(primeSolutionsCount, qCount);

		// profiling
		this.profile = profile;
		this.aDuration = 0;
		this.firstBDuration = 0;
		this.filterPBDuration = 0;
		this.firstXArrayDuration = 0;
		this.nextBDuration = 0;
		this.nextXArrayDuration = 0;
	}
	
	/**
	 * For all primes p in the prime base, find the modular sqrt's of kN (mod p), i.e. the t such that t^2 == kN (mod p).
	 */
	private int[] computeTArray() {
		int[] tArray = new int[primeBaseSize]; // zero-initialized
		// special treatment for p[0]=2 (always contained in prime base)
		tArray[0] = kN.and(ONE).intValue();
		// odd primes
		for (int i = primeBaseSize-1; i>0; i--) {
			// Tonelli_Shanks requires Legendre(kN|p)==1, 0 is not ok. But this is easy to "heal":
			// Since p is prime, Legendre(kN|p)==0 means that kN is a multiple of p.
			// Thus t^2 == kN == 0 (mod p) and the modular sqrt t is 0, too.
			int p = primesArray[i];
			int kN_mod_p = kN_UBI.mod(p);
			if (kN_mod_p > 0) {
				tArray[i] = modularSqrtEngine.Tonelli_Shanks(kN_mod_p, p);
			} // else: we do not need to set tArray[i] = 0, because the array has already been initialized with zeros
		}
		if (DEBUG) {
			assertEquals(BigInteger.valueOf(tArray[0]).pow(2).mod(TWO), kN.mod(TWO));
			ModularSqrt modularSqrtEngine_big = new ModularSqrt();
			for (int i = primeBaseSize-1; i>0; i--) {
				int p = primesArray[i];
				int kN_mod_p = kN_UBI.mod(p);
				if (kN_mod_p > 0) {
					assertEquals(tArray[i], modularSqrtEngine_big.Tonelli_Shanks(kN, p));
					assertEquals(tArray[i], modularSqrtEngine_big.Tonelli_Shanks(kN.mod(BigInteger.valueOf(p)), p));
				}
			}
		}
		return tArray;
	}
	
	public void computeLogPArray() {
		this.logPArray = new byte[primeBaseSize];
		for (int i=primeBaseSize-1; i>=0; i--) {
			logPArray[i] = (byte) ((float) Math.log(primesArray[i]) * lnPMultiplier + 0.5F);
		}
	}

	@Override
	public void nextPolynomial() {
		if (bIndex==maxBIndex) {
			// Incrementing bIndex would exceed the maximum value -> we need a new a-parameter.
			// Find a new a-parameter and its q_l-set:
			if (profile) timer.capture();
			a = aParamGenerator.computeNextAParameter();
			a_UBI = new UnsignedBigInt(a);
			qArray = aParamGenerator.getQArray();
			qIndexArray = aParamGenerator.getQIndexArray();
			maxBIndex = 1<<(qCount-1); // 2^(qCount-1)
			if (profile) aDuration += timer.capture();
			// compute the first b
			computeFirstBParameter();
			//LOG.debug("first a=" + a + ", b=" + b);
			bIndex = 1;
			if (profile) firstBDuration += timer.capture();
			// filter prime base
			filterPrimeBase();
			if (profile) filterPBDuration += timer.capture();
			// compute ainvp[], Bainv2[][] and solution x-arrays for a and first b
			computeFirstXArrays();
			computeFirstXArraysForPrimePowers();
			// pass data to sub-engines
			sieveEngine.setPrimeSolutions(primeSolutions);
			sieveEngine.setPrimePowerSolutions(powerSolutions);
			tDivEngine.setPrimeSolutions(a, b, primeSolutions, qArray);
			if (profile) firstXArrayDuration += timer.capture();
		} else {
			// compute the next b-parameter:
			// the gray code v with 2^v || 2*i in [Contini97] is the exponent
			// at which 2*i contains the 2. Here we have bIndex instead of Contini's "i".
			if (profile) timer.capture();
			int v = Integer.numberOfTrailingZeros(bIndex<<1);
			// bIndex/2^v is a half-integer. Therefore we have ceilTerm = ceil(bIndex/2^v) = bIndex/2^v + 1.
			// If ceilTerm is even, then (-1)^ceilTerm is positive and B_l[v] must be added.
			// Slightly faster is: if ceilTerm-1 = bIndex/2^v is odd then B_l[v] must be added.
			boolean bParameterNeedsAddition = ((bIndex/(1<<v))%2==1);
			b = bParameterNeedsAddition ? b.add(B2Array[v]) : b.subtract(B2Array[v]);
			b_UBI = new UnsignedBigInt(b);
			// WARNING: In contrast to the description in [Contini p.10, 2nd paragraph],
			// WARNING: b must not be computed (mod a) !
			tDivEngine.setBParameter(b);
			if (DEBUG) {
				assertTrue(0<v && v<qCount); // exact
				// Contini defines computations for (i+1)th polynomial in i
				// -> the second b-parameter is computed with i=1, the third b-parameter with i=2, etc.
				// -> do asserts involving bIndex before bIndex is incremented
				assertTrue((2*bIndex) % Math.pow(2, v) == 0);
				assertTrue((2*bIndex) % Math.pow(2, v+1) > 0);
				assertEquals(ZERO, b.multiply(b).subtract(kN).mod(a)); // we have b^2 == kN (mod a)
			}
			bIndex++;
			//LOG.debug("a=" + a + ": " + bIndex + ".th b=" + b + ", c=" + c);
			if (profile) nextBDuration += timer.capture();

			// Update solution arrays: 
			// Since only the array-content is modified, the x-arrays in poly are updated implicitly.
			// This approach would work in a multi-threaded SIQS implementation too, if we create a new thread for each new a-parameter.
			// Note that fix prime divisors depend only on a and k -> they do not change at a new b-parameter.
			computeNextXArrays(v, bParameterNeedsAddition);
			if (profile) nextXArrayDuration += timer.capture();
		}
	}

	/**
	 * Compute the B-array and the first b-parameter.
	 */
	private void computeFirstBParameter() {
		// compute 2*B_l[] and the first b; the notation is mostly following [Contini97]
		this.b = ZERO;
		// The entries in 2*B_l[] = B2Array are stored at Contini's original indices l=1..s to save one "-1" operation in later steps.
		for (int l=1; l<=qCount; l++) {
			int ql = qArray[l-1]; // q-indices start at 0
			int qIndex = qIndexArray[l-1];
			int t = tArray[qIndex];
			BigInteger ql_big = BigInteger.valueOf(ql);
			BigInteger a_div_ql = a.divide(ql_big); // exact
			// the modular inverse is small enough to fit into int, but for the product below we need long precision
			long a_div_ql_modInv_ql = a_div_ql.modInverse(ql_big).longValue();
			int gamma = (int) ((t*a_div_ql_modInv_ql) % ql);
			if (gamma > (ql>>1)) gamma = ql - gamma; // take the smaller choice of gamma
			BigInteger Bl = a_div_ql.multiply(BigInteger.valueOf(gamma));
			if (DEBUG) {
				assertTrue(Bl.compareTo(ZERO) >= 0);
				assertEquals(ZERO, Bl.multiply(Bl).subtract(kN).mod(ql_big));
			}
			B2Array[l] = Bl.shiftLeft(1); // store 2 * B_l in B2[1]...B2[s]
			B2Array_UBI[l] = new UnsignedBigInt(B2Array[l]);
			b = b.add(Bl);
			b_UBI = new UnsignedBigInt(b);
			// WARNING: In contrast to the description in [Contini p.10, 2nd paragraph],
			// WARNING: b must not be computed (mod a) !
		}
		if (DEBUG) assertEquals(ZERO, b.multiply(b).subtract(kN).mod(a)); // we have b^2 == kN (mod a)
	}
	
	/**
	 * Creates a <code>filteredPrimeBase</code> where the <code>q</code>'s whose product forms the <code>a</code>-parameter have been filtered out.
	 */
	private void filterPrimeBase() {
		int[] filteredPrimeBase = primeSolutions.primesOrPowers;
		int[] filteredTArray = primeSolutions.tArray;
		byte[] filteredLogPArray = primeSolutions.logPArray;
		int lastqIndex = -1;
		for (int i=0; i<qCount; i++) {
			int qIndex = qIndexArray[i];
			int srcPos = lastqIndex+1;
			int destPos = lastqIndex+1-i;
			int length = qIndex-lastqIndex-1;
			System.arraycopy(primesArray, srcPos, filteredPrimeBase, destPos, length);
			System.arraycopy(tArray, srcPos, filteredTArray, destPos, length);
			System.arraycopy(logPArray, srcPos, filteredLogPArray, destPos, length);
			lastqIndex = qIndex;
		}
		// last piece
		if (lastqIndex < primeBaseSize-1) {
			int srcPos = lastqIndex+1;
			int destPos = lastqIndex+1-qCount;
			int length = primeBaseSize-lastqIndex-1;
			System.arraycopy(primesArray, srcPos, filteredPrimeBase, destPos, length);
			System.arraycopy(tArray, srcPos, filteredTArray, destPos, length);
			System.arraycopy(logPArray, srcPos, filteredLogPArray, destPos, length);
		}
		if (DEBUG) {
			// qIndexArray[] entries must be sorted bottom up
			LOG.debug("qIndexArray = " + Arrays.toString(qIndexArray));
			LOG.debug("primesArray = " + Arrays.toString(primesArray));
			LOG.debug("filteredPrimeBase = " + Arrays.toString(filteredPrimeBase));
		}
		
		// powerEntries contains only powers of primes p<pMin. Now we must remove powers of the q_l. The result is a set sorted bottom-up by powers.
		HashSet<Integer> qSet = new HashSet<Integer>();
		for (int q : qArray) {
			if (q >= pMin) break;
			qSet.add(q);
		}
		filteredPowerEntries = new TreeSet<PowerEntry>();
		for (PowerEntry powerEntry : powerEntries) {
			if (!qSet.contains(powerEntry.p)) {
				filteredPowerEntries.add(powerEntry);
			}
		}
	}
	
	/**
	 * Compute the ainvp[] required for Bainv2[][], the Bainv2[][] required to compute next b's and next x-arrays,
	 * and the first x-arrays.
	 * 
	 * The x-arrays contain the smallest non-negative solutions x_1,2 of (ax+b)^2-kN == 0 (mod p)
	 * for the first b-parameter and for all p in the prime base.
	 * 
	 * All modular inverses 1/a % p exist because the q's whose product gives the a-parameter have been filtered out before.
	 */
	private void computeFirstXArrays() { // performance-critical !
		int[] filteredPrimeBase = primeSolutions.primesOrPowers;
		int[] filteredTArray = primeSolutions.tArray;
		int[][] Bainv2Array = primeSolutions.Bainv2Array;
		int[] x1Array = primeSolutions.x1Array;
		int[] x2Array = primeSolutions.x2Array;
		for (int pIndex=primeSolutionsCount-1; pIndex>0; pIndex--) { // we do not need solutions for p[0]=2
			// 1. compute ainvp ------------------------------------------------------------------
			// All modular inverses 1/a % p exist because the q's whose product gives the a-parameter have been filtered out before.
			// Since 1/a % p = 1/(a%p) % p, we can compute the modular inverse in ints, which is much faster than with BigIntegers.
			// ainvp needs long precision in the products below.
			final int p = filteredPrimeBase[pIndex];
			final long ainvp = eea.computeHalf(a_UBI.mod(p), p).a;
			
			// 2. compute Bainv2[] -----------------------------------------------------------
			for (int j=qCount-1; j>0; j--) { // Contini's j=1...s-1
				// Bainv2 = 2 * B_j * (1/a) mod p.
				Bainv2Array[j][pIndex] = (int) ((B2Array_UBI[j].mod(p) * ainvp) % p); // much faster than BigInteger.mod(BigInteger)
			}
			
			// 3. compute first x-array entries -----------------------------------------------
			final int t = filteredTArray[pIndex];
			final int bModP = b_UBI.mod(p);
			// x1 = (1/a)* (+t - b) (mod p)
			int t_minus_b_modP = t - bModP;
			if (t_minus_b_modP < 0) t_minus_b_modP += p;
			x1Array[pIndex] = (int) ((ainvp * t_minus_b_modP) % p);
			// x2 = (1/a)* (-t - b) (mod p): For p=2 and p|k, there is no distinct second solution.
			// The number of these primes is very small, so one could think a case distinction on t makes no sense.
			// Nevertheless, without that distinction we could get p-t-bModP = p, and again a second case distinction would be necessary...
			if (t>0) { // there is a second solution
				int minus_t_minus_b_modP = p -t - bModP;
				if (minus_t_minus_b_modP < 0) minus_t_minus_b_modP += p;
				x2Array[pIndex] = (int) ((ainvp * minus_t_minus_b_modP) % p);
			} else { // only one solution
				x2Array[pIndex] = x1Array[pIndex];
			}
			
			if (DEBUG) {
				BigInteger p_big = BigInteger.valueOf(p);
				assertEquals(ainvp, a.modInverse(p_big).longValue());

				for (int j=qCount-1; j>0; j--) { // Contini's j=1...s-1
					assertTrue(0<=Bainv2Array[j][pIndex] && Bainv2Array[j][pIndex]<p);
				}
				assertTrue(0<=t_minus_b_modP && t_minus_b_modP<p);
				if (t>0) {
					int minus_t_minus_b_modP = p -t - bModP;
					if (minus_t_minus_b_modP < 0) minus_t_minus_b_modP += p;
					assertTrue(0<=minus_t_minus_b_modP && minus_t_minus_b_modP<p);
				}
				// x1,x2 were chosen such that p divides Q
				int x1 = x1Array[pIndex];
				BigInteger Q1 = a.multiply(BigInteger.valueOf(x1)).add(b).pow(2).subtract(kN);
				assertEquals(ZERO, Q1.mod(p_big));
				int x2 = x2Array[pIndex];
				BigInteger Q2 = a.multiply(BigInteger.valueOf(x2)).add(b).pow(2).subtract(kN);
				assertEquals(ZERO, Q2.mod(p_big));
				if (x1<0 || x2<0) LOG.debug("p=" + p + ", ainvp=" + ainvp + ": x1 = " + x1 + ", x2 = " + x2);
			}
		} // end_for (primes)
	}
	
	private void computeFirstXArraysForPrimePowers() {
		// Allocate the arrays
		powerSolutionsCount = filteredPowerEntries.size();
		if (DEBUG) LOG.info("primeSolutionsCount=" + primeSolutionsCount + ", pMin=" + pMin + ", pMax=" + pMax + ", powerSolutionsCount = " + powerSolutionsCount);
		powerSolutions = new PolySolutions(powerSolutionsCount, qCount);
		int[] powers = powerSolutions.primesOrPowers;
		int[][] powerBainv2Array = powerSolutions.Bainv2Array;
		int[] powerX1Array = powerSolutions.x1Array;
		int[] powerX2Array = powerSolutions.x2Array;
		byte[] logPowerArray = powerSolutions.logPArray;
		
		// Fill the arrays with solutions
		int pIndex = 0;
		for (PowerEntry powerEntry : filteredPowerEntries) {
			logPowerArray[pIndex] = powerEntry.logPower;
			int power = powers[pIndex] = powerEntry.power;
			int t = powerEntry.t;
			// Resolve t = (a*x+b) for x:
			if (DEBUG) LOG.debug("p=" + powerEntry.p + ", power=" + power + ", t=" + t);
			final long ainvpower = eea.computeHalf(a_UBI.mod(power), power).a;
			int bModPower = b_UBI.mod(power);
			int x1 = (int) ((ainvpower * (t - bModPower)) % power);
			powerX1Array[pIndex] = (x1 < 0) ? x1 + power : x1;
			int x2 = (int) ((ainvpower * (power-t - bModPower)) % power);
			powerX2Array[pIndex] = (x2 < 0) ? x2 + power : x2;

			// compute Bainv2 for powers
			for (int j=qCount-1; j>0; j--) { // Contini's j=1...s-1
				// Bainv2 = 2 * B_j * (1/a) mod power.
				powerBainv2Array[j][pIndex] = (int) ((B2Array_UBI[j].mod(power) * ainvpower) % power);
			}
			
			// next
			pIndex++;
		}
		if (DEBUG) LOG.debug("powers = " + Arrays.toString(powers));
	}
	
	/**
	 * Update the entries of the solution arrays for the next b-parameter.
	 * @param v gray code, with v in [1, ..., qCount-1]
	 * @param xArraysNeedSubtraction true if ceil(bIndex/2^v) is even, (-1)^ceil(bIndex/2^v) == +1
	 */
	private void computeNextXArrays(int v, boolean xArraysNeedSubtraction) { // performance-critical !
		// update solution arrays:
		// Note that trial division needs the solutions for all primes p,
		// even if the sieve leaves out the smallest p[i] with i < pMinIndex.
		int[] filteredPrimeBase = primeSolutions.primesOrPowers;
		int[] Bainv2Row = primeSolutions.Bainv2Array[v];
		int[] x1Array = primeSolutions.x1Array;
		int[] x2Array = primeSolutions.x2Array;
		int[] powers = powerSolutions.primesOrPowers;
		int[] powerBainv2Row = powerSolutions.Bainv2Array[v];
		int[] powerX1Array = powerSolutions.x1Array;
		int[] powerX2Array = powerSolutions.x2Array;
		// WARNING: The correct case distinction depending on the sign of (-1)^ceil(bIndex/2^v)
		// WARNING: is just the opposite of [Contini, table p.14, last 2 lines]
		if (xArraysNeedSubtraction) {
			// (-1)^ceil(bIndex/2^v) == +1 -> Bainv2 must be subtracted
			for (int pIndex=primeSolutionsCount-1; pIndex>0; pIndex--) {
				final int p = filteredPrimeBase[pIndex];
				final int Bainv2 = Bainv2Row[pIndex];
				int x1 = x1Array[pIndex] - Bainv2;
				x1Array[pIndex] = x1<0 ? x1+p : x1; // faster than (mod p)
				int x2 = x2Array[pIndex] - Bainv2;
				x2Array[pIndex] = x2<0 ? x2+p : x2;
			} // end for (primes)
			// prime powers
			for (int pIndex=powerSolutionsCount-1; pIndex>=0; pIndex--) {
				final int power = powers[pIndex];
				final int Bainv2 = powerBainv2Row[pIndex];
				int x1 = powerX1Array[pIndex] - Bainv2;
				powerX1Array[pIndex] = x1<0 ? x1+power : x1; // faster than (mod p)
				int x2 = powerX2Array[pIndex] - Bainv2;
				powerX2Array[pIndex] = x2<0 ? x2+power : x2;
			} // end for (primes)
		} else {
			// (-1)^ceil(bIndex/2^v) == -1 -> Bainv2 must be added
			for (int pIndex=primeSolutionsCount-1; pIndex>0; pIndex--) {
				final int p = filteredPrimeBase[pIndex];
				final int Bainv2 = Bainv2Row[pIndex];
				int x1 = x1Array[pIndex] + Bainv2; // Bainv2 >= 0
				x1Array[pIndex] = x1>=p ? x1-p : x1;
				int x2 = x2Array[pIndex] + Bainv2;
				x2Array[pIndex] = x2>=p ? x2-p : x2;
			} // end for (primes)
			// prime powers
			for (int pIndex=powerSolutionsCount-1; pIndex>=0; pIndex--) {
				final int power = powers[pIndex];
				final int Bainv2 = powerBainv2Row[pIndex];
				int x1 = powerX1Array[pIndex] + Bainv2;
				powerX1Array[pIndex] = x1>=power ? x1-power : x1;
				int x2 = powerX2Array[pIndex] + Bainv2;
				powerX2Array[pIndex] = x2>=power ? x2-power : x2;
			} // end for (primes)
		}
		if (DEBUG) debugNextXArrays(v);
	}

	private void debugNextXArrays(int v) {
		int[] filteredPrimeBase = primeSolutions.primesOrPowers;
		int[][] Bainv2Array = primeSolutions.Bainv2Array;
		int[] x1Array = primeSolutions.x1Array;
		int[] x2Array = primeSolutions.x2Array;
		for (int pIndex=primeSolutionsCount-1; pIndex>0; pIndex--) {
			int p = filteredPrimeBase[pIndex];
			int Bainv2 = Bainv2Array[v][pIndex];
			int x1 = x1Array[pIndex];
			int x2 = x2Array[pIndex];
			assertTrue(0 <= x1 && x1 < p);
			assertTrue(0 <= x2 && x2 < p);
			BigInteger p_big = BigInteger.valueOf(p);
			assertEquals(kN.mod(p_big), a.multiply(BigInteger.valueOf(x1)).add(b).pow(2).mod(p_big));
			assertEquals(kN.mod(p_big), a.multiply(BigInteger.valueOf(x2)).add(b).pow(2).mod(p_big));
			if (x1<0 || x2<0) LOG.debug("p=" + p + ", Bainv2=" + Bainv2 + ": x1 = " + x1 + ", x2 = " + x2);
		}
		// prime powers
		int[] powers = powerSolutions.primesOrPowers;
		int[][] powerBainv2Array = powerSolutions.Bainv2Array;
		int[] powerX1Array = powerSolutions.x1Array;
		int[] powerX2Array = powerSolutions.x2Array;
		for (int pIndex=powerSolutionsCount-1; pIndex>=0; pIndex--) {
			int power = powers[pIndex];
			int Bainv2 = powerBainv2Array[v][pIndex];
			int x1 = powerX1Array[pIndex];
			int x2 = powerX2Array[pIndex];
			assertTrue(0 <= x1 && x1 < power);
			assertTrue(0 <= x2 && x2 < power);
			BigInteger power_big = BigInteger.valueOf(power);
			assertEquals(kN.mod(power_big), a.multiply(BigInteger.valueOf(x1)).add(b).pow(2).mod(power_big));
			assertEquals(kN.mod(power_big), a.multiply(BigInteger.valueOf(x2)).add(b).pow(2).mod(power_big));
			if (x1<0 || x2<0) LOG.debug("power=" + power + ", Bainv2=" + Bainv2 + ": x1 = " + x1 + ", x2 = " + x2);
		}
	}

	@Override
	public String getProfilingReport() {
		return "a-param=" + aDuration + "ms, first b-param=" + firstBDuration + "ms, filter prime base=" + filterPBDuration + "ms, first x-arrays=" + firstXArrayDuration + "ms, next b-params=" + nextBDuration + "ms, next x-arrays=" + nextXArrayDuration + "ms";
	}
	
	@Override
	public void cleanUp() {
		primesArray = null;
		tArray = null;
		logPArray = null;
		primeSolutions = null;
		powerSolutions = null;
		aParamGenerator.cleanUp();
	}
}
