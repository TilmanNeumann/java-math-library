// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor.siqs.tdiv;

import java.math.BigInteger;
import java.util.List;

import de.tilman_neumann.math.factor.basics.congruence.AQPair;
import de.tilman_neumann.math.factor.siqs.PolySolutions;

/**
 * Interface for trial division engines to find the factorization of smooth Q(x) with given x.
 */
public interface TDiv_QS {
	
	/**
	 * @return the name of this algorithm
	 */
	public String getName();

	/**
	 * Initialize this trial division engine for a new N.
	 * @param N_dbl
	 * @param kN multiplier k (typically Knuth-Schroeppel) * factor argument N
	 */
	public void initialize(double N_dbl, BigInteger kN);

	/**
	 * Set prime base, polynomial parameters and smallest x-solutions.
	 * @param a the a-parameter
	 * @param b the b-parameter
	 * @param primeSolutions
	 * @param unsievedPrimeBaseElements Prime base elements that were excluded from sieving, like the q's that give the a-parameter in SIQS
	 */
	void setPrimeSolutions(BigInteger a, BigInteger b, PolySolutions primeSolutions, int[] unsievedPrimeBaseElements);
	
	/**
	 * Set a new b-parameter.
	 */
	void setBParameter(BigInteger b);
	
	/**
	 * Test if Q(x) is smooth (factors completely over the prime base) or "sufficiently smooth" (factors almost over the prime base)
	 * for all x in the given list.
	 * @param xList
	 * @return the AQ-pairs where Q is at least "sufficiently smooth"
	 */
	List<AQPair> testList(List<Integer> xList);
	
	/**
	 * @return a description of the performed tests.
	 */
	String getReportString();
	
	/**
	 * Release memory after a factorization.
	 */
	void cleanUp();
}
