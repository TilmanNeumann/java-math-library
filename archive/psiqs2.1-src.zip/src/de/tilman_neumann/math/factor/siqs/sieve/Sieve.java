// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor.siqs.sieve;

import java.math.BigInteger;
import java.util.List;

import de.tilman_neumann.math.factor.siqs.PolySolutions;

/**
 * Interface for sieve algorithms.
 */
public interface Sieve {
	
	/**
	 * @return the name of this sieve algorithm
	 */
	String getName();
	
	/**
	 * Initialize for a new N.
	 * @param N_dbl
	 * @param kN multiplier * factor argument
	 * @param unfilteredPrimeBaseSize the size of prime base before q_l are filtered out
	 * @param unfilteredPrimesArray the unfiltered prime base
	 * @param unfilteredTArray modular square roots t of t^2 == kN (mod p)
	 * @param sieveArraySize
	 * @param profile get phase timings?
	 */
	void initialize(double N_dbl, BigInteger kN, int unfilteredPrimeBaseSize, int[] unfilteredPrimesArray, int[] unfilteredTArray, int sieveArraySize, boolean profile);

	/**
	 * @return the multiplier to convert lnP-values to logP values with the adjusted base
	 */
	float getLnPMultiplier();
	
	/**
	 * Set (filtered) prime base and smallest polynomial solutions.
	 * @param primeSolutions
	 */
	void setPrimeSolutions(PolySolutions primeSolutions);
	
	/**
	 * Do the sieving.
	 * @return list of sieve locations x where Q(x) is smooth enough to be passed to trial division
	 */
	List<Integer> sieve();

	/**
	 * @return description of the durations of the individual sub-phases
	 */
	String getProfilingReport();
	
	/**
	 * Release memory after a factorization.
	 */
	void cleanUp();
}
