// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor.siqs;

import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

import org.apache.log4j.Logger;

import de.tilman_neumann.math.factor.basics.BinarySearch;

import static de.tilman_neumann.math.base.bigint.BigIntConstants.*;

/**
 * Generator for the a-parameter (or "hypercube"), which is the leading coefficient of the quadratic polynomial
 * Q(x) = (a*x+b)^2 - kN used by SIQS.</br></br>
 * 
 * The a-parameter in SIQS is chosen as a product of primes from the prime base: <code>a = q1 * ... * q_s</code>.
 * Its value should be roughly a ~ sqrt(2*k*N)/M, where M is the sieve array size, such that |Q(x)|
 * is about the same at x=+M and x=-M, and |Q(x)| <= kN for all x.
 * 
 * As suggested by [Carrier/Wagstaff], it is important to avoid q_l that divide k.
 * Otherwise for many N we would require a big number of solver runs.
 * 
 * This class does not implement the standard-procedure due to [Carrier/Wagstaff] for two reasons:
 * 1. I wanted to test which size of the q_l is actually the best. It turned out that the q_l should be rather large and qCount rather small.
 * 2. Splitting the prime base and {q_l} into three sets feels like introducing some unnecessary complexity to the code.
 * 
 * The algorithm used here is mostly random, chosing the q_l from a range of about the wanted size.
 * The last q_l is chosen deterministically such that the best a-parameter is matched as close as possible.
 * Therefore the algorithm is not stable for N < 50 bit, but faster for bigger N.
 * The expected best a-value is approximated quite accurately.
 * 
 * Since 2016-12-15, entries of qArray and qIndexArray are sorted bottom-up now.
 */
public class AParamGenerator01 implements AParamGenerator {
	private static final Logger LOG = Logger.getLogger(AParamGenerator01.class);
	private static final boolean DEBUG = false;

	/** multiplier k: we must avoid q_l that divide k */
	private int k;
	/** the number to factor */
	private BigInteger N;
	private BigInteger kN;
	/** the wanted number of factors of the a-parameter (null -> automatic choice) */
	private Integer wanted_qCount;
	// prime base
	private int primeBaseSize;
	private int[] primesArray;
	/** sieve array size for kN */
	private int sieveArraySize;
	
	/** approximate size of the a-parameter for some kN */
	private double best_a;
	/** the actual number of factors of the a-parameter for given kN */
	private int qCount;
	/** centre and variance for q-index generation */
	private int indexVariance, indexCentre;
	/** indices of the prime base elements that are the factors of a */
	private int[] qIndexArray;
	/** and the factors themselves */
	private int[] qArray;
	/** random generator */
	private SecureRandom rng = new SecureRandom();
	/** the set of a-values already used */
	private HashSet<BigInteger> aParamHistory;

	/** The generated a-parameter */
	private BigInteger a;

	private BinarySearch binarySearch = new BinarySearch();

	/**
	 * Full constructor.
	 * @param wanted_qCount the wanted number of factors of the a-parameter; null for automatic selection
	 */
	public AParamGenerator01(Integer wanted_qCount) {
		this.wanted_qCount = wanted_qCount;
	}

	@Override
	public String getName() {
		return "apg01(" + qCount + ")";
	}

	@Override
	public void initialize(int k, BigInteger N, BigInteger kN, int primeBaseSize, int[] primesArray, int sieveArraySize) {
		this.k = k;
		this.N = N;
		this.kN = kN;
		this.primeBaseSize = primeBaseSize;
		this.primesArray = primesArray;
		this.sieveArraySize = sieveArraySize;
		
		// adjust qCount and compute best parameters to generate prime base indices
		computeIndexGenerationParameters();
		// reset aParamHistory
		aParamHistory = new HashSet<BigInteger>();
	}

	private void computeIndexGenerationParameters() {
		// compute expected best a-parameter. The constant 2 has been confirmed experimentally.
		this.best_a = Math.sqrt(2*kN.doubleValue()) / (double)sieveArraySize;
		
		if (wanted_qCount == null) {
			// automatic estimate of best qCount; derived from tests up to 280 bit
			int N_bits = N.bitLength();
			if (N_bits<130) {
				qCount = (int) (2.67F + N_bits/30.0);
			} else {
				qCount = (int) (3.75F + N_bits/40.0);
			}
		} else {
			qCount = wanted_qCount;
		}
		
		// compute safe bounds for qCount:
		// a) the minimum qCount is the number of elements of the product of biggest primes that exceeds best_a
		int minQCount = 0;
		double bigQProd = 1;
		for (int i=primeBaseSize-1; i>0; i--) { // avoid p[0]==2
			bigQProd *= primesArray[i];
			minQCount++; // count always
			if (bigQProd > best_a) break; // bigQProd exceeds best_a -> done
		}
		// b) the maximum qCount is the number of elements of the product of smallest primes that does not exceed best_a
		int maxQCount = 0;
		double smallQProd = 1;
		for (int i=1; i<primeBaseSize; i++) {
			smallQProd *= primesArray[i];
			if (smallQProd > best_a) break; // smallQProd exceeds best_a -> do not count that q anymore
			maxQCount++;
		}
		maxQCount--; // reduce 1 because the upper bound is too unstable
		
		// apply safe bounds to adjust qCount
		if (minQCount>maxQCount) {
			this.qCount = (int) ( (minQCount+maxQCount)/2.0 + 0.5);
			LOG.error("the available qCount-range for kN=" + kN + " is empty! -> use the middle value of allowed bounds, qCount = " + qCount);
		} else if (qCount<minQCount) {
			if (DEBUG) LOG.warn("wanted_qCount=" + qCount + " is too small for kN=" + kN + " and the chosen prime base -> use the smallest possible value, qCount = " + minQCount);
			this.qCount = minQCount; // safe choice
		} else if (qCount>maxQCount) {
			if (DEBUG) LOG.warn("wanted_qCount=" + qCount + " is too big for kN=" + kN + " and the chosen prime base -> use the biggest possible value, qCount = " + maxQCount);
			this.qCount = maxQCount;
		}
		// compute average "best" q, such that best_q^qCount = best_a
		double best_q = Math.pow(best_a, 1/(double)qCount);
		// compute index of average "best" q, in the sense of realizing the a-parameter with qCount prime base values
		int best_q_index = getBestIndex(best_q);
		// compute centre and variance for index generator
		indexVariance = (int) (1.0*Math.sqrt(primeBaseSize)); // near-optimal? multipliers < 1 are unstable, multipliers > 1 degrade performance for big N
		indexCentre = best_q_index;
		int minIndex = indexCentre - indexVariance; // this should be 1 at least (to avoid p[0]=2)
		if (minIndex < 1) {
			int minIndexDefect = 1-minIndex; // minIndex is that much too small
			indexCentre += minIndexDefect; // move centre up so that the defect vanishes
		}
		int maxIndex = indexCentre + indexVariance;
		if (maxIndex>=primeBaseSize) {
			int maxIndexDefect = maxIndex - (primeBaseSize-1); // maxIndex is that much too big
			indexCentre -= maxIndexDefect; // move centre down so that the defect vanishes
		}
	}
	
	/**
	 * Given qCount and best_a, compute qIndexArray, qArray and <code>a</code>.
	 * The computation should be pretty safe to avoid that QS becomes unstable for bad choices of qCount.
	 */
	private void computeAParameter() {
		TreeSet<Integer> qIndexSet = new TreeSet<Integer>();
		a = ONE;
		// find the first (qCount-1) q randomly
		for (int i=0; i<qCount-1; i++) {
			// introduce some randomness
			int randomOffset = rng.nextInt(indexVariance<<1) - indexVariance; // randomOffset = -indexVariance..+indexVariance -> centered at 0
			int wanted_qIndex = indexCentre + randomOffset;
			if (DEBUG) LOG.debug("indexCentre=" + indexCentre + ", indexVariance=" + indexVariance + " -> randomOffset=" + randomOffset + ", wanted_qIndex=" + wanted_qIndex);
			// find the first "free" index around wanted_qIndex
			Integer qIndex = findFreeQIndex(qIndexSet, wanted_qIndex);
			// now we have found qIndex :)
			qIndexSet.add(qIndex);
			int q = primesArray[qIndex];
			BigInteger q_big = BigInteger.valueOf(q);
			a = a.multiply(q_big);
		}
		// determine the last q such that we get a good fit with best_a
		double a_rest = best_a / a.doubleValue();
		int best_q_index = getBestIndex(a_rest);
		int qIndex = findFreeQIndex(qIndexSet, best_q_index);
		qIndexSet.add(qIndex);
		int q = primesArray[qIndex];
		BigInteger q_big = BigInteger.valueOf(q);
		a = a.multiply(q_big);
		// finally, create qArray and qIndexArray sorted bottom-up
		qIndexArray = new int[qCount];
		qArray = new int[qCount];
		Iterator<Integer> qIndexIter = qIndexSet.iterator();
		for (int i=0; i<qCount; i++) {
			qIndexArray[i] = qIndex = qIndexIter.next().intValue();
			qArray[i] = primesArray[qIndex];
		}

		//LOG.debug("kN=" + kN + " -> best_a = " + best_a + ", qCount = " + qCount + " -> qArray = " + Arrays.toString(qArray) + ", a = " + a);
	}

	private int getBestIndex(double wanted_q) {
		int q1_index = binarySearch.getFirstGreaterEntryIndex(primesArray, primeBaseSize, (int) wanted_q);
		if (q1_index==-1) return primeBaseSize-1; // wanted_q is bigger than pMax
		if (q1_index<2) return 1; // avoid p[0]=2
		double q1_error = Math.abs(wanted_q - primesArray[q1_index]);
		int q0_index = q1_index-1;
		double q0_error = Math.abs(wanted_q - primesArray[q0_index]);
		return (q1_error < q0_error) ? q1_index : q0_index;
	}

	private int findFreeQIndex(Set<Integer> qIndexSet, int wanted_qIndex) {
		if (!qIndexSet.contains(wanted_qIndex)) {
			if (k % primesArray[wanted_qIndex] != 0) { // avoid q_l that divide k
				return wanted_qIndex; // easy
			}
		}
		// the wanted index is not available anymore -> check the neighbors
		for (int step=1; ; step++) {
			int stepUp_qIndex = wanted_qIndex+step;
			if (stepUp_qIndex<primeBaseSize && !qIndexSet.contains(stepUp_qIndex)) {
				if (k % primesArray[stepUp_qIndex] != 0) { // avoid q_l that divide k
					return stepUp_qIndex;
				}
			}
			int stepDown_qIndex = wanted_qIndex-step;
			if (stepDown_qIndex>0 && !qIndexSet.contains(stepDown_qIndex)) { // avoid p[0]==2
				if (k % primesArray[stepDown_qIndex] != 0) { // avoid q_l that divide k
					return stepDown_qIndex;
				}
			}
		}
	}

	@Override
	public BigInteger computeNextAParameter() {
		@SuppressWarnings("unused")
		int duplicateACount = 0;
		while (true) {
			this.computeAParameter();
			if (!aParamHistory.contains(a)) break; // a new "a"
			duplicateACount++;
			if (DEBUG) LOG.warn("New a-parameter #" + aParamHistory.size() + ": a=" + a + " has already been used! #(duplicate a in a row) = " + duplicateACount);
		}
		aParamHistory.add(a);
		return a;
	}

	@Override
	public int getQCount() {
		return qCount;
	}

	@Override
	public int[] getQIndexArray() {
		return qIndexArray;
	}

	@Override
	public int[] getQArray() {
		return qArray;
	}
	
	@Override
	public void cleanUp() {
		primesArray = null;
		aParamHistory = null;
		qArray = null;
		qIndexArray = null;
	}
}
