// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor.basics.congruence;

import java.math.BigInteger;
import java.util.Arrays;

import de.tilman_neumann.math.factor.basics.SortedIntegerArray;

/**
 * A perfect smooth congruence.
 */
public class Smooth_Perfect extends AQPair implements Smooth {

	private Integer[] oddExpElements;

	/**
	 * Full constructor.
	 * @param A
	 * @param smallFactors small factors of Q
	 */
	public Smooth_Perfect(BigInteger A, SortedIntegerArray smallFactors) {
		super(A, smallFactors);
		this.oddExpElements = super.getSmallFactorsWithOddExponent();
	}
	
	@Override
	public Integer[] getMatrixElements() {
		return oddExpElements;
	}

	@Override
	public AQPair[] getAQPairs() {
		return new AQPair[] {this};
	}

	@Override
	public int getNumberOfLargeFactors() {
		return 0;
	}

	@Override
	public boolean isExactSquare() {
		return oddExpElements.length==0;
	}

	@Override
	public String toString() {
		String str = super.toString();
		str = str.substring(0, str.length()-3); // remove last " * "
		return "[oddExpFactors = " + Arrays.toString(oddExpElements) + ", aqPair = " + str + "]";
	}
}
