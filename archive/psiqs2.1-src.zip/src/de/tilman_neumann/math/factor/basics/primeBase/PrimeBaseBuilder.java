// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor.basics.primeBase;

import java.math.BigInteger;

/**
 * Interface for prime base builders.
 */
public interface PrimeBaseBuilder {

	/**
	 * Compute the first <code>count</code> small primes.
	 * @param count
	 * @return
	 */
	Primes getPrimes(int count);
	
	/**
	 * Compute all primes below the given bound.
	 * @param bound
	 * @return
	 */
	Primes getPrimesBelow(int bound);

	/**
	 * Compute a reduced prime base containing the 2 and odd primes p with Jacobi(kN|p)>=0
	 * 
	 * @param kN has to be a quadratic residue modulo all p
	 * @param primeBaseSize the wanted number of primes
	 * @param primesArray is filled with the primes p satisfying Jacobi(kN|p)>=0
	 */
	void computeReducedPrimeBase(BigInteger kN, int primeBaseSize, int[] primesArray);

	/**
	 * Compute a reduced prime base containing the 2 and odd primes p with Jacobi(kN|p)>=0
	 * 
	 * @param kN has to be a quadratic residue modulo all p
	 * @param primeBaseSize the wanted number of primes
	 * @param primesArray is filled with the primes p satisfying Jacobi(kN|p)>=0
	 * @param primesArray_big if not null then this array is filled with the p in BigInteger
	 */
	void computeReducedPrimeBase(BigInteger kN, int primeBaseSize, int[] primesArray, BigInteger[] primesArray_big);

}