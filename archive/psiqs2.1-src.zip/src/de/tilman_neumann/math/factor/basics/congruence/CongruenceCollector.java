// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor.basics.congruence;

import static org.junit.Assert.assertTrue;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

import org.apache.log4j.Logger;

import de.tilman_neumann.math.factor.FactorException;
import de.tilman_neumann.math.factor.basics.matrixSolver.FactorTest;
import de.tilman_neumann.math.factor.basics.matrixSolver.MatrixSolver01_Gauss;
import de.tilman_neumann.math.factor.basics.matrixSolver.PartialSolverController;
import de.tilman_neumann.types.Multiset;
import de.tilman_neumann.types.SortedMultiset_TreeMapImpl;

/**
 * Collects smooth and partial congruences, and assembles partials to smooth congruences on-the-fly.
 * Partials may have any number of large factors.
 */
public class CongruenceCollector {
	private static final Logger LOG = Logger.getLogger(CongruenceCollector.class);
	private static final boolean DEBUG = false;
	private static final boolean ANALYZE_FACTORS = false;

	/** smooth congruences */
	private ArrayList<Smooth> smoothCongruences;
	/** 
	 * A map from big factors with odd exp to partial congruences.
	 * Here we need a 1:n relation because one partial can have several big factors;
	 * thus one big factor may be contained in many distinct partials.
	 */
	private HashMap<Long, ArrayList<Partial>> oddExpBigFactors_2_partialCongruences; // here HashMap is faster than TreeMap or LinkedHashMap
	/** A controller for the solver used to create smooth congruences from partials */
	private PartialSolverController partialSolverController;
	/** factor tester */
	private FactorTest factorTest;

	// statistics
	private boolean analyze, analyzeFactors;
	private int perfectSmoothCount, totalPartialCount;
	private int[] smoothFromPartialCounts, partialCounts;
	private Multiset<Integer> oddExpBigFactorSizes4Smooth, oddExpBigFactorSizes;
	
	/**
	 * Unique constructor.
	 */
	public CongruenceCollector() {
		this.partialSolverController = new PartialSolverController(new MatrixSolver01_Gauss<Long>());
	}

	/**
	 * @return algorithm name
	 */
	public String getName() {
		return "cc_nL";
	}
	
	/**
	 * Initialize congruence collector for a new N.
	 * @param N
	 * @param analyze true -> analysis is carried out
	 */
	public void initialize(BigInteger N, FactorTest factorTest, boolean analyze) {
		smoothCongruences = new ArrayList<Smooth>();
		oddExpBigFactors_2_partialCongruences = new HashMap<Long, ArrayList<Partial>>();
		partialSolverController.initialize(N, factorTest);
		this.factorTest = factorTest;
		
		// statistics
		this.analyze = analyze;
		this.analyzeFactors = analyze && ANALYZE_FACTORS;
		this.perfectSmoothCount = 0;
		// zero-initialized smoothFromPartialCounts: index 0 -> from 1-partials, index 1 -> from 2-partials, index 2 -> from 2-partials
		this.smoothFromPartialCounts = new int[3];
		this.partialCounts = new int[3];
		this.totalPartialCount = 0;
		// collected vs. useful partials
		oddExpBigFactorSizes4Smooth = new SortedMultiset_TreeMapImpl<Integer>();
		oddExpBigFactorSizes = new SortedMultiset_TreeMapImpl<Integer>();
	}
	
	/**
	 * Add a new elementary partial or smooth congruence.
	 * @param aqPair
	 * @return true if a smooth congruence was added
	 * @throws FactorException
	 */
	public boolean add(AQPair aqPair) throws FactorException {
		if (DEBUG) LOG.debug("new aqPair = " + aqPair);
		if (aqPair instanceof Smooth) {
			Smooth smooth = (Smooth) aqPair;
			boolean added = this.addSmooth(smooth);
			if (added) {
				if (DEBUG) LOG.debug("Found new smooth congruence " + smooth + " --> #smooth = " + smoothCongruences.size() + ", #partials = " + getPartialCongruenceCount());
				perfectSmoothCount++;
				return true;
			}
			return false;
		}
		
		// otherwise aqPair must be a partial with at least one large factor.
		Partial partial = (Partial) aqPair;
		Long[] oddExpBigFactors = partial.getMatrixElements();
		int oddExpBigFactorsCount = oddExpBigFactors.length;
		if (DEBUG) assertTrue(oddExpBigFactorsCount > 0);
		
		// Check if the partial helps to assemble a smooth congruence:
		// First collect all partials that are somehow related to the new partial via big factors:
		HashSet<Partial> relatedPartials = findRelatedPartials(oddExpBigFactors); // oddExpBigFactors is not modified in the method
		if (DEBUG) LOG.debug("#relatedPartials = " + relatedPartials.size());
		if (relatedPartials.size()>0) {
			// We found some "old" partials that share at least one big factor with the new partial.
			// Since relatedPartials is a set, we can not get duplicate AQ-pairs.
			relatedPartials.add(partial);
			// Solve partial congruence equation system
			ArrayList<Smooth> foundSmooths = partialSolverController.solve(relatedPartials); // throws FactorException
			if (foundSmooths.size()>0) {
				// We found one or more smooths from the new partial
				int addedCount = 0;
				for (Smooth foundSmooth : foundSmooths) {
					if (addSmooth(foundSmooth)) {
						if (analyze) {
							// count kind of partials that helped to find smooths
							int maxLargeFactorCount = 0;
							for (AQPair aqPairFromSmooth : foundSmooth.getAQPairs()) {
								int largeFactorCount = aqPairFromSmooth.getNumberOfLargeFactors();
								if (largeFactorCount > maxLargeFactorCount) maxLargeFactorCount = largeFactorCount;
							}
							smoothFromPartialCounts[maxLargeFactorCount-1]++;
							if (DEBUG) LOG.debug("Found smooth congruence from " + maxLargeFactorCount + "-partial --> #smooth = " + smoothCongruences.size() + ", #partials = " + getPartialCongruenceCount());
						}
						addedCount++; // increment counter if foundSmooth was really added
					}
				}
				if (addedCount>0) {
					if (analyzeFactors) {
						// register size of large factors that helped to find smooths
						for (Long oddExpBigFactor : oddExpBigFactors) {
							int oddExpBigFactorBits = 64 - Long.numberOfLeadingZeros(oddExpBigFactor);
							oddExpBigFactorSizes4Smooth.add(oddExpBigFactorBits);
						}
					}
					return true;
				}
				return false;
				// Not adding the new partial is sufficient to keep the old partials linear independent,
				// which is required to avoid duplicate solutions.
			}
		}
		
		// We were not able to construct a smooth congruence with the new partial, so just keep the partial:
		if (DEBUG) LOG.debug("add new partial");
		addPartial(partial);
		if (analyze) {
			totalPartialCount++;
			partialCounts[oddExpBigFactorsCount-1]++;
		}
		if (DEBUG) LOG.debug("Found new partial relation " + aqPair + " --> #smooth = " + smoothCongruences.size() + ", #partials = " + getPartialCongruenceCount());
		return false; // no smooth added
	}
	
	/**
	 * Find "old" partials related to a new partial.
	 * The oddExpBigFactors remain unaltered!
	 * 
	 * @param oddExpBigFactors the big factors with odd exponent of the new partial
	 * @return set of related partial congruences
	 */
	private HashSet<Partial> findRelatedPartials(Long[] oddExpBigFactors) {
		HashSet<Long> bigFactorsAlreadyUsed = new HashSet<Long>();
		HashSet<Partial> relatedPartials = new HashSet<Partial>(); // we need a set to avoid adding the same partial more than once
		ArrayList<Long> currentFactors = new ArrayList<Long>();
		for (Long oddExpBigFactor : oddExpBigFactors) {
			currentFactors.add(oddExpBigFactor);
		}
		while (currentFactors.size()>0) {
			if (DEBUG) LOG.debug("currentFactors = " + currentFactors);
			ArrayList<Long> nextFactors = new ArrayList<Long>(); // no Set required, ArrayList has faster iteration
			for (Long oddExpBigFactor : currentFactors) {
				bigFactorsAlreadyUsed.add(oddExpBigFactor);
				ArrayList<Partial> partialList = oddExpBigFactors_2_partialCongruences.get(oddExpBigFactor);
				if (partialList!=null && partialList.size()>0) {
					for (Partial relatedPartial : partialList) {
						relatedPartials.add(relatedPartial);
						for (Long nextFactor : relatedPartial.getMatrixElements()) {
							if (!bigFactorsAlreadyUsed.contains(nextFactor)) nextFactors.add(nextFactor);
						}
					}
				}
			}
			currentFactors = nextFactors;
		}
		return relatedPartials;
	}

	/**
	 * Add smooth congruence.
	 * @param smoothCongruence
	 * @return true if a smooth congruence was added
	 * @throws FactorException
	 */
	protected boolean addSmooth(Smooth smoothCongruence) throws FactorException {
		if (smoothCongruence.isExactSquare()) {
			// we found a square congruence!
			HashSet<AQPair> totalAQPairs = new HashSet<AQPair>();
			AQPair[] aqPairs = smoothCongruence.getAQPairs();
			for (AQPair aqPair : aqPairs) {
				if (!totalAQPairs.remove(aqPair)) totalAQPairs.add(aqPair);
			}
			factorTest.testForFactor(totalAQPairs);
			// no FactorException -> the square congruence was improper -> drop it
			return false;
		}
		// no square -> add
		smoothCongruences.add(smoothCongruence);
		return true;
	}
	
	private void addPartial(Partial newPartial) {
		for (Long oddExpBigFactor : newPartial.getMatrixElements()) {
			ArrayList<Partial> partialCongruenceList = oddExpBigFactors_2_partialCongruences.get(oddExpBigFactor);
			// For large N, most large factors appear only once. Therefore we create an ArrayList with initialCapacity=1 to safe memory.
			// Even less memory would be needed if we had a HashMap<Long, Object> oddExpBigFactors_2_partialCongruences
			// and store AQPairs or AQPair[] in the Object part. But I do not want to break the generics...
			if (partialCongruenceList==null) partialCongruenceList = new ArrayList<Partial>(1);
			partialCongruenceList.add(newPartial);
			oddExpBigFactors_2_partialCongruences.put(oddExpBigFactor, partialCongruenceList);
			int oddExpBigFactorBits = 64 - Long.numberOfLeadingZeros(oddExpBigFactor);
			oddExpBigFactorSizes.add(oddExpBigFactorBits);
		}
	}
	
	@SuppressWarnings("unused")
	private void dropPartial(Partial partial) {
		for (Long oddExpBigFactor : partial.getMatrixElements()) {
			ArrayList<Partial> partialCongruenceList = oddExpBigFactors_2_partialCongruences.get(oddExpBigFactor);
			partialCongruenceList.remove(partial);
			if (partialCongruenceList.size()==0) {
				// partialCongruenceList is empty now -> drop the whole entry
				oddExpBigFactors_2_partialCongruences.remove(oddExpBigFactor);
			}
		}
	}

	/**
	 * @return number of smooth congruences found so far.
	 */
	public int getSmoothCongruenceCount() {
		return smoothCongruences.size();
	}

	/**
	 * @return smooth congruences found so far.
	 */
	public ArrayList<Smooth> getSmoothCongruences() {
		return smoothCongruences;
	}
	
	/**
	 * @return number of partial congruences found so far.
	 */
	public int getPartialCongruenceCount() {
		return totalPartialCount;
	}

	/**
	 * A report about the smooth and partial congruences that were found.
	 * @return report as String
	 */
	public String getReportString() {
		String smoothFromPartialsStr = smoothFromPartialCounts[0] + " from 1-partials";
		if (smoothFromPartialCounts[1]>0) smoothFromPartialsStr += ", " + smoothFromPartialCounts[1] + " from 2-partials";
		if (smoothFromPartialCounts[2]>0) smoothFromPartialsStr += ", " + smoothFromPartialCounts[2] + " from 3-partials";
		String partialsStr = partialCounts[0] + " 1-partials";
		if (partialCounts[1]>0) partialsStr += ", " + partialCounts[1] + " 2-partials";
		if (partialCounts[2]>0) partialsStr += ", " + partialCounts[2] + " 3-partials";
		String ret = "Found " + smoothCongruences.size() + " smooth congruences (" + perfectSmoothCount + " perfect, " 
				   + smoothFromPartialsStr + ") and " + getPartialCongruenceCount() + " partials (" + partialsStr + ")";
		if (analyzeFactors) {
			ret += "\nBig factor sizes of collected partials: " + oddExpBigFactorSizes;
			ret += "\nBig factor sizes of partials for smooths: " + oddExpBigFactorSizes4Smooth;
		}
		return ret;
	}
	
	/**
	 * Release memory after a factorization.
	 */
	public void cleanUp() {
		smoothCongruences = null;
		oddExpBigFactors_2_partialCongruences = null;
		partialSolverController.cleanUp();
		factorTest = null;
	}
}