// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor.basics.congruence;

import java.math.BigInteger;
import java.util.ArrayList;

import de.tilman_neumann.math.factor.basics.SortedIntegerArray;
import de.tilman_neumann.types.SortedMultiset;

/**
 * A partial congruence having an arbitrary number of large factors.
 */
public class Partial_nLarge extends Partial {

	private long[] bigFactors;
	private byte[] bigFactorExponents;
	
	/**
	 * Full constructor.
	 * @param A
	 * @param smallFactors small factors of Q
	 * @param bigFactors large factors of Q
	 * @param bigFactorExponents the exponents of all large factors
	 */
	public Partial_nLarge(BigInteger A, SortedIntegerArray smallFactors, long[] bigFactors, byte[] bigFactorExponents) {
		super(A, smallFactors);
		// big factor arguments have already been copied
		this.bigFactors = bigFactors;
		this.bigFactorExponents = bigFactorExponents;
	}

	@Override
	public SortedMultiset<Long> getQFactors() {
		// get small factors of Q
		SortedMultiset<Long> allFactors = super.getQFactors();
		// add large factors
		for (int i=0; i<bigFactors.length; i++) {
			allFactors.add(bigFactors[i], bigFactorExponents[i]);
		}
		return allFactors;
	}

	@Override
	public Long[] getMatrixElements() {
		ArrayList<Long> result = new ArrayList<Long>();
		for (int i=0; i<bigFactors.length; i++) {
			if ((bigFactorExponents[i]&1)==1) result.add(bigFactors[i]);
		}
		return result.toArray(new Long[result.size()]);
	}

	@Override
	public int getNumberOfLargeFactors() {
		int count = 0;
		for (int i=0; i<bigFactorExponents.length; i++) {
			count += bigFactorExponents[i];
		}
		return count;
	}

	@Override
	public String toString() {
		String str = super.toString();
		// add big factors
		if (bigFactors.length>0) {
			for (int i=0; i<bigFactors.length; i++) {
				str += bigFactors[i];
				int exp = bigFactorExponents[i];
				if (exp>1) str += "^" + exp;
				str += " * ";
			}
		}
		str = str.substring(0, str.length()-3); // remove last " * "
		return str;
	}
}
