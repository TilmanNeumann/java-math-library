// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor.basics.matrixSolver;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Set;

import de.tilman_neumann.math.factor.FactorException;
import de.tilman_neumann.math.factor.basics.congruence.AQPair;
import de.tilman_neumann.math.factor.basics.congruence.Congruence;
import de.tilman_neumann.math.factor.basics.congruence.Smooth;
import de.tilman_neumann.math.factor.basics.congruence.Smooth_Composed;

/**
 * A controller for the matrix solver used for partial congruence equations systems.
 * Solving such a system may give smooth congruences.
 * The controller pattern allows to have distinct matrix solver implementations, and a fallback procedure
 * that applies when a solver run gives only improper solutions.
 */
public class PartialSolverController implements NullVectorProcessor {
	
	private MatrixSolver<Long> matrixSolver;
	
	/** factor tester */
	private FactorTest factorTest;

	private ArrayList<Smooth> foundSmoothCongruences;

	public PartialSolverController(MatrixSolver<Long> matrixSolver) {
		// this hook would be a memory leak if we'ld create many pairs of controller and solver objects;
		// but we have only 1 object pair in the whole application run time
		matrixSolver.setNullVectorProcessor(this);
		this.matrixSolver = matrixSolver;
	}
	
	public void initialize(BigInteger N, FactorTest factorTest) {
		this.factorTest = factorTest;
	}

	/**
	 * Solve a partial congruence equation system.
	 * @param rawCongruences the partial congruence equation system
	 * @return list of smooth congruences found
	 * @throws FactorException if a factor of N was found
	 */
	public ArrayList<Smooth> solve(Collection<? extends Congruence<Long>> rawCongruences) throws FactorException {
		foundSmoothCongruences = new ArrayList<Smooth>();
		matrixSolver.solve(rawCongruences);
		return foundSmoothCongruences;
	}
	
	@Override
	public void processNullVector(Set<AQPair> aqPairs) throws FactorException {
		// we found a smooth congruence from partials!
		Smooth smoothCongruence = new Smooth_Composed(aqPairs);
		// Since smoothCongruence was assembled from several partials (each of which can not be square),
		// the new solution may give a Q that is an exact square!
		if (smoothCongruence.isExactSquare()) {
			// Q is an exact square -> does it give a factor?
			factorTest.testForFactor(aqPairs);
			// no FactorException -> the square congruence was improper -> drop it
		} else {
			// no exact square -> just keep the new smooth congruence
			foundSmoothCongruences.add(smoothCongruence);
		}
	}
	
	/**
	 * Release memory after a factorization.
	 */
	public void cleanUp() {
		foundSmoothCongruences = null;
		factorTest = null;
	}
}
