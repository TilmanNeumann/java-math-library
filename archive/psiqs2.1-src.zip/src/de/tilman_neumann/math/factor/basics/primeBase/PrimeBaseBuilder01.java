// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor.basics.primeBase;

import java.math.BigInteger;

import org.apache.log4j.Logger;

import de.tilman_neumann.math.base.bigint.JacobiSymbol;
import de.tilman_neumann.math.base.smallint.SmallPrimesGenerator31;

import static de.tilman_neumann.math.base.bigint.BigIntConstants.*;
import static org.junit.Assert.*;

/**
 * Fly-weight prime base builder.
 * This class is stateless and instantiation is very cheap; thus it does not need to be passed as argument.
 * 
 * computeReducedPrimeBase() methods return the 2 and odd primes with Legendre(kN|p)>=0, i.e. such that kN is not a non-residue (mod p).
 * Instead of the Legendre symbol, the Jacobi symbol is computed, which is faster.
 */
public class PrimeBaseBuilder01 implements PrimeBaseBuilder {
	private static final Logger LOG = Logger.getLogger(PrimeBaseBuilder01.class);
	private static final boolean DEBUG = false;
	
	private static final SmallPrimesGenerator31 PRIME_GENERATOR = new SmallPrimesGenerator31();

	private static int RAW_PRIMEBASE_SIZE = 100;
	/** the first RAW_PRIMEBASE_SIZE primes */
	private static int[] RAW_PRIMES_ARRAY = new int[RAW_PRIMEBASE_SIZE];
	
	static {
		// set up precomputed unfiltered prime base: the first RAW_PRIMEBASE_SIZE primes
		RAW_PRIMES_ARRAY[0] = PRIME_GENERATOR.nextPrime(); // 2 is added always
		assertEquals(2, RAW_PRIMES_ARRAY[0]);
		for (int i=1; i<RAW_PRIMEBASE_SIZE; i++) {
			int p = PRIME_GENERATOR.nextPrime();
			RAW_PRIMES_ARRAY[i] = p;
		}
	}
	
	private JacobiSymbol jacobiEngine = new JacobiSymbol();
	
	public PrimeBaseBuilder01() {
		if (DEBUG) assertEquals(3, RAW_PRIMES_ARRAY[1]);
	}

	@Override
	public Primes getPrimes(int count) {
		while (RAW_PRIMEBASE_SIZE < count) expandRawPrimesArray();
		return new Primes(RAW_PRIMES_ARRAY, RAW_PRIMEBASE_SIZE);
	}

	@Override
	public Primes getPrimesBelow(int bound) {
		while (RAW_PRIMES_ARRAY[RAW_PRIMEBASE_SIZE-1] < bound) expandRawPrimesArray();
		return new Primes(RAW_PRIMES_ARRAY, RAW_PRIMEBASE_SIZE);
	}

	@Override
	public void computeReducedPrimeBase(BigInteger kN, int primeBaseSize, int[] primesArray) {
		computeReducedPrimeBase(kN, primeBaseSize, primesArray, null);
	}

	@Override
	public void computeReducedPrimeBase(BigInteger kN, int primeBaseSize, int[] primesArray, BigInteger[] primesArray_big) {
		// the 2 is always added
		primesArray[0] = 2;
		if (primesArray_big!=null) primesArray_big[0] = TWO;
		// odd primes
		int count = 1;
		for (int i=1; ; i++) {
			if (i==RAW_PRIMEBASE_SIZE) expandRawPrimesArray();
			int p = RAW_PRIMES_ARRAY[i];
			int jacobi = jacobiEngine.jacobiSymbol(kN, p);
			if (DEBUG) {
				BigInteger p_big = BigInteger.valueOf(p);
				if (jacobi<-1 || jacobi>1) LOG.debug("kN=" + kN + ", p=" + p + " -> jacobi=" + jacobi);
				assertTrue(p_big.isProbablePrime(20));
			}
			// Q(x) = A(x)^2 - kN can only be divisible by p with Legendre(kN|p) >= 0.
			// It is important to add p with Legendre(kN|p) == 0, too! Otherwise we would not find such p during trial division.
			// On the other hand, doing a factor test here in that case makes no sense,
			// because it is typically caused by k, and we will find such factors during trial division anyway.
			if (jacobi>=0) {
				// kN is a quadratic residue mod p (or not coprime)
				primesArray[count] = p;
				// if not null, then fill primesArray_big, too
				if (primesArray_big!=null) primesArray_big[count] = BigInteger.valueOf(p);
				if (++count == primeBaseSize) break;
			}
		}
	}
	
	/**
	 * Expand the prime base.
	 */
	private void expandRawPrimesArray() {
		int nextSize = 2*RAW_PRIMEBASE_SIZE;
		int[] nexPrimesArray = new int[nextSize];
		System.arraycopy(RAW_PRIMES_ARRAY, 0, nexPrimesArray, 0, RAW_PRIMEBASE_SIZE);
		while (RAW_PRIMEBASE_SIZE < nextSize) {
			nexPrimesArray[RAW_PRIMEBASE_SIZE++] = PRIME_GENERATOR.nextPrime();
		}
		RAW_PRIMES_ARRAY = nexPrimesArray;
	}
}
