// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor.basics.congruence;

import java.math.BigInteger;
import java.util.HashSet;
import java.util.Set;

import de.tilman_neumann.math.factor.basics.SortedIntegerArray;
import de.tilman_neumann.types.SortedMultiset;
import de.tilman_neumann.types.SortedMultiset_TreeMapImpl;

/**
 * An <em>elementary</em> smooth or partially smooth congruence A^2 == Q (mod N).
 * Elementary means that only one (A,Q) pair is involved.
 * 
 * Eventual large factors must be added by subclasses!
 */
abstract public class AQPair {
	
	private BigInteger A;
	
	/** small factors of Q */
	private int[] smallFactors;
	private short[] smallFactorExponents;
	
	/** AQ-pairs never change -> compute hashCode only once */
	private int hashCode;
	
	/**
	 * Full constructor.
	 * @param A
	 * @param smallFactors small factors of Q
	 */
	public AQPair(BigInteger A, SortedIntegerArray smallFactors) {
		this.A = A;
		// precompute hashCode
		this.hashCode = A.hashCode();
		// copy small factors of Q
		this.smallFactors = smallFactors.copyFactors();
		this.smallFactorExponents = smallFactors.copyExponents();
	}

	public BigInteger getA() {
		return A;
	}

	/**
	 * @return all Q-factors with exponents.
	 * This method is only called in the final test of null vectors found by the smooth solver;
	 * but then it is needed for a whole bunch of AQPairs.
	 */
	public SortedMultiset<Long> getQFactors() {
		SortedMultiset<Long> allFactors = new SortedMultiset_TreeMapImpl<Long>();
		for (int i=0; i<smallFactors.length; i++) {
			allFactors.add((long)smallFactors[i], smallFactorExponents[i]);
		}
		return allFactors;
	}

	/**
	 * @return a copy of the set of small factors contained in Q with odd exponent.
	 * This method is called about twice on average for each smooth congruence.
	 */
	public Integer[] getSmallFactorsWithOddExponent() {
		Set<Integer> result = new HashSet<Integer>();
		for (int i=0; i<smallFactors.length; i++) {
			if ((smallFactorExponents[i]&1)==1) result.add(smallFactors[i]);
		}
		return result.toArray(new Integer[result.size()]);
	}

	/**
	 * @return the total number of large factors in this AQPair.
	 */
	abstract public int getNumberOfLargeFactors();
	
	/**
	 * hashCode() and equals() must be based on A to avoid duplicates.
	 * Q is not required, not even in CFrac.
	 */
	@Override
	public int hashCode() {
		// used in BlockLanczos solver and (Partial/Smooth)Congruence constructors
		//LOG.debug("hashCode()", new Throwable());
		return hashCode;
	}

	/**
	 * hashCode() and equals() must be based on A to avoid duplicates.
	 * Q is not required, not even in CFrac.
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null || getClass() != obj.getClass()) return false;
		AQPair other = (AQPair) obj;
		// equal objects must have the same hashCode
		if (hashCode != other.hashCode) return false;
		// since Q=A^2-kN is a function of A, we only need A
		return this.A.equals(other.getA());
	}

	@Override
	public String toString() {
		String str = "A=" + A + ", Q = ";
		if (smallFactors.length>0) {
			for (int i=0; i<smallFactors.length; i++) {
				str += smallFactors[i];
				int exp = smallFactorExponents[i];
				if (exp>1) str += "^" + exp;
				str += " * ";
			}
		}
		return str;
		// subclasses have to remove the last " * "
	}
}
