// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor.basics.matrixSolver;

import java.math.BigInteger;
import java.util.Collection;

import org.apache.log4j.Logger;

import de.tilman_neumann.math.factor.FactorException;
import de.tilman_neumann.math.factor.basics.congruence.AQPair;
import de.tilman_neumann.types.SortedMultiset;
import de.tilman_neumann.types.SortedMultiset_TreeMapImpl;

import static de.tilman_neumann.math.base.bigint.BigIntConstants.*;
import static org.junit.Assert.*;

/**
 * Factor test using modular reduction (mod N).
 */
public class FactorTest01 implements FactorTest {
	private static final Logger LOG = Logger.getLogger(FactorTest01.class);
	private static final boolean DEBUG = false;

	private BigInteger N;
	
	public FactorTest01(BigInteger N) {
		this.N = N;
	}
	
	/* (non-Javadoc)
	 * @see de.tilman_neumann.math.factor._basics.FactorTest#getName()
	 */
	@Override
	public String getName() {
		return "FactorTest01(" + N + ")";
	}

	/**
	 * Test if a square congruence A^2 == Q (mod kN) gives a factor of N.
	 * 
	 * Reducing both A and sqrt(Q) (mod N) means a great speed gain. Otherwise these products can become huge, 
	 * like a 1.000.000 bit number for N having 250 bit.
	 *
	 * @param aqPairs
	 * @throws FactorException
	 */
	@Override
	public void testForFactor(Collection<AQPair> aqPairs) throws FactorException {
		// Collect Q-factors from all AQPairs
		SortedMultiset<Long> totalQ_factors = new SortedMultiset_TreeMapImpl<Long>();
		for (AQPair aqPair : aqPairs) {
			totalQ_factors.addAll(aqPair.getQFactors());
		}
		// Compose totalQSqrt from the prime factorizations of the involved Q's;
		// BlockLanczos returns non-square "solutions", too, so we test on the fly if Q is really a square.
		long t0 = System.currentTimeMillis();
		BigInteger totalQSqrt = ONE;
		for (long factor : totalQ_factors.keySet()) {
			if (factor == -1) continue; // sqrt(Q-product) can be positive or negative, but we want the positive solution -> skip sign
			int exp = totalQ_factors.get(factor);
			if (exp%2==1) {
				// non-square "solution" -> early exit
				if (DEBUG) LOG.debug("factor = " + factor + ", exp = " + exp);
				return;
			}
			int halfExp = exp>>1;
			totalQSqrt = totalQSqrt.multiply(BigInteger.valueOf(factor).pow(halfExp)).mod(N); // reduction (mod N) is much faster
		}
		// Compute product of all A (mod N)
		BigInteger AProd = ONE;
		for (AQPair aqPair : aqPairs) {
			AProd = AProd.multiply(aqPair.getA()).mod(N); // reduction (mod N) is much faster
		}
		
		if (DEBUG) {
			long compositionDuration = System.currentTimeMillis() - t0;
			LOG.debug("N = " + N + ": testForFactor(): A=" + getAString(aqPairs) + "=" + AProd + ", Q=" + getQString(aqPairs) + ", sqrt(Q)=" + totalQSqrt);
			// verify congruence A^2 == Q (mod N)
			BigInteger totalQ = totalQSqrt.multiply(totalQSqrt);
			BigInteger div[] = AProd.pow(2).subtract(totalQ).divideAndRemainder(N);
			assertEquals(ZERO, div[1]);
			LOG.debug("A^2-Q = " + div[0] + " * N");
			LOG.debug("A^2 % N = " + AProd.pow(2).mod(N) + ", Q = " + totalQ);
		}

		// test A-sqrt(Q)
		BigInteger minusGcd = AProd.subtract(totalQSqrt).gcd(N);
		if (DEBUG) LOG.debug("minusGcd = " + minusGcd);
		if (minusGcd.compareTo(ONE)>0 && minusGcd.compareTo(N)<0) throw new FactorException(minusGcd); // factor!
		// test A+sqrt(Q)
		BigInteger plusGcd = AProd.add(totalQSqrt).gcd(N);
		if (DEBUG) LOG.debug("plusGcd = " + plusGcd);
		if (plusGcd.compareTo(ONE)>0 && plusGcd.compareTo(N)<0) throw new FactorException(plusGcd); // factor!
		// no factor exception -> no success
	}
	
	private String getAString(Collection<AQPair> aqPairs) {
		String str = "";
		for (AQPair aqPair : aqPairs) {
			str += aqPair.getA() + "*";
		}
		return str.substring(0, str.length()-1); // remove last "*"
	}
	
	private String getQString(Collection<AQPair> aqPairs) {
		String str = "";
		for (AQPair aqPair : aqPairs) {
			str += aqPair.getQFactors() + "*";
		}
		return str.substring(0, str.length()-1); // remove last "*"
	}
	
//	@Override
//	protected void finalize() {
//		LOG.debug("release " + this);
//	}
}
