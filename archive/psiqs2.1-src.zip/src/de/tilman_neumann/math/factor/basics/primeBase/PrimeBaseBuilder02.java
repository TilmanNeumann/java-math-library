// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor.basics.primeBase;

import java.math.BigInteger;
import java.util.Arrays;

import org.apache.log4j.Logger;

import de.tilman_neumann.math.base.bigint.JacobiSymbol;

import static de.tilman_neumann.math.base.bigint.BigIntConstants.*;
import static org.junit.Assert.*;

/**
 * Fly-weight prime base builder.
 * 
 * The raw prime base is extended when needed using a simple sieve of Eratosthenes.
 * 
 * computeReducedPrimeBase() methods return the 2 and odd primes with Legendre(kN|p)>=0, i.e. such that kN is not a non-residue (mod p).
 * Instead of the Legendre symbol, the Jacobi symbol is computed, which is faster.
 */
// TODO: This algorithm would run into memory problems when we try to retrieve the first 100 Mio primes.
public class PrimeBaseBuilder02 implements PrimeBaseBuilder {
	private static final Logger LOG = Logger.getLogger(PrimeBaseBuilder02.class);
	private static final boolean DEBUG = false;
	
	/** the first primes */
	private static int[] RAW_PRIMES_ARRAY = new int[] {2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97};
	private static int RAW_PRIMEBASE_SIZE = RAW_PRIMES_ARRAY.length;
	
	private JacobiSymbol jacobiEngine = new JacobiSymbol();
	
	public PrimeBaseBuilder02() {
		if (DEBUG) assertEquals(3, RAW_PRIMES_ARRAY[1]);
	}

	@Override
	public Primes getPrimes(int count) {
		while (RAW_PRIMEBASE_SIZE < count) expandRawPrimesArray();
		return new Primes(RAW_PRIMES_ARRAY, RAW_PRIMEBASE_SIZE);
	}

	@Override
	public Primes getPrimesBelow(int bound) {
		while (RAW_PRIMES_ARRAY[RAW_PRIMEBASE_SIZE-1] < bound) expandRawPrimesArray();
		return new Primes(RAW_PRIMES_ARRAY, RAW_PRIMEBASE_SIZE);
	}

	@Override
	public void computeReducedPrimeBase(BigInteger kN, int primeBaseSize, int[] primesArray) {
		computeReducedPrimeBase(kN, primeBaseSize, primesArray, null);
	}

	@Override
	public void computeReducedPrimeBase(BigInteger kN, int primeBaseSize, int[] primesArray, BigInteger[] primesArray_big) {
		// the 2 is always added
		primesArray[0] = 2;
		if (primesArray_big!=null) primesArray_big[0] = TWO;
		// odd primes
		int count = 1;
		for (int i=1; ; i++) {
			if (i==RAW_PRIMEBASE_SIZE) expandRawPrimesArray();
			int p = RAW_PRIMES_ARRAY[i];
			int jacobi = jacobiEngine.jacobiSymbol(kN, p);
			if (DEBUG) {
				BigInteger p_big = BigInteger.valueOf(p);
				if (jacobi<-1 || jacobi>1) LOG.debug("kN=" + kN + ", p=" + p + " -> jacobi=" + jacobi);
				assertTrue(p_big.isProbablePrime(20));
			}
			// Q(x) = A(x)^2 - kN can only be divisible by p with Legendre(kN|p) >= 0.
			// It is important to add p with Legendre(kN|p) == 0, too! Otherwise we would not find such p during trial division.
			// On the other hand, doing a factor test here in that case makes no sense,
			// because it is typically caused by k, and we will find such factors during trial division anyway.
			if (jacobi>=0) {
				// kN is a quadratic residue mod p (or not coprime)
				primesArray[count] = p;
				// if not null, then fill primesArray_big, too
				if (primesArray_big!=null) primesArray_big[count] = BigInteger.valueOf(p);
				if (++count == primeBaseSize) break;
			}
		}
	}
	
	/**
	 * Expand the raw prime base using a simple sieve of Eratosthenes.
	 */
	private void expandRawPrimesArray() {
		final int lastSize = RAW_PRIMEBASE_SIZE;
		final int lastPMax = RAW_PRIMES_ARRAY[RAW_PRIMEBASE_SIZE-1];
		if (DEBUG) LOG.info("lastSize=" + RAW_PRIMEBASE_SIZE + ", lastPMax=" + lastPMax + ", last primes = " + Arrays.toString(RAW_PRIMES_ARRAY));
		// Sieve up to 4*lastPMax will give > 3 times the number of primes we already have.
		// So this is a trade-off between performance and memory requirements.
		final int sieveLimit = 4*lastPMax;
		boolean[] isComposite = new boolean[sieveLimit+1]; // zero initialized
		int maxPrimeNeededForSieving = (int) Math.sqrt(sieveLimit);
		for (int p : RAW_PRIMES_ARRAY) {
			if (p>maxPrimeNeededForSieving) break;
			int rest = lastPMax % p;
			int x = lastPMax + p - rest;
			if (DEBUG) LOG.info("x = lastPMax + p - rest = " + lastPMax + "+" + p + "-" + rest + " = " + x + " is divisible by p=" + p);
			for (; x<=sieveLimit; x+=p) {
				isComposite[x] = true;
			}
		}
		if (DEBUG) LOG.info("sieveLimit=" + sieveLimit + ", next primes array length = " + 4*RAW_PRIMEBASE_SIZE);
		int[] nextPrimesArray = new int[4*RAW_PRIMEBASE_SIZE];
		System.arraycopy(RAW_PRIMES_ARRAY, 0, nextPrimesArray, 0, RAW_PRIMEBASE_SIZE);
		for (int x=lastPMax+1; x<sieveLimit; x++) {
			if (!isComposite[x]) {
				nextPrimesArray[RAW_PRIMEBASE_SIZE++] = x;
			}
		}
		RAW_PRIMES_ARRAY = nextPrimesArray;
		if (DEBUG) {
			LOG.info("lastSize=" + lastSize + ", newSize=" + RAW_PRIMEBASE_SIZE + " -> ratio=" + ((float)RAW_PRIMEBASE_SIZE)/lastSize);
			LOG.info("next " + RAW_PRIMEBASE_SIZE + " primes = " + Arrays.toString(nextPrimesArray));
		}
	}
}
