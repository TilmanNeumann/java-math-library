// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor.basics.congruence;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/**
 * A smooth congruence composed from several partials.
 */
public class Smooth_Composed implements Smooth {
	private Integer[] oddExpElements;
	private AQPair[] aqPairs;
	/** congruences never change; therefore we must compute the hashCode only once. */
	private int hashCode;

	/**
	 * Constructor from several AQ-pairs.
	 * @param aqPairs
	 */
	public Smooth_Composed(Set<AQPair> aqPairs) {
		this.aqPairs = new AQPair[aqPairs.size()];
		HashSet<Integer> smallFactorsWithOddExp = new HashSet<Integer>();
		int aqPairCount = 0;
		for (AQPair aqPair : aqPairs) {
			this.aqPairs[aqPairCount++] = aqPair;
			Integer[] oddExpSmallFactors = aqPair.getSmallFactorsWithOddExponent();
			// add via xor
			for (Integer oddExpSmallFactor : oddExpSmallFactors) {
				if (!smallFactorsWithOddExp.remove(oddExpSmallFactor)) smallFactorsWithOddExp.add(oddExpSmallFactor);
			}
		}
		this.oddExpElements = smallFactorsWithOddExp.toArray(new Integer[smallFactorsWithOddExp.size()]);
		this.hashCode = aqPairs.hashCode();
	}
	
	@Override
	public Integer[] getMatrixElements() {
		return oddExpElements;
	}

	@Override
	public AQPair[] getAQPairs() {
		return aqPairs;
	}

	@Override
	public boolean isExactSquare() {
		return oddExpElements.length==0;
	}

	@Override
	public int hashCode() {
		// only used in equals()
		//LOG.debug("hashCode()", new Throwable());
		return hashCode;
	}
	
	@Override
	public boolean equals(Object o) {
		if (o==null || !(o instanceof Smooth_Composed)) return false;
		Smooth_Composed other = (Smooth_Composed) o;
		// equal objects must have the same hashCode
		if (hashCode != other.hashCode) return false;
		return Arrays.equals(this.aqPairs, other.aqPairs);
	}

	@Override
	public String toString() {
		String str = "[oddExpFactors = " + Arrays.toString(oddExpElements) + ", aqPairs = ";
		for (AQPair aqPair : aqPairs) {
			str += aqPair.toString() + ", ";
		}
		return str.substring(0, str.length()-2) + "]";
	}
}
