// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor.basics.primeBase;

import org.apache.log4j.Logger;

import de.tilman_neumann.util.ConfigUtil;

/**
 * Test performance and correctness of results of prime base builders.
 */
public class TestPrimeBaseBuilders {
	private static final Logger LOG = Logger.getLogger(TestPrimeBaseBuilders.class);
	
	/**
	 * Test.
	 * @param args ignored
	 */
	public static void main(String[] args) {
    	ConfigUtil.initProject();
		for (int count=100; count<=10000000; count*=10) {
			// test performance
			long start = System.currentTimeMillis();
			PrimeBaseBuilder01 pbb01 = new PrimeBaseBuilder01();
			Primes primes01 = pbb01.getPrimes(count);
			LOG.info("PrimeBaseBuilder01(" + count + ") took " + (System.currentTimeMillis()-start) + "ms");
			start = System.currentTimeMillis();
			PrimeBaseBuilder02 pbb02 = new PrimeBaseBuilder02();
			Primes primes02 = pbb02.getPrimes(count);
			LOG.info("PrimeBaseBuilder02(" + count + ") took " + (System.currentTimeMillis()-start) + "ms");
			
			// check correctness
			for (int i=0; i<count; i++) {
				if (primes01.array[i] != primes02.array[i]) {
					LOG.error("The " + i + ".th prime differs! pbb01 gave " + primes01.array[i] + " and pbb02 gave " + primes02.array[i]);
				}
			}
		}
	}
}
