// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor.basics.congruence;

/**
 * A congruence from 1 or more AQ-pairs.
 * 
 * @param ME_T class of matrix elements
 */
public interface Congruence<ME_T extends Comparable<ME_T>> {
	
	/**
	 * @return set of factors of type ME_T that this congruence has with odd exponent.
	 */
	ME_T[] getMatrixElements();

	/**
	 * @return aqPairs of this congruence
	 */
	AQPair[] getAQPairs();
}
