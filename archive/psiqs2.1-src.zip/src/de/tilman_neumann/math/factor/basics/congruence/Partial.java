// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor.basics.congruence;

import java.math.BigInteger;

import de.tilman_neumann.math.factor.basics.SortedIntegerArray;

/**
 * Base class for partial congruences.
 */
abstract public class Partial extends AQPair implements Congruence<Long> {

	/**
	 * Full constructor.
	 * @param A
	 * @param smallFactors small factors of Q
	 * @param bigFactor the single large factor of Q
	 */
	public Partial(BigInteger A, SortedIntegerArray smallFactors) {
		super(A, smallFactors);
	}

	@Override
	abstract public Long[] getMatrixElements();

	@Override
	public AQPair[] getAQPairs() {
		return new AQPair[] {this};
	}
}
