// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor.basics.congruence;

import java.math.BigInteger;

import de.tilman_neumann.math.factor.basics.SortedIntegerArray;
import de.tilman_neumann.types.SortedMultiset;

/**
 * A smooth congruence with 1 large factor contained as a square.
 */
public class Smooth_1LargeSquare extends AQPair implements Smooth {

	private Integer[] oddExpElements;

	/** the large factor contained as a square */
	private long bigFactor;
	
	/**
	 * Full constructor.
	 * @param A
	 * @param smallFactors small factors of Q
	 * @param bigFactor the single large factor of Q contained as square
	 */
	public Smooth_1LargeSquare(BigInteger A, SortedIntegerArray smallFactors, long bigFactor) {
		super(A, smallFactors);
		this.oddExpElements = super.getSmallFactorsWithOddExponent();
		// the large factor contained as a square
		this.bigFactor = bigFactor;
	}

	@Override
	public SortedMultiset<Long> getQFactors() {
		// get small factors of Q
		SortedMultiset<Long> allFactors = super.getQFactors();
		// add single large factor square
		allFactors.add(bigFactor, 2);
		return allFactors;
	}
	
	@Override
	public Integer[] getMatrixElements() {
		return oddExpElements;
	}

	@Override
	public AQPair[] getAQPairs() {
		return new AQPair[] {this};
	}

	@Override
	public int getNumberOfLargeFactors() {
		return 2;
	}

	@Override
	public boolean isExactSquare() {
		return oddExpElements.length==0;
	}

	@Override
	public String toString() {
		String str = super.toString();
		// always 1 big factor, contained as square
		str += bigFactor + "^2";
		return str;
	}
}
