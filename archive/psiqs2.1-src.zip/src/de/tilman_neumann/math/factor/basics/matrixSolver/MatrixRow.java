// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor.basics.matrixSolver;

import java.util.ArrayList;

import org.apache.log4j.Logger;

/**
 * A congruence used by the matrix solver where the elements have been mapped to integer indices.
 */
public class MatrixRow {
	private static final Logger LOG = Logger.getLogger(MatrixRow.class);

	/** The indices of the factors with odd exponent in this row. */
	private IndexSet columnIndices;
	/** The indices of the original rows that where combined to this row (via xor) */
	private IndexSet rowIndexHistory;

	/**
	 * Full constructor. (no copy)
	 * @param columnIndices
	 * @param rowIndexHistory
	 */
	public MatrixRow(IndexSet columnIndices, IndexSet rowIndexHistory) {
		this.columnIndices = columnIndices;
		this.rowIndexHistory = rowIndexHistory;
	}
	
	public ArrayList<Integer> getRowIndexHistoryAsList() {
		return rowIndexHistory.toList();
	}
	
	public int getBiggestColumnIndex() {
		return columnIndices.last();		
	}

	/**
	 * Combine this and other in Z_2, modifying this.
	 * The operation in Z_2 is equivalent to "xor".
	 * @param other
	 */
	public void addXor(MatrixRow other) {
		this.columnIndices.addXor(other.columnIndices);
		this.rowIndexHistory.addXor(other.rowIndexHistory);
	}
	
	/**
	 * @return true if there are no odd exponent factor indices
	 */
	public boolean isNullVector() {
		return columnIndices.isEmpty();
	}
	
	@Override
	public int hashCode() {
		LOG.debug("hashCode()", new Throwable()); // never used
		return this.rowIndexHistory.hashCode();
	}
	
	@Override
	public boolean equals(Object o) {
		if (o==null || !(o instanceof MatrixRow)) return false;
		MatrixRow other = (MatrixRow) o;
		return this.rowIndexHistory.equals(other.rowIndexHistory);
	}

	@Override
	public String toString() {
		return "[columnIndices = " + columnIndices + ", rowIndexHistory = " + rowIndexHistory + "]";
	}
	
//	@Override
//	protected void finalize() {
//		LOG.debug("release " + this);
//	}
}
