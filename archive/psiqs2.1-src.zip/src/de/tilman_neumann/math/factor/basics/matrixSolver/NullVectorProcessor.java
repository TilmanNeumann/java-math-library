// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor.basics.matrixSolver;

import java.util.Set;

import de.tilman_neumann.math.factor.FactorException;
import de.tilman_neumann.math.factor.basics.congruence.AQPair;

/**
 * Simple interface to decouple congruence solver classes.
 */
public interface NullVectorProcessor {
	/**
	 * Process a null vector found by a matrix solver.
	 * @param aqPairs the AQ-pairs of the null vector.
	 * @throws FactorException
	 */
	void processNullVector(Set<AQPair> aqPairs) throws FactorException;
}
