/*
 * PSIQS 4.0 is a Java library for integer factorization, including a parallel self-initializing quadratic sieve (SIQS).
 * Copyright (C) 2018  Tilman Neumann (www.tilman-neumann.de)
 *
 * This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied
 * warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program;
 * if not, see <http://www.gnu.org/licenses/>.
 */
package de.tilman_neumann.math.base.bigint.sequence;

import java.math.BigInteger;

import org.apache.log4j.Logger;

import de.tilman_neumann.math.base.bigint.primes.exact.SieveFacade;
import de.tilman_neumann.util.ConfigUtil;

import static de.tilman_neumann.math.base.bigint.BigIntConstants.*;

/**
 * Sequence of multiplier * {squarefree numbers 1,2,3,5,6,7,10,11,13,...}, long implementation.
 * @author Tilman Neumann
 */
public class SquarefreeSequence63 implements IntegerSequence<Long> {
	private static final Logger LOG = Logger.getLogger(SquarefreeSequence63.class);

	private SieveFacade primeGen = SieveFacade.get();
	
	private long multiplier;
	private long next;
	
	public SquarefreeSequence63(long multiplier) {
		this.multiplier = multiplier;
	}
	
	@Override
	public String getName() {
		return multiplier + "*squarefree63";
	}

	public void reset() {
		this.next = 1;
	}
	
	@Override
	public void reset(BigInteger N) {
		this.next = 1;
	}

	@Override
	public Long next() {
		long ret = next;
		// compute next square free number
		while (true) {
			next = next + 1;
			boolean isSquareFree = true;
			// next must not be divisible by any prime square p^2 <= next
			long test = next;
			int primeIndex = 0;
			for (long p = 2; p*p<=test; p = primeGen.getPrime(++primeIndex)) {
				// test p
				if (test%p == 0) {
					test /= p;
					if (test%p == 0) {
						// next is not square free !
						isSquareFree = false;
						break;
					}
				}
			}
			if (isSquareFree) break; // found next square-free number
		}
		return ret * multiplier;
	}
	
	// standalone test
	public static void main(String[] args) {
	   	ConfigUtil.initProject();
	   	SquarefreeSequence63 seqGen = new SquarefreeSequence63(1);
		seqGen.reset(ONE); // >1 required!
		for (int i=1; i<=1000; i++) {
			LOG.info("squarefree(" + i + ") = " + seqGen.next());
		}
	}
}
