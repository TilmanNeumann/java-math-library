// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.util;

import java.io.File;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;
import org.apache.log4j.xml.DOMConfigurator;

/**
 * Global configuration tasks.
 * 
 * @author Tilman Neumann
 */
public class ConfigUtil {

	private static final Logger LOG = Logger.getLogger(ConfigUtil.class);
	
	private static boolean alreadyInitialized = false;
	public static boolean verbose = false;
	
	/** File separator used on this OS. */
	public static String FILE_SEPARATOR;
	/** Path separator used on this OS. */
	public static String PATH_SEPARATOR;
	/** The root directory of the current project. */
	public static String PROJECT_ROOT;
	/** The base folder for all configuration files in this project. */
	public static String CONF_ROOT;
	/** Java class path */
	public static String JAVA_CLASS_PATH;
	/** Java library path */
	public static String JAVA_LIBRARY_PATH;
	/** Java temp directory */
	public static String JAVA_TMP_DIR;
	/** user home directory */
	public static String USER_HOME;

	/** number of processors to use for parallel implementations */
	public static int NUMBER_OF_PROCESSORS;
	
	private ConfigUtil() {
		// static class
	}

	/**
	 * Project configuration.
	 */
	public static void initProject() {
		// avoid re-initialization from junit tests
		if (alreadyInitialized) return;
		
		FILE_SEPARATOR = System.getProperty("file.separator");
		if (verbose) System.out.println("system file separator = " + FILE_SEPARATOR);
		PATH_SEPARATOR = System.getProperty("path.separator");
		if (verbose) System.out.println("system path separator = " + PATH_SEPARATOR);
		PROJECT_ROOT = System.getProperty("user.dir");
		if (verbose) System.out.println("project root directory = " + PROJECT_ROOT);
		CONF_ROOT = PROJECT_ROOT + FILE_SEPARATOR + "conf";
		if (verbose) System.out.println("conf root directory = " + CONF_ROOT);
		JAVA_CLASS_PATH = System.getProperty("java.class.path");
		if (verbose) System.out.println("java.class.path = " + JAVA_CLASS_PATH);
		JAVA_LIBRARY_PATH = System.getProperty("java.library.path");
		if (verbose) System.out.println("java.library.path = " + JAVA_LIBRARY_PATH);
		JAVA_TMP_DIR = System.getProperty("java.io.tmpdir");
		if (verbose) System.out.println("java.io.tmpdir = " + JAVA_TMP_DIR);
		USER_HOME = System.getProperty("user.home");
		if (verbose) System.out.println("conf root directory = " + USER_HOME);
		NUMBER_OF_PROCESSORS = Runtime.getRuntime().availableProcessors();
		if (verbose) System.out.println("number of processors = " + NUMBER_OF_PROCESSORS);
		
		String confFileStr = CONF_ROOT + FILE_SEPARATOR + "log4jconf.xml";
		File confFile = new File(confFileStr);
		if (confFile.exists()) {
			// initialize XML-style Log4j-configuration
	    	DOMConfigurator.configure(CONF_ROOT + FILE_SEPARATOR + "log4jconf.xml");
	    	if (verbose) LOG.info("log4j configuration loaded.");
	    	if (verbose) LOG.info("project initialization finished.\n");
	    	alreadyInitialized = true;
		} else {
			// emergency initialization that logs into console
			PatternLayout layout = new PatternLayout();
			ConsoleAppender appender = new ConsoleAppender(layout);
			appender.setThreshold(Level.DEBUG); // TODO: Set to ERROR before creating jar file, to DEBUG before creating src distribution
			BasicConfigurator.configure(appender);
	    	alreadyInitialized = true;
		}
	}
}
