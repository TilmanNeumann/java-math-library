// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor.cfrac.tdiv;

import java.math.BigInteger;

import org.apache.log4j.Logger;

import de.tilman_neumann.math.factor.basics.SortedIntegerArray;
import de.tilman_neumann.math.factor.basics.congruence.AQPair;
import de.tilman_neumann.math.factor.basics.congruence.Partial_1Large;
import de.tilman_neumann.math.factor.basics.congruence.Smooth_Perfect;

import static de.tilman_neumann.math.base.bigint.BigIntConstants.*;
import static org.junit.Assert.*;

/**
 * Auxiliary factor algorithm to find smooth decompositions of Q's.
 * 
 * Version 01:
 * Uses only trial division -> this means that partials can have only 1 big factor
 * 
 * @author Tilman Neumann
 */
public class TDiv_CF01 implements TDiv_CF {
	@SuppressWarnings("unused")
	private static final Logger LOG = Logger.getLogger(TDiv_CF01.class);
	private static final boolean DEBUG = false;
	
	private int primeBaseSize;
	private int[] primesArray_int;
	private BigInteger[] primesArray_big;
	
	/** Q is sufficiently smooth if the unfactored Q_rest is smaller than this bound depending on N */
	private double maxSufficientSmoothRest;

	// result: two arrays that are reused, their content is _copied_ to AQ-pairs
	private SortedIntegerArray smallFactors = new SortedIntegerArray();

	@Override
	public String getName() {
		return "TDiv01";
	}

	public void initialize(BigInteger N, double maxSufficientSmoothRest) {
		this.maxSufficientSmoothRest = maxSufficientSmoothRest;
	}
	
	public void initialize(BigInteger kN, int primeBaseSize, int[] primesArray, BigInteger[] primesArray_big) {
		this.primeBaseSize = primeBaseSize;
		this.primesArray_int = primesArray;
		this.primesArray_big = primesArray_big;
	}

	public AQPair test(BigInteger A, BigInteger Q) {
		smallFactors.reset();
		
		// sign
		BigInteger Q_rest = Q;
		if (Q.signum() < 0) {
			smallFactors.add(-1);
			Q_rest = Q.negate();
		}
		// Remove multiples of 2
		int lsb = Q_rest.getLowestSetBit();
		if (lsb > 0) {
			for (int i=0; i<lsb; i++) {
				smallFactors.add(2);
			}
			Q_rest = Q_rest.shiftRight(lsb);
		}

		// Trial division chain:
		// -> first do it in BigInteger, then in long, then in int.
		// -> (small or probabilistic) prime tests during trial division just slow it down.
		// -> running indices bottom-up is faster because small dividends are more likely to reduce the size of Q_rest.
		int trialDivIndex = 1; // p[0]=2 has already been tested
		int Q_rest_bits = Q_rest.bitLength();
		if (Q_rest_bits>63) {
			// trial division in BigInteger required
			BigInteger p, div[];
			while (trialDivIndex < primeBaseSize) {
				p = primesArray_big[trialDivIndex];
				div = Q_rest.divideAndRemainder(p);
				if (div[1].equals(ZERO)) {
					// no remainder -> exact division -> small factor
					smallFactors.add(p.intValue());
					Q_rest = div[0];
					// After division by a prime base element (typically < 20 bit), Q_rest is >= 44 bits.
					Q_rest_bits = Q_rest.bitLength();
					if (Q_rest_bits<64) break; // continue in long version
					// trialDivIndex must remain as it is to find the same p more than once
				} else {
					trialDivIndex++;
				}
			} // end while (trialDivIndex < primeBaseSize)
		}
		if (Q_rest_bits>31 && Q_rest_bits<64 && trialDivIndex<primeBaseSize) {
			// continue trial division in long
			long Q_rest_long = Q_rest.longValue();
			while (trialDivIndex<primeBaseSize) {
				int p = primesArray_int[trialDivIndex];
				if (Q_rest_long % p == 0) {
					// no remainder -> exact division -> small factor
					smallFactors.add(p);
					Q_rest_long /= p;
					// After division by a prime base element (typically < 20 bit), Q_rest is 12..61 bits.
					Q_rest_bits = 64 - Long.numberOfLeadingZeros(Q_rest_long);
					if (Q_rest_bits<32) break; // continue with int
					// trialDivIndex must remain as it is to find the same p more than once
				} else {
					trialDivIndex++;
				}
			} // end while (trialDivIndex < primeBaseSize)
			Q_rest = BigInteger.valueOf(Q_rest_long); // keep Q_rest up-to-date
		}
		if (DEBUG) assertTrue(Q_rest.compareTo(ONE)>0);
		if (Q_rest_bits<32) {
			int Q_rest_int = Q_rest.intValue();
			while (trialDivIndex < primeBaseSize) {
				// continue trial division in int
				int p = primesArray_int[trialDivIndex];
				while (Q_rest_int % p == 0) { // in the last loop, a while pays out!
					// no remainder -> exact division -> small factor
					smallFactors.add(p);
					Q_rest_int /= p;
				}
				trialDivIndex++;
			} // end while (trialDivIndex < primeBaseSize)
			if (Q_rest_int==1) return new Smooth_Perfect(A, smallFactors);
			Q_rest = BigInteger.valueOf(Q_rest_int); // keep Q_rest up-to-date
		}

		// trial division was not sufficient to factor Q completely.
		// the remaining Q is either a prime > pMax, or a composite > pMax^2.
		if (Q_rest.doubleValue() > maxSufficientSmoothRest) return null; // Q is not sufficiently smooth
		
		// Q is sufficiently smooth
		return new Partial_1Large(A, smallFactors, Q_rest.longValue());
	}
}
