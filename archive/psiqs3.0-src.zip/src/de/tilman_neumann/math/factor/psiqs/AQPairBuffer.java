// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor.psiqs;

import java.util.ArrayList;
import java.util.Collection;

import de.tilman_neumann.math.factor.basics.congruence.AQPair;

/**
 * A synchronized buffer used to pass AQ-pairs from sieve threads to the control thread.
 * @author Tilman Neumann
 */
public class AQPairBuffer {
	private static final int INITIAL_BUFFER_SIZE = 100;
	
	private ArrayList<AQPair> aqPairs;
	public AQPairBuffer() {
		this.aqPairs = new ArrayList<AQPair>(INITIAL_BUFFER_SIZE);
	}
	
	public void addAll(Collection<AQPair> newAQPairs) {
		synchronized(this) { // block write from other threads and read access from control thread
			aqPairs.addAll(newAQPairs);
			this.notify(); // notify control thread about incoming data
		}
	}
	
	// this method must be synchronized externally on this to block write access
	public ArrayList<AQPair> removeAll() {
		ArrayList<AQPair> ret = aqPairs;
		aqPairs = new ArrayList<AQPair>(INITIAL_BUFFER_SIZE);
		return ret;
	}
}
