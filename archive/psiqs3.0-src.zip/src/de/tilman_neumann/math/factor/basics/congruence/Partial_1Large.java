// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor.basics.congruence;

import java.math.BigInteger;

import de.tilman_neumann.math.factor.basics.SortedIntegerArray;
import de.tilman_neumann.types.SortedMultiset;

/**
 * A partial congruence having 1 large factor.
 * 
 * @author Tilman Neumann
 */
public class Partial_1Large extends Partial {

	private long bigFactor;
	
	/**
	 * Full constructor.
	 * @param A
	 * @param smallFactors small factors of Q
	 * @param bigFactor the single large factor of Q
	 */
	public Partial_1Large(BigInteger A, SortedIntegerArray smallFactors, long bigFactor) {
		super(A, smallFactors);
		// only 1 large factor
		this.bigFactor = bigFactor;
	}

	@Override
	public SortedMultiset<Long> getQFactors() {
		// get small factors of Q
		SortedMultiset<Long> allFactors = super.getQFactors();
		// add single large factor
		allFactors.add(bigFactor);
		return allFactors;
	}

	@Override
	public Long[] getMatrixElements() {
		return new Long[] {bigFactor};
	}

	@Override
	public int getNumberOfLargeFactors() {
		return 1;
	}

	@Override
	public String toString() {
		String str = super.toString();
		// always 1 big factor
		str += bigFactor;
		return str;
	}
}
