// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor.basics.matrixSolver;

import java.util.Collection;

import de.tilman_neumann.math.factor.FactorException;
import de.tilman_neumann.math.factor.basics.congruence.AQPair;

/**
 * Interface for final factor tests when a square congruence A^2 == Q (mod kN) has been found.
 * The congruence may be improper though...
 * 
 * @author Tilman Neumann
 */
public interface FactorTest {

	/** 
	 * @return the algorithm name 
	 */
	String getName();

	/**
	 * Test if a square congruence A^2 == Q (mod kN) gives a factor of N.
	 *
	 * @param aqPairs
	 * @throws FactorException
	 */
	void testForFactor(Collection<AQPair> aqPairs) throws FactorException;
}