// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor.basics.matrixSolver;

import java.util.ArrayList;

/**
 * Interface for index sets used as matrix row elements and column elements.
 * @author Tilman Neumann
 */
public interface IndexSet {
	
	void addXor(IndexSet other);

	boolean contains(Object o);

	Integer last();

	/**
	 * @return true if this set is empty
	 */
	boolean isEmpty();

	/**
	 * @return this index set as a list
	 */
	ArrayList<Integer> toList();
	
	@Override
	boolean equals(Object o);
	
	@Override
	String toString();
}
