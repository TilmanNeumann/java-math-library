// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor.basics.matrixSolver;

import java.math.BigInteger;
import java.util.Collection;
import java.util.Set;

import org.apache.log4j.Logger;

import de.tilman_neumann.math.factor.FactorException;
import de.tilman_neumann.math.factor.basics.congruence.AQPair;
import de.tilman_neumann.math.factor.basics.congruence.Congruence;

/**
 * A controller for the matrix solver used for smooth congruence equations systems.
 * Solving such a system (mod N) may give square congruences, and a factor of N if such a square congruence is proper.
 * The controller pattern allows to have distinct matrix solver implementations, and a fallback procedure
 * that applies when a solver run gives only improper solutions.
 * 
 * @author Tilman Neumann
 */
public class SmoothSolverController implements NullVectorProcessor {
	@SuppressWarnings("unused")
	private static final Logger LOG = Logger.getLogger(SmoothSolverController.class);

	private MatrixSolver<Integer> matrixSolver;

	/** factor tester */
	private FactorTest factorTest;

	// for debugging only
	private int testedNullVectorCount;

	public SmoothSolverController(MatrixSolver<Integer> matrixSolver) {
		// this hook would be a memory leak if we'ld create many pairs of controller and solver objects;
		// but we have only 1 object pair in the whole application run time
		matrixSolver.setNullVectorProcessor(this);
		this.matrixSolver = matrixSolver;
	}
	
	public String getName() {
		return matrixSolver.getName();
	}
	
	public void initialize(BigInteger N, FactorTest factorTest) {
		this.factorTest = factorTest;
		this.testedNullVectorCount = 0;
	}
	
	/**
	 * Solve a smooth congruence equation system.
	 * @param rawCongruences the smooth congruence equation system
	 * @throws FactorException if a factor of N was found
	 */
	public void solve(Collection<? extends Congruence<Integer>> rawCongruences) throws FactorException {
		matrixSolver.solve(rawCongruences);
	}

	@Override
	public void processNullVector(Set<AQPair> aqPairs) throws FactorException {
		// found square congruence -> check for factor
		testedNullVectorCount++;
		factorTest.testForFactor(aqPairs);
		// no factor exception -> drop improper square congruence
	}
	
	public int getTestedNullVectorCount() {
		return testedNullVectorCount;
	}
	
	/**
	 * Release memory after a factorization.
	 */
	public void cleanUp() {
		factorTest = null;
	}
}
