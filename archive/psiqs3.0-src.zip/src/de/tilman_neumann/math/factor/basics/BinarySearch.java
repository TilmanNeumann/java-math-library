// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor.basics;

import static org.junit.Assert.*;

/**
 * Binary search.
 * @author Tilman Neumann
 */
public class BinarySearch {
	private static final boolean DEBUG = false;
	
	/**
	 * Find the index of the first array entry that is greater than elementToSearch.
	 * 
	 * @param elementArray the array to search in
	 * @param elementCount the valid number of array entries (may be smaller than the array size)
	 * @param elementToSearch
	 * @return the index of the first array entry greater than elementToSearch. or -1 if there is no such element
	 */
	public int getFirstGreaterEntryIndex(int[] elementArray, int elementCount, int elementToSearch) {
		if (elementCount<=0 || elementArray[elementCount-1] <= elementToSearch) return -1; // there is no entry greater than elementToSearch
		int left = 0;
		int right = elementCount-1;
		int median;
		do {
			median = (left+right)>>1; // floor
			if (elementArray[median] <= elementToSearch) {
				// the tested element was too small, the result must have a higher index
				left = median + 1;
			} else {
				// the tested element was not too small, it could be right or too big
				right = median;
			}
		} while (left!=right);
		if (DEBUG) {
			if (left>0)	assertTrue(elementArray[left-1] <= elementToSearch);
			assertTrue(elementToSearch < elementArray[left]);
		}
		return left;
	}
}
