// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor.basics.congruence;

import java.math.BigInteger;

import de.tilman_neumann.math.factor.basics.SortedIntegerArray;
import de.tilman_neumann.math.factor.basics.SortedLongArray;

/**
 * Creates an elementary congruence of the subclass appropriate for the given large factors.
 * @author Tilman Neumann
 */
public class AQPairFactory {
	/**
	 * @param A
	 * @param smallFactors small factors of Q
	 * @param bigFactors large factors of Q
	 */
	public AQPair create(BigInteger A, SortedIntegerArray smallFactors, SortedLongArray bigFactors) {
		long[] bigFactorsCopy = bigFactors.copyFactors();
		int distinctBigFactorsCount = bigFactorsCopy.length;
		if (distinctBigFactorsCount == 0) return new Smooth_Perfect(A, smallFactors);
		byte[] bigFactorExponents = bigFactors.copyExponents();
		if (distinctBigFactorsCount == 1) {
			int exp = bigFactorExponents[0];
			if (exp==1) return new Partial_1Large(A, smallFactors, bigFactorsCopy[0]);
			if (exp==2) return new Smooth_1LargeSquare(A, smallFactors, bigFactorsCopy[0]);
			// higher exponents are treated below
		} else if (distinctBigFactorsCount == 2) {
			if (bigFactorExponents[0]==1 && bigFactorExponents[1]==1) return new Partial_2Large(A, smallFactors, bigFactorsCopy[0], bigFactorsCopy[1]);
			// higher exponents are treated below
		}
		// now in total we have at least 3 large factors
		boolean isSquare = true;
		for (int i=0; i<bigFactorsCopy.length; i++) {
			if ((bigFactorExponents[i]&1)==1) {
				isSquare = false;
				break;
			}
		}
		if (!isSquare) {
			// partial
			return new Partial_nLarge(A, smallFactors, bigFactorsCopy, bigFactorExponents);
		}
		// smooth
		return new Smooth_nLargeSquares(A, smallFactors, bigFactorsCopy, bigFactorExponents);
	}
}
