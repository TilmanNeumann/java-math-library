// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor.basics.matrixSolver;

import java.util.HashSet;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import de.tilman_neumann.math.factor.FactorException;
import de.tilman_neumann.math.factor.basics.congruence.AQPair;
import de.tilman_neumann.math.factor.basics.congruence.Congruence;

/**
 * An adapter for Dario Alpern's Block-Lanczos solver.
 * 
 * Appears to be faster than the Gaussian solver starting at N>200 bit.
 * 
 * @author Tilman Neumann
 * 
 * @param ME_T class of matrix elements
 */
public class MatrixSolver02_BlockLanczos<ME_T extends Comparable<ME_T>> extends MatrixSolver<ME_T> {
	@SuppressWarnings("unused")
	private static final Logger LOG = Logger.getLogger(MatrixSolver02_BlockLanczos.class);

	private BlockLanczos blockLanczosSolver = new BlockLanczos();
	
	@Override
	public String getName() {
		return "solver02_BL";
	}
	
	@Override
	protected void solve(List<Congruence<ME_T>> congruences, Map<ME_T, Integer> factors_2_columnIndices) throws FactorException {
		// create the matrix:
		// * the rows are in the same order as in the congruences list
		// * we fill a row with the column indices where the congruence has a factor with odd exponent
		int matrixBlength = congruences.size();
		int[][] matrixB = new int[matrixBlength][];
		int i=0;
		for (Congruence<ME_T> congruence : congruences) {
			// row entry = set of column indices where the congruence has a factor with odd exponent
			ME_T[] oddExpFactors = congruence.getMatrixElements();
			int[] matrixRow = new int[oddExpFactors.length];
			int j=0;
			for (ME_T oddExpFactor : oddExpFactors) {
				matrixRow[j++] = factors_2_columnIndices.get(oddExpFactor);
			}
			matrixB[i++] = matrixRow;
		}
		//LOG.debug("constructed matrix with " + matrixBlength + " rows and " + factors_2_columnIndices.size() + " columns");
		
		// invoke Alperns Block Lanczos solver
		int[] matrixV = blockLanczosSolver.computeBlockLanczos(matrixB, matrixBlength);
		//LOG.debug("BlockLanzcos returned matrixV = " + Arrays.toString(matrixV));
		
		// See Siqs.LinearAlgebraPhase() for how to interprete matrixV:
		// There can be up to 32 potential solutions encoded in matrixV!
		// One in bit 0 of all ints, the next in bit 1 of all ints, and so on.
  		for (int mask = 1; mask != 0; mask *= 2) {
  			HashSet<AQPair> totalAQPairs = new HashSet<AQPair>(); // Set required for the "xor"-operation below
  			for (int row = matrixBlength - 1; row >= 0; row--) {
  				if ((matrixV[row] & mask) != 0) {
  					// the current row belongs to the solution encoded in matrixV by the bit addressed by mask.
  					// the row indices are the same as in my congruences list.
  					Congruence<ME_T> congruence = congruences.get(row);
  					//LOG.info("mask=" + mask + ": add congruence " + congruence);
					// add the new AQ-pairs via "xor" !
  					AQPair[] aqPairs = congruence.getAQPairs();
  					for (AQPair aqPair : aqPairs) {
  						if (!totalAQPairs.remove(aqPair)) totalAQPairs.add(aqPair);
  					}
  				}
  			}
  			
  			if (!totalAQPairs.isEmpty()) {
  				// Sometimes the BlockLanczos() method returns non-null-vectors (having q-factors with odd exponent),
  				// but it did not seem beneficial to test the exponents before calling processNullVector(.)
	  			// So just "return" the AQ-pairs of the null vector:
	  			nullVectorProcessor.processNullVector(totalAQPairs);
  			}
  		}
	}
}
