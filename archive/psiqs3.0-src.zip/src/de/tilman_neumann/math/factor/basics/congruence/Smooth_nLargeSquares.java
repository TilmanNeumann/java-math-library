// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor.basics.congruence;

import java.math.BigInteger;

import de.tilman_neumann.math.factor.basics.SortedIntegerArray;
import de.tilman_neumann.types.SortedMultiset;

/**
 * A smooth congruence having an arbitrary number of large factors.
 * 
 * @author Tilman Neumann
 */
public class Smooth_nLargeSquares extends AQPair implements Smooth {

	private Integer[] oddExpElements;

	private long[] bigFactors;
	private byte[] bigFactorExponents;
	
	/**
	 * Full constructor.
	 * @param A
	 * @param smallFactors small factors of Q
	 * @param bigFactors large factors of Q
	 * @param bigFactorExponents the exponents of all large factors
	 */
	public Smooth_nLargeSquares(BigInteger A, SortedIntegerArray smallFactors, long[] bigFactors, byte[] bigFactorExponents) {
		super(A, smallFactors);
		// copy big factors of Q
		this.bigFactors = bigFactors;
		this.bigFactorExponents = bigFactorExponents;
		// small factors with odd exponent
		this.oddExpElements = super.getSmallFactorsWithOddExponent();
	}

	@Override
	public SortedMultiset<Long> getQFactors() {
		// get small factors of Q
		SortedMultiset<Long> allFactors = super.getQFactors();
		// add large factors
		for (int i=0; i<bigFactors.length; i++) {
			allFactors.add(bigFactors[i], bigFactorExponents[i]);
		}
		return allFactors;
	}
	
	@Override
	public Integer[] getMatrixElements() {
		return oddExpElements;
	}

	@Override
	public AQPair[] getAQPairs() {
		return new AQPair[] {this};
	}

	@Override
	public int getNumberOfLargeFactors() {
		int count = 0;
		for (int i=0; i<bigFactorExponents.length; i++) {
			count += bigFactorExponents[i];
		}
		return count;
	}

	@Override
	public boolean isExactSquare() {
		return oddExpElements.length==0;
	}

	@Override
	public String toString() {
		String str = super.toString();
		// add big factors
		if (bigFactors.length>0) {
			for (int i=0; i<bigFactors.length; i++) {
				str += bigFactors[i];
				int exp = bigFactorExponents[i];
				if (exp>1) str += "^" + exp;
				str += " * ";
			}
		}
		str = str.substring(0, str.length()-3); // remove last " * "
		return str;
	}
}
