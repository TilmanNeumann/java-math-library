// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor.basics.congruence;

import java.math.BigInteger;

import de.tilman_neumann.math.factor.basics.SortedIntegerArray;
import de.tilman_neumann.types.SortedMultiset;

/**
 * A partial congruence having 2 distinct large factors.
 * 
 * @author Tilman Neumann
 */
public class Partial_2Large extends Partial {

	private long bigFactor1, bigFactor2;
	
	/**
	 * Full constructor.
	 * @param A
	 * @param smallFactors small factors of Q
	 * @param bigFactor1 the first large factor of Q
	 * @param bigFactor2 the second large factor of Q
	 */
	public Partial_2Large(BigInteger A, SortedIntegerArray smallFactors, long bigFactor1, long bigFactor2) {
		super(A, smallFactors);
		// only 1 large factor
		this.bigFactor1 = bigFactor1;
		this.bigFactor2 = bigFactor2;
	}

	@Override
	public SortedMultiset<Long> getQFactors() {
		// get small factors of Q
		SortedMultiset<Long> allFactors = super.getQFactors();
		// add single large factor
		allFactors.add(bigFactor1);
		allFactors.add(bigFactor2);
		return allFactors;
	}

	@Override
	public Long[] getMatrixElements() {
		return new Long[] {bigFactor1, bigFactor2};
	}

	@Override
	public int getNumberOfLargeFactors() {
		return 2;
	}

	@Override
	public String toString() {
		String str = super.toString();
		// always 1 big factor
		str += bigFactor1 + " * " + bigFactor2;
		return str;
	}
}
