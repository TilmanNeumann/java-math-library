// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor.pollardRho;

import java.math.BigInteger;
import java.security.SecureRandom;

import org.apache.log4j.Logger;

import de.tilman_neumann.math.base.bigint.Gcd63;
import de.tilman_neumann.math.factor.FactorAlgorithmBase;

/**
 * 31-bit implementation of Pollard' Rho method.
 * 
 * From <link>http://www.cs.princeton.edu/introcs/79crypto/PollardRho.java</link>
 * (INTRODUCTION TO COMPUTER SCIENCE by Robert Sedgewick and Kevin Wayne):
 *
 * "Pollards Rho method is a randomized factoring algorithm that can factor 128 bit numbers
 * in a reasonable amount of time, especially if the numbers have some small factors.
 * It is based on the following fact: if d is the smallest nontrivial factor of N and
 * x-y is a nontrivial multiple of d then gcd(x-y, N) = d. A naive method would be to 
 * generate a bunch of random values x[1], x[2], ..., x[m] and compute gcd(x[i]-x[j], N) 
 * for all pairs i and j. Pollard's rho method is an ingenious method way to find x and y 
 * without doing all of the pairwise computations. It works as follows: choose a and b
 * at random between 1 and N-1, and initialize x = y = a. Repeatedly update x = f(x), y = f(f(y)),
 * where f(x) = x^2 + b as long as gcd(x-y, N) = 1. The gcd is a factor of N, but if you
 * get unlucky, it could be equal to N. By randomly choosing a and b each time, we
 * ensure that we never get too unlucky."
 * 
 * @author Tilman Neumann
 */
public class PollardRho31 extends FactorAlgorithmBase {
	@SuppressWarnings("unused")
	private static final Logger LOG = Logger.getLogger(PollardRho31.class);
	private static final SecureRandom RNG = new SecureRandom();

	private Gcd63 gcdEngine = new Gcd63();

	/** factor argument converted to int */
	private int n;

	@Override
	public String getName() {
		return "PollardRho31";
	}
	
	@Override
	public BigInteger findSingleFactor(BigInteger N) {
		this.n = N.intValue();
		
        long gcd;
        long x = RNG.nextInt(n); // uniform random int from [0, n)
        long xx = x;
        do {
        	int c = RNG.nextInt(n); // uniform random int from [0, n)
	        do {
	            x  = addModN(squareModN(x), c);
	            xx = addModN(squareModN(xx), c);
	            xx = addModN(squareModN(xx), c);
	            gcd = gcdEngine.gcd(x-xx, n);
	        } while(gcd==1);
        } while (gcd==n); // leave loop if factor found; otherwise continue with a new random c
		//LOG.debug("Found factor of " + N + " = " + factor);
        return BigInteger.valueOf(gcd);
	}

	/**
	 * Addition modulo N, with <code>a, b < N</code>.
	 * @param a
	 * @param b
	 * @return (a+b) mod N
	 */
	private long addModN(long a, int b) {
		long sum = a + b;
		return sum<n ? sum : sum-n;
	}

	/**
	 * x^2 modulo N.
	 * @param x
	 * @return
	 */
	private long squareModN(long x) {
		long square = x * x;
		return square % n;
	}
}
