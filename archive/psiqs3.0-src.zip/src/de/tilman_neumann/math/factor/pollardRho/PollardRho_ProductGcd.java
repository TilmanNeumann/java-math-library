// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor.pollardRho;

import java.math.BigInteger;
import java.security.SecureRandom;

import org.apache.log4j.Logger;

import de.tilman_neumann.math.factor.FactorAlgorithmBase;

import static de.tilman_neumann.math.base.bigint.BigIntConstants.*;

/**
 * Pollard's Rho algorithm improved by doing the GCD on products.
 * 
 * @author Tilman Neumann
 */
public class PollardRho_ProductGcd extends FactorAlgorithmBase {
	@SuppressWarnings("unused")
	private static final Logger LOG = Logger.getLogger(PollardRho_ProductGcd.class);
	private static final SecureRandom RNG = new SecureRandom();

	private BigInteger N;

	@Override
	public String getName() {
		return "PollardRho_Prod";
	}
	
	@Override
	public BigInteger findSingleFactor(BigInteger N) {
		this.N = N;
		int bitLength = N.bitLength();
        BigInteger product, gcd;
        
        do {
	        // start with random x0, c from [0, 2^n] where n=upper(ld N)
        	BigInteger c = new BigInteger(bitLength, RNG);
            BigInteger x = new BigInteger(bitLength, RNG);
            BigInteger xx = x;
	        
	        do {
	        	product = ONE;
	        	for (int i=0; i<100; i++) {
		            x  = addModN( x.multiply(x) .mod(N), c);
		            xx = addModN(xx.multiply(xx).mod(N), c);
		            xx = addModN(xx.multiply(xx).mod(N), c);
		            product = product.multiply(x.subtract(xx)).mod(N);
	        	}
	            gcd = product.gcd(N); // the gcd function must give gcd(0,N) = N
	        } while(gcd.equals(ONE));
	        
	    // leave loop if factor found; otherwise continue with new random x0, c
        } while (gcd.equals(N));
		//LOG.debug("Found factor of " + N + " = " + factor);
        return gcd;
	}

	/**
	 * Addition modulo N, with <code>a, b < N</code>.
	 * @param a
	 * @param b
	 * @return (a+b) mod N
	 */
	private BigInteger addModN(BigInteger a, BigInteger b) {
		BigInteger sum = a.add(b);
		return sum.compareTo(N)<0 ? sum : sum.subtract(N);
	}
}
