// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor.tdiv;

import java.math.BigInteger;

import de.tilman_neumann.math.base.bigint.primes.possible.PPGen;
import de.tilman_neumann.math.base.bigint.primes.possible.PPGen02;
import de.tilman_neumann.math.factor.FactorAlgorithmBase;

import static de.tilman_neumann.math.base.bigint.BigIntConstants.*;

/**
 * Trial division, with my own possible prime generator.
 * 
 * @author Tilman Neumann
 */
public class TDiv_PPGen2 extends FactorAlgorithmBase {

	@Override
	public String getName() {
		return "TDiv/ppgen2";
	}

	@Override
	public BigInteger findSingleFactor(BigInteger n) {
		// test 3 and 5, not covered by PPGen2
		BigInteger[] div = n.divideAndRemainder(THREE);
		if (div[1].equals(ZERO)) return THREE;
		div = n.divideAndRemainder(FIVE);
		if (div[1].equals(ZERO)) return FIVE;
		
		// if n is odd and composite then the loop runs maximally up to test = floor(sqrt(n))
		PPGen ppGen = new PPGen02();
		while (true) {
			BigInteger test = ppGen.next();
			div = n.divideAndRemainder(test);
			if (div[1].equals(ZERO)) return test;
		}
	}
	
	/**
	 * Test if n has a factor <= maxTestNumber.
	 * @param n
	 * @param maxTestNumber
	 * @return small factor, or null if n has no factor <= maxTestNumber
	 */
	public BigInteger findSmallFactor(BigInteger n, BigInteger maxTestNumber) {
		// test 2, 3 and 5, not covered by PPGen2
		if (maxTestNumber.compareTo(TWO)<0) return null;
		if (n.and(ONE).equals(ZERO)) return TWO;
		if (maxTestNumber.compareTo(THREE)<0) return null;
		BigInteger[] div = n.divideAndRemainder(THREE);
		if (div[1].equals(ZERO)) return THREE;
		if (maxTestNumber.compareTo(FIVE)<0) return null;
		div = n.divideAndRemainder(FIVE);
		if (div[1].equals(ZERO)) return FIVE;
		
		// test until maxTestNumber or until a factor is found
		PPGen ppGen = new PPGen02();
		BigInteger test = ppGen.next();
		while (test.compareTo(maxTestNumber)<=0) {
			div = n.divideAndRemainder(test);
			if (div[1].equals(ZERO)) return test;
			// next
			test = ppGen.next();
		}
		return null;
	}

}
