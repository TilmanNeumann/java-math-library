// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor.siqs;

import java.math.BigInteger;

/**
 * Interface for generators that produce the leading coefficient <code>a</code> of the quadratic polynomial
 * Q(x) = (a*x+b)^2 - kN used by SIQS.</br></br>
 * 
 * The a-parameter in SIQS is chosen as a product of primes from the prime base: <code>a = q1 * ... * q_s</code>.
 * Its value should be roughly a ~ sqrt(2*k*N)/M, where M is the sieve array size, such that |Q(x)|
 * is about the same at x=+M and x=-M, and |Q(x)| <= kN for all x.
 * 
 * The quality of the a-generator is crucial for both stability and performance of SIQS.
 * 
 * @author Tilman Neumann
 */
public interface AParamGenerator {

	String getName();
	
	/**
	 * Initialize this a-parameter generator for a new N.
	 * One result has to be a <code>qCount</code> value fixed throughout the rest of the factorization of N.
	 * @param k
	 * @param N
	 * @param kN
	 * @param primeBaseSize
	 * @param primesArray
	 * @param sieveArraySize
	 */
	void initialize(int k, BigInteger N, BigInteger kN, int primeBaseSize, int[] primesArray, int sieveArraySize);
	
	BigInteger computeNextAParameter();
	
	/**
	 * @return number of primes <code>s</code> with <code>a-parameter = q_1 * ... * q_s</code>
	 */
	int getQCount();
	
	int[] getQIndexArray();
	
	int[] getQArray();
	
	/**
	 * Release memory after a factorization.
	 */
	void cleanUp();
}
