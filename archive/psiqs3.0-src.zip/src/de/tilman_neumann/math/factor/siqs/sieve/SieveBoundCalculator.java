// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor.siqs.sieve;

/**
 * Algorithms to compute the minimal sum of ln(p_i) values required for a Q to pass the sieve.
 * 
 * This bound is computed as ln(Q/a) - ln(max rest), where ln(Q/a) is the natural logarithm of average (Q/a)-values,
 * estimated according to the papers of Contini, Pomerance and Silverman as ln(Q/a) = ln(M) + ln(kN)/2 - 1/2.
 * 
 * The second term ln(max rest) is the natural logarithm of the maximum "unfactored rest" we want to permit after sieveing.
 * It depends on the algorithm chosen here:</br>
 * N_BASED:    ln(max rest) = T * ln(N)     (my first choice)</br>
 * KN_BASED:   ln(max rest) = T * ln(kN)    (my second choice)</br>
 * PMAX_BASED: ln(max rest) = T * ln(p_max) (Silverman)</br></br>
 * 
 * The T-parameter should be around 0.16 for N_BASED, KN_BASED, and around 2.0 for PMAX_BASED (Silverman's parametrization)
 * 
 * Including the a-parameter in the computation of ln(Q/a) does not pay out
 * because then we need to re-initialize too many things for each new a-parameter.
 * 
 * @author Tilman Neumann
 */
public enum SieveBoundCalculator {
	N_BASED {
		@Override
		public double computeSieveBound(float T, double lnN, double lnkN, int pMax, int sieveArraySize) {
			// [Contini], [Pomerance], [Silverman] etc.
			double lnM = Math.log(sieveArraySize);
			double lnQdivAEstimate = lnM + lnkN/2 - 0.5;
			// my first choice
			double lnMaxAllowedRest = T * lnN;
			return lnQdivAEstimate - lnMaxAllowedRest;
		}
	},
	
	KN_BASED {
		@Override
		public double computeSieveBound(float T, double lnN, double lnkN, int pMax, int sieveArraySize) {
			// [Contini], [Pomerance], [Silverman] etc.
			double lnM = Math.log(sieveArraySize);
			double lnQdivAEstimate = lnM + lnkN/2 - 0.5;
			// my second choice
			double lnMaxAllowedRest = T * lnkN;
			return lnQdivAEstimate - lnMaxAllowedRest;
		}
	},

	PMAX_BASED {
		@Override
		public double computeSieveBound(float T, double lnN, double lnkN, int pMax, int sieveArraySize) {
			// [Contini], [Pomerance], [Silverman] etc.
			double lnM = Math.log(sieveArraySize);
			double lnQdivAEstimate = lnM + lnkN/2 - 0.5;
			// [Silverman]
			double lnPMax = Math.log(pMax);
			double lnMaxAllowedRest = T * lnPMax;
			return lnQdivAEstimate - lnMaxAllowedRest;
		}
	};
	
	/**
	 * Compute the minimal sum of ln(p_i) values required for a Q to pass the sieve.
	 * @param T around 0.16 for N_BASED, KN_BASED, and around 2.0 for PMAX_BASED
	 * @param lnN
	 * @param lnkN
	 * @param pMax
	 * @param sieveArraySize
	 * @return minimal required ln(p_i) sum
	 */
	abstract public double computeSieveBound(float T, double lnN, double lnkN, int pMax, int sieveArraySize);
}
