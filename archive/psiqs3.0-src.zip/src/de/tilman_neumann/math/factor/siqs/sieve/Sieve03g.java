// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor.siqs.sieve;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import de.tilman_neumann.math.factor.basics.BinarySearch;
import de.tilman_neumann.math.factor.siqs.PolySolutions;
import de.tilman_neumann.util.Timer;

/**
 * Advanced non-segmented sieve implementation.
 * 
 * Version 03:
 * -> The smallest primes are not used for sieving.
 *    A prime p makes an overall contribution proportional to log(p)/p to the sieve array,
 *    but the runtime of sieving with a prime p is proportional to sieveArraySize/p.
 *    Thus sieving with small primes is less effective, and skipping them improves performance.
 * -> Let counters run down -> simpler termination condition
 * -> Faster zero-initialization of sieve array with System.arrayCopy().
 * 
 * Version 03b:
 * -> Initialize sieve array such that a sieve hit is achieved if (logPSum & 0x80) != 0,
 *    and then use the or-trick in sieve:collect.
 * -> precompute minSolutionCounts for all p
 * -> allocate sieveArray with pMax extra entries to save size checks
 * 
 * Version 03c:
 * -> sieve positive x-values first, then negative x-values. Surprising improvement.
 * 
 * Version 03d:
 * -> Special treatment for large primes having 0-1 solutions for each of x1, x2 inside the sieve array.
 *    This is the biggest performance improvement since the 1.0.2 release!
 * 
 * Version 03e:
 * -> Collect smooth Q(x) for pos/neg x independently -> another small improvement
 * 
 * Version 03f:
 * -> Initialization is be done independently for pos/neg x, too -> now only 1 sieve array is needed!
 * 
 * Version 03g:
 * -> further unrolling of large primes
 * -> sieve with all primes as if they have 2 x-solutions
 * 
 * @author Tilman Neumann
 */
public class Sieve03g implements Sieve {
	private static final Logger LOG = Logger.getLogger(Sieve03g.class);
	private static final boolean DEBUG = false;
	
	// factor argument data
	private float lnN;
	private double lnkN;

	// prime base
	private int primeBaseSize;
	private float pMinMult; // multiplier to compute pMinIndex
	/** we do not sieve with primes p_i, i<pMinIndex */
	private int pMinIndex;
	/** p_i with i>pLargeIndex have at most 1 solution in the sieve array for each of x1, x2 */
	private int pLargeIndex;
	private int p2Index;
	private int p3Index;
	private int[] minSolutionCounts_m3;
	private float lnPMultiplier;
	
	private PolySolutions primeSolutions;

	// sieve
	/** Algorithm to compute the logPSum threshold value */
	private SieveBoundCalculator sieveBoundCalculator = SieveBoundCalculator.N_BASED;
	/** Algorithm to compute the initializer value */
	private InitializerCalculator initializerCalculator = InitializerCalculator.SMALL;
	
	private float T;
	private int sieveArraySize;
	private int wantedMinLogPSum;
	/** basic building block for fast initialization of sieve array */
	private byte[] initializer;
	/** the sieve array */
	private byte[] sieve_logPSumArray;

	private BinarySearch binarySearch = new BinarySearch();

	// timings
	private boolean profile;
	private Timer timer = new Timer();
	private long initDuration, sieveDuration, collectDuration;

	/**
	 * Simplified constructor.
	 * @param T the T parameter: reasonable values are T ~ 0.16 for SieveBoundCalculator.N_BASED, T ~ 2.0 for SieveBoundCalculator.PMAX_BASED
	 * @param wantedMinLogPSum values between 70..120 seem best (experimental results)
	 * @param pMinMult a multiplier to compute the smallest prime in the prime base to be used for sieving
	 */
	public Sieve03g(float T, int wantedMinLogPSum, float pMinMult) {
		this.T = T;
		this.wantedMinLogPSum = wantedMinLogPSum;
		this.pMinMult = pMinMult;
	}
	
	@Override
	public String getName() {
		return "sieve03g(" + T + ", " + wantedMinLogPSum + ", " + pMinMult + ")";
	}
	
	@Override
	public void initialize(double N_dbl, BigInteger kN, int unfilteredPrimeBaseSize, int[] unfilteredPrimesArray, int[] unfilteredTArray, int sieveArraySize, boolean profile) {
		this.lnN = (float) Math.log(N_dbl);
		lnkN = Math.log(kN.doubleValue());

		this.minSolutionCounts_m3 = new int[unfilteredPrimeBaseSize]; // XXX: allocate in setPrimeSolutions() with size p3Index ?
		this.pMinIndex = Math.max(1, (int) (pMinMult * Math.log(unfilteredPrimeBaseSize))); // avoid p[0]==2 which is not used in several sieves
		int pMax = unfilteredPrimesArray[unfilteredPrimeBaseSize-1];
		
		// Compute sieve bound in natural logarithm & convert to the actual logBase:
		double minLnPSum = sieveBoundCalculator.computeSieveBound(T, lnN, lnkN, pMax, sieveArraySize);
		float lnLogBase = (float) (minLnPSum / wantedMinLogPSum); // normalizer to be used as a divisor for p_i values
		int minLogPSum = (int) (minLnPSum / lnLogBase); // floor, result should be ~wantedMinLogPSum
		if (DEBUG) {
			float logBase = (float) Math.exp(lnLogBase);
			LOG.debug("logBase=" + logBase + ", lnLogBase=" + lnLogBase + ", minLnPSum = " + minLnPSum + ", minLogPSum = " + minLogPSum);
		}
		initializer = initializerCalculator.compute(unfilteredPrimesArray, pMinIndex, minLogPSum, lnLogBase);
		lnPMultiplier = 1.0F/lnLogBase; // normalizer to be used as a multiplier for p_i values (faster)

		// Allocate sieve array: Typically SIQS adjusts such that 2.75 * sieveArraySize ~ pMax.
		// For large primes with 0 or 1 sieve locations we need to allocate pMax+1 entries;
		// For primes p[i], i<pLargeIndex, we need p[i]+sieveArraySize = 2*sieveArraySize entries.
		this.sieveArraySize = sieveArraySize;
		int sieveAllocationSize = Math.max(pMax+1, 2*sieveArraySize);
		sieve_logPSumArray = new byte[sieveAllocationSize];
		if (DEBUG) LOG.debug("unfilteredPrimeBaseSize = " + unfilteredPrimeBaseSize + ", pMax = " + pMax + ", sieveArraySize = " + sieveArraySize + " --> sieveAllocationSize = " + sieveAllocationSize);

		// profiling
		this.profile = profile;
		initDuration = sieveDuration = collectDuration = 0;
	}

	@Override
	public int getPMinIndex() {
		return pMinIndex;
	}

	@Override
	public float getLnPMultiplier() {
		return lnPMultiplier;
	}

	@Override
	public void setPrimeSolutions(PolySolutions primeSolutions) {
		this.primeSolutions = primeSolutions;
		int[] primesArray = primeSolutions.primesOrPowers;
		this.primeBaseSize = primesArray.length;
		
		this.pLargeIndex = binarySearch.getFirstGreaterEntryIndex(primesArray, primeBaseSize, sieveArraySize);
		if (pLargeIndex<0) pLargeIndex = primeBaseSize;
		this.p2Index = binarySearch.getFirstGreaterEntryIndex(primesArray, pLargeIndex, (sieveArraySize+1)/2);
		if (p2Index<0) p2Index = pLargeIndex;
		this.p3Index = binarySearch.getFirstGreaterEntryIndex(primesArray, p2Index, (sieveArraySize+2)/3);
		if (p3Index<0) p3Index = p2Index;
		if (DEBUG) LOG.debug("primeBaseSize=" + primeBaseSize + ", pLargeIndex=" + pLargeIndex + ", p2Index=" + p2Index + ", p3Index=" + p3Index);
		
		// The minimum number of x-solutions in the sieve array is floor(sieveArraySize/p).
		// E.g. for p=3, sieveArraySize=8 there are solutions (0, 3, 6), (1, 4, 7), (2, 5)  <-- 8 is not in sieve array anymore
		// -> minSolutionCount = 2
		for (int i=p3Index-1; i>=pMinIndex; i--) {
			minSolutionCounts_m3[i] = sieveArraySize/primesArray[i] - 3;
			//LOG.debug("p=" + primesArray[i] + ": minSolutionCount = " + minSolutionCounts_m3[i]);
		}
	}

	@Override
	public List<Integer> sieve() {
		if (profile) timer.capture();
		this.initializeSieveArray(sieveArraySize);
		if (profile) initDuration += timer.capture();
		
		// Sieve with positive x, large primes:
		final int[] primesArray = primeSolutions.primesOrPowers;
		final int[] x1Array = primeSolutions.x1Array;
		final int[] x2Array = primeSolutions.x2Array;
		final byte[] logPArray = primeSolutions.logPArray;
		int i, x1, x2, j;
		for (i=primeBaseSize-1; i>=pLargeIndex; i--) {
			// x1 == x2 happens only if p divides k -> for large primes p > k there are always 2 distinct solutions.
			// x1, x2 may exceed sieveArraySize, but we allocated the arrays somewhat bigger to save the size checks.
			final byte logP = logPArray[i];
			sieve_logPSumArray[x1Array[i]] += logP;
			sieve_logPSumArray[x2Array[i]] += logP;
		}
		for ( ; i>=p2Index; i--) {
			final int p = primesArray[i];
			final byte logP = logPArray[i];
			x1 = x1Array[i];
			x2 = x2Array[i];
			sieve_logPSumArray[x1] += logP;
			sieve_logPSumArray[x2] += logP;
			sieve_logPSumArray[x1+p] += logP;
			sieve_logPSumArray[x2+p] += logP;
		}
		for ( ; i>=p3Index; i--) {
			final int p = primesArray[i];
			final byte logP = logPArray[i];
			x1 = x1Array[i];
			x2 = x2Array[i];
			sieve_logPSumArray[x1] += logP;
			sieve_logPSumArray[x2] += logP;
			sieve_logPSumArray[x1+p] += logP;
			sieve_logPSumArray[x2+p] += logP;
			final int p2 = p<<1;
			sieve_logPSumArray[x1+p2] += logP;
			sieve_logPSumArray[x2+p2] += logP;
		}
		// Positive x, small primes:
		for ( ; i>=pMinIndex; i--) {
			final int p = primesArray[i];
			final byte logP = logPArray[i];
			x1 = x1Array[i];
			x2 = x2Array[i];
			// Solution x1 == x2 happens in any of (basic QS, MPQS, SIQS) if p divides k.
			// But there are very few of such primes (none if k==1), so we are better off avoiding that case distinction.
			// The last x may exceed sieveArraySize, but we allocated the arrays somewhat bigger to save the size checks.
			sieve_logPSumArray[x1] += logP;
			sieve_logPSumArray[x2] += logP;
			sieve_logPSumArray[x1+p] += logP;
			sieve_logPSumArray[x2+p] += logP;
			final int p2 = p<<1;
			sieve_logPSumArray[x1+=p2] += logP;
			sieve_logPSumArray[x2+=p2] += logP;
			for (j=minSolutionCounts_m3[i]; j>=0; j--) {
				sieve_logPSumArray[x1+=p] += logP;
				sieve_logPSumArray[x2+=p] += logP;
			}
		} // end for (p)
		if (profile) sieveDuration += timer.capture();

		// collect results
		List<Integer> smoothXList = new ArrayList<Integer>();
		// let the sieve entry counter x run down to 0 is much faster because of the simpler exit condition
		for (int x=sieveArraySize-1; x>=0; ) {
			// Unfortunately, in Java we can not cast byte[] to int[] or long[].
			// So we have to use 'or'. More than 4 'or's do not pay out.
			if (((sieve_logPSumArray[x--] | sieve_logPSumArray[x--] | sieve_logPSumArray[x--] | sieve_logPSumArray[x--]) & 0x80) != 0) {
				// at least one of the tested Q(x) is sufficiently smooth to be passed to trial division!
				if (sieve_logPSumArray[x+1] < 0) smoothXList.add(x+1);
				if (sieve_logPSumArray[x+2] < 0) smoothXList.add(x+2);
				if (sieve_logPSumArray[x+3] < 0) smoothXList.add(x+3);
				if (sieve_logPSumArray[x+4] < 0) smoothXList.add(x+4);
			}
		}
		if (profile) collectDuration += timer.capture();
		
		// re-initialize sieve array for negative x
		this.initializeSieveArray(sieveArraySize);
		if (profile) initDuration += timer.capture();

		// negative x, large primes:
		for (i=primeBaseSize-1; i>=pLargeIndex; i--) {
			final int p = primesArray[i];
			final byte logP = logPArray[i];
			sieve_logPSumArray[p-x1Array[i]] += logP;
			sieve_logPSumArray[p-x2Array[i]] += logP;
		}
		for (; i>=p2Index; i--) {
			final int p = primesArray[i];
			final byte logP = logPArray[i];
			x1 = p-x1Array[i];
			x2 = p-x2Array[i];
			sieve_logPSumArray[x1] += logP;
			sieve_logPSumArray[x2] += logP;
			sieve_logPSumArray[x1+p] += logP;
			sieve_logPSumArray[x2+p] += logP;
		}
		for (; i>=p3Index; i--) {
			final int p = primesArray[i];
			final byte logP = logPArray[i];
			x1 = p-x1Array[i];
			x2 = p-x2Array[i];
			sieve_logPSumArray[x1] += logP;
			sieve_logPSumArray[x2] += logP;
			sieve_logPSumArray[x1+p] += logP;
			sieve_logPSumArray[x2+p] += logP;
			final int p2 = p<<1;
			sieve_logPSumArray[x1+p2] += logP;
			sieve_logPSumArray[x2+p2] += logP;
		}
		// negative x, small primes:
		for (; i>=pMinIndex; i--) {
			final int p = primesArray[i];
			final byte logP = logPArray[i];
			x1 = p-x1Array[i];
			x2 = p-x2Array[i];
			sieve_logPSumArray[x1] += logP;
			sieve_logPSumArray[x2] += logP;
			sieve_logPSumArray[x1+p] += logP;
			sieve_logPSumArray[x2+p] += logP;
			final int p2 = p<<1;
			sieve_logPSumArray[x1+=p2] += logP;
			sieve_logPSumArray[x2+=p2] += logP;
			for (j=minSolutionCounts_m3[i]; j>=0; j--) {
				sieve_logPSumArray[x1+=p] += logP;
				sieve_logPSumArray[x2+=p] += logP;
			}
		} // end for (p)
		if (profile) sieveDuration += timer.capture();

		// collect results
		// let the sieve entry counter x run down to 0 is much faster because of the simpler exit condition
		for (int x=sieveArraySize-1; x>=0; ) {
			// Unfortunately, in Java we can not cast byte[] to int[] or long[].
			// So we have to use 'or'. More than 4 'or's do not pay out.
			if (((sieve_logPSumArray[x--] | sieve_logPSumArray[x--] | sieve_logPSumArray[x--] | sieve_logPSumArray[x--]) & 0x80) != 0) {
				// at least one of the tested Q(-x) is sufficiently smooth to be passed to trial division!
				if (sieve_logPSumArray[x+1] < 0) smoothXList.add(-(x+1));
				if (sieve_logPSumArray[x+2] < 0) smoothXList.add(-(x+2));
				if (sieve_logPSumArray[x+3] < 0) smoothXList.add(-(x+3));
				if (sieve_logPSumArray[x+4] < 0) smoothXList.add(-(x+4));
			}
		}
		if (profile) collectDuration += timer.capture();
		return smoothXList;
	}

	/**
	 * Initialize the sieve array(s) with the initializer value computed before.
	 * @param sieveArraySize
	 */
	private void initializeSieveArray(int sieveArraySize) {
		// overwrite existing arrays with initializer. we know that sieve array size is a multiple of 256
		System.arraycopy(initializer, 0, sieve_logPSumArray, 0, 256);
		int filled = 256;
		int unfilled = sieveArraySize-filled;
		while (unfilled>0) {
			int fillNext = Math.min(unfilled, filled);
			System.arraycopy(sieve_logPSumArray, 0, sieve_logPSumArray, filled, fillNext);
			filled += fillNext;
			unfilled = sieveArraySize-filled;
		}
	}
	
	@Override
	public String getProfilingReport() {
		return "init=" + initDuration + "ms, sieve=" + sieveDuration + "ms, collect=" + collectDuration + "ms";
	}
	
	@Override
	public void cleanUp() {
		primeSolutions = null;
		minSolutionCounts_m3 = null;
		sieve_logPSumArray = null;
	}
}
