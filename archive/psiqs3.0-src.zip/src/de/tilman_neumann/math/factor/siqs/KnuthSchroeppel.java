// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor.siqs;

import static de.tilman_neumann.math.base.bigint.BigIntConstants.SEVEN;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;

import org.apache.log4j.Logger;

import de.tilman_neumann.math.base.bigint.JacobiSymbol;
import de.tilman_neumann.math.base.bigint.primes.exact.PrimeGenerator;
import de.tilman_neumann.math.base.bigint.primes.exact.SieveOfEratosthenes02;
import de.tilman_neumann.math.base.bigint.sequence.SquarefreeSequence;

/**
 * Computation of the Knuth-Schroeppel multiplier k for the quadratic sieve.
 * 
 * Most often the algorithm finds k with kN == 1 (mod 8), but kN == 3,5,7 (mod 8) are possible, too.
 * Most "best k" are prime, but we also find composite and 1.
 *
 * @see [Pomerance 1985: "The Quadratic Sieve Factoring Algorithm"].
 * @see [Silverman 1987: "The Multiple Polynomial Quadratic Sieve", page 335].
 * 
 * @author Tilman Neumann
 */
public class KnuthSchroeppel {
	
	private static final Logger LOG = Logger.getLogger(KnuthSchroeppel.class);
	private final static boolean DEBUG = false;
	
	private static final double HALF_LN2 = 0.5 * Math.log(2);
	private static final double LN2      = 1.0 * Math.log(2);
	private static final double TWO_LN2  = 2.0 * Math.log(2);
	
	// 10000 primes would always be enough, but using the expandable sieve is nicer
	private PrimeGenerator primeGen = SieveOfEratosthenes02.get();
	private SquarefreeSequence squareFreeSequence = new SquarefreeSequence(1);

	private int[] kArray = new int[10000];
	private BigInteger[] kNArray = new BigInteger[10000];
	private double[] fArray = new double[10000];
	private int[] primeCountArray = new int[10000];

	private JacobiSymbol jacobiEngine = new JacobiSymbol();
	
	/**
	 * Compute Knuth-Schroeppel multiplier k for N.
	 * @param N
	 * @param primeBaseSize
	 * @return k
	 */
	public int computeMultiplier(BigInteger N, int primeBaseSize) {
		// Parameters have been chosen experimentally as a tradeoff between the runtime
		// of the Knuth-Schroeppel algorithm and the quality of the k-evaluation.
		// 195 bits is the transition point between the small N and large N optimizations.
		int NBits = N.bitLength();
		int wantedPrimeCount = NBits < 195 ? (int) (Math.pow(2, 3.39+0.036*(NBits-50))) : 2*NBits; // the number of primes that would be part of the prime base to be tested
		int kMax = wantedPrimeCount; // the maximum value of k to consider
		double penaltyMult = 0.35; // 0.35 is better than 0.5 proposed by literature
		
		// f(k, N) is the score for k that we wish to maximize.
		// initialize f(k, N) with the p=2 case and a bad penalty for big k:
		squareFreeSequence.reset(); // start at k=1
		int kCount = 0;		
		while (true) {
			BigInteger k_big = squareFreeSequence.next();
			int k = k_big.intValue();
			if (k%2==0) continue;
			if (k>kMax) break;
			// now k is odd and square-free and not too big
			BigInteger kN = N.multiply(k_big);
			int kNMod8 = kN.and(SEVEN).intValue();
			
			double f;
			if (kNMod8==1) {
				f =  TWO_LN2 - penaltyMult * Math.log(k);
			} else if (kNMod8==5) {
				f =      LN2 - penaltyMult * Math.log(k);
			} else { // kN == 3, 7 (mod 8)
				f = HALF_LN2 - penaltyMult * Math.log(k);
			}
			// store
			kArray[kCount] = k;
			kNArray[kCount] = kN;
			fArray[kCount] = f;
			primeCountArray[kCount++] = 1; // p=2
		}
		// Analysis: kCount ~ 0.406 * kMax
		
		// From the following list we will remove the indices of any k that have been completely evaluated.
		// ArrayList performs better than LinkedList, even with that many remove() operations.
		ArrayList<Integer> kIndexList = new ArrayList<Integer>(kCount);
		for (int kIndex=0; kIndex<kCount; kIndex++) kIndexList.add(kIndex);
		
		// add odd primes contribution
		int i=1;
		for (; ; i++) {
			int p = primeGen.getPrime(i);
			double lnP = Math.log(p);
			double lnPTerm1 = lnP / (double) p;
			double lnPTerm2 = 2*lnP / (double) (p-1);
			int Legendre_N_p = jacobiEngine.jacobiSymbol(N, p);
			Iterator<Integer> kIndexIter = kIndexList.iterator();
			while (kIndexIter.hasNext()) {
				int kIndex = kIndexIter.next();
				int k = kArray[kIndex];
				if (k % p == 0) {
            		// p divides k -> only one x-solution.
            		fArray[kIndex] += lnPTerm1;
            		primeCountArray[kIndex]++;
				} else if (jacobiEngine.jacobiSymbol(k, p) * Legendre_N_p == 1) {
            		// kN is quadratic residue (mod p) -> 2 x-solutions.
            		// The cost of computing Legendre(kN|p) dominates the algorithm.
            		// Here we use Legendre(kN|p) = Legendre(k|p)*Legendre(N|p) with precomputed Legendre(N|p) to improve performance
            		fArray[kIndex] += lnPTerm2;
            		primeCountArray[kIndex]++;
            	} // else: p is not part of the resulting prime base -> skip
            	
            	// if we are done with some k then remove its kIndex from the list
				if (primeCountArray[kIndex] == wantedPrimeCount) kIndexIter.remove();
	        } // end for (k)
			
			// are we done with all k ?
			if (kIndexList.isEmpty()) break;
		} // end for (odd primes)
		if (DEBUG) LOG.debug("kCount = " + kCount + ": required number of primes = " + (i+1));
		// Analysis: required number of primes < 6*kCount
		
		// now we have evaluated f(k, N) for all k. pick the one that maximizes f [Pomerance 1985]
		int best_k = 1;
		double best_f = Double.MIN_VALUE;
		for (int kIndex=0; kIndex<kCount; kIndex++) {
			if (fArray[kIndex] > best_f) {
				best_f = fArray[kIndex];
				best_k = kArray[kIndex];
	        }
			//LOG.debug("f(k=" + k + ") = " + f + ", best f = " + best_f + " at k=" + best_k);
	    }
		//LOG.debug("Knuth-Schroeppel multiplier k = " + best_k);
		return best_k;
	}
}
