// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor.siqs;

import static de.tilman_neumann.math.base.bigint.BigIntConstants.ONE;
import static de.tilman_neumann.math.base.bigint.BigIntConstants.TWO;
import static org.junit.Assert.assertEquals;

import java.math.BigInteger;

import de.tilman_neumann.math.base.bigint.ModularSqrt;
import de.tilman_neumann.math.base.bigint.ModularSqrt31;
import de.tilman_neumann.math.base.bigint.UnsignedBigInt;

/**
 * Engine to compute the smallest modular sqrts for all elements of the prime base.
 * @author Tilman Neumann
 */
public class ModularSqrtsEngine {
	
	private static final boolean DEBUG = false;
	
	private ModularSqrt31 modularSqrtEngine = new ModularSqrt31();

	/**
	 * For all primes p in the prime base, find the modular sqrt's of kN (mod p), i.e. the t such that t^2 == kN (mod p).
	 *
	 * @param primesArray
	 * @param primeBaseSize
	 * @param kN
	 * @return
	 */
	public int[] computeTArray(int[] primesArray, int primeBaseSize, BigInteger kN) {
		UnsignedBigInt kN_UBI = new UnsignedBigInt(kN);
		int[] tArray = new int[primeBaseSize]; // zero-initialized
		// special treatment for p[0]=2 (always contained in prime base)
		tArray[0] = kN.and(ONE).intValue();
		// odd primes
		for (int i = primeBaseSize-1; i>0; i--) {
			// Tonelli_Shanks requires Legendre(kN|p)==1, 0 is not ok. But this is easy to "heal":
			// Since p is prime, Legendre(kN|p)==0 means that kN is a multiple of p.
			// Thus t^2 == kN == 0 (mod p) and the modular sqrt t is 0, too.
			int p = primesArray[i];
			int kN_mod_p = kN_UBI.mod(p);
			if (kN_mod_p > 0) {
				tArray[i] = modularSqrtEngine.Tonelli_Shanks(kN_mod_p, p);
			} // else: we do not need to set tArray[i] = 0, because the array has already been initialized with zeros
		}
		if (DEBUG) {
			assertEquals(BigInteger.valueOf(tArray[0]).pow(2).mod(TWO), kN.mod(TWO));
			ModularSqrt modularSqrtEngine_big = new ModularSqrt();
			for (int i = primeBaseSize-1; i>0; i--) {
				int p = primesArray[i];
				int kN_mod_p = kN_UBI.mod(p);
				if (kN_mod_p > 0) {
					assertEquals(tArray[i], modularSqrtEngine_big.Tonelli_Shanks(kN, p));
					assertEquals(tArray[i], modularSqrtEngine_big.Tonelli_Shanks(kN.mod(BigInteger.valueOf(p)), p));
				}
			}
		}
		return tArray;
	}
}
