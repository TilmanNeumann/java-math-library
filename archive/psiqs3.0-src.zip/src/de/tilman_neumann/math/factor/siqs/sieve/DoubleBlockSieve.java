// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor.siqs.sieve;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import de.tilman_neumann.math.factor.basics.BinarySearch;
import de.tilman_neumann.math.factor.siqs.PolySolutions;
import de.tilman_neumann.util.Timer;

/**
 * Double block sieve implementation, essentially following [Wambach, Wettig 1995].
 * 
 * @author Tilman Neumann
 */
public class DoubleBlockSieve implements Sieve {
	private static final Logger LOG = Logger.getLogger(DoubleBlockSieve.class);
	private static final boolean DEBUG = false;
	
	// factor argument data
	private float lnN;
	private double lnkN;

	// prime base
	private int primeBaseSize;
	private float pMinMult; // multiplier to compute pMinIndex
	private int pMinIndex;
	private float lnPMultiplier;

	private PolySolutions primeSolutions;

	// sieve
	/** Algorithm to compute the logPSum threshold value */
	private SieveBoundCalculator sieveBoundCalculator = SieveBoundCalculator.N_BASED;
	/** Algorithm to compute the initializer value */
	private InitializerCalculator initializerCalculator = InitializerCalculator.SMALL;
	private float T;
	private int sieveArraySize;
	private int wantedMinLogPSum;
	private byte[] sieve_logPSumArray;
	/** sieve block size */
	private int B1, B2;
	/** number of complete blocks */
	private int k1, k2;
	private byte[] initializedBlock;
	
	private int[] selectedPrimes;
	private byte[] selectedLogP;
	private int[] selectedX1;
	private int[] selectedX1Neg;
	private int[] selectedD1;
	private int[] selectedD1Neg;

	private BinarySearch binarySearch = new BinarySearch();

	// timings
	private boolean profile;
	private Timer timer = new Timer();
	private long initDuration, sieveDuration, collectDuration;

	/**
	 * Full constructor.
	 * @param T the T parameter: reasonable values are T ~ 0.16 for SieveBoundCalculator.N_BASED, T ~ 2.0 for SieveBoundCalculator.PMAX_BASED
	 * @param wantedMinLogPSum values between 70..120 seem best (experimental results)
	 * @param pMinMult a multiplier to compute the smallest prime in the prime base to be used for sieving
	 * @param B1 inner block size, e.g. 32kB; B1 should divide B2
	 * @param B2 outer block size
	 */
	public DoubleBlockSieve(float T, int wantedMinLogPSum, float pMinMult, int B1, int B2) {
		this.T = T;
		this.wantedMinLogPSum = wantedMinLogPSum;
		this.pMinMult = pMinMult;
		this.B1 = B1;
		this.B2 = B2;
		this.k1 = B2 / B1; // number of inner blocks per outer block
	}
	
	@Override
	public String getName() {
		return "doubleBlock(" + T + ", " + wantedMinLogPSum + ", " + pMinMult + ", " + B1 + ", " + B2 + ")";
	}
	
	@Override
	public void initialize(double N_dbl, BigInteger kN, int unfilteredPrimeBaseSize, int[] unfilteredPrimesArray, int[] unfilteredTArray, int sieveArraySize, boolean profile) {
		this.lnN = (float) Math.log(N_dbl);
		lnkN = Math.log(kN.doubleValue());

		this.pMinIndex = Math.max(1, (int) (pMinMult * Math.log(unfilteredPrimeBaseSize))); // avoid p[0]==2 which is not used in several sieves
		this.sieveArraySize = sieveArraySize;
		if (DEBUG) LOG.debug("sieveArraySize = " + sieveArraySize);

		// Compute sieve bound in natural logarithm & convert to the actual logBase; then compute initializer.
		int pMax = unfilteredPrimesArray[unfilteredPrimeBaseSize-1];
		double minLnPSum = sieveBoundCalculator.computeSieveBound(T, lnN, lnkN, pMax, sieveArraySize);
		float lnLogBase = (float) (minLnPSum / wantedMinLogPSum); // normalizer to be used as a divisor for p_i values
		int minLogPSum = (int) (minLnPSum / lnLogBase); // floor, result should be ~wantedMinLogPSum
		if (DEBUG) {
			float logBase = (float) Math.exp(lnLogBase);
			LOG.debug("logBase=" + logBase + ", lnLogBase=" + lnLogBase + ", minLnPSum = " + minLnPSum + ", minLogPSum = " + minLogPSum);
		}
		byte[] initializer = initializerCalculator.compute(unfilteredPrimesArray, pMinIndex, minLogPSum, lnLogBase);
		lnPMultiplier = 1.0F/lnLogBase; // normalizer to be used as a multiplier for p_i values (faster)

		// create initialized block
		int effectiveSieveArraySize = Math.min(sieveArraySize, B2);
		initializedBlock = new byte[effectiveSieveArraySize];
		int filled = Math.min(256, effectiveSieveArraySize);
		System.arraycopy(initializer, 0, initializedBlock, 0, filled);
		int unfilled = effectiveSieveArraySize-filled;
		while (unfilled>0) {
			int fillNext = Math.min(unfilled, filled);
			System.arraycopy(initializedBlock, 0, initializedBlock, filled, fillNext);
			filled += fillNext;
			unfilled = effectiveSieveArraySize-filled;
		}
		
		// allocate sieve block
		sieve_logPSumArray = new byte[effectiveSieveArraySize];
		// number of complete outer blocks
		k2 = sieveArraySize / B2;
		if (DEBUG) LOG.debug("#complete outer blocks k2 = " + k2);

		selectedPrimes = new int[unfilteredPrimeBaseSize];
		selectedLogP = new byte[unfilteredPrimeBaseSize];
		selectedX1 = new int[unfilteredPrimeBaseSize];
		selectedX1Neg = new int[unfilteredPrimeBaseSize];
		selectedD1 = new int[unfilteredPrimeBaseSize];
		selectedD1Neg = new int[unfilteredPrimeBaseSize];

		// profiling
		this.profile = profile;
		initDuration = sieveDuration = collectDuration = 0;
	}

	@Override
	public int getPMinIndex() {
		return pMinIndex;
	}

	@Override
	public float getLnPMultiplier() {
		return lnPMultiplier;
	}
	
	@Override
	public void setPrimeSolutions(PolySolutions primeSolutions) {
		this.primeSolutions = primeSolutions;
		this.primeBaseSize = primeSolutions.primesOrPowers.length;
	}
	
	@Override
	public List<Integer> sieve() {
		if (profile) timer.capture();

		// preprocessing
		final int[] primesArray = primeSolutions.primesOrPowers;
		final int[] x1Array = primeSolutions.x1Array;
		final int[] x2Array = primeSolutions.x2Array;
		final byte[] logPArray = primeSolutions.logPArray;
		int selectionCount = 0;
		int x1, x2;
		for (int i=pMinIndex; i<primeBaseSize; i++) {
			x1 = x1Array[i];
			final int p = selectedPrimes[selectionCount] = primesArray[i];
			selectedLogP[selectionCount] = logPArray[i];
			x2 = x2Array[i];
			if (x1<x2) {
				selectedX1[selectionCount] = x1;
				selectedX1Neg[selectionCount] = p - x2;
				selectedD1Neg[selectionCount] = selectedD1[selectionCount] = x2 - x1;
			} else {
				selectedX1[selectionCount] = x2;
				selectedX1Neg[selectionCount] = p - x1;
				selectedD1Neg[selectionCount] = selectedD1[selectionCount] = x1 - x2;
			}
			selectionCount++;
		}

		int r_l = binarySearch.getFirstGreaterEntryIndex(selectedPrimes, selectionCount, B2);
		if (r_l < 0) {
			// B > pMax -> all primes have both roots inside the block
			r_l = selectionCount;
		}
		int r_m = binarySearch.getFirstGreaterEntryIndex(selectedPrimes, r_l, B2/4); //  TODO: experiments needed
		if (r_m < 0) {
			r_m = r_l;
		}
		int r_s = binarySearch.getFirstGreaterEntryIndex(selectedPrimes, r_m, B1);
		if (r_s < 0) {
			r_s = r_m;
		}
		if (DEBUG) {
			LOG.debug("db: sieveArraySize=" + sieveArraySize + ", B2=" + B2 + ", k2=" + k2 + ", B1=" + B1 + ", k1=" + k1);
			LOG.debug("db: r_s=" + r_s + ", r_m = " + r_m + ", r_l = " + r_l);
		}

		List<Integer> smoothXList = new ArrayList<Integer>();
		for (int b2=0; b2<k2; b2++) { // bottom-up order is required because in each block, the data for the next block is adjusted
			// positive x: initialize block
			System.arraycopy(initializedBlock, 0, sieve_logPSumArray, 0, B2);
			if (profile) initDuration += timer.capture();

			for (int b1=0; b1<k1; b1++) {
				// sieve inner block [b1*B1, (b1+1)*B1] with prime index ranges 0...r_s-1 and r_s...r_m
				//LOG.debug("db: b2 = " + b2 + ", b1 = " + b1);
				sievePositiveXBlock(B1, b1*B1, 0, r_s, r_m);
			}
			// sieve outer block [b2*B2, (b2+1)*B2] with prime index ranges r_m...r_l-1 and r_l...max
			sievePositiveXBlock(B2, 0, r_m, r_l, selectionCount);
			if (profile) sieveDuration += timer.capture();

			// collect block
			// let the sieve entry counter x run down to 0 is much faster because of the simpler exit condition
			final int blockOffset1 = b2*B2+1;
			final int blockOffset2 = blockOffset1+1;
			final int blockOffset3 = blockOffset2+1;
			final int blockOffset4 = blockOffset3+1;
			for (int x=B2-1; x>=0; ) {
				// Unfortunately, in Java we can not cast byte[] to int[] or long[].
				// So we have to use 'or'. More than 4 'or's do not pay out.
				if (((sieve_logPSumArray[x--] | sieve_logPSumArray[x--] | sieve_logPSumArray[x--] | sieve_logPSumArray[x--]) & 0x80) != 0) {
					// at least one of the tested Q(x) is sufficiently smooth to be passed to trial division!
					if (sieve_logPSumArray[x+1] < 0) smoothXList.add(x+blockOffset1);
					if (sieve_logPSumArray[x+2] < 0) smoothXList.add(x+blockOffset2);
					if (sieve_logPSumArray[x+3] < 0) smoothXList.add(x+blockOffset3);
					if (sieve_logPSumArray[x+4] < 0) smoothXList.add(x+blockOffset4);
				}
			} // end for (x)
			if (profile) collectDuration += timer.capture();
			
			// negative x: initialize block
			System.arraycopy(initializedBlock, 0, sieve_logPSumArray, 0, B2);
			if (profile) initDuration += timer.capture();
			
			for (int b1=0; b1<k1; b1++) {
				// sieve inner block [b1*B1, (b1+1)*B1] with prime index ranges 0...r_s-1 and r_s...r_m
				//LOG.debug("db: b2 = " + b2 + ", b1 = " + b1);
				sieveNegativeXBlock(B1, b1*B1, 0, r_s, r_m);
			}
			// sieve outer block [b2*B2, (b2+1)*B2] with prime index ranges r_m...r_l-1 and r_l...max
			sieveNegativeXBlock(B2, 0, r_m, r_l, selectionCount);
			if (profile) sieveDuration += timer.capture();
			
			// collect block
			// let the sieve entry counter x run down to 0 is much faster because of the simpler exit condition
			for (int x=B2-1; x>=0; ) {
				// Unfortunately, in Java we can not cast byte[] to int[] or long[].
				// So we have to use 'or'. More than 4 'or's do not pay out.
				if (((sieve_logPSumArray[x--] | sieve_logPSumArray[x--] | sieve_logPSumArray[x--] | sieve_logPSumArray[x--]) & 0x80) != 0) {
					// at least one of the tested Q(-x) is sufficiently smooth to be passed to trial division!
					if (sieve_logPSumArray[x+1] < 0) smoothXList.add(-(x+blockOffset1));
					if (sieve_logPSumArray[x+2] < 0) smoothXList.add(-(x+blockOffset2));
					if (sieve_logPSumArray[x+3] < 0) smoothXList.add(-(x+blockOffset3));
					if (sieve_logPSumArray[x+4] < 0) smoothXList.add(-(x+blockOffset4));
				}
			} // end for (x)
			if (profile) collectDuration += timer.capture();
		}
		
		// sieve last, incomplete block (with b=k)
		int B2_incomplete = sieveArraySize % B2;
		k1 = B2_incomplete / B1; // number of complete inner blocks, floor!
		// TODO: adjust r_m, r_l ?
		if (DEBUG) LOG.debug("last outer block: B2_incomplete = " + B2_incomplete + ", k1 = " + k1);
		
		if (B2_incomplete>0) {
			// positive x: initialize(S, B)
			System.arraycopy(initializedBlock, 0, sieve_logPSumArray, 0, B2_incomplete);
			if (profile) initDuration += timer.capture();
			
			for (int b1=0; b1<k1; b1++) {
				// sieve inner block [b1*B1, (b1+1)*B1] with prime index ranges 0...r_s-1 and r_s...r_m
				//LOG.debug("db: b2 = " + b2 + ", b1 = " + b1);
				sievePositiveXBlock(B1, b1*B1, 0, r_s, r_m);
			}
			// sieve last, incomplete inner block [k1*B1, (k1+1)*B1] with prime index ranges 0...r_s-1 and r_s...r_m
			int B1_incomplete = B2_incomplete % B1;
			if (DEBUG) LOG.debug("db, last outer block, last inner block: B1_incomplete = " + B1_incomplete);
			// TODO: adjust r_s ?
			//LOG.debug("db: r_s=" + r_s + ", r_m = " + r_m + ", r_l = " + r_l);
			sievePositiveXBlock(B1_incomplete, k1*B1, 0, r_s, r_m);
			// sieve outer block [b2*B2, (b2+1)*B2] with prime index ranges r_m...r_l-1 and r_l...max
			sievePositiveXBlock(B2_incomplete, 0, r_m, r_l, selectionCount);
			if (profile) sieveDuration += timer.capture();

			// evaluate(S, B), collect results
			// let the sieve entry counter x run down to 0 is much faster because of the simpler exit condition
			final int blockOffset1 = k2*B2+1;
			final int blockOffset2 = blockOffset1+1;
			final int blockOffset3 = blockOffset2+1;
			final int blockOffset4 = blockOffset3+1;
			//LOG.debug("db: blockOffset = " + blockOffset);
			for (int x=B2_incomplete-1; x>=0; ) {
				// Unfortunately, in Java we can not cast byte[] to int[] or long[].
				// So we have to use 'or'. More than 4 'or's do not pay out.
				if (((sieve_logPSumArray[x--] | sieve_logPSumArray[x--] | sieve_logPSumArray[x--] | sieve_logPSumArray[x--]) & 0x80) != 0) {
					// at least one of the tested Q(x) is sufficiently smooth to be passed to trial division!
					if (sieve_logPSumArray[x+1] < 0) smoothXList.add(x+blockOffset1);
					if (sieve_logPSumArray[x+2] < 0) smoothXList.add(x+blockOffset2);
					if (sieve_logPSumArray[x+3] < 0) smoothXList.add(x+blockOffset3);
					if (sieve_logPSumArray[x+4] < 0) smoothXList.add(x+blockOffset4);
				}
			} // end for (x)
			if (profile) collectDuration += timer.capture();
			
			// negative x
			// initialize(S, B)
			System.arraycopy(initializedBlock, 0, sieve_logPSumArray, 0, B2_incomplete);
			if (profile) initDuration += timer.capture();
			
			for (int b1=0; b1<k1; b1++) {
				// sieve inner block [b1*B1, (b1+1)*B1] with prime index ranges 0...r_s-1 and r_s...r_m
				//LOG.debug("db: b2 = " + b2 + ", b1 = " + b1);
				sieveNegativeXBlock(B1, b1*B1, 0, r_s, r_m);
			}
			// sieve last, incomplete inner block [k1*B1, (k1+1)*B1] with prime index ranges 0...r_s-1 and r_s...r_m
			B1_incomplete = B2_incomplete % B1;
			if (DEBUG) LOG.debug("db, last outer block, last inner block: B1_incomplete = " + B1_incomplete);
			// TODO: adjust r_s ?
			//LOG.debug("db: r_s=" + r_s + ", r_m = " + r_m + ", r_l = " + r_l);
			sieveNegativeXBlock(B1_incomplete, k1*B1, 0, r_s, r_m);
			// sieve outer block [b2*B2, (b2+1)*B2] with prime index ranges r_m...r_l-1 and r_l...max
			sieveNegativeXBlock(B2_incomplete, 0, r_m, r_l, selectionCount);
			if (profile) sieveDuration += timer.capture();

			// evaluate(S, B), collect results
			// let the sieve entry counter x run down to 0 is much faster because of the simpler exit condition
			for (int x=B2_incomplete-1; x>=0; ) {
				// Unfortunately, in Java we can not cast byte[] to int[] or long[].
				// So we have to use 'or'. More than 4 'or's do not pay out.
				if (((sieve_logPSumArray[x--] | sieve_logPSumArray[x--] | sieve_logPSumArray[x--] | sieve_logPSumArray[x--]) & 0x80) != 0) {
					// at least one of the tested Q(-x) is sufficiently smooth to be passed to trial division!
					if (sieve_logPSumArray[x+1] < 0) smoothXList.add(-(x+blockOffset1));
					if (sieve_logPSumArray[x+2] < 0) smoothXList.add(-(x+blockOffset2));
					if (sieve_logPSumArray[x+3] < 0) smoothXList.add(-(x+blockOffset3));
					if (sieve_logPSumArray[x+4] < 0) smoothXList.add(-(x+blockOffset4));
				}
			} // end for (x)
			if (profile) collectDuration += timer.capture();
		}
		return smoothXList;
	}
	
	
	/**
	 * sieve a single block for positive x. this method is used to sieve inner and outer blocks.
	 * 
	 * @param B the size of the block to sieve
	 * @param sieveArrayOffset offset of the current block in an outer block
	 * @param r_start index of the first prime to sieve with
	 * @param r_medium index of the first prime > B -> all smaller primes have at least 2 x-solutions in the block
	 * @param r_max index of the biggest prime to sieve with
	 */
	private void sievePositiveXBlock(final int B, final int sieveArrayOffset, final int r_start, final int r_medium, final int r_max) {
		int r, x, d1;
		// positive x, large primes
		for (r=r_max-1; r>=r_medium; r--) {
			x = selectedX1[r];
			final byte logP = selectedLogP[r];
			// solution x2: x1 == x2 happens in any of (basic QS, MPQS, SIQS) if p divides k, which implies t=0
			if ((d1 = selectedD1[r]) != 0) { // two x-solutions
				//LOG.debug("p=" + p + ", x1=" + x + ", d1=" + d1);
				if (x<B) {
					sieve_logPSumArray[x+sieveArrayOffset] += logP;
					x += d1;
					final int d2 = selectedPrimes[r] - d1;
					if (x<B) {
						sieve_logPSumArray[x+sieveArrayOffset] += logP;
						x += d2;
						// the difference is still correct
					} else {
						selectedD1[r] = d2;
					}
				}
			} else {
				// only one x-solution
				//LOG.debug("p=" + p + ", x1=" + x);
				if (x<B) {
					sieve_logPSumArray[x+sieveArrayOffset] += logP;
					x += selectedPrimes[r];
				}
			} // end if (x2 == x1)
			selectedX1[r] = x-B;
		}
		// positive x, small primes
		for (; r>=r_start; r--) {
			x = selectedX1[r];
			final byte logP = selectedLogP[r];
			// solution x2: x1 == x2 happens in any of (basic QS, MPQS, SIQS) if p divides k, which implies t=0
			if ((d1 = selectedD1[r]) != 0) { // two x-solutions
				//LOG.debug("p=" + p + ", x1=" + x + ", d1=" + d1);
				final int d2 = selectedPrimes[r]-d1;
				final int M_d = B - d1;
				for ( ; x<M_d; ) {
					sieve_logPSumArray[x+sieveArrayOffset] += logP;
					x += d1;
					sieve_logPSumArray[x+sieveArrayOffset] += logP;
					x += d2;
				}
				// sieve last location
				if (x<B) {
					sieve_logPSumArray[x+sieveArrayOffset] += logP;
					x += d1;
					selectedD1[r] = d2;
				} // else: the difference is still correct
			} else {
				// only one x-solution
				//LOG.debug("p=" + p + ", x1=" + x);
				final int p = selectedPrimes[r];
				for ( ; x<B; x+=p) {
					sieve_logPSumArray[x+sieveArrayOffset] += logP;
				}
			} // end if (x2 == x1)
			selectedX1[r] = x-B;
		}
	}
	
	/**
	 * sieve a single block for negative x. this method is used to sieve inner and outer blocks.
	 * 
	 * @param B the size of the block to sieve
	 * @param sieveArrayOffset offset of the current block in an outer block
	 * @param r_start index of the first prime to sieve with
	 * @param r_medium index of the first prime > B -> all smaller primes have at least 2 x-solutions in the block
	 * @param r_max index of the biggest prime to sieve with
	 */
	private void sieveNegativeXBlock(final int B, final int sieveArrayOffset, final int r_start, final int r_medium, final int r_max) {
		int r, x, d1;
		// negative x, large primes
		for (r=r_max-1; r>=r_medium; r--) {
			final byte logP = selectedLogP[r];
			x = selectedX1Neg[r];
			// solution x2: x1 == x2 happens in any of (basic QS, MPQS, SIQS) if p divides k, which implies t=0
			if ((d1 = selectedD1Neg[r]) != 0) { // two x-solutions
				//LOG.debug("p=" + p + ", x1=" + x + ", d1=" + d1);
				if (x<B) {
					sieve_logPSumArray[x+sieveArrayOffset] += logP;
					x += d1;
					final int d2 = selectedPrimes[r] - d1;
					if (x<B) {
						sieve_logPSumArray[x+sieveArrayOffset] += logP;
						x += d2;
						// the difference is still correct
					} else {
						selectedD1Neg[r] = d2;
					}
				}
			} else {
				// only one x-solution
				//LOG.debug("p=" + p + ", x1=" + x);
				if (x<B) {
					sieve_logPSumArray[x+sieveArrayOffset] += logP;
					x += selectedPrimes[r];
				}
			} // end if (x2 == x1)
			selectedX1Neg[r] = x-B;
		}
		// negative x, small primes
		for (; r>=r_start; r--) {
			final byte logP = selectedLogP[r];
			x = selectedX1Neg[r];
			// solution x2: x1 == x2 happens in any of (basic QS, MPQS, SIQS) if p divides k, which implies t=0
			if ((d1 = selectedD1Neg[r]) != 0) { // two x-solutions
				//LOG.debug("p=" + p + ", x1=" + x + ", d1=" + d1);
				final int d2 = selectedPrimes[r]-d1;
				final int M_d = B - d1;
				for ( ; x<M_d; ) {
					sieve_logPSumArray[x+sieveArrayOffset] += logP;
					// d1 = (p-x2)-(p-x1) = x1-x2
					x += d1;
					sieve_logPSumArray[x+sieveArrayOffset] += logP;
					// d2 = p + (p-x1)-(p-x2) = p+x2-x1
					x += d2;
				}
				// sieve last locations
				if (x<B) {
					sieve_logPSumArray[x+sieveArrayOffset] += logP;
					x += d1;
					selectedD1Neg[r] = d2;
				} // else: the difference is still correct
			} else {
				// only one x-solution
				//LOG.debug("p=" + p + ", x1=" + x);
				final int p = selectedPrimes[r];
				for ( ; x<B; x+=p) {
					sieve_logPSumArray[x+sieveArrayOffset] += logP;
				}
			} // end if (x2 == x1)
			selectedX1Neg[r] = x-B;
		}
	}
	
	@Override
	public String getProfilingReport() {
		return "init=" + initDuration + "ms, sieve=" + sieveDuration + "ms, collect=" + collectDuration + "ms";
	}
	
	@Override
	public void cleanUp() {
		sieve_logPSumArray = null;
		initializedBlock = null;
		selectedPrimes = null;
		selectedLogP = null;
		selectedX1 = null;
		selectedX1Neg = null;
		selectedD1 = null;
		selectedD1Neg = null;
	}
}
