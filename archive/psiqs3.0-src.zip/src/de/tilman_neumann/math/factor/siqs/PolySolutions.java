// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor.siqs;

/**
 * Passive data structure bundling primes/powers and their smallest x-solutions.
 * 
 * Having a structure with several arrays of the same size is faster than having an array of a structure,
 * because the former permits to exploit AVX/SSE mechanisms in Java 8.
 * 
 * @author Tilman Neumann
 */
public class PolySolutions {
	/** The primes or powers */
	public int[] primesOrPowers;
	/** the modular sqrt's t with t^2==kN (mod p) for primes p, or t^2==kN (mod power) for powers */
	public int[] tArray;
	public int[] x1Array;
	public int[] x2Array;
	/** log-values of the primes or powers */
	public byte[] logPArray;
	public int[][] Bainv2Array;
	
	/**
	 * Full constructor, allocates all arrays.
	 * @param solutionsCount
	 * @param qCount
	 */
	public PolySolutions(int solutionsCount, int qCount) {
		primesOrPowers = new int[solutionsCount];
		tArray = new int[solutionsCount];
		x1Array = new int[solutionsCount];
		x2Array = new int[solutionsCount];
		logPArray = new byte[solutionsCount];
		// Bainv2: full initialization; the sub-arrays are in reverse order compared to [Contini], which almost doubles the speed of nextXArrays()
		Bainv2Array = new int[qCount][solutionsCount];
	}
}
