// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor.siqs;

import java.math.BigInteger;

import de.tilman_neumann.math.factor.siqs.sieve.Sieve;
import de.tilman_neumann.math.factor.siqs.tdiv.TDiv_QS;

/**
 * Interface for polynomial generators.
 * @author Tilman Neumann
 */
public interface SIQSPolyBuilder {

	/**
	 * @return the name of this polynomial generator
	 */
	String getName();

	/**
	 * Register sub-engines that shall be accessible to the polynomial generator.
	 * @param sieveEngine
	 * @param tDivEngine
	 */
	void setSubEngines(Sieve sieveEngine, TDiv_QS tDivEngine);

	/**
	 * Initialize the polynomial generator for a new N.
	 * @param k multiplier
	 * @param N
	 * @param kN
	 * @param primeBaseSize
	 * @param primesArray prime base
	 * @param tArray modular square roots for all primes in the prime base
	 * @param sieveArraySize
	 * @param profile
	 */
	void initialize(int k, BigInteger N, BigInteger kN, int primeBaseSize, int[] primesArray, int[] tArray, int sieveArraySize, boolean profile);

	/**
	 * Compute a new polynomial.
	 * @return
	 */
	void nextPolynomial();

	/**
	 * @return description of the durations of the individual sub-phases
	 */
	String getProfilingReport();

	/**
	 * Release memory after a factorization.
	 */
	void cleanUp();

}