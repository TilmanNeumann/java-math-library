// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor.siqs.sieve;

import org.apache.log4j.Logger;

/**
 * Various algorithms to compute the sieve initializer.
 * 
 * @author Tilman Neumann
 */
public enum InitializerCalculator {
	/** Constant zero initializer */
	ZERO {
		@Override
		protected double computeLnSmallPSum(int[] primesArray, int pMinIndex) {
			return 0;
		}
	},
	
	/** Sum of average small primes contributions. */
	SMALL {
		@Override
		protected double computeLnSmallPSum(int[] primesArray, int pMinIndex) {
			double lnSmallPSum = 0;
			for (int i=pMinIndex-1; i>=0; i--) {
				int p = primesArray[i];
				lnSmallPSum += Math.log(p) / p;
			}
			return lnSmallPSum;
		}
	};
	
	private static final Logger LOG = Logger.getLogger(InitializerCalculator.class);
	private static final boolean DEBUG = false;
	
	/**
	 * Compute contribution of small primes in nats.
	 * @param primesArray prime base
	 * @param pMinIndex
	 * @return
	 */
	abstract protected double computeLnSmallPSum(int[] primesArray, int pMinIndex);

	/**
	 * Compute the initializer value and fill the initializer array with it.
	 * @param primesArray prime base
	 * @param pMinIndex the index of the first prime used for sieving
	 * @param minLogPSum
	 * @param lnLogBase
	 */
	public byte[] compute(int[] primesArray, int pMinIndex, int minLogPSum, double lnLogBase) {
		// compute contribution of small primes in nats, convert to wanted log base
		double logSmallPSum = computeLnSmallPSum(primesArray, pMinIndex) / lnLogBase;
		// compute initializerValue, rounded
		byte initializerValue = (byte) (128 - minLogPSum + logSmallPSum + 0.5);
		if (DEBUG) LOG.debug("initializerValue = " + initializerValue);
		
		// fill initializer with that value
		byte[] initializer = new byte[256];
		for (int i=255; i>=0; i--) {
			initializer[i] = initializerValue;
		}
		return initializer;
	}
}
