// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.factor.squfof;

import java.math.BigInteger;

/**
 * An entry of SquFoFs queue.
 * @author Tilman Neumann
 */
public class QueueEntry {
	BigInteger x, y;
	
	public QueueEntry(BigInteger x, BigInteger y) {
		this.x = x;
		this.y = y;
	}
	
	public boolean equals(Object o) {
		if (o==null) return false;
		if (! (o instanceof QueueEntry)) return false;
		QueueEntry other = (QueueEntry) o;
		return (x.equals(other.x) && y.equals(other.y));
	}
}
