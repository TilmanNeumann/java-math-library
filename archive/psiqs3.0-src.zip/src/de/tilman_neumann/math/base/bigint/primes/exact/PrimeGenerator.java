// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.base.bigint.primes.exact;

/**
 * Interface for (small) primes generators.
 * @author Tilman Neumann
 */
public interface PrimeGenerator {

	/**
	 * Compute the first <code>count</code> small primes.
	 * @param count
	 * @return
	 */
	Primes getPrimes(int count);
	
	/**
	 * Compute all primes below the given bound.
	 * The returned primes array may contain primes greater than the specified bound, because it is expanded in chunks.
	 * Furthermore, that number may be smaller than the array size.
	 * 
	 * @param bound
	 * @return primes array and total number of primes contained (which may be smaller than array.length)
	 */
	Primes getPrimesBelow(int bound);
	
	/**
	 * return i.th prime.
	 * @param index
	 * @return p_index
	 */
	int getPrime(int index);
}
