// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.base.bigint.primes.exact;

import java.math.BigInteger;
import java.util.HashSet;

/**
 * A set containing all primes up to a given bound.
 * @author Tilman Neumann
 */
public class SmallPrimesSet extends HashSet<Integer> {
	private static final long serialVersionUID = -75335169624758798L;

	public static SmallPrimesSet fromBitBound(int bits) {
		int bound = (1<<bits) - 1; // the biggest prime that shall be contained in the set
		return new SmallPrimesSet(bound);
	}
	
	public static SmallPrimesSet fromBound(int bound) {
		return new SmallPrimesSet(bound);
	}
	
	private SmallPrimesSet(int bound) {
		super();
		// hash all primes <= bound
		PrimeGenerator primeGen = SieveOfEratosthenes02.get();
		int p=2, index = 0;
		do {
			p = primeGen.getPrime(index++);
			super.add(p);
		} while(p <= bound);
	}

	public boolean contains(BigInteger N) {
		return super.contains(N.intValue());
	}

	public boolean contains(Long N) {
		return super.contains(N.intValue());
	}

	public boolean contains(Integer N) {
		return super.contains(N);
	}
}
