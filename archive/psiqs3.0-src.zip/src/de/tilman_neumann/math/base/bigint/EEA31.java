// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.base.bigint;

/**
 * Extended Euclidean algorithm, following [Crandall/Pomerance 2005: "Prime numbers", algorithm 2.1.4].
 * 
 * This int implementation is very fast.
 * 
 * @author Tilman Neumann
 */
public class EEA31 {

	public static class Result {
		/** if g==1 and y>0 then a = (1/x) mod y */
		public int a;
		/** if g==1 and y>0 then a = (1/y) mod x */
		public int b;
		/** gcd */
		public int g;
		
		public Result(int g, int a, int b) {
			this.a = a;
			this.b = b;
			this.g = g;
		}
	}
	
	/**
	 * Computes gcd, a = (1/x) mod y and b = (1/y) mod x.
	 * @param x
	 * @param y
	 * @return
	 */
	public Result computeAll(int x, int y) {
		// initialize
		int a = 1;
		int b = 0;
		int g = x;
		int u = 0;
		int v = 1;
		int w = y;
		// loop
		int q, tmp;
		while(w>0) {
			q = g/w; // floor
			// update
			tmp = a - q*u; a=u; u=tmp;
			tmp = b - q*v; b=v; v=tmp;
			tmp = g - q*w; g=w; w=tmp;
		}
		if (a<0) a = a+y; // TODO: change b, too?
		return new Result(g, a, b);
	}
	
	/**
	 * Computes only gcd and a = (1/x) mod y.
	 * @param x
	 * @param y
	 * @return
	 */
	public Result computeHalf(int x, int y) {
		// initialize
		int a = 1;
		int g = x;
		int u = 0;
		int w = y;
		// loop
		int tmp, rem;
		while (w != 0) {
			rem = g % w;
			tmp = a - (g/w)*u; // floor(g/w) !
			a=u; 
			u=tmp;
			g=w; 
			w=rem;
		}
		if (a<0) a = a+y;
		return new Result(g, a, -1);
	}
}
