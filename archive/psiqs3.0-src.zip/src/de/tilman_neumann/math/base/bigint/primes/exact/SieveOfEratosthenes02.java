// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.base.bigint.primes.exact;

import java.util.Arrays;

import org.apache.log4j.Logger;

/**
 * A simple, auto-expanding Sieve of Eratosthenes.
 * Singleton implementation to avoid spending too much memory on the primes in different instances.
 * 
 * Version 02 needs 32 times less memory because it uses a bit array instead of an array of boolean (which are stored as ints).
 * 
 * @author Tilman Neumann
 */
public class SieveOfEratosthenes02 implements PrimeGenerator {
	private static final Logger LOG = Logger.getLogger(SieveOfEratosthenes02.class);
	private static final boolean DEBUG = false;
	
	private int[] storedPrimes;
	private int storedPrimesCount;

	// singleton
	private static final SieveOfEratosthenes02 THE_SIEVE = new SieveOfEratosthenes02();

	public static SieveOfEratosthenes02 get() {
		return THE_SIEVE;
	}

	private SieveOfEratosthenes02() {
		storedPrimes = new int[] {2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97};
		storedPrimesCount = storedPrimes.length;
	}

	@Override
	public Primes getPrimes(int count) {
		while (storedPrimesCount < count) expandRawPrimesArray();
		return new Primes(storedPrimes, storedPrimesCount);
	}

	@Override
	public Primes getPrimesBelow(int bound) {
		while (storedPrimes[storedPrimesCount-1] < bound) expandRawPrimesArray();
		return new Primes(storedPrimes, storedPrimesCount);
	}

	@Override
	public int getPrime(int index) {
		if (storedPrimesCount <= index) expandRawPrimesArray();
		return storedPrimes[index];
	}
	
	/**
	 * Expand the primes array.
	 */
	// TODO: make synchronized? that would be 10-20% slower
	// TODO: Permit to precise the new upper limit? Could speed up some applications...
	private /*synchronized*/ void expandRawPrimesArray() {
		final int lastSize = storedPrimesCount;
		final int lastPMax = storedPrimes[storedPrimesCount-1];
		if (DEBUG) LOG.info("lastSize=" + storedPrimesCount + ", lastPMax=" + lastPMax + ", last primes = " + Arrays.toString(storedPrimes));
		// Sieve up to 4*lastPMax will give > 3 times the number of primes we already have.
		// So this is a trade-off between performance and memory requirements.
		final int sieveLimit = 4*lastPMax;
		if (DEBUG) LOG.debug("sieveLimit = " + sieveLimit);
		int[] isComposite = new int[1 + sieveLimit/32]; // zero initialized
		int maxPrimeNeededForSieving = (int) Math.sqrt(sieveLimit);
		for (int p : storedPrimes) {
			if (p>maxPrimeNeededForSieving) break;
			int rest = lastPMax % p;
			int x = lastPMax + p - rest;
			if (DEBUG) LOG.info("x = lastPMax + p - rest = " + lastPMax + "+" + p + "-" + rest + " = " + x + " is divisible by p=" + p);
			for (; x<=sieveLimit; x+=p) {
				int bitIndex = x & 31;
				isComposite[x>>5] |= (1<<bitIndex);
			}
		}
		
		// The prime array is allocated with a size that surely exceeds the number of primes we want to get now.
		// On the other hand, not all entries of the array will be filled, that's why we need storedPrimesCount.
		if (DEBUG) LOG.info("sieveLimit=" + sieveLimit + ", next primes array length = " + 4*storedPrimesCount);
		int[] nextPrimesArray = new int[4*storedPrimesCount];
		System.arraycopy(storedPrimes, 0, nextPrimesArray, 0, storedPrimesCount);
		for (int x=lastPMax+2; x<sieveLimit; x+=2) { // test odd numbers only
			int bitIndex = x & 31;
			if ((isComposite[x>>5] & (1<<bitIndex)) == 0) {
				nextPrimesArray[storedPrimesCount++] = x;
			}
		}
		storedPrimes = nextPrimesArray;
		if (DEBUG) {
			LOG.info("lastSize=" + lastSize + ", newSize=" + storedPrimesCount + " -> ratio=" + ((float)storedPrimesCount)/lastSize);
			LOG.info("next " + storedPrimesCount + " primes = " + Arrays.toString(nextPrimesArray));
		}
	}
}
