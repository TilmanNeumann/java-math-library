// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.base.bigint.primes.probable;

import static de.tilman_neumann.math.base.bigint.BigIntConstants.ONE;

import java.math.BigInteger;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Miller-Rabin probable prime test.
 * @author Tilman Neumann
*/
public class MillerRabinTest {
	
	private BigInteger N, N_m1, N_m1_without2s;
	private int lsb;
	
	private Random rng = ThreadLocalRandom.current();

	/**
	 * Perform up to numberOfRounds Miller-Rabin tests with random bases.
	 * @param N
	 * @param numberOfRounds
	 * @return true if N passes all tests, false if N is composite
	 */
	public boolean isProbablePrime(BigInteger N, int numberOfRounds) {
		initialize(N);
		int N_bits = N.bitLength();
        for (int round = 0; round < numberOfRounds; round++) {
        	// get random base x with 1 < x < N
            BigInteger x;
            do {
                x = new BigInteger(N_bits, rng);
            } while (x.compareTo(ONE) <= 0 || x.compareTo(N) >= 0);
            
            // do Miller-Rabin test to base x
            if (!testSingleBase(x)) return false;
        }

        return true;
	}
	
	/**
	 * Perform a Miller-Rabin test of N to base x.
	 * @param N
	 * @param x
	 * @return true if N passes the test to base x, false if N is composite
	 */
	public boolean isProbablePrime(BigInteger N, BigInteger x) {
		initialize(N);
		return testSingleBase(x);
	}

	private void initialize(BigInteger N) {
		this.N = N;
		N_m1 = N.subtract(ONE);
        N_m1_without2s = N_m1;
        lsb = N_m1_without2s.getLowestSetBit();
        N_m1_without2s = N_m1_without2s.shiftRight(lsb);
	}

	private boolean testSingleBase(BigInteger x) {
        int l = 0;
        BigInteger test = x.modPow(N_m1_without2s, N);
        if ((!test.equals(ONE)) && !test.equals(N_m1)) {
            if (++l == lsb) return false;
            test = test.multiply(test).mod(N);
            while (!test.equals(N_m1)) {
                if (test.equals(ONE) || ++l == lsb) return false;
                test = test.multiply(test).mod(N);
            }
        }
        return true;
	}
}
