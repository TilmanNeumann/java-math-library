// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.base.bigint;

import java.math.BigInteger;

import static de.tilman_neumann.math.base.bigint.BigIntConstants.*;

/**
 * Modular power.
 * @author Tilman Neumann
 */
public class ModularPower {
	/**
	 * Computes a^b (mod c) for all-BigInteger arguments.</br></br>
	 * 
	 * <em>BigIntegers implementation is much faster!</em>.
	 * 
	 * @param a
	 * @param b
	 * @param c
	 * @return a^b (mod c)
	 */
  	/* not public */ BigInteger modPow(BigInteger a, BigInteger b, BigInteger c) {
  		BigInteger modPow = ONE;
  		while (b.compareTo(ZERO) > 0) {
  			if (b.and(ONE).intValue() == 1) modPow = modPow.multiply(a).mod(c);
  			a = a.multiply(a).mod(c);
  			b = b.shiftRight(1);
  		}
  		return modPow;
  	}
  	
	/**
	 * Computes a^b (mod c) for <code>a</code> BigInteger, <code>b, c</code> int. Very fast.
	 * @param a
	 * @param b
	 * @param c
	 * @return a^b (mod c)
	 */
  	public int modPow(BigInteger a, int b, int c) {
  		// products need long precision
  		long modPow = 1;
  		long aModC = a.mod(BigInteger.valueOf(c)).longValue();
  		while (b > 0) {
  			if ((b&1) == 1) modPow = (modPow * aModC) % c;
  			aModC = (aModC * aModC) % c;
  			b >>= 1;
  		}
  		return (int) modPow;
  	}
  	
	/**
	 * Computes a^b (mod c) for all-int arguments. Very fast.
	 * @param a
	 * @param b
	 * @param c
	 * @return a^b (mod c)
	 */
  	public int modPow(int a, int b, int c) {
  		// products need long precision
  		long modPow = 1;
  		long aModC = a % c;
  		while (b > 0) {
  			if ((b&1) == 1) modPow = (modPow * aModC) % c;
  			aModC = (aModC * aModC) % c;
  			b >>= 1;
  		}
  		return (int) modPow;
  	}
}
