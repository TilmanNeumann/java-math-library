// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.base.bigint.primes.exact;

/**
 * Auxiliary class bundling an array of primes and it's real size, which may differ from array.length.
 * @author Tilman Neumann
 */
public class Primes {
	public int[] array;
	public int count;
	
	public Primes(int[] array, int count) {
		this.array = array;
		this.count = count;
	}
}