// Written by Tilman Neumann (www.tilman-neumann.de) 2016, 2017
// Any commercial use of this software requires the written consent of the author.
// Usage and republication are free for non-commercial purposes, as long as this header is carried along.
// The author takes no warranties for the correctness of the software.
package de.tilman_neumann.math.base.bigint.primes.possible;

import java.math.BigInteger;

import static de.tilman_neumann.math.base.bigint.BigIntConstants.*;

/**
 * A generator for "nontrivial" possible primes as BigInteger values, starting with 7. (2, 3 and 5 are considered trivial)
 * To exclude sure non-primes, the rests of primes modulo 30 are used.
 * @author Tilman Neumann
 */
public class PPGen02 implements PPGen {

	private static BigInteger[] possiblePrimeMods = {ONE, SEVEN, ELEVEN, THIRTEEN, SEVENTEEN, NINETEEN, TWENTYTHREE, TWENTYNINE};

	private int primeDiffIdx = 0;
	private BigInteger base = ZERO;
	
	public BigInteger next() {
		primeDiffIdx++; // the first index is 1, which gives the prime 7
		if (primeDiffIdx == 8) {
			primeDiffIdx = 0;
			base = base.add(THIRTY);
		}
		return base.add(possiblePrimeMods[primeDiffIdx]);
	}
}
