/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * This file is part of the PSIQS package version 01 from 2016-01-07, 
 * developed by Tilman Neumann, Edemissen, Germany.
 * 
 * Use and redistribution of PSIQS are free for non-commercial purposes, as long as this
 * header is not modified or removed. Any commercial usage of the whole or parts
 * of PSIQS requires the written consent of the author.
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

package de.tilman_neumann.types;

import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.SortedSet;
import java.util.TreeMap;

/**
 * A sorted set of elements with multiple occurrences, sorted smallest elements first.
 * Sorting is due to extending TreeMap; with HashMap the sorting behavior would be undefined.
 * Elements must implement the Comparable interface.
 * 
 * @author Tilman Neumann
 * 
 * @param <T> element class
 */
public class SortedMultiset_TreeMapImpl<T extends Comparable<T>> extends TreeMap<T, Integer> implements SortedMultiset<T> {
	
	private static final long serialVersionUID = -6604624351619809213L;
	
	@SuppressWarnings("unused")
	private static final Logger LOG = Logger.getLogger(SortedMultiset_TreeMapImpl.class);

	private int totalCount = 0;
	
	/**
	 * Constructor for an empty multiset, sorted smallest elements first.
	 */
	public SortedMultiset_TreeMapImpl() {
		super();
	}
	
	/**
	 * Constructor for a multiset, sorted smallest elements first, from a collection.
	 * @param values
	 */
	public SortedMultiset_TreeMapImpl(Collection<T> values) {
		this();
		this.addAll(values);
	}
	
	/**
	 * Constructor for a multiset, sorted smallest elements first, from a value array.
	 * @param values
	 */
	public SortedMultiset_TreeMapImpl(T[] values) {
		this();
		for (T value : values) {
			this.add(value);
		}
	}

	/**
	 * Copy constructor for a multiset, sorted smallest elements first.
	 * @param original
	 */
	public SortedMultiset_TreeMapImpl(Multiset<T> original) {
		this();
		this.addAll(original);
	}
	
	public int add(T entry) {
		Integer myMult = super.get(entry);
		int oldMult = (myMult!=null) ? myMult.intValue() : 0;
		int newMult = oldMult+1;
		super.put(entry, Integer.valueOf(newMult));
		totalCount++;
		return oldMult;
	}

	public int add(T entry, int mult) {
		//LOG.debug("entry " + entry + " has " + entry.getClass());
		Integer myMult = super.get(entry);
		int oldMult = (myMult!=null) ? myMult.intValue() : 0;
		if (mult > 0) {
			int newMult = oldMult + mult;
			super.put(entry, Integer.valueOf(newMult));
			totalCount += mult;
		}
		return oldMult;
	}

	public void addAll(Multiset<T> other) {
		if (other!=null) {
			// we need to recreate the entries of the internal set to avoid
			// that changes in the copy affect the old original
			for (Map.Entry<T, Integer> entry : other.entrySet()) {
				this.add(entry.getKey(), entry.getValue().intValue());
			}
		}
	}
	
	public void addAll(Collection<T> values) {
		if (values != null) {
			for (T value : values) {
				this.add(value);
			}
		}
	}
	
	public Integer remove(Object key) {
		Integer mult = this.get(key);
		if (mult!=null) {
			int imult = mult.intValue();
			if (imult>0) {
				if (imult>1) {
					// the cast works if we only put T-type keys into the map
					// which should be guaranteed in the add-methods
					this.put((T)key, Integer.valueOf(imult-1));
				} else {
					// delete entry from internal map
					super.remove(key);
				}
				this.totalCount--;
			}
		}
		return mult;
	}

	public int remove(T key, int mult) {
		Integer myMult = super.get(key);
		int oldMult = (myMult!=null) ? myMult.intValue() : 0;
		if (oldMult>0) {
			int newMult = Math.max(0, oldMult - mult);
			totalCount += (newMult-oldMult);
			if (newMult>0) {
				super.put(key, Integer.valueOf(newMult));
				return oldMult;
			}
			return super.remove(key).intValue();
		}
		// nothing to remove
		return 0;
	}
	
	public int removeAll(T key) {
		Integer mult = this.get(key);
		if (mult!=null) {
			int imult = mult.intValue();
			if (imult>0) {
				// delete entry from internal map
				super.remove(key);
				this.totalCount -= imult;
			}
			return imult;
		}
		return 0;
	}

	public SortedMultiset<T> intersect(Multiset<T> other) {
		SortedMultiset<T> resultset = new SortedMultiset_TreeMapImpl<T>();
		if (other != null) {
			for (Map.Entry<T, Integer> myEntry: this.entrySet()) {
				int myMult = myEntry.getValue().intValue();
				if (myMult > 0) {
					T myKey = myEntry.getKey();
					Integer otherMult = other.get(myKey);
					if (otherMult != null) {
						int jointMult = Math.min(myMult, otherMult.intValue());
						if (jointMult > 0) {
							resultset.add(myKey, jointMult);
						}
					} // other has myKey
				} // myKey is contained
			}
		}
		return resultset;
	}
	
	public int keyCount() {
		return this.size();
	}
	
	public int totalCount() {
		return this.totalCount;
	}

	public T getSmallestElement() {
		return (this.size() > 0) ? this.keySet().iterator().next() : null;
	}
	
	public T getBiggestElement() {
		return ((SortedSet<T>)(this.keySet())).last();
	}

	public List<T> toList() {
		List<T> flatList = new ArrayList<T>(totalCount);
		for (Map.Entry<T, Integer> entry : this.entrySet()) {
			T value = entry.getKey();
			int multiplicity = entry.getValue().intValue();
			for (int i=0; i<multiplicity; i++) {
				flatList.add(value);
			}
		}
		return flatList;
	}

	/**
	 * Comparable multisets are equal if they have exactly the same elements and
	 * these elements the same multiplicity; additionally the elements must
	 * be in the same order because they are comparable, too. 
	 * 
	 * Exploiting the element order probably gives no performance improvement
	 * because we have to compare all elements anyway; nevertheless here I
	 * attempt it.
	 */
	public boolean equals(Object o) {
		if (o!=null && o instanceof SortedMultiset) {
			@SuppressWarnings("unchecked")
			SortedMultiset<T> other = (SortedMultiset<T>) o;
			if (this.totalCount != other.totalCount()) return false;
			//if (this.keyCount() != other.keyCount()) return false;
			Iterator<Map.Entry<T, Integer>> otherIter = other.entrySet().iterator();
			for (Map.Entry<T, Integer> myEntry : this.entrySet()) {
				if (!myEntry.equals(otherIter.next())) return false;
			}
			return true;
		}
		return false;
	}
}
