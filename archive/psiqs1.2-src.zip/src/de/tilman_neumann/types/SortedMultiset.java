/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * This file is part of the PSIQS package version 01 from 2016-01-07, 
 * developed by Tilman Neumann, Edemissen, Germany.
 * 
 * Use and redistribution of PSIQS are free for non-commercial purposes, as long as this
 * header is not modified or removed. Any commercial usage of the whole or parts
 * of PSIQS requires the written consent of the author.
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

package de.tilman_neumann.types;

/**
 * A multiset with a sort relation between elements.<br>
 * 
 * The sorting of elements has the following consequences:
 * - elements must be Comparable
 * - SortedMaps are a bit slower than HashMaps
 * - output of sorted multisets looks nicer than that of unsorted multisets
 * - we could define a sorting on multisets as well
 * 
 * @author Tilman Neumann
 * 
 * @param <T> value class
 */
public interface SortedMultiset<T extends Comparable<T>> extends Multiset<T> {

	/**
	 * @return The smallest element.
	 */
	T getSmallestElement();

	/**
	 * @return The biggest element.
	 */
	T getBiggestElement();

	/**
	 * Returns the multiset of elements contained in both this and in the other multiset.
	 * @param other
	 * @return
	 */
	@Override // declare exact result data type
	SortedMultiset<T> intersect(Multiset<T> other);
}