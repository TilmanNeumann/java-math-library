/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * This file is part of the PSIQS package version 01 from 2016-01-07, 
 * developed by Tilman Neumann, Edemissen, Germany.
 * 
 * Use and redistribution of PSIQS are free for non-commercial purposes, as long as this
 * header is not modified or removed. Any commercial usage of the whole or parts
 * of PSIQS requires the written consent of the author.
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

package de.tilman_neumann.math.base.bigint.primes;

import java.math.BigInteger;

import de.tilman_neumann.math.base.bigint.BigIntConstants;

/**
 * A generator for "nontrivial" possible primes as BigInteger values, starting with 7. (2, 3 and 5 are considered trivial)
 * To exclude sure non-primes, the rests of primes modulo 30 are used.
 * @author Tilman Neumann
 */
public class PPGen02 implements PPGen {

	private static BigInteger[] possiblePrimeMods = {BigIntConstants.ONE, BigIntConstants.SEVEN, BigIntConstants.ELEVEN, BigIntConstants.THIRTEEN, BigIntConstants.SEVENTEEN, BigIntConstants.NINETEEN, BigIntConstants.TWENTYTHREE, BigIntConstants.TWENTYNINE};

	private int primeDiffIdx = 0;
	private BigInteger base = BigIntConstants.ZERO;
	
	public BigInteger next() {
		primeDiffIdx++; // the first index is 1, which gives the prime 7
		if (primeDiffIdx == 8) {
			primeDiffIdx = 0;
			base = base.add(BigIntConstants.THIRTY);
		}
		return base.add(possiblePrimeMods[primeDiffIdx]);
	}
}
