/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * This file is part of the PSIQS package version 01 from 2016-01-07, 
 * developed by Tilman Neumann, Edemissen, Germany.
 * 
 * Use and redistribution of PSIQS are free for non-commercial purposes, as long as this
 * header is not modified or removed. Any commercial usage of the whole or parts
 * of PSIQS requires the written consent of the author.
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

package de.tilman_neumann.math.base.bigint.sequence;

import java.math.BigInteger;

/**
 * Interface for integer sequence generators.
 * @author Tilman Neumann
 * 
 * @param T sequence element type
 */
public interface IntegerSequence<T> {
	/** The name of this sequence generator */
	public String getName();
	
	/**
	 * Reset sequence so that it starts again with its first element.
	 * @param N the number to factor
	 */
	public void reset(BigInteger N);
	
	/** Return the next integer */
	public T next();
}
