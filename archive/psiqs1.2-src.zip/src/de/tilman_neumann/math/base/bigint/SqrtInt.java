/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * This file is part of the PSIQS package version 01 from 2016-01-07, 
 * developed by Tilman Neumann, Edemissen, Germany.
 * 
 * Use and redistribution of PSIQS are free for non-commercial purposes, as long as this
 * header is not modified or removed. Any commercial usage of the whole or parts
 * of PSIQS requires the written consent of the author.
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

package de.tilman_neumann.math.base.bigint;

import java.math.BigInteger;

/**
 * Fast sqrt() computation with integer solutions using Herons (or the Babylonian) method
 * and the built-in Math.sqrt() as initial guess.
 * 
 * @author Tilman Neumann
 */
public class SqrtInt/*02*/ {
	private static final BigInteger ZERO = BigInteger.ZERO;
	private static final BigInteger ONE = BigInteger.ONE;
	
	/**
	 * sqrt() computation with integer solutions using Herons (or the Babylonian) method
	 * and the built-in Math.sqrt() as initial guess.
	 * 
	 * @param N
	 * @return [lower, upper] int values of sqrt(N)
	 */
	public static BigInteger[] iSqrt(BigInteger N) {
		// Make sure N is a positive number
		int sign = N.signum();
		if (sign>0) {
			// Use built-in Math.sqrt() as initial guess, for any precision and avoiding BigDecimals.
			BigInteger initialGuess;
			int bits = N.bitLength();
			if (bits>63) {
				// get even number of right shifts so that N>>shifts has less than 64 bits
				int shifts = bits-63;
				if (shifts%2==1) shifts++; // make even
				long n = N.shiftRight(shifts).longValue(); // fits always
				// compute sqrt of shifted n with < 64 bits
				long sqrt = (long) Math.sqrt(n);
				// shift the result back half the number of the right shifts applied above
				initialGuess = BigInteger.valueOf(sqrt).shiftLeft(shifts>>1);
			} else {
				initialGuess = BigInteger.valueOf((long) Math.sqrt(N.longValue()));
			}
			
			// run Heron's approximation
			return iSqrt/*_Heron2*/(N, initialGuess);
		}
		if (sign==0) return new BigInteger[] {ZERO, ZERO};
		throw new IllegalArgumentException("n = " + N + ", but sqrt(n) is defined for n>=0 only!");
	}

	// algorithms ----------------------------------------------------------------------------------------------------------------

	/**
	 * Simplest Heron-type sqrt() implementation.
	 * Here we use guess - n/guess as convergence criterion, which is simple and correct.
	 * 
	 * @param n
	 * @return [lower, upper] int values of sqrt(n)
	 */
	public static BigInteger[] iSqrt/*_Heron2*/(BigInteger n, BigInteger guess) {
		// do one approximation step before first convergence check
		guess = n.divide(guess).add(guess).shiftRight(1);
		//LOG.debug("initial guess: sqrt(" + n + ") ~ " + guess);
		
		BigInteger lastGuess;
		do {
			lastGuess = guess;
			guess = n.divide(guess).add(guess).shiftRight(1);
			//LOG.debug("next guess: sqrt(" + n + ") ~ " + guess);
		} while (guess.subtract(lastGuess).abs().bitLength()>1); // while absolute difference > 1
		
		int cmp = guess.multiply(guess).compareTo(n);
		if (cmp < 0) return new BigInteger[] {guess, guess.add(ONE)};
		if (cmp > 0) return new BigInteger[] {guess.subtract(ONE), guess};
		return new BigInteger[] {guess, guess}; // exact sqrt()
	}
}
