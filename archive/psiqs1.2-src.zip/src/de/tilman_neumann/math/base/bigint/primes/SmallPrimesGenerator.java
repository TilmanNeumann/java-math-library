/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * This file is part of the PSIQS package version 01 from 2016-01-07, 
 * developed by Tilman Neumann, Edemissen, Germany.
 * 
 * Use and redistribution of PSIQS are free for non-commercial purposes, as long as this
 * header is not modified or removed. Any commercial usage of the whole or parts
 * of PSIQS requires the written consent of the author.
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

package de.tilman_neumann.math.base.bigint.primes;

import java.math.BigInteger;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import de.tilman_neumann.math.base.bigint.SqrtInt;
import de.tilman_neumann.util.ConfigUtil;

import static de.tilman_neumann.math.base.bigint.BigIntConstants.*;

/**
 * A generator for the first few small primes.
 * Pretty fast for bounds <= 1.000.000.
 * 
 * @author Tilman Neumann
 */
public class SmallPrimesGenerator {
	private static final Logger LOG = Logger.getLogger(SmallPrimesGenerator.class);
	private boolean init;
	private double bound;
	private ArrayList<BigInteger> primes;
	private PPGen ppgen = new PPGen02(); // generates "possible" primes starting at 7
	private BigInteger nextPossiblePrime;
	
	/**
	 * Create an initial prime base containing only the 2.
	 */
	public SmallPrimesGenerator() {
		this.primes = new ArrayList<BigInteger>();
		primes.add(TWO);
		nextPossiblePrime = THREE;
		this.bound = 2;
		init = true;
	}
	
	/**
	 * Create a prime base containing all primes < the given bound.
	 * @param bound
	 */
	public SmallPrimesGenerator(double bound) {
		this(); // prime base that only has the 2
		expand(bound);
	}
	
	/**
	 * Create a prime base with the given numberOfPrimes.
	 * @param numberOfPrimes
	 */
	public SmallPrimesGenerator(int numberOfPrimes) {
		this();
		while (primes.size()<numberOfPrimes) expand();
	}
	
	/**
	 * Delivers the i.th prime from this prime base, starting with i=1, P_1=2.
	 * The prime must already be contained in the prime base!
	 * @param i
	 * @return
	 */
	public BigInteger ithPrime(int i) {
		return primes.get(i-1);
	}
	
	/**
	 * Returns all primes in sequence.
	 * Needs a new PrimeBase() to start a 2.
	 * @return next prime
	 */
	public BigInteger nextPrime() {
		BigInteger ret = this.getMaxPrime();
		expand(); // prepare next
		return ret;
	}
	
	/**
	 * Expand the prime base by exactly one new prime.
	 */
	public void expand() {
		while (tryToExpandByNextPossiblePrime()==false); // loop without body!
		bound = nextPossiblePrime.doubleValue()-1;
	}
	
	/**
	 * Expand to all primes <= newBound.
	 * @param newBound
	 */
	public void expand(double newBound) {
		if (newBound <= bound) return; // no change
		
		while (newBound >= nextPossiblePrime.doubleValue()) {
			tryToExpandByNextPossiblePrime();
		}
		bound = newBound;
	}

	/**
	 * @return true if nextPossiblePrime is prime and has been added to this prime base.
	 */
	private boolean tryToExpandByNextPossiblePrime() {
		// check if next possible prime is really a prime:
		// we do this via division by all primes <= sqrt(nextPossiblePrime)
		boolean isPrime = true;
		BigInteger floorSqrt = SqrtInt.iSqrt(nextPossiblePrime)[0];
		for (BigInteger p : primes) {
			if (p.compareTo(floorSqrt)>0) break;
			// test
			BigInteger mod = nextPossiblePrime.mod(p);
			if (mod.signum()==0) {
				// nextPossiblePrime divides p, so it is no prime
				isPrime = false;
				break;
			}
		}
		if (isPrime) {
			// nextPossiblePrime is really prime -> add it to the prime base
			primes.add(nextPossiblePrime);
		}
		// generate next possible prime
		if (init) {
			// init==true means that nextPossiblePrime==3, and next we have to add FIVE
			nextPossiblePrime = FIVE;
			init = false;
		} else {
			nextPossiblePrime = ppgen.next();
		}
		return isPrime;
	}
	
	public int size() {
		return primes.size();
	}
	
	public ArrayList<BigInteger> getPrimes() {
		return primes;
	}
	
	public BigInteger getMaxPrime() {
		return primes.get(primes.size()-1);
	}
	
	public String toString() {
		return primes.toString();
	}
	
	/**
	 * Stand-alone test.
	 * @param args ignored
	 */
	public static void main(String[] args) {
    	ConfigUtil.initProject();
    	
    	// test prime base expansion
    	SmallPrimesGenerator pb = new SmallPrimesGenerator();
    	LOG.info("initial prime base = " + pb);
    	pb.expand(28.9);
    	LOG.info("new bound=28.9 -> prime base = " + pb);
    	pb.expand(12.5);
    	LOG.info("new bound=12.5 -> prime base = " + pb);
    	pb.expand(43);
    	LOG.info("new bound=43 -> prime base = " + pb);
    	pb.expand(104);
    	LOG.info("new bound=104 -> prime base = " + pb);
    	
    	// test nextPrime()
    	pb = new SmallPrimesGenerator();
    	for (int i=1; i<=100; i++) {
    		LOG.info("p_" + i + " = " + pb.nextPrime());
    	}
	}
}
