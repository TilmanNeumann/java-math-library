package de.tilman_neumann.math.base.bigint;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.math.BigInteger;

import org.apache.log4j.Logger;

import de.tilman_neumann.util.ConfigUtil;

import static de.tilman_neumann.math.base.bigint.BigIntConstants.*;

/**
 * Test for pure powers (with exponent >= 2), following [en.wiki:Rational_Sieve].
 * @author Tilman Neumann
 */
public class PurePowerTest {
	private static final Logger LOG = Logger.getLogger(PurePowerTest.class);

	public static class Result {
		public BigInteger base;
		public int exponent;
		
		public Result(BigInteger base, int exponent) {
			this.base = base;
			this.exponent = exponent;
		}
	}
	
	/**
	 * Test if N is a pure power.
	 * @param N
	 * @return prime power representing N, or null if N is no pure power.
	 */
	public Result test(BigInteger N) {
		if (N.compareTo(FOUR)<0) return null; // negative or not composite
		if (N.bitCount()==1) {
			// only 1 bit set -> power of 2
			return new Result(TWO, N.getLowestSetBit());
		}
		
		// test according to [en.wiki:Rational_Sieve]:
		double log3N = Math.log(N.doubleValue())/Math.log(3.0) + 1; // +1 resolves precision issues
		for (int b=2; b<log3N; b++) {
			BigInteger floor_bthRoot = Roots.ithRoot(N, b)[0];
			if (floor_bthRoot.pow(b).equals(N)) {
				// found exact power!
				return new Result(floor_bthRoot, b);
			}
		}
		// no pure power
		return null;
	}

	/**
	 * Test.
	 * @param args ignored
	 */
	public static void main(String[] args) {
	   	ConfigUtil.initProject();
	   	PurePowerTest powTest = new PurePowerTest();
	   	while(true) {
			try {
				LOG.info("Insert test argument N:");
				BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
				String input = in.readLine().trim();
				//LOG.debug("input = >" + input + "<");
				BigInteger N = new BigInteger(input);
				Result purePower = powTest.test(N);
				if (purePower == null) {
					LOG.info("N = " + N + " is not a pure power.");
				} else {
					LOG.info("N = " + N + " = " + purePower.base + "^" + purePower.exponent + " is a pure power!");
				}
			} catch (Exception ex) {
				LOG.error("Error " + ex, ex);
			}
		}
	}
}
