/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * This file is part of the PSIQS package version 01 from 2016-01-07, 
 * developed by Tilman Neumann, Edemissen, Germany.
 * 
 * Use and redistribution of PSIQS are free for non-commercial purposes, as long as this
 * header is not modified or removed. Any commercial usage of the whole or parts
 * of PSIQS requires the written consent of the author.
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

package de.tilman_neumann.math.base.bigint.sequence;

import java.math.BigInteger;

import static de.tilman_neumann.math.base.bigint.BigIntConstants.*;

/**
 * Sequence of multiplier * {1,3,5,7,11,13,...}.
 * @author Tilman Neumann
 */
public class PrimeSequence01 implements IntegerSequence<BigInteger> {

	private boolean init = true;
	private BigInteger multiplier;
	private BigInteger next;
	
	public PrimeSequence01(BigInteger multiplier) {
		this.multiplier = multiplier;
	}
	
	@Override
	public String getName() {
		return multiplier + "*prime01";
	}

	@Override
	public void reset(BigInteger N) {
		this.init = true;
	}

	@Override
	public BigInteger next() {
		if (init) {
			next = THREE;
			init = false;
			return multiplier; // 1*multiplier
		}
		BigInteger current = next;
		next = next.nextProbablePrime(); // nextProbablePrime() is slow -> improved in class PrimeSequence02 (but this has little influence on total performance)
		return current.multiply(multiplier);
	}
}
