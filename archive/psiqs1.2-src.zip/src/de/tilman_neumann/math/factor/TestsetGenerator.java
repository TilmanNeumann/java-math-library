/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * This file is part of the PSIQS package version 01 from 2016-01-07, 
 * developed by Tilman Neumann, Edemissen, Germany.
 * 
 * Use and redistribution of PSIQS are free for non-commercial purposes, as long as this
 * header is not modified or removed. Any commercial usage of the whole or parts
 * of PSIQS requires the written consent of the author.
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

package de.tilman_neumann.math.factor;

import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import static de.tilman_neumann.math.base.bigint.BigIntConstants.*;
import static org.junit.Assert.*;

/**
 * Generation of random N that are not too easy to factor.
 * 
 * @author Tilman Neumann
 */
public class TestsetGenerator {
	private static final Logger LOG = Logger.getLogger(TestsetGenerator.class);
	private static final boolean DEBUG = false;
	
	/** random generator */
	private static final SecureRandom RNG = new SecureRandom();

	/**
	 * Generate N_count random numbers of the given bit length.
	 * @param bits
	 * @param N_count
	 * @return test set
	 */
	public static ArrayList<BigInteger> generate(int bits, int N_count) {
		ArrayList<BigInteger> squareTest_NSet = new ArrayList<BigInteger>();
		int minBits = (bits+2)/3; // analogue to 3rd root(N)
		int maxBits = (bits+1)/2;
		for (int i=0; i<N_count; i++) {
			// generate random N and increment until we find a non-easy number
			int n1bits = uniformRandomInteger(minBits, maxBits);
			BigInteger n1 = uniformRandomBigInteger(ONE.shiftLeft(n1bits), ONE.shiftLeft(n1bits+1));
			n1 = n1.nextProbablePrime();
			int n2bits = bits-n1.bitLength();
			BigInteger n2 = uniformRandomBigInteger(ONE.shiftLeft(n2bits), ONE.shiftLeft(n2bits+1));
			n2 = n2.nextProbablePrime();
			BigInteger N = n1.multiply(n2);
			int resultBits = N.bitLength();
			// the resulting N may have 1 bit too much
			if (DEBUG) {
				LOG.debug("TestsetGenerator2: wanted bits = " + bits + ", result bits = " + resultBits);
				assertTrue(resultBits>=bits);
				assertTrue(resultBits<=bits+1);
			}
			if (resultBits>bits) {
				// N is 1 bit too big -> reduce second prime by 1 bit
				n2 = n2.shiftRight(1).nextProbablePrime();
				N = n1.multiply(n2);
				if (DEBUG) assertEquals(bits, N.bitLength());
			}
			squareTest_NSet.add(N);
		}
		return squareTest_NSet;
	}
	
	/**
	 * Creates a random integer from the uniform distribution U[0, maxValue-1].
	 * @param maxValue
	 * @return
	 */
	private static int uniformRandomInteger(int maxValue) {
		if (maxValue<1) throw new IllegalArgumentException("maxValue=" + maxValue + " but must be positive");
		return RNG.nextInt(maxValue);
	}
	
	/**
	 * Creates a random integer from the uniform distribution U[minValue, maxValue-1].
	 * Works also for negative arguments; the only requirement is maxValue>minValue.
	 * @param minValue
	 * @param maxValue
	 * @return
	 */
	private static int uniformRandomInteger(int minValue, int maxValue) {
		int diff = maxValue-minValue;
		if (diff<1) throw new IllegalArgumentException("maxValue=" + maxValue + " must be bigger than minValue=" + minValue);
		int normedMaxValue = maxValue - minValue; // then normed min value is zero
		return uniformRandomInteger(normedMaxValue) + minValue;
	}
	
	/**
	 * Generates a BigInteger from U[0, maxValue).
	 * @param maxValue exclusive
	 * @return
	 */
	private static BigInteger uniformRandomBigInteger(BigInteger maxValue) {
		int maxBits = maxValue.bitLength()+1;
		BigInteger randomValue = null;
		do {
			randomValue = uniformRandomBigInteger_fromBits(maxBits); // 0 ... 2^maxBits - 1
		} while (randomValue.compareTo(maxValue) >= 0); // too big
		return randomValue;
	}
	
	/**
	 * Generates a BigInteger from U[minValue, maxValue).
	 * @param minValue inclusive
	 * @param maxValue exclusive
	 * @return
	 */
	private static BigInteger uniformRandomBigInteger(BigInteger minValue, BigInteger maxValue) {
		BigInteger normedMaxValue = maxValue.subtract(minValue); // normed by minValue->0
		return uniformRandomBigInteger(normedMaxValue).add(minValue);
	}

	/**
	 * Get uniformly distributed random integer with the specified maximum number of bits,
	 * i.e. a number from U[0, 2^maxBits - 1].
	 * 
	 * @param maxBits size in bits
	 */
	private static BigInteger uniformRandomBigInteger_fromBits(int maxBits) {
		if (maxBits<0) throw new IllegalArgumentException("maxBits=" + maxBits + " but must be non-negative");
		return new BigInteger(maxBits, RNG);
	}
}
