/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * This file is part of the PSIQS package version 01.01 from 2016-01-15, 
 * developed by Tilman Neumann, Edemissen, Germany.
 * 
 * Use and redistribution of PSIQS are free for non-commercial purposes, as long as this
 * header is not modified or removed. Any commercial usage of the whole or parts
 * of PSIQS requires the written consent of the author.
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

package de.tilman_neumann.math.factor;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigInteger;
import java.util.StringTokenizer;

import org.apache.log4j.Logger;

import de.tilman_neumann.math.factor._congruence.CongruenceCollector01;
import de.tilman_neumann.math.factor._congruence.CongruenceCollector02;
import de.tilman_neumann.math.factor._matrixSolver.MatrixSolver01;
import de.tilman_neumann.math.factor.psiqs.PSIQS;
import de.tilman_neumann.math.factor.qs.AParamGenerator01;
import de.tilman_neumann.math.factor.qs.QS;
import de.tilman_neumann.math.factor.qs.SIQSPolyBuilder02;
import de.tilman_neumann.math.factor.qs.sieve.Sieve04b;
import de.tilman_neumann.math.factor.qs.tdiv.TDiv_QS02;
import de.tilman_neumann.math.factor.qs.tdiv.TDiv_QS03;
import de.tilman_neumann.math.factor.squfof.SquFoF31;
import de.tilman_neumann.math.factor.squfof.SquFoF63;
import de.tilman_neumann.math.factor.tdiv.TDiv31Preload;
import de.tilman_neumann.types.SortedMultiset;
import de.tilman_neumann.util.ConfigUtil;
import de.tilman_neumann.util.TimeUtil;

import static de.tilman_neumann.math.base.bigint.BigIntConstants.*;

/**
 * Final combination of factor algorithms.
 * 
 * @author Tilman Neumann
 */
public class CombinedFactorAlgorithm extends FactorAlgorithmBase {
	@SuppressWarnings("unused")
	private static final Logger LOG = Logger.getLogger(CombinedFactorAlgorithm.class);

	private static final String JAR_FILE = "psiqs01.01.jar";
	
	private int numberOfThreads;
	
	private TDiv31Preload tDiv31;
	private SquFoF31 squFoF31;
	private SquFoF63 squFoF63;
	private QS siqs_smallArgs;
	private SingleFactorFinder siqs_bigArgs;
	
	/**
	 * Complete constructor.
	 * 
	 * @param primeTestBits log of probability of predicting false primes
	 * @param numberOfThreads the number of parallel threads for PSIQS
	 */
	// TODO: timeout parameter?
	public CombinedFactorAlgorithm(int primeTestBits, int numberOfThreads) {
		super(primeTestBits);
		this.numberOfThreads = numberOfThreads;
		tDiv31 = new TDiv31Preload(primeTestBits);
		squFoF31 = new SquFoF31(primeTestBits);
		squFoF63 = new SquFoF63(primeTestBits);
		// SIQS for N < 200 bit
		siqs_smallArgs = new QS(primeTestBits, 0.32F, 0.42F, new SIQSPolyBuilder02(3, new AParamGenerator01(), 2), new Sieve04b(1, 0.16F, 0.25F, 1), new TDiv_QS02(primeTestBits, 0.18F), new CongruenceCollector01(), 10, new MatrixSolver01<Integer>(2));
		// for N >= 200 bit: PSIQS if numberOfThreads>1, else SIQS with TDiv_QS03+CC02
		siqs_bigArgs = numberOfThreads>1 ? new PSIQS(primeTestBits, 0.315F, 0.39F, null, 0.17F, 1.4427F, 0.185F, numberOfThreads)
										 : new QS(primeTestBits, 0.32F, 0.42F, new SIQSPolyBuilder02(3, new AParamGenerator01(), 2), new Sieve04b(1, 0.16F, 0.25F, 1), new TDiv_QS03(primeTestBits, 0.18F), new CongruenceCollector02(), 10, new MatrixSolver01<Integer>(2));;
	}

	@Override
	public String getName() {
		return "combi";
	}

	@Override
	public BigInteger findSingleFactor(BigInteger N) {
		int N_bits = N.bitLength();
		if (N_bits <= 27) return tDiv31.findSingleFactor(N);
		if (N_bits <= 42) return squFoF31.findSingleFactor(N);
		if (N_bits <= 68) return squFoF63.findSingleFactor(N);
		if (N_bits <= 97 || (numberOfThreads==1 && N_bits<200)) return siqs_smallArgs.findSingleFactor(N);
		return siqs_bigArgs.findSingleFactor(N);
	}
	
	/**
	 * Run with command-line arguments or console input (if no command-line arguments are given).
	 * Usage for executable jar file:
	 * java -jar <jar_file> [[-t <numberOfThreads>] <numberToFactor>]
	 * 
	 * @param args [-t <numberOfThreads>] <numberToFactor>
	 */
	public static void main(String[] args) {
		ConfigUtil.verbose = false;
    	ConfigUtil.initProject();
    	
    	try {
	    	if (args.length==0) {
	    		// test standard input in a loop
	    		testInput();
	    	}
	    	
	    	// otherwise we have commandline arguments -> parse them
	    	testArgs(args);
    	} catch (Exception ite) {
    		// when the jar is shut down with Ctrl-C, an InvocationTargetException is thrown (log4j?).
    		// just suppress it and exit
    		System.exit(0);
    	}
	}
	
	private static int testInput() {
		while(true) {
			int numberOfThreads = 1;
			BigInteger N;
			String line = null;
			try {
				System.out.println("Please insert [-t <numberOfThreads>] <numberToFactor> :");
				BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
				line = in.readLine();
				String input = line.trim();
				if (input.startsWith("-t")) {
					input = input.substring(2).trim();
					StringTokenizer parser = new StringTokenizer(input);
					numberOfThreads = Integer.parseInt(parser.nextToken().trim());
					N = new BigInteger(parser.nextToken().trim());
				} else {
					N = new BigInteger(input);
				}
			} catch (IOException ioe) {
				System.err.println("IO-error occuring on input: " + ioe.getMessage());
				continue;
			} catch (NumberFormatException nfe) {
				System.err.println("Illegal input: " + line);
				continue;
			}
			test(numberOfThreads, N);
		} // next input...
	}

	private static void testArgs(String[] args) {
    	int numberOfThreads = 1;
    	BigInteger N = null;
    	if (args.length==1) {
    		try {
    			N = new BigInteger(args[0].trim());
    		} catch (NumberFormatException nfe) {
    			System.err.println("Invalid numberToFactor = " + args[0].trim());
    			System.exit(-1);
    		}
    	} else if (args.length==3) {
    		if (!args[0].trim().equals("-t")) {
    			System.err.println("Illegal option: '" + args[0] + "'. Usage: java -jar " + JAR_FILE + " [-t <numberOfThreads>] <numberToFactor>");
    			System.exit(-1);
    		}
    		try {
    			numberOfThreads = Integer.parseInt(args[1].trim());
    		} catch (NumberFormatException nfe) {
    			System.err.println("Invalid numberOfThreads = " + args[1].trim());
    			System.exit(-1);
    		}
    		try {
    			N = new BigInteger(args[2].trim());
    		} catch (NumberFormatException nfe) {
    			System.err.println("Invalid numberToFactor = " + args[2].trim());
    			System.exit(-1);
    		}
    	} else {
			System.err.println("Illegal number of arguments. Usage: java -jar " + JAR_FILE + " [-t <numberOfThreads>] <numberToFactor>");
			System.exit(-1);
    	}
    	// run
    	int exitCode = test(numberOfThreads, N);
		System.exit(exitCode);
	}
	
	private static int test(int numberOfThreads, BigInteger N) {
		if (numberOfThreads < 0) {
			System.err.println("numberOfThreads must be positive.");
			return -1;
		}
		if (numberOfThreads > ConfigUtil.NUMBER_OF_PROCESSORS) {
			System.err.println("Too big numberOfThreads = " + numberOfThreads + ": Your machine has only " + ConfigUtil.NUMBER_OF_PROCESSORS + " processors");
			return -1;
		}
    	
    	// size check
    	//LOG.debug("N = " + N);
		int N_bits = N.bitLength();
    	if (N.bitLength()>400) {
			System.err.println("Too big numberToFactor: Currently only inputs <= 400 bits are supported. (Everything else would take months or years)");
			return -1;
    	}
    	// run
    	long t0 = System.currentTimeMillis();
    	CombinedFactorAlgorithm factorizer = new CombinedFactorAlgorithm(20, numberOfThreads);
    	SortedMultiset<BigInteger> result = factorizer.factor(N);
		long duration = System.currentTimeMillis()-t0;
		String durationStr = TimeUtil.timeStr(duration);
		if (result.totalCount()==1) {
			BigInteger singleElement = result.keySet().iterator().next();
			if (singleElement.abs().compareTo(ONE)<=0) {
				System.out.println(N + " is trivial");
			} else {
				System.out.println(N + " is probable prime");
			}
		} else if (result.totalCount()==2 && result.keySet().contains(MINUS_ONE)) {
			System.out.println(N + " is probable prime");
		} else {
			System.out.println(N + " (" + N_bits + " bits) = " + factorizer.getPrettyFactorString(result) + " (factored in " + durationStr + ")");
		}
		return 0;
	}
}
