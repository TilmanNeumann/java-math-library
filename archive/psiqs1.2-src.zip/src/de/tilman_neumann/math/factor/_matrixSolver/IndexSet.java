/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * This file is part of the PSIQS package version 01 from 2016-01-07, 
 * developed by Tilman Neumann, Edemissen, Germany.
 * 
 * Use and redistribution of PSIQS are free for non-commercial purposes, as long as this
 * header is not modified or removed. Any commercial usage of the whole or parts
 * of PSIQS requires the written consent of the author.
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

package de.tilman_neumann.math.factor._matrixSolver;

import java.util.ArrayList;

/**
 * Interface for index sets used as matrix row elements and column elements.
 * @author Tilman Neumann
 */
public interface IndexSet {
	
	void addXor(IndexSet other);

	boolean contains(Object o);

	Integer last();

	/**
	 * @return true if this set is empty
	 */
	boolean isEmpty();

	/**
	 * @return this index set as a list
	 */
	ArrayList<Integer> toList();
	
	@Override
	boolean equals(Object o);
	
	@Override
	String toString();
}
