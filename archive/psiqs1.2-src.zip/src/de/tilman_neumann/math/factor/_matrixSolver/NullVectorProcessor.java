/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * This file is part of the PSIQS package version 01 from 2016-01-07, 
 * developed by Tilman Neumann, Edemissen, Germany.
 * 
 * Use and redistribution of PSIQS are free for non-commercial purposes, as long as this
 * header is not modified or removed. Any commercial usage of the whole or parts
 * of PSIQS requires the written consent of the author.
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

package de.tilman_neumann.math.factor._matrixSolver;

import java.util.Set;

import de.tilman_neumann.math.factor.FactorException;
import de.tilman_neumann.math.factor._congruence.AQPair;

/**
 * Simple interface to decouple congruence solver classes.
 * @author Tilman Neumann
 */
public interface NullVectorProcessor {
	/**
	 * Process a null vector found by a matrix solver.
	 * @param aqPairs the AQ-pairs of the null vector.
	 * @throws FactorException
	 */
	void processNullVector(Set<AQPair> aqPairs) throws FactorException;
}
