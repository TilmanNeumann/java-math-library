/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * This file is part of the PSIQS package version 01 from 2016-01-07, 
 * developed by Tilman Neumann, Edemissen, Germany.
 * 
 * Use and redistribution of PSIQS are free for non-commercial purposes, as long as this
 * header is not modified or removed. Any commercial usage of the whole or parts
 * of PSIQS requires the written consent of the author.
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

package de.tilman_neumann.math.factor._matrixSolver;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.TreeSet;

import org.apache.log4j.Logger;

/**
 * Array implementation of an IndexSet that is Iterator and Iterable in one.
 * The xor() implementation has complexity O(n), where n is the sum of the size of the two argument arrays.
 * 
 * @author Tilman Neumann
 */
public class IndexSet_ArrayListImpl implements IndexSet, Iterator<Integer>, Iterable<Integer> {
	private static final Logger LOG = Logger.getLogger(IndexSet_ArrayListImpl.class);
	private static final boolean DEBUG = false;

	private int[] indexArray;
	private int size;
	/** current array position required by iterator */
	private int position;
	
	/**
	 * Precomputed hashCode, may be used in equals.
	 * When the indices change, hashCode must be set to null to indicate that a recomputation is necessary.
	 */
	private Integer hashCode;

	/**
	 * Constructor from given indices.
	 * @param indices
	 */
	public IndexSet_ArrayListImpl(Collection<Integer> indices) {
		TreeSet<Integer> sortedIndices = new TreeSet<Integer>();
		sortedIndices.addAll(indices); // smallest first
		this.size = sortedIndices.size();
		this.indexArray = new int[size];
		int i=0;
		for (int index : sortedIndices) {
			indexArray[i++] = index;
		}
		this.hashCode = null; // dirty
	}

	public Iterator<Integer> iterator() {
		this.position = 0;
		return this;
	}

	@Override
	public boolean hasNext() {
		return position<size;
	}
	
	@Override
	public Integer next() {
		return indexArray[position++];
	}
	
	@Override
	public boolean contains(Object o) {
		LOG.debug("contains()", new Throwable()); // never used, method untested
		if (o==null || !(o instanceof Integer)) return false;
		int x = ((Integer)o).intValue();
		if (indexArray[size-1] < x) return false; // there is no entry as big as x
		int left = 0;
		int right = size-1;
		int median;
		do {
			median = (left+right)>>1; // floor
			int entry = indexArray[median];
			if (entry == x) return true;
			if (entry < x) {
				// the tested element was too small, the result must have a higher index
				left = median + 1;
			} else {
				// the tested element was not too small, it could be right or too big
				right = median;
			}
		} while (left!=right);
		return indexArray[left]==x;
	}

	@Override
	public Integer last() {
		return indexArray[size-1];
	}

	@Override
	public boolean isEmpty() {
		return size==0;
	}

	@Override
	public void addXor(IndexSet o) {
		if (!(o instanceof IndexSet_ArrayListImpl)) throw new IllegalArgumentException("bitArray.xor() works only with intArray arguments");
		IndexSet_ArrayListImpl other = (IndexSet_ArrayListImpl) o;
		//LOG.debug(this + " xor " + other + " ...");
		int maxSize = size + other.size; // we waste some memory for speed
		int[] combinedIndices = new int[maxSize];
		int resultPosition = 0;
		int myPosition = 0;
		Integer myEntry = size>0 ? indexArray[0] : null;
		for (Integer otheroddExpIndex : other) {
			//LOG.debug("myEntry = " + myEntry + ", otherEntry = " + otheroddExpIndex);
			if (myEntry!=null) {
				int cmp = myEntry.compareTo(otheroddExpIndex);
				while (cmp<0) {
					// myEntry is smaller -> add first
					combinedIndices[resultPosition++] = myEntry;
					myPosition++;
					myEntry = size>myPosition ? indexArray[myPosition] : null;
					cmp = myEntry.compareTo(otheroddExpIndex);
				}
				if (cmp==0) {
					 // the same index is contained in both sets -> by xor they cancel out
					myPosition++;
					myEntry = size>myPosition ? indexArray[myPosition] : null;
					continue;
				}
				// otherwise myEntry is bigger -> add the other below
			} // else: my array is finished -> add the rest of other
			combinedIndices[resultPosition++] = otheroddExpIndex;
		}
		// are there entries in my array left?
		for (; myPosition < size; myPosition++) {
			//LOG.debug("myIndex = " + indices[myPosition]);
			combinedIndices[resultPosition++] = indexArray[myPosition];
		}
		// done. set the new array:
		//LOG.debug(this + " ^ " + other + " = " + Arrays.toString(combinedIndices));
		this.indexArray = combinedIndices;
		this.size = resultPosition;
		this.hashCode = null; // dirty
	}
	
	public ArrayList<Integer> toList() {
		ArrayList<Integer> result = new ArrayList<Integer>();
		for (int i=0; i<size; i++) {
			result.add(indexArray[i]);
		}
		return result;
	}
	
	@Override
	public int hashCode() {
		if (DEBUG) throw new IllegalStateException("hashCode() is never called!?"); // true
		if (hashCode==null) computeHashCode(); // lazy
		return hashCode;
	}
	
	private void computeHashCode() {
		int result = 1;
		int prime = 31;
		for (int i=0; i<size; i++) {
			result = result*prime + indexArray[i];
		}
		this.hashCode = result;
	}

	@Override
	public boolean equals(Object o) {
		if (!(o instanceof IndexSet_ArrayListImpl)) return false;
		IndexSet_ArrayListImpl other = (IndexSet_ArrayListImpl) o;
		if (this.size != other.size) return false;
		// compare hashCode if available, but do not recompute it if null:
		if (this.hashCode!=null && other.hashCode!=null && this.hashCode!=other.hashCode) return false;
		int i=0;
		for (int otherEntry : other) {
			if (indexArray[i++] != otherEntry) return false;
		}
		return true;
	}

	@Override
	public String toString() {
		String str = "[";
		for (int i=0; i<size; i++) {
			str += indexArray[i] + ", ";
		}
		return str.substring(0, str.length()-2) + "]";
	}
}
