/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * This file is part of the PSIQS package version 01 from 2016-01-07, 
 * developed by Tilman Neumann, Edemissen, Germany.
 * 
 * Use and redistribution of PSIQS are free for non-commercial purposes, as long as this
 * header is not modified or removed. Any commercial usage of the whole or parts
 * of PSIQS requires the written consent of the author.
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

package de.tilman_neumann.math.factor._matrixSolver;

import java.math.BigInteger;
import java.util.Collection;
import java.util.Set;

import org.apache.log4j.Logger;

import de.tilman_neumann.math.factor.FactorException;
import de.tilman_neumann.math.factor._basics.FactorTest;
import de.tilman_neumann.math.factor._congruence.AQPair;
import de.tilman_neumann.math.factor._congruence.Congruence;

/**
 * A wrapper for the matrix solver used for smooth congruence equations systems.
 * Solving such a system (mod N) may give square congruences, and a factor of N if such a square congruence is proper.
 * The wrapper pattern allows to have several matrix solver implementations.
 * 
 * @author Tilman Neumann
 */
public class SmoothSolverWrapper implements NullVectorProcessor {
	@SuppressWarnings("unused")
	private static final Logger LOG = Logger.getLogger(SmoothSolverWrapper.class);

	private MatrixSolver<Integer> matrixSolver;

	/** factor tester */
	private FactorTest factorTest;

	// for debugging only
	private int testedNullVectorCount;

	public SmoothSolverWrapper(MatrixSolver<Integer> matrixSolver) {
		// this hook would be a memory leak if we'ld create many pairs of solver and solver wrapper objects;
		// but we have only 1 object pair in the whole application run time
		matrixSolver.setNullVectorProcessor(this);
		this.matrixSolver = matrixSolver;
	}
	
	
	public void initialize(BigInteger N, FactorTest factorTest) {
		this.factorTest = factorTest;
		this.testedNullVectorCount = 0;
	}
	
	/**
	 * Solve a smooth congruence equation system.
	 * @param rawCongruences the smooth congruence equation system
	 * @throws FactorException if a factor of N was found
	 */
	public void solve(Collection<? extends Congruence<Integer>> rawCongruences) throws FactorException {
		matrixSolver.solve(rawCongruences);
	}

	@Override
	public void processNullVector(Set<AQPair> aqPairs) throws FactorException {
		// found square congruence -> check for factor
		testedNullVectorCount++;
		factorTest.testForFactor(aqPairs);
		// no factor exception -> drop improper square congruence
	}
	
	public int getTestedNullVectorCount() {
		return testedNullVectorCount;
	}
	
	/**
	 * Release memory after a factorization.
	 */
	public void cleanUp() {
		factorTest = null;
	}
}
