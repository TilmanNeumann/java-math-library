/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * This file is part of the PSIQS package version 01 from 2016-01-07, 
 * developed by Tilman Neumann, Edemissen, Germany.
 * 
 * Use and redistribution of PSIQS are free for non-commercial purposes, as long as this
 * header is not modified or removed. Any commercial usage of the whole or parts
 * of PSIQS requires the written consent of the author.
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

package de.tilman_neumann.math.factor._matrixSolver;

import java.util.ArrayList;
import java.util.TreeSet;

/**
 * TreeSet implementation of an IndexSet.
 * At construction time, indices are added via the add() method.
 * The xor() implementation has complexity O(n*ln(n), where n is the sum of the size of the two argument sets.
 * As such, it is much slower than the int[] implementation.
 * 
 * @author Tilman Neumann
 */
public class IndexSet_TreeSetImpl extends TreeSet<Integer> implements IndexSet, Iterable<Integer> {
	private static final long serialVersionUID = 1440516056348288490L;

	@Override
	public void addXor(IndexSet o) {
		if (!(o instanceof IndexSet_TreeSetImpl)) throw new IllegalArgumentException("IndexSet_TreeSetImpl.addXor() works only with TreeSet arguments");
		IndexSet_TreeSetImpl other = (IndexSet_TreeSetImpl) o;
		for (Integer otheroddExpIndex : other) {
			if (!super.remove(otheroddExpIndex)) super.add(otheroddExpIndex); 
		}
	}

	@Override
	public ArrayList<Integer> toList() {
		return new ArrayList<Integer>(this);
	}
}
