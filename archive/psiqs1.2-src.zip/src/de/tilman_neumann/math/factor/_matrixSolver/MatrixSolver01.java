/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * This file is part of the PSIQS package version 01 from 2016-01-07, 
 * developed by Tilman Neumann, Edemissen, Germany.
 * 
 * Use and redistribution of PSIQS are free for non-commercial purposes, as long as this
 * header is not modified or removed. Any commercial usage of the whole or parts
 * of PSIQS requires the written consent of the author.
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

package de.tilman_neumann.math.factor._matrixSolver;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import de.tilman_neumann.math.factor.FactorException;
import de.tilman_neumann.math.factor._congruence.AQPair;
import de.tilman_neumann.math.factor._congruence.Congruence;

/**
 * A simple congruence equation system solver, doing Gaussian elimination.
 * 
 * @author Tilman Neumann
 * 
 * @param ME_T class of matrix elements
 */
public class MatrixSolver01<ME_T extends Comparable<ME_T>> extends MatrixSolver<ME_T> {
	@SuppressWarnings("unused")
	private static final Logger LOG = Logger.getLogger(MatrixSolver01.class);

	/**
	 * Choice of the IndexSet implementation:
	 * 0: TreeSet
	 * 1: IntArray (much faster)
	 * 2: BitArray (much, much faster)
	 */
	private int indexType;

	/**
	 * Full constructor.
	 * @param indexType choice of the IndexSet implementation:</br>
	 * 0: TreeSet (very slow)</br>
	 * 1: IntArray (much faster)</br>
	 * 2: BitArray (much, much faster)</br>
	 */
	public MatrixSolver01(int indexType) {
		this.indexType = indexType;
	}
	
	@Override
	public String getName() {
		return "solver01(" + indexType + ")";
	}
	
	@Override
	protected void solve(List<Congruence<ME_T>> congruences, Map<ME_T, Integer> factors_2_columnIndices) throws FactorException {
		// create matrix
		List<MatrixRow> rows = createMatrix(congruences, factors_2_columnIndices);
		// solve
		while (rows.size()>0) {
			// find pivot column index and row:
			// Note that sorting the rows is not good for performance,
			// because the insort-operation is more expensive then iterating over all rows.
			Iterator<MatrixRow> rowIter = rows.iterator();
			MatrixRow pivotRow = null;
			Integer pivotColumnIndex = null;
			while (rowIter.hasNext()) {
				MatrixRow row = rowIter.next();
				//LOG.debug("row = " + row);
				int biggestColumnIndex = row.getBiggestColumnIndex();
				if (pivotColumnIndex==null || biggestColumnIndex>pivotColumnIndex) {
					// new pivot candidate
					pivotRow = row;
					pivotColumnIndex = biggestColumnIndex;
				}
			}
			// Now we have selected a pivotColumnIndex and a row having it.
			// -> remove the pivot row from the list and do one Gaussian elimination step
			rows.remove(pivotRow);
			rowIter = rows.iterator();
			//LOG.debug("solve(): 2: " + rows.size() + " rows");
			while (rowIter.hasNext()) {
				MatrixRow row = rowIter.next();
				//LOG.debug("solve(): 3: current row " + row);
				if (row.getBiggestColumnIndex() == pivotColumnIndex) {
					//LOG.debug("solve(): 4: current row has pivotColumnIndex");
					// Add the pivot row to the current row in Z_2 ("xor"):
					// We can modify the current row object because its old state is not required anymore,
					// and because working on it does not affect the original congruences.
					row.addXor(pivotRow); // This operation should be fast!
					if (row.isNullVector()) {
						//LOG.debug("solve(): 5: Found null-vector: " + row);
						// Found null vector -> recover the set of AQ-pairs from the its row index history
						HashSet<AQPair> totalAQPairs = new HashSet<AQPair>(); // Set required for the "xor"-operation below
						for (int rowIndex : row.getRowIndexHistoryAsList()) {
							Congruence<ME_T> congruence = congruences.get(rowIndex);
							Collection<AQPair> aqPairs = congruence.getAQPairs();
							// add the new AQ-pairs via "xor" !
							for (AQPair aqPair : aqPairs) {
								if (!totalAQPairs.remove(aqPair)) totalAQPairs.add(aqPair);
							}
						}
						// "return" the AQ-pairs of the null vector
						nullVectorProcessor.processNullVector(totalAQPairs);
						// no factor exception -> drop improper null vector
						rowIter.remove(); 
					} // else: current row is not a null-vector -> just keep it
				} // else: current row does not have the pivotColumnIndex -> just keep it
			}
		}
	}

	/**
	 * 5. Create the matrix.
	 * @param congruences
	 * @param factors_2_columnIndices
	 * @return
	 */
	private List<MatrixRow> createMatrix(List<Congruence<ME_T>> congruences, Map<ME_T, Integer> factors_2_columnIndices) {
		ArrayList<MatrixRow> matrixRows = new ArrayList<MatrixRow>(congruences.size()); // ArrayList is faster than LinkedList, even with many remove() operations
		int rowIndex = 0;
		int numberOfRows = congruences.size();
		for (Congruence<ME_T> congruence : congruences) {
			// row entries = set of column indices where the congruence has a factor with odd exponent
			IndexSet columnIndicesFromOddExpFactors = createColumnIndexSetFromCongruence(congruence, factors_2_columnIndices);
			// initial row history = the current row index
			IndexSet rowIndexHistory = createRowIndexHistory(numberOfRows, rowIndex++);
			MatrixRow matrixRow = new MatrixRow(columnIndicesFromOddExpFactors, rowIndexHistory);
			matrixRows.add(matrixRow);
		}
		//LOG.debug("constructed matrix with " + matrixRows.size() + " rows and " + factors_2_columnIndices.size() + " columns");
		return matrixRows;
	}

	/**
	 * Create the set of matrix column indices from the factors that the congruence has with odd exponent.
	 * @param congruence
	 * @param factors_2_columnIndices
	 * @return set of column indices
	 */
	private IndexSet createColumnIndexSetFromCongruence(Congruence<ME_T> congruence, Map<ME_T, Integer> factors_2_columnIndices) {
		// For efficiency reasons we directly create the column indices in the form required by the chosen implementation.
		// Otherwise it might be necessary to have ColumnIndexSet classes parametrized with <ME_T>,
		// or to create indices using one datatype and copy then again in the ColumnIndexSet constructors.
		Collection<ME_T> oddExpFactors = congruence.getOddExpFactors();
		switch (indexType) {
		case 0: { // TreeSet implementation
			IndexSet_TreeSetImpl columnIndexSet = new IndexSet_TreeSetImpl();
			for (ME_T oddExpFactor : oddExpFactors) {
				columnIndexSet.add(factors_2_columnIndices.get(oddExpFactor));
			}
			return columnIndexSet;
		} case 1: { // int[] implementation
			ArrayList<Integer> indices = new ArrayList<Integer>();
			for (ME_T oddExpFactor : oddExpFactors) {
				indices.add(factors_2_columnIndices.get(oddExpFactor));
			}
			return new IndexSet_ArrayListImpl(indices);
		} case 2: { // BitArray implementation
			IndexSet_BitArrayImpl columnIndexBitset = new IndexSet_BitArrayImpl(factors_2_columnIndices.size());
			for (ME_T oddExpFactor : oddExpFactors) {
				columnIndexBitset.add(factors_2_columnIndices.get(oddExpFactor));
			}
			return columnIndexBitset;
		} default: throw new IllegalStateException("Unknown INDEX_TYPE = " + indexType);
		}
	}
	
	private IndexSet createRowIndexHistory(int numberOfRows, int rowIndex) {
		switch (indexType) {
		case 0: { // TreeSet implementation
			IndexSet_TreeSetImpl rowIndexHistory = new IndexSet_TreeSetImpl();
			rowIndexHistory.add(rowIndex);
			return rowIndexHistory;
		} case 1: { // int[] implementation
			ArrayList<Integer> indices = new ArrayList<Integer>();
			indices.add(rowIndex);
			return new IndexSet_ArrayListImpl(indices);
		} case 2: { // BitArray implementation
			IndexSet_BitArrayImpl rowIndexHistory = new IndexSet_BitArrayImpl(numberOfRows);
			rowIndexHistory.add(rowIndex);
			//LOG.debug("numberOfRows=" + numberOfRows + ", rowIndex=" + rowIndex + " -> rowIndexHistory = " + rowIndexHistory);
			return rowIndexHistory;
		} default: throw new IllegalStateException("Unknown INDEX_TYPE = " + indexType);
		}
	}
}
