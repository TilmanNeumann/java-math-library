/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * This file is part of the PSIQS package version 01 from 2016-01-07, 
 * developed by Tilman Neumann, Edemissen, Germany.
 * 
 * Use and redistribution of PSIQS are free for non-commercial purposes, as long as this
 * header is not modified or removed. Any commercial usage of the whole or parts
 * of PSIQS requires the written consent of the author.
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

package de.tilman_neumann.math.factor._matrixSolver;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import de.tilman_neumann.math.factor.FactorException;
import de.tilman_neumann.math.factor._congruence.Congruence;

/**
 * Base implementation for a congruence equation system (the "LinAlg phase matrix") solver.
 * 
 * @author Tilman Neumann
 * 
 * @param ME_T class of LinAlg-matrix elements
 */
abstract public class MatrixSolver<ME_T extends Comparable<ME_T>> {
	@SuppressWarnings("unused")
	private static final Logger LOG = Logger.getLogger(MatrixSolver.class);

	protected NullVectorProcessor nullVectorProcessor;
	
	public abstract String getName();

	public void setNullVectorProcessor(NullVectorProcessor nullVectorProcessor) {
		this.nullVectorProcessor = nullVectorProcessor;
	}

	/**
	 * Main method to solve a congruence equation system.
	 * @param congruences the congruences forming the equation system
	 * @throws FactorException if a factor of N was found
	 */
	public void solve(Collection<? extends Congruence<ME_T>> congruences) throws FactorException {
		// 1. Create a copy of the congruences and a map from primes with odd power 2 congruences.
		// The congruence list must be copied to avoid that the original is modified during singleton removal.
		// The map must be sorted so that small primes get small indices in step 4.
		//LOG.debug("#congruences = " + congruences.size());
		@SuppressWarnings({ "unchecked", "rawtypes" })
		ArrayList<Congruence<ME_T>> congruencesCopy = new ArrayList(congruences.size());
		Map<ME_T, ArrayList<Congruence<ME_T>>> oddExpFactors_2_congruences = new HashMap<ME_T, ArrayList<Congruence<ME_T>>>();
		for (Congruence<ME_T> congruence : congruences) {
			congruencesCopy.add(congruence);
			for (ME_T factor : congruence.getOddExpFactors()) {
				ArrayList<Congruence<ME_T>> congruenceList = oddExpFactors_2_congruences.get(factor);
				if (congruenceList==null) congruenceList = new ArrayList<Congruence<ME_T>>();
				congruenceList.add(congruence);
				oddExpFactors_2_congruences.put(factor, congruenceList);
			}
		}
		// 2. remove singletons
		removeSingletons(congruencesCopy, oddExpFactors_2_congruences);
		// 3. Try to identify disconnected sub-equation systems ?
		// TODO
		// 4. Map odd-exp-elements to column indices
		Map<ME_T, Integer> factors_2_indices = createFactor2ColumnIndexMap(oddExpFactors_2_congruences);
		// 5+6. Create & solve matrix
		solve(congruencesCopy, factors_2_indices);
	}
	
	/**
	 * 2. Remove singletons from <code>congruences</code>.
	 * This can reduce the size of the equation system; actually it never diminishes the difference (#eqs - #vars).
	 * It is very fast, too - like 60ms for a matrix for which solution via Gauss elimination takes 1 minute.
	 */
	protected void removeSingletons(List<Congruence<ME_T>> congruences, Map<ME_T, ArrayList<Congruence<ME_T>>> oddExpFactors_2_congruences) {
		// Parse all congruences as long as we find a singleton in a complete pass
		boolean foundSingleton = true;
		do {
			foundSingleton = false;
			Iterator<? extends Congruence<ME_T>> congruenceIter = congruences.iterator();
			while (congruenceIter.hasNext()) {
				boolean isSingleton = false;
				Congruence<ME_T> congruence = congruenceIter.next();
				Iterable<ME_T> oddExpFactors = congruence.getOddExpFactors();
				for (ME_T oddExpFactor : oddExpFactors) {
					int count = oddExpFactors_2_congruences.get(oddExpFactor).size();
					if (count==1) {
						isSingleton = true;
						foundSingleton = true;
						break;
					}
				}
				if (isSingleton) {
					// found singleton -> remove from list
					//LOG.debug("Found singleton -> remove " + congruence);
					congruenceIter.remove();
					// remove from oddExpFactors_2_congruences so we can detect further singletons
					for (ME_T factor : oddExpFactors) {
						ArrayList<Congruence<ME_T>> congruenceList = oddExpFactors_2_congruences.get(factor);
						congruenceList.remove(congruence);
						if (congruenceList.size()==0) {
							// there are no more congruences with the current factor
							oddExpFactors_2_congruences.remove(factor);
						} else {
							// push back
							oddExpFactors_2_congruences.put(factor, congruenceList);
						}
					}
				}
			} // one pass finished
		} while (foundSingleton && congruences.size()>0);
		// now all singletons have been removed from congruences.
		//LOG.debug("#congruences after removing singletons: " + congruences.size());
	}
	
	/**
	 * 4. Create a map from odd-exp-elements to matrix column indices.
	 * @param oddExpFactors_2_congruences
	 * @return
	 */
	protected Map<ME_T, Integer> createFactor2ColumnIndexMap(Map<ME_T, ArrayList<Congruence<ME_T>>> oddExpFactors_2_congruences) {
		int index = 0;
		Map<ME_T, Integer> factors_2_columnIndices = new HashMap<ME_T, Integer>();
		for (ME_T factor : oddExpFactors_2_congruences.keySet()) {
			factors_2_columnIndices.put(factor, index++);
		}
		return factors_2_columnIndices;
	}

	/**
	 * 5+6. Create the matrix from the pre-processed congruences and solve it.
	 * @param congruences
	 * @param factors_2_columnIndices
	 * @throws FactorException 
	 */
	abstract protected void solve(List<Congruence<ME_T>> congruences, Map<ME_T, Integer> factors_2_columnIndices) throws FactorException;
}
