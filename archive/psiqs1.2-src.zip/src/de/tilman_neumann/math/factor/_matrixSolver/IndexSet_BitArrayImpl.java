/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * This file is part of the PSIQS package version 01 from 2016-01-07, 
 * developed by Tilman Neumann, Edemissen, Germany.
 * 
 * Use and redistribution of PSIQS are free for non-commercial purposes, as long as this
 * header is not modified or removed. Any commercial usage of the whole or parts
 * of PSIQS requires the written consent of the author.
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

package de.tilman_neumann.math.factor._matrixSolver;

import java.util.ArrayList;

import org.apache.log4j.Logger;

import static org.junit.Assert.*;

/**
 * BitArray implementation of an IndexSet, realized in long[].
 * The xor() operation has complexity O(n), where n is the sum of the size of the two argument arrays.
 * This complexity is like that of the ArrayList implementation.
 * But since here 64 xor's are done at once, this implementation is much faster.
 * 
 * Since int's are clearly faster than long's in many respects, a realization in int[] was tested, too;
 * however this time the longs turned out to be clearly faster.
 * 
 * @author Tilman Neumann
 */
public class IndexSet_BitArrayImpl implements IndexSet {
	private static final Logger LOG = Logger.getLogger(IndexSet_BitArrayImpl.class);
	private static final boolean DEBUG = false;

	/**
	 * the bit array:
	 * bitArray[0] has bits 0..63, bitArray[1] bits 64..127 and so on.
	 */
	private long[] bitArray;
	private int numberOfBits;
	private int numberOfLongs;
	private int biggestEntry; // biggestEntry = -1 indicates that no bit is set / the "set" is empty

	/**
	 * Standard constructor, creates an empty bit array capable to hold the given numberOfBits.
	 * 
	 * @param numberOfBits
	 */
	public IndexSet_BitArrayImpl(int numberOfBits) {
		this.numberOfBits = numberOfBits;
		this.numberOfLongs = (numberOfBits+63)>>6; // ceil(numberOfBits/64)
		this.bitArray = new long[numberOfLongs];
		this.biggestEntry = -1; // no bit set
	}
	
	/**
	 * Add a single element x to this index set.
	 * @param x
	 */
	public void add(int x) {
		int longIndex = x>>6; // floor(x/64)
		int restIndex = x-(longIndex<<6); // x-64*longIndex
		bitArray[longIndex] |= (1L<<restIndex); // set bit
		if (x>biggestEntry) biggestEntry = x; // update biggest entry
	}
	
	@Override
	public boolean contains(Object o) {
		LOG.debug("contains()", new Throwable()); // never used, method untested
		if (o==null || !(o instanceof Integer)) return false;
		int x = ((Integer)o).intValue();
		if (x >= numberOfBits) return false; // there is no entry as big as x
		int longIndex = x>>6; // floor(x/64)
		long theLong = bitArray[longIndex];
		int restIndex = x - (longIndex<<6);
		return (theLong & (1L<<restIndex)) != 0; // bit theLong[restIndex] is set
	}

	@Override
	public Integer last() {
		return biggestEntry;
	}

	@Override
	public boolean isEmpty() {
		return biggestEntry<0;
	}

	@Override
	public void addXor(IndexSet o) {
		if (!(o instanceof IndexSet_BitArrayImpl)) throw new IllegalArgumentException("bitArray.xor() works only with bitArray arguments");
		IndexSet_BitArrayImpl other = (IndexSet_BitArrayImpl) o;
		if (numberOfBits!=other.numberOfBits) throw new IllegalArgumentException("bitArray.xor(): the argument has a different size!");
	
		int xMax = Math.max(biggestEntry, other.biggestEntry);
		int maxLongIndex = xMax>>6; // xMax/64
		for (int longIndex=maxLongIndex; longIndex>=0; longIndex--) {
			bitArray[longIndex] ^= other.bitArray[longIndex]; // xor of 64 bits at once
		}
		// recompute biggest entry
		for (int longIndex=maxLongIndex; longIndex>=0; longIndex--) {
			long theLong = bitArray[longIndex];
			if (theLong != 0) {
				// some bit is set
				for (int i=63; i>=0; i--) {
					if ((theLong & (1L<<i)) != 0) {
						biggestEntry = 64*longIndex + i;
						return;
					}
				}
				throw new IllegalStateException("theLong != 0 -> some bit should have been set!?");
			}
		}
		// nothing found
		this.biggestEntry = -1;
	}
	
	public ArrayList<Integer> toList() {
		ArrayList<Integer> result = new ArrayList<Integer>();
		for (int i=0; i<numberOfLongs; i++) {
			long theLong = bitArray[i];
			int x = i<<6; // x = 64*i
			if (DEBUG) assertEquals(64*i, x);
			if (x>biggestEntry) break;
			for (int j=0; j<64; j++) {
				boolean isSet = (theLong & (1L<<j)) != 0;
				if (isSet) result.add(x+j);
			}
		}
		return result;
	}

	@Override
	public boolean equals(Object o) {
		if (!(o instanceof IndexSet_BitArrayImpl)) return false;
		IndexSet_BitArrayImpl other = (IndexSet_BitArrayImpl) o;
		if (this.numberOfBits != other.numberOfBits) return false;
		if (this.biggestEntry != other.biggestEntry) return false;
		for (int i=0; i<numberOfLongs; i++) {
			if (bitArray[i] != other.bitArray[i]) return false;
		}
		return true;
	}

	@Override
	public String toString() {
		String str = "[";
		for (int i=0; i<numberOfLongs; i++) {
			str += Long.toBinaryString(bitArray[i]) + " ";
		}
		return str.substring(0, str.length()-1) + "]";
	}
	
//	@Override
//	protected void finalize() {
//		LOG.debug("release " + this);
//	}
}
