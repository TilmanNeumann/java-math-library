/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * This file is part of the PSIQS package version 01 from 2016-01-07, 
 * developed by Tilman Neumann, Edemissen, Germany.
 * 
 * Use and redistribution of PSIQS are free for non-commercial purposes, as long as this
 * header is not modified or removed. Any commercial usage of the whole or parts
 * of PSIQS requires the written consent of the author.
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

package de.tilman_neumann.math.factor._matrixSolver;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Set;

import de.tilman_neumann.math.factor.FactorException;
import de.tilman_neumann.math.factor._basics.FactorTest;
import de.tilman_neumann.math.factor._congruence.AQPair;
import de.tilman_neumann.math.factor._congruence.Congruence;
import de.tilman_neumann.math.factor._congruence.SmoothCongruence;

/**
 * A wrapper for the matrix solver used for partial congruence equations systems.
 * Solving such a system may give smooth congruences.
 * The wrapper pattern allows to have several matrix solver implementations.
 * 
 * @author Tilman Neumann
 */
public class PartialSolverWrapper implements NullVectorProcessor {
	
	private MatrixSolver<BigInteger> matrixSolver;
	
	/** factor tester */
	private FactorTest factorTest;

	private ArrayList<SmoothCongruence> foundSmoothCongruences;

	public PartialSolverWrapper(MatrixSolver<BigInteger> matrixSolver) {
		// this hook would be a memory leak if we'ld create many pairs of solver and solver wrapper objects;
		// but we have only 1 object pair in the whole application run time
		matrixSolver.setNullVectorProcessor(this);
		this.matrixSolver = matrixSolver;
	}
	
	public void initialize(BigInteger N, FactorTest factorTest) {
		this.factorTest = factorTest;
	}

	/**
	 * Solve a partial congruence equation system.
	 * @param rawCongruences the partial congruence equation system
	 * @return list of smooth congruences found
	 * @throws FactorException if a factor of N was found
	 */
	public ArrayList<SmoothCongruence> solve(Collection<? extends Congruence<BigInteger>> rawCongruences) throws FactorException {
		foundSmoothCongruences = new ArrayList<SmoothCongruence>();
		matrixSolver.solve(rawCongruences);
		return foundSmoothCongruences;
	}
	
	@Override
	public void processNullVector(Set<AQPair> aqPairs) throws FactorException {
		// we found a smooth congruence from partials!
		SmoothCongruence smoothCongruence = new SmoothCongruence(aqPairs);
		// Since smoothCongruence was assembled from several partials (each of which can not be square),
		// the new solution may give a Q that is an exact square!
		if (smoothCongruence.isExactSquare()) {
			// Q is an exact square -> does it give a factor?
			factorTest.testForFactor(aqPairs);
			// no FactorException -> the square congruence was improper -> drop it
		} else {
			// no exact square -> just keep the new smooth congruence
			foundSmoothCongruences.add(smoothCongruence);
		}
	}
	
	/**
	 * Release memory after a factorization.
	 */
	public void cleanUp() {
		foundSmoothCongruences = null;
		factorTest = null;
	}
}
