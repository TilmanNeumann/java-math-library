/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * This file is part of the PSIQS package version 01 from 2016-01-07, 
 * developed by Tilman Neumann, Edemissen, Germany.
 * 
 * Use and redistribution of PSIQS are free for non-commercial purposes, as long as this
 * header is not modified or removed. Any commercial usage of the whole or parts
 * of PSIQS requires the written consent of the author.
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

package de.tilman_neumann.math.factor.pollardRho;

import java.math.BigInteger;
import java.security.SecureRandom;

import org.apache.log4j.Logger;

import de.tilman_neumann.math.factor.FactorAlgorithmBase;

/**
 * From: http://www.cs.princeton.edu/introcs/79crypto/PollardRho.java
 * (INTRODUCTION TO COMPUTER SCIENCE by Robert Sedgewick and Kevin Wayne)

 * Pollards Rho method. Pollard's rho method is a randomized factoring algorithm
 * that can factor 128 bit numbers in a reasonable amount of time, especially if
 * the numbers have some small factors. It is based on the following fact: if d is
 * the smallest nontrivial factor of N and x - y is a nontrivial multiple of d then
 * gcd(x-y, N) = d. A naive method would be to generate a bunch of random values
 * x[1], x[2], ..., x[m] and compute gcd(x[i]-x[j], N) for all pairs i and j.
 * Pollard's rho method is an ingenious method way to find x and y without doing
 * all of the pairwise computations. It works as follows: choose a and b at random
 * between 1 and N-1, and initialize x = y = a. Repeatedly update x = f(x), y = f(f(y)),
 * where f(x) = x^2 + b as long as gcd(x-y, N) = 1. The gcd is a factor of N, but if you
 * get unlucky, it could be equal to N. By randomly choosing a and b each time, we
 * ensure that we never get too unlucky.
 * 
 * Version 02: Uses simpler addition (mod N)
 * 
 * @author Tilman Neumann
 */
public class PollardRho02 extends FactorAlgorithmBase {
	@SuppressWarnings("unused")
	private static final Logger LOG = Logger.getLogger(PollardRho02.class);
	private static final SecureRandom RNG = new SecureRandom();

	private BigInteger N;
	
	/**
	 * Complete constructor.
	 * 
	 * @param primeTestBits log of probability of predicting false primes
	 */
	public PollardRho02(int primeTestBits) {
		super(primeTestBits);
	}
	
	// Methods ==========================================================================

	@Override
	public String getName() {
		return "PollardRho02";
	}
	
	@Override
	public BigInteger findSingleFactor(BigInteger N) {
		this.N = N;
        BigInteger factor;
		int bitLength = N.bitLength();
        BigInteger x = new BigInteger(bitLength, RNG); // this may be bigger than n, but reducing it via x=x-n gives no speed improvement
        BigInteger xx = x;

        do {
	        // c is a random int from [0, 2^n] where n=upper(ld N)
        	BigInteger c = new BigInteger(bitLength, RNG); // this may be bigger than n, but reducing it via c=c-n gives no speed improvement
	        
	        do {
	            x  = addModN( x.multiply(x) .mod(N), c);
	            xx = addModN(xx.multiply(xx).mod(N), c);
	            xx = addModN(xx.multiply(xx).mod(N), c);
	            factor = x.subtract(xx).gcd(N); // the gcd function must give gcd(0,N) = N
	        } while(factor.compareTo(BigInteger.ONE)==0);
	        
		// leave loop if factor found; otherwise continue with a new random c
        } while (factor.compareTo(N)==0);
		//LOG.debug("RHO: factor of " + N + " = " + factor);
        return factor;
	}

	/**
	 * Addition modulo N, with <code>a, b < N</code>.
	 * @param a
	 * @param b
	 * @return (a+b) mod N
	 */
	private BigInteger addModN(BigInteger a, BigInteger b) {
		BigInteger sum = a.add(b);
		return sum.compareTo(N)<0 ? sum : sum.subtract(N);
	}
}
