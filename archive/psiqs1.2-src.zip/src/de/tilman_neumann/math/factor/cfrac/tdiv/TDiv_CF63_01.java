/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * This file is part of the PSIQS package version 01 from 2016-01-07, 
 * developed by Tilman Neumann, Edemissen, Germany.
 * 
 * Use and redistribution of PSIQS are free for non-commercial purposes, as long as this
 * header is not modified or removed. Any commercial usage of the whole or parts
 * of PSIQS requires the written consent of the author.
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

package de.tilman_neumann.math.factor.cfrac.tdiv;

import java.math.BigInteger;

import org.apache.log4j.Logger;

import de.tilman_neumann.math.factor._basics.SortedBigIntegerArray;
import de.tilman_neumann.math.factor._basics.SortedIntegerArray;
import de.tilman_neumann.math.factor._congruence.AQPair;
import de.tilman_neumann.math.factor._congruence.AQPair01;

import static org.junit.Assert.*;

/**
 * Auxiliary factor algorithm to find smooth decompositions of Q's.
 * 
 * Version 01:
 * Uses only trial division -> this means that partials can have only 1 big factor
 * 
 * @author Tilman Neumann
 */
public class TDiv_CF63_01 implements TDiv_CF63 {
	@SuppressWarnings("unused")
	private static final Logger LOG = Logger.getLogger(TDiv_CF63_01.class);
	private static final boolean DEBUG = false;
	
	private int primeBaseSize;
	private int[] primesArray;
	
	/** Q is sufficiently smooth if the unfactored Q_rest is smaller than this bound depending on N */
	private double maxSufficientSmoothRest;

	// result: two arrays that are reused, their content is _copied_ to AQ-pairs
	private SortedIntegerArray smallFactors = new SortedIntegerArray();
	private SortedBigIntegerArray bigFactors = new SortedBigIntegerArray();
	
	public TDiv_CF63_01(int primeTestBits) {
		// empty
	}

	@Override
	public String getName() {
		return "TDiv63-01";
	}

	public void initialize(BigInteger N, double maxSufficientSmoothRest) {
		this.maxSufficientSmoothRest = maxSufficientSmoothRest;
	}
	
	public void initialize(BigInteger kN, int primeBaseSize, int[] primesArray) {
		this.primeBaseSize = primeBaseSize;
		this.primesArray = primesArray;
	}

	public AQPair test(BigInteger A, long Q) {
		smallFactors.reset();
		bigFactors.reset();
		if (!test(Q)) return null; // not sufficiently smooth
		// otherwise Q was sufficiently smooth -> return AQ-pair
		return new AQPair01(A, BigInteger.valueOf(Q), smallFactors, bigFactors);
	}
	
	public boolean test(long Q) {
		// sign
		long Q_rest = Q;
		if (Q < 0) {
			smallFactors.add(-1);
			Q_rest = -Q;
		}
		// Remove multiples of 2
		while (Q_rest%2==0) {
			smallFactors.add(2);
			Q_rest = Q_rest>>1;
		}

		// Trial division chain:
		// -> first do it in long, then in int.
		// -> (small or probabilistic) prime tests during trial division just slow it down.
		// -> running indices bottom-up is faster because small dividends are more likely to reduce the size of Q_rest.
		int trialDivIndex = 1; // p[0]=2 has already been tested
		int Q_rest_bits = 64 - Long.numberOfLeadingZeros(Q_rest);
		if (Q_rest_bits>31) {
			// do trial division in long
			while (trialDivIndex < primeBaseSize) {
				int p = primesArray[trialDivIndex];
				if (Q_rest % p == 0) {
					// no remainder -> exact division -> small factor
					smallFactors.add(p);
					Q_rest /= p;
					// After division by a prime base element (typically < 20 bit), Q_rest is 12..61 bits.
					Q_rest_bits = 64 - Long.numberOfLeadingZeros(Q_rest);
					if (Q_rest_bits<32) break; // continue with int
					// trialDivIndex must remain as it is to find the same p more than once
				} else {
					trialDivIndex++;
				}
			} // end while (trialDivIndex < primeBaseSize)
		}
		if (DEBUG) assertTrue(Q_rest>1);
		if (Q_rest_bits<32) {
			int Q_rest_int = (int) Q_rest;
			while (trialDivIndex < primeBaseSize) {
				// continue trial division in int
				int p = primesArray[trialDivIndex];
				while (Q_rest_int % p == 0) { // in the last loop, a while pays out!
					// no remainder -> exact division -> small factor
					smallFactors.add(p);
					Q_rest_int /= p;
				}
				trialDivIndex++;
			} // end while (trialDivIndex < primeBaseSize)
			if (Q_rest_int==1) return true;
			Q_rest = (long) Q_rest_int; // keep Q_rest up-to-date
		}
		
		// trial division was not sufficient to factor Q completely.
		// the remaining Q is either a prime > maxPrime, or a composite > maxPrime^2.
		if (Q_rest > maxSufficientSmoothRest) return false; // Q is not sufficiently smooth
	
		// Q is sufficiently smooth
		bigFactors.add(BigInteger.valueOf(Q_rest));
		return true;
	}
}
