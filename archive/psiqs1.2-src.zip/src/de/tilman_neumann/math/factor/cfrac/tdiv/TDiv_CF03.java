/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * This file is part of the PSIQS package version 01 from 2016-01-07, 
 * developed by Tilman Neumann, Edemissen, Germany.
 * 
 * Use and redistribution of PSIQS are free for non-commercial purposes, as long as this
 * header is not modified or removed. Any commercial usage of the whole or parts
 * of PSIQS requires the written consent of the author.
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

package de.tilman_neumann.math.factor.cfrac.tdiv;

import java.math.BigInteger;

import org.apache.log4j.Logger;

import de.tilman_neumann.math.base.bigint.primes.ProbablePrimeTest;
import de.tilman_neumann.math.base.bigint.primes.SmallPrimesSet;
import de.tilman_neumann.math.factor._basics.PrimeBaseBuilder;
import de.tilman_neumann.math.factor._basics.SortedBigIntegerArray;
import de.tilman_neumann.math.factor._basics.SortedIntegerArray;
import de.tilman_neumann.math.factor._congruence.AQPair;
import de.tilman_neumann.math.factor._congruence.AQPair01;
import de.tilman_neumann.math.factor.squfof.SquFoF31;
import de.tilman_neumann.math.factor.squfof.SquFoF63;

import static de.tilman_neumann.math.base.bigint.BigIntConstants.*;
import static org.junit.Assert.*;

/**
 * Auxiliary factor algorithm to find smooth decompositions of Q's.
 * 
 * Version 03:
 * Uses trial division first, complete factorization if Q is considered sufficiently smooth.
 * Use a _simple_ level2 prime base at end of factor recurrence.
 * 
 * @author Tilman Neumann
 */
public class TDiv_CF03 implements TDiv_CF {
	private static final Logger LOG = Logger.getLogger(TDiv_CF03.class);
	private static final boolean DEBUG = false;

	private PrimeBaseBuilder primeBaseBuilder = new PrimeBaseBuilder();
	private int primeBaseSize;
	private int[] primesArray_int;
	private BigInteger[] primesArray_big;
	private int maxPrime;
	private BigInteger maxPrimeSquare;

	/** Q is sufficiently smooth if the unfactored Q_rest is smaller than this bound depending on N */
	private double maxSufficientSmoothRest;
	
	private int max_tDiv_bits;
	
	private int[] level2PrimesArray;
	private int level2PrimeBaseMaxIndex;
	private int level2PrimeBaseStartIndex;
	private int level2TDivIndex;

	private SquFoF31 squFoF31; // used for 2^max_tDiv_bits < Q <= 2^42
	private SquFoF63 squFoF63; // used for 2^43 <= Q <= 2^77
	
	private ProbablePrimeTest probablePrimeTest;
	private SmallPrimesSet smallPrimesSet;
	private int max_smallPrimes_bits;

	// result: two arrays that are reused, their content is _copied_ to AQ-pairs
	private SortedIntegerArray smallFactors = new SortedIntegerArray();
	private SortedBigIntegerArray bigFactors = new SortedBigIntegerArray();
	
	public TDiv_CF03(int primeTestBits, int max_tDiv_bits) {
		this.probablePrimeTest = new ProbablePrimeTest(primeTestBits);
		this.squFoF31 = new SquFoF31(primeTestBits);
		this.squFoF63 = new SquFoF63(primeTestBits);
		this.max_smallPrimes_bits = 20; // TODO: pass in constructor
		this.smallPrimesSet = new SmallPrimesSet(max_smallPrimes_bits);
		this.max_tDiv_bits = max_tDiv_bits;
		// simple second-level prime base
		double max_tDiv_Q = (1L<<max_tDiv_bits) - 1; // the biggest Q for which trial division shall be applied
		int level2MaxPrimeBound = (int) Math.sqrt(max_tDiv_Q)+1; // the biggest prime in the level2 prime base required to factor any Q <= max_tDiv_Q
		this.level2PrimesArray = primeBaseBuilder.getRawPrimesArray();
		this.level2PrimeBaseMaxIndex = primeBaseBuilder.getIndexOfFirstRawPrimeGreaterThan(level2MaxPrimeBound);
	}

	@Override
	public String getName() {
		return "TDiv03(" + max_tDiv_bits + ")";
	}

	public void initialize(BigInteger N, double maxSufficientSmoothRest) {
		this.maxSufficientSmoothRest = maxSufficientSmoothRest;
	}

	public void initialize(BigInteger kN, int primeBaseSize, int[] primesArray, BigInteger[] primesArray_big) {
		this.primeBaseSize = primeBaseSize;
		this.primesArray_int = primesArray;
		this.primesArray_big = primesArray_big;
		this.maxPrime = primesArray[primeBaseSize-1];
		this.maxPrimeSquare = BigInteger.valueOf(maxPrime * (long) maxPrime);
		// set start index for level 2 prime base
		int maxPrime = primesArray[primeBaseSize-1];
		this.level2PrimeBaseStartIndex = primeBaseBuilder.getIndexOfFirstRawPrimeGreaterThan(maxPrime);
	}

	public AQPair test(BigInteger A, BigInteger Q) {
		smallFactors.reset();
		bigFactors.reset();
		if (!test(Q)) return null; // not sufficiently smooth
		// otherwise Q was sufficiently smooth -> return AQ-pair
		return new AQPair01(A, Q, smallFactors, bigFactors);
	}

	public boolean test(BigInteger Q) {
		// sign
		BigInteger Q_rest = Q;
		if (Q.signum() < 0) {
			smallFactors.add(-1);
			Q_rest = Q.negate();
		}
		// Remove multiples of 2
		int lsb = Q_rest.getLowestSetBit();
		if (lsb > 0) {
			for (int i=0; i<lsb; i++) {
				smallFactors.add(2);
			}
			Q_rest = Q_rest.shiftRight(lsb);
		}

		// Trial division chain:
		// -> first do it in BigInteger, then in long, then in int.
		// -> (small or probabilistic) prime tests during trial division just slow it down.
		// -> running indices bottom-up is faster because small dividends are more likely to reduce the size of Q_rest.
		int trialDivIndex = 1; // p[0]=2 has already been tested
		int Q_rest_bits = Q_rest.bitLength();
		if (Q_rest_bits>63) {
			// trial division in BigInteger required
			BigInteger p, div[];
			while (trialDivIndex < primeBaseSize) {
				p = primesArray_big[trialDivIndex];
				div = Q_rest.divideAndRemainder(p);
				if (div[1].equals(ZERO)) {
					// no remainder -> exact division -> small factor
					smallFactors.add(p.intValue());
					Q_rest = div[0];
					// After division by a prime base element (typically < 20 bit), Q_rest is >= 44 bits.
					Q_rest_bits = Q_rest.bitLength();
					if (Q_rest_bits<64) break; // continue in long version
					// trialDivIndex must remain as it is to find the same p more than once
				} else {
					trialDivIndex++;
				}
			} // end while (trialDivIndex < primeBaseSize)
		}
		if (Q_rest_bits>31 && Q_rest_bits<64 && trialDivIndex<primeBaseSize) {
			// continue trial division in long
			long Q_rest_long = Q_rest.longValue();
			while (trialDivIndex<primeBaseSize) {
				int p = primesArray_int[trialDivIndex];
				if (Q_rest_long % p == 0) {
					// no remainder -> exact division -> small factor
					smallFactors.add(p);
					Q_rest_long /= p;
					// After division by a prime base element (typically < 20 bit), Q_rest is 12..61 bits.
					Q_rest_bits = 64 - Long.numberOfLeadingZeros(Q_rest_long);
					if (Q_rest_bits<32) break; // continue with int
					// trialDivIndex must remain as it is to find the same p more than once
				} else {
					trialDivIndex++;
				}
			} // end while (trialDivIndex < primeBaseSize)
			Q_rest = BigInteger.valueOf(Q_rest_long); // keep Q_rest up-to-date
		}
		if (DEBUG) assertTrue(Q_rest.compareTo(ONE)>0);
		if (Q_rest_bits<32) {
			int Q_rest_int = Q_rest.intValue();
			while (trialDivIndex < primeBaseSize) {
				// continue trial division in int
				int p = primesArray_int[trialDivIndex];
				while (Q_rest_int % p == 0) { // in the last loop, a while pays out!
					// no remainder -> exact division -> small factor
					smallFactors.add(p);
					Q_rest_int /= p;
				}
				trialDivIndex++;
			} // end while (trialDivIndex < primeBaseSize)
			if (Q_rest_int==1) return true;
			Q_rest = BigInteger.valueOf(Q_rest_int); // keep Q_rest up-to-date
		}

		// trial division was not sufficient to factor Q completely.
		// the remaining Q is either a prime > maxPrime, or a composite > maxPrime^2.
		if (Q_rest.doubleValue() > maxSufficientSmoothRest) return false; // Q is not sufficiently smooth
		
		// now we consider Q as sufficiently smooth. then we want to know all prime factors!
		//LOG.debug("before factor_recurrent()");
		factor_recurrent(Q_rest);
		if (DEBUG) if (bigFactors.size()>1) LOG.debug("Found " + bigFactors.size() + " distinct big factors!");
		return true;
	}

	private void factor_recurrent(BigInteger Q_rest) {
		if (Q_rest.compareTo(maxPrimeSquare)<0) {
			// we divided Q_rest by all primes <= maxPrime and the rest is < maxPrime^2 -> it must be prime
			if (DEBUG) assertTrue(probablePrimeTest.isProbablePrime(Q_rest));
			bigFactors.add(Q_rest);
			return;
		}
		// here we can not do without isProbablePrime(), because calling findSingleFactor() may not return when called with a prime argument
		int Q_rest_bits = Q_rest.bitLength();
		if ((Q_rest_bits<=max_smallPrimes_bits && smallPrimesSet.contains(Q_rest))) {
			// Q_rest is small prime -> end of recurrence (in contrast to QS, this happens in CFRAC!)
			if (DEBUG) LOG.debug("maxPrime = " + maxPrime + ", Q_rest = " + Q_rest + " is small prime!");
			bigFactors.add(Q_rest);
			return;
		} // else: Q_rest is surely not prime
		if (probablePrimeTest.isProbablePrime(Q_rest)) {
			// Q_rest is (probable) prime -> end of recurrence
			bigFactors.add(Q_rest);
			return;
		} // else: Q_rest is surely not prime

		// Q_rest is maxPrime < Q_rest <= maxSufficientSmoothRest, composite and odd.
		if (Q_rest_bits <= max_tDiv_bits) {
			// Q_rest can surely be factored with the second level prime base -> end of recurrence
			finalTDiv(Q_rest.longValue(), Q_rest_bits);
			return;
		}
		
		// the expensive part: find a factor of Q_rest, where Q_rest is composite and odd
		BigInteger factor1;
		if (Q_rest_bits < 43) {
			factor1 = squFoF31.findSingleFactor(Q_rest);
		} else if (Q_rest_bits < 78) {
			factor1 = squFoF63.findSingleFactor(Q_rest);
		} else {
			throw new IllegalStateException("Q_rest = " + Q_rest + " (" + Q_rest_bits + " bits) is too big!");
		}
		// Recurrence: Is it possible to further decompose the parts?
		factor_recurrent(factor1);
		factor_recurrent(Q_rest.divide(factor1));
		return;
	}

	private void finalTDiv(long Q_rest, int Q_rest_bits) {
		this.level2TDivIndex = level2PrimeBaseStartIndex;
		if (Q_rest_bits < 32) {
			finalTDiv_int( (int) Q_rest);
			return;
		}
		while (level2TDivIndex < level2PrimeBaseMaxIndex) {
			int p = level2PrimesArray[level2TDivIndex];
			if (Q_rest % p == 0) {
				// no remainder, exact division!
				bigFactors.add(BigInteger.valueOf(p));
				Q_rest /= p;
				// quick return possible? (in final tDiv this is a big speed-up)
				Q_rest_bits = 64 - Long.numberOfLeadingZeros(Q_rest);
				if (Q_rest_bits<=max_smallPrimes_bits && smallPrimesSet.contains(Q_rest)) {
					bigFactors.add(BigInteger.valueOf(Q_rest));
					return;
				}
				if (Q_rest_bits < 32) {
					finalTDiv_int( (int) Q_rest);
					return;
				}
				// level2TDivIndex must remain as it is to find primes with exponent > 1, too
			} else {
				level2TDivIndex++;
			}
		} // end while (level2TDivIndex < level2PrimeBaseSize)
		throw new IllegalStateException("Q_rest = " + Q_rest + " has not been factored completely! Q_rest = " + Q_rest);
	}

	private void finalTDiv_int(int Q_rest) {
		while (level2TDivIndex < level2PrimeBaseMaxIndex) {
			int p = level2PrimesArray[level2TDivIndex];
			if (Q_rest % p == 0) {
				// no remainder, exact division!
				bigFactors.add(BigInteger.valueOf(p));
				Q_rest /= p;
				// quick return possible? (in final tDiv this is a big speed-up)
				if (Q_rest==1) return;
				if (smallPrimesSet.contains(Q_rest)) {
					bigFactors.add(BigInteger.valueOf(Q_rest));
					return;
				}
				// level2TDivIndex must remain as it is to find primes with exponent > 1, too
			} else {
				level2TDivIndex++;
			}
		} // end while (level2TDivIndex < level2PrimeBaseSize)
		throw new IllegalStateException("Q_rest = " + Q_rest + " has not been factored completely! Q_rest = " + Q_rest);
	}
}
