/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * This file is part of the PSIQS package version 01 from 2016-01-07, 
 * developed by Tilman Neumann, Edemissen, Germany.
 * 
 * Use and redistribution of PSIQS are free for non-commercial purposes, as long as this
 * header is not modified or removed. Any commercial usage of the whole or parts
 * of PSIQS requires the written consent of the author.
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

package de.tilman_neumann.math.factor.tdiv;

import java.math.BigInteger;

import de.tilman_neumann.math.base.smallint.PPGen63;
import de.tilman_neumann.math.factor.FactorAlgorithmBase;

import static de.tilman_neumann.math.base.bigint.BigIntConstants.*;

/**
 * Trial division factor algorithm with 63-bit longs, using a possible prime generator.
 * 
 * @author Tilman Neumann
 */
public class TDiv63 extends FactorAlgorithmBase {

	public TDiv63(int primeTestPrecisionBits) {
		super(primeTestPrecisionBits);
	}

	@Override
	public String getName() {
		return "TDiv63";
	}

	@Override
	public BigInteger findSingleFactor(BigInteger N) {
		long n = N.longValue();
		// test 3 and 5, not covered by PPGen2
		if (n%3==0) return THREE;
		if (n%5==0) return FIVE;
		
		// if n is odd and composite then the loop runs maximally up to test = floor(sqrt(n))
		long test;
		PPGen63 ppGen = new PPGen63();
		while (true) {
			test = ppGen.next();
			if (n%test==0) return BigInteger.valueOf(test);
		}
	}
	
	/**
	 * Test if N has a factor <= maxTestNumber.
	 * @param N
	 * @param maxTestNumber
	 * @return small factor, or null if N has no factor <= maxTestNumber
	 */
	public BigInteger findSmallFactor(BigInteger N, BigInteger maxTestNumber) {
		long n = N.longValue();
		long maxTestNumberL = maxTestNumber.longValue();
		// test 2, 3 and 5, not covered by PPGen2
		if (maxTestNumberL<2) return null;
		if (n%2==0) return TWO;
		if (maxTestNumberL<3) return null;
		if (n%3==0) return THREE;
		if (maxTestNumberL<5) return null;
		if (n%5==0) return FIVE;
		
		// test until maxTestNumber or until a factor is found
		PPGen63 ppGen = new PPGen63();
		long test = ppGen.next();
		while (test <= maxTestNumberL) {
			if (n%test==0) return BigInteger.valueOf(test);
			// next
			test = ppGen.next();
		}
		return null;
	}
}
