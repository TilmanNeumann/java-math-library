/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * This file is part of the PSIQS package version 01 from 2016-01-07, 
 * developed by Tilman Neumann, Edemissen, Germany.
 * 
 * Use and redistribution of PSIQS are free for non-commercial purposes, as long as this
 * header is not modified or removed. Any commercial usage of the whole or parts
 * of PSIQS requires the written consent of the author.
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

package de.tilman_neumann.math.factor.tdiv;

import java.math.BigInteger;

import de.tilman_neumann.math.base.smallint.PPGen31;
import de.tilman_neumann.math.factor.FactorAlgorithmBase;

import static de.tilman_neumann.math.base.bigint.BigIntConstants.*;

/**
 * Trial division factor algorithm using a possible prime generator.
 * 
 * int version.
 * 
 * @author Tilman Neumann
 */
public class TDiv31 extends FactorAlgorithmBase {

	public TDiv31(int primeTestPrecisionBits) {
		super(primeTestPrecisionBits);
	}

	@Override
	public String getName() {
		return "TDiv31";
	}


	@Override
	public BigInteger findSingleFactor(BigInteger N) {
		return BigInteger.valueOf(findSingleFactor(N.intValue()));
	}
	
	public long findSingleFactor(long N) {
		return (long) findSingleFactor( (int) N);
	}
	
	public int findSingleFactor(int N) {
		// test 3 and 5, not covered by PPGen2
		if (N%3==0) return 3;
		if (N%5==0) return 5;
		
		// if N is odd and composite then the loop runs maximally up to test = floor(sqrt(N))
		int test;
		PPGen31 ppGen = new PPGen31();
		while (true) {
			test = ppGen.next();
			if (N%test==0) return test;
		}
	}
	
	/**
	 * Test if N has a factor <= maxTestNumber.
	 * @param N
	 * @param maxTestNumber
	 * @return small factor, or null if N has no factor <= maxTestNumber
	 */
	public BigInteger findSmallFactor(BigInteger N, BigInteger maxTestNumber) {
		int n = N.intValue();
		int maxTestNumberL = maxTestNumber.intValue();
		// test 2, 3 and 5, not covered by PPGen2
		if (maxTestNumberL<2) return null;
		if (n%2==0) return TWO;
		if (maxTestNumberL<3) return null;
		if (n%3==0) return THREE;
		if (maxTestNumberL<5) return null;
		if (n%5==0) return FIVE;
		
		// test until maxTestNumber or until a factor is found
		PPGen31 ppGen = new PPGen31();
		int test = ppGen.next();
		while (test <= maxTestNumberL) {
			if (n%test==0) return BigInteger.valueOf(test);
			// next
			test = ppGen.next();
		}
		return null;
	}
}
