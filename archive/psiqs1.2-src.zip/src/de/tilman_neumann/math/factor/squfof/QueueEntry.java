/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * This file is part of the PSIQS package version 01 from 2016-01-07, 
 * developed by Tilman Neumann, Edemissen, Germany.
 * 
 * Use and redistribution of PSIQS are free for non-commercial purposes, as long as this
 * header is not modified or removed. Any commercial usage of the whole or parts
 * of PSIQS requires the written consent of the author.
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

package de.tilman_neumann.math.factor.squfof;

import java.math.BigInteger;

/**
 * An entry of SquFoFs queue.
 * @author Tilman Neumann
 */
public class QueueEntry {
	BigInteger x, y;
	
	public QueueEntry(BigInteger x, BigInteger y) {
		this.x = x;
		this.y = y;
	}
	
	public boolean equals(Object o) {
		if (o==null) return false;
		if (! (o instanceof QueueEntry)) return false;
		QueueEntry other = (QueueEntry) o;
		return (x.equals(other.x) && y.equals(other.y));
	}
}
