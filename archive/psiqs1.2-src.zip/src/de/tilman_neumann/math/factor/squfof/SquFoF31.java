/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * This file is part of the PSIQS package version 01 from 2016-01-07, 
 * developed by Tilman Neumann, Edemissen, Germany.
 * 
 * Use and redistribution of PSIQS are free for non-commercial purposes, as long as this
 * header is not modified or removed. Any commercial usage of the whole or parts
 * of PSIQS requires the written consent of the author.
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

package de.tilman_neumann.math.factor.squfof;

import java.math.BigInteger;

import org.apache.log4j.Logger;

import de.tilman_neumann.math.base.bigint.sequence.SquarefreeSequence;
import de.tilman_neumann.math.base.smallint.Gcd63;
import de.tilman_neumann.math.factor.FactorAlgorithmBase;

/**
 * Shanks' SQUFOF algorithm, 31-bit version.
 * This version works for N <= 2^40 and is about 35% faster than the 63-bit version.
 * 
 * @author Tilman Neumann
 */
public class SquFoF31 extends FactorAlgorithmBase {
	@SuppressWarnings("unused")
	private static final Logger LOG = Logger.getLogger(SquFoF31.class);

	// input
	private long N, kN;
	private int floor_sqrt_kN;
	
	// maximum number of iterations
	private int maxI;
	
	// gcd engine
	private Gcd63 gcdEngine = new Gcd63();
	
	/**
	 * Standard constructor.
	 * @param primeTestBits
	 */
	public SquFoF31(int primeTestBits) {
		super(primeTestBits);
	}

	@Override
	public String getName() {
		return "SquFoF31";
	}
	
	@Override
	public BigInteger findSingleFactor(BigInteger N) {
		return BigInteger.valueOf(findSingleFactor(N.longValue()));
	}

	/**
	 * Find a factor of the given composite N.</br></br>
	 * <em>Warning:</em> This method will not return when called with a prime argument.
	 * @param N composite integer
	 * @return factor of N
	 */
	public long findSingleFactor(long N) {
		this.N = N;
		// best parameters found by experiments:
		// multiplier = 1680 always, and stopMult  approximated piecewise:
		float stopMult;
		int bits = 64 - Long.numberOfLeadingZeros(N);
		if (bits < 34) stopMult = 1.92F + (33-bits)*0.06F;
		else           stopMult = 1.1F  + (50-bits)*0.035F;
		// max iterations
		this.maxI = (int) (stopMult * Math.pow(N, 0.2)); // stopMult * (5.th root of N)
		// sequence: for each new N start again with the first k
		SquarefreeSequence kSequence = new SquarefreeSequence(BigInteger.valueOf(1680));
		kSequence.reset();
		while (true) {
			// get a new k, return immediately if kN is square
			this.kN = kSequence.next().longValue() * N;
			floor_sqrt_kN = (int) Math.sqrt(kN);
			int diff = (int) (kN - floor_sqrt_kN*(long)floor_sqrt_kN);
			if (diff==0) return gcdEngine.gcd(N, floor_sqrt_kN);
			if (diff<0) {
				// floor_sqrt_kN was too big, diff too small -> compute correction
				floor_sqrt_kN--;
				diff += (floor_sqrt_kN<<1) + 1;
			}
			// search square Q_i
			Long factor = test(diff);
			if (factor!=null) return factor;
		}
	}

	protected Long test(int Q_ip1) {
		// initialization for first iteration step
		int i = 0;
		int P_im1 = 1;
		int P_i = floor_sqrt_kN;
		int Q_i = 1;
		
		// first iteration step
		while (true) {
			// [McMath 2004] points out that we have to look for a square Q_i at some even i.
			// Here I test Q_i+1, so I have to look for square Q_i+1 at odd i!
			if (i%2==1) {
				int Q_ip1_sqrt = (int) Math.sqrt(Q_ip1);
				if (Q_ip1_sqrt*Q_ip1_sqrt==Q_ip1) {
					// Q_i+1 is square -> do reverse iteration
					Long factor = reverseIteration(P_i, Q_ip1_sqrt);
					if (factor!=null) return factor; // if factor is null we try another k
				}
			}
		
			// exit ?
			if (++i==maxI) return null;
			// keep values from last round
			P_im1 = P_i;
			int Q_im1 = Q_i;
			Q_i = Q_ip1;
			// compute next values
			int b_i = (floor_sqrt_kN + P_im1)/Q_i; // floor(rational result)
			P_i = b_i*Q_i - P_im1;
			Q_ip1 = Q_im1 + b_i*(P_im1-P_i);
		}
	}
	
	private Long reverseIteration(int found_P, int found_Q_sqrt) {
		// initialization for second iteration step
		int i = 0;
		int b_i = (floor_sqrt_kN-found_P)/found_Q_sqrt; // floor(rational result)
		int P_i = b_i*found_Q_sqrt + found_P;
		int Q_i = found_Q_sqrt;
		int Q_ip1 = (int) ((kN - P_i*(long)P_i)/found_Q_sqrt);
		
		// second iteration step
		int P_im1, Q_im1;
		do {
			// exit ?
			if (++i==maxI) return null;
			// keep values from last round
			P_im1 = P_i;
			Q_im1 = Q_i;
			Q_i = Q_ip1;
			// compute next values
			b_i = (floor_sqrt_kN+P_im1)/Q_i; // floor(rational result)
			P_i = b_i*Q_i - P_im1;
			Q_ip1 = Q_im1 + b_i*(P_im1-P_i);
		} while (P_i != P_im1);
		
		// result
		long gcd = gcdEngine.gcd(N, P_i);
		return (gcd>1 && gcd<N) ? gcd : null;
	}
}
