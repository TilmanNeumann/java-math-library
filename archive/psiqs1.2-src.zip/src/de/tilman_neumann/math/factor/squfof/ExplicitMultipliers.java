/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * This file is part of the PSIQS package version 01.02 from 2016-01-17, 
 * developed by Tilman Neumann, Edemissen, Germany.
 * 
 * Use and redistribution of PSIQS are free for non-commercial purposes, as long as this
 * header is not modified or removed. Any commercial usage of the whole or parts
 * of PSIQS requires the written consent of the author.
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
package de.tilman_neumann.math.factor.squfof;

import java.math.BigInteger;

import de.tilman_neumann.math.base.bigint.sequence.IntegerSequence;

/**
 * A hand-selected list of multipliers.
 * @author Tilman Neumann
 */
public class ExplicitMultipliers implements IntegerSequence<BigInteger> {

	/** Gower&Wagstaff multipliers */
	public static final ExplicitMultipliers GW = new ExplicitMultipliers("GW", 
			new int[] {	3*5*7*11, 3*5*7,  3*5*7*11*13, 3*5*7*13, 3*5*7*11*17, 3*5*11,
						3*5*7*17, 3*5,    3*5*7*11*19, 3*5*11*13,3*5*7*19,    3*5*7*13*17,
						3*5*13,   3*7*11, 3*7,         5*7*11,   3*7*13,      5*7,
						3*5*17,   5*7*13, 3*5*19,      3*11,     3*7*17,      3,
						3*11*13,  5*11,   3*7*19,      3*13,     5,           5*11*13,
						5*7*19,   5*13,   7*11,        7,        3*17,        7*13,
						11,       1});

	/** Some smooth _even_ multipliers followed by Gower&Wagstaff's multipliers */
	public static final ExplicitMultipliers EVEN_AND_GW = new ExplicitMultipliers("Even+GW", 
			new int[] {	10080, 5760, 4032, 6720, 8400, 3360, 5040, 10752, 7920, 9504, 2880,
						7200, 8640, 4320, 6240, 8064, 4800, 5280, 10560, 7392,
						3*5*7*11, 3*5*7,  3*5*7*11*13, 3*5*7*13, 3*5*7*11*17, 3*5*11,
						3*5*7*17, 3*5,    3*5*7*11*19, 3*5*11*13,3*5*7*19,    3*5*7*13*17,
						3*5*13,   3*7*11, 3*7,         5*7*11,   3*7*13,      5*7,
						3*5*17,   5*7*13, 3*5*19,      3*11,     3*7*17,      3,
						3*11*13,  5*11,   3*7*19,      3*13,     5,           5*11*13,
						5*7*19,   5*13,   7*11,        7,        3*17,        7*13,
						11,       1});

	private String name;
	private BigInteger[] multiplierArray;
	private int index;
	
	public ExplicitMultipliers(String name, int[] multiplierArray) {
		this.name = name;
		// convert int-array into BigInteger-array
		this.multiplierArray = new BigInteger[multiplierArray.length];
		for (int i=0; i<multiplierArray.length; i++) this.multiplierArray[i] = BigInteger.valueOf(multiplierArray[i]);
		this.index = 0;
	}

	@Override
	public void reset(BigInteger N) {
		index = 0;
	}

	@Override
	public String getName() {
		return name;
	}

	@Override
	public BigInteger next() {
		return (index < multiplierArray.length) ? multiplierArray[index++] : null;
	}
}
