/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * This file is part of the PSIQS package version 01 from 2016-01-07, 
 * developed by Tilman Neumann, Edemissen, Germany.
 * 
 * Use and redistribution of PSIQS are free for non-commercial purposes, as long as this
 * header is not modified or removed. Any commercial usage of the whole or parts
 * of PSIQS requires the written consent of the author.
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

package de.tilman_neumann.math.factor.squfof;

import java.math.BigInteger;
import java.util.LinkedList;

import org.apache.log4j.Logger;

import de.tilman_neumann.math.base.bigint.SqrtExact;
import de.tilman_neumann.math.base.bigint.SqrtInt;
import de.tilman_neumann.math.base.bigint.sequence.IntegerSequence;
import de.tilman_neumann.math.factor.FactorAlgorithmBase;

import static de.tilman_neumann.math.base.bigint.BigIntConstants.*;

/**
 * Shanks' SQUFOF algorithm.<br/>
 * Implemented according to <link>http://en.wikipedia.org/wiki/Shanks'_square_forms_factorization</link>.
 * 
 * Version 3 := Version 1 + queue
 * 
 * Stopping criterion: after a maximum number of iterations.
 * 
 * @author Tilman Neumann
 */
public class SquFoF03_maxI extends FactorAlgorithmBase {
	@SuppressWarnings("unused")
	private static final Logger LOG = Logger.getLogger(SquFoF03_maxI.class);

	private IntegerSequence<BigInteger> kSequence;

	// input
	private BigInteger N, kN, floor_sqrt_kN;

	// maximum number of iterations
	private int stopRoot;
	private float stopMult;
	private long maxI;
	// required for queue
	private BigInteger L, half_L;
	
	/**
	 * Standard constructor.
	 * @param kSequence multiplier generator
	 * @param stopRoot order of the root to compute the maximum number of iterations
	 * @param stopMult multiplier to compute the maximum number of iterations
	 */
	public SquFoF03_maxI(int primeTestBits, IntegerSequence<BigInteger> kSequence, int stopRoot, float stopMult) {
		super(primeTestBits);
		this.kSequence = kSequence;
		this.stopRoot = stopRoot;
		this.stopMult = stopMult;
	}

	@Override
	public String getName() {
		return "SquFoF03_maxI(" + kSequence.getName() + ", " + stopRoot + ", " + stopMult + ")";
	}
	
	/**
	 * Test the current N.
	 * @return factor, or null if no factor was found.
	 */
	public BigInteger findSingleFactor(BigInteger N) {
		this.N = N;
		// max iterations: there is no need to account for k, because expansions of smooth kN are typically not longer than those for N
		this.maxI = (long) (stopMult*Math.pow(N.doubleValue(), 1.0/stopRoot));
		// for each new N start again with the first k
		kSequence.reset(N);
		while (true) {
			// get a new k, return immediately if kN is square
			this.kN = kSequence.next().multiply(N);
			BigInteger[] iSqrt = SqrtInt.iSqrt(kN);
			this.floor_sqrt_kN = iSqrt[0];
			if (floor_sqrt_kN.equals(iSqrt[1])) return N.gcd(floor_sqrt_kN);
			// search square Q_i
			this.L = BigInteger.valueOf( (long) (2.82842712F * Math.pow(kN.doubleValue(), 0.25)) );
			this.half_L = L.shiftRight(1);
			BigInteger factor = test();
			if (factor!=null) return factor;
		}
	}

	protected BigInteger test() {
		// initialization for first iteration step
		long i = 0;
		BigInteger P_im1 = ONE;
		BigInteger P_i = floor_sqrt_kN;
		BigInteger Q_i = ONE;
		BigInteger Q_ip1 = kN.subtract(P_i.multiply(P_i)); // faster than P_i.pow(2)
		LinkedList<QueueEntry> queue = new LinkedList<QueueEntry>();
		
		// first iteration step
		while (true) {
			// [McMath 2004] points out that we have to look for a square Q_i at some even i.
			// Here I test Q_i+1, so I have to look for square Q_i+1 at odd i!
			if (i%2==1) {
				BigInteger Q_ip1_sqrt = SqrtExact.exactSqrt(Q_ip1);
				if (Q_ip1_sqrt!=null) {
					// Q_i+1 is square
					boolean pairFound = false;
					LinkedList<QueueEntry> parsedEntries = new LinkedList<QueueEntry>();
					for (QueueEntry entry : queue) {
						parsedEntries.add(entry);
						if (entry.x.equals(Q_ip1_sqrt)) {
							int r_cmp = Q_ip1_sqrt.compareTo(ONE);
							if (r_cmp==0) return null; // no proper form
							if (r_cmp>0 && (P_i.subtract(entry.y).mod(entry.x).equals(ZERO))) {
								// remove all entries from head to current
								queue.removeAll(parsedEntries);
								pairFound = true;
								break;
							}
						}
					}
					if (pairFound==false) {
						// -> do reverse iteration
						BigInteger factor = reverseIteration(P_i, Q_ip1_sqrt);
						if (factor!=null) return factor; // if factor is null we try another k
					} // else: cycle on
				}
			}
		
			// exit ?
			if (++i==maxI) return null;
			
			// update queue
			if (Q_ip1.compareTo(L)<=0) {
				if (Q_ip1.and(ONE).equals(ZERO)) { // Q_ip1 is even
					BigInteger half_Q = Q_ip1.shiftRight(1);
					queue.add(new QueueEntry(half_Q, P_i.mod(half_Q)));
				} else if (Q_ip1.compareTo(half_L)<=0) {
					// Q_ip1 is odd and <= L/2
					queue.add(new QueueEntry(Q_ip1, P_i.mod(Q_ip1)));
				}
			}

			// keep values from last round
			P_im1 = P_i;
			BigInteger Q_im1 = Q_i;
			Q_i = Q_ip1;
			// compute next values
			BigInteger b_i = floor_sqrt_kN.add(P_im1).divideAndRemainder(Q_i)[0]; // floor(rational result)
			P_i = b_i.multiply(Q_i).subtract(P_im1);
			Q_ip1 = Q_im1.add(b_i.multiply(P_im1.subtract(P_i)));
		}
	}
	
	private BigInteger reverseIteration(BigInteger found_P, BigInteger found_Q_sqrt) {
		// initialization for second iteration step
		long i = 0;
		BigInteger b_i = floor_sqrt_kN.subtract(found_P).divideAndRemainder(found_Q_sqrt)[0]; // floor(rational result)
		BigInteger P_i = b_i.multiply(found_Q_sqrt).add(found_P);
		BigInteger Q_i = found_Q_sqrt;
		BigInteger Q_ip1 = kN.subtract(P_i.multiply(P_i)).divide(found_Q_sqrt); // faster than P_i.pow(2)
		
		// second iteration step
		BigInteger P_im1, Q_im1;
		do {
			// exit ?
			if (++i==maxI) return null;
			// keep values from last round
			P_im1 = P_i;
			Q_im1 = Q_i;
			Q_i = Q_ip1;
			// compute next values
			b_i = floor_sqrt_kN.add(P_im1).divideAndRemainder(Q_i)[0]; // floor(rational result)
			P_i = b_i.multiply(Q_i).subtract(P_im1);
			Q_ip1 = Q_im1.add(b_i.multiply(P_im1.subtract(P_i)));
		} while(!P_i.equals(P_im1));
		
		// result
		BigInteger gcd = N.gcd(P_i);
		return (gcd.compareTo(ONE)>0 && gcd.compareTo(N)<0) ? gcd : null;
	}
}
