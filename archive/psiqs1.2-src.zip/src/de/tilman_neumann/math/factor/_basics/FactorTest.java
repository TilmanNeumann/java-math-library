/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * This file is part of the PSIQS package version 01 from 2016-01-07, 
 * developed by Tilman Neumann, Edemissen, Germany.
 * 
 * Use and redistribution of PSIQS are free for non-commercial purposes, as long as this
 * header is not modified or removed. Any commercial usage of the whole or parts
 * of PSIQS requires the written consent of the author.
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

package de.tilman_neumann.math.factor._basics;

import java.math.BigInteger;
import java.util.Collection;

import org.apache.log4j.Logger;

import de.tilman_neumann.math.base.bigint.SqrtInt;
import de.tilman_neumann.math.factor.FactorException;
import de.tilman_neumann.math.factor._congruence.AQPair;
import de.tilman_neumann.types.SortedMultiset;
import de.tilman_neumann.types.SortedMultiset_TreeMapImpl;

import static de.tilman_neumann.math.base.bigint.BigIntConstants.*;
import static org.junit.Assert.*;

/**
 * Factor tester.
 * @author Tilman Neumann
 */
public class FactorTest {
	private static final Logger LOG = Logger.getLogger(FactorTest.class);
	private static final boolean DEBUG = false;

	private BigInteger N;
	
	public FactorTest(BigInteger N) {
		this.N = N;
	}
	
	/**
	 * Test if a square congruence gives a factor of N.
	 * The Q-product must not be reduced (mod N); the result can be huge, like a 1.000.000 bit number for N having 250 bit.
	 * As such, it is faster to compose sqrt(Q-product) from the known prime factorizations of the involved Q's than to compute
	 * the sqrt directly. On the other hand, storing the complete Q-factorizations needs a lot of memory. Currently we stay with it.
	 *
	 * @param aqPairs
	 * @throws FactorException
	 */
	public void testForFactor(Collection<AQPair> aqPairs) throws FactorException {
		BigInteger AProd = ONE;
		SortedMultiset<BigInteger> totalQ_factors = new SortedMultiset_TreeMapImpl<BigInteger>();
		for (AQPair aqPair : aqPairs) {
			AProd = AProd.multiply(aqPair.getA());
			totalQ_factors.addAll(aqPair.getQFactors());
		}
		// Compose totalQSqrt from the prime factorizations of the involved Q's
		long t0 = System.currentTimeMillis();
		BigInteger totalQSqrt = ONE;
		for (BigInteger factor : totalQ_factors.keySet()) {
			if (factor.equals(MINUS_ONE)) continue; // sqrt(Q-product) can be positive or negative, but we want the positive solution -> skip sign
			int exp = totalQ_factors.get(factor);
			if (DEBUG) assertTrue(exp%2==0);
			int halfExp = exp>>1;
			totalQSqrt = totalQSqrt.multiply(factor.pow(halfExp));
		}
		
		if (DEBUG) {
			long compositionDuration = System.currentTimeMillis() - t0;
			LOG.debug("N = " + N + ": testForFactor(): A=" + getAString(aqPairs) + "=" + AProd + ", Q=" + getQString(aqPairs) + ", sqrt(Q)=" + totalQSqrt);
			// 1. verify congruence A^2 == Q (mod N)
			BigInteger totalQ = totalQSqrt.multiply(totalQSqrt);
			BigInteger div[] = AProd.pow(2).subtract(totalQ).divideAndRemainder(N);
			assertEquals(ZERO, div[1]); // works
			LOG.debug("A^2-Q = " + div[0] + " * N");
			LOG.debug("A^2 % N = " + AProd.pow(2).mod(N) + ", Q = " + totalQ);
			// 2. compare performance of composition vs. direct computation of totalQSqrt
			long t1 = System.currentTimeMillis();
			BigInteger QProd = ONE;
			for (AQPair aqPair : aqPairs) QProd = QProd.multiply(aqPair.getQ());
			BigInteger[] iSqrt = SqrtInt.iSqrt(QProd);
			long t2 = System.currentTimeMillis();
			LOG.debug("sqrt(Q) has " + totalQSqrt.bitLength() + " bits; composition took " + compositionDuration + "ms, direct computation took " + (t2-t1) + "ms");
			assertEquals(iSqrt[0], iSqrt[1]);
			//LOG.debug("totalQSqrt = " + totalQSqrt + ", iSqrt = " + iSqrt[1]);
			assertEquals(totalQSqrt, iSqrt[1]);
		}

		// test A-sqrt(Q)
		BigInteger minusGcd = AProd.subtract(totalQSqrt).gcd(N);
		if (DEBUG) LOG.debug("minusGcd = " + minusGcd);
		if (minusGcd.compareTo(ONE)>0 && minusGcd.compareTo(N)<0) throw new FactorException(minusGcd); // factor!
		// test A+sqrt(Q)
		BigInteger plusGcd = AProd.add(totalQSqrt).gcd(N);
		if (DEBUG) LOG.debug("plusGcd = " + plusGcd);
		if (plusGcd.compareTo(ONE)>0 && plusGcd.compareTo(N)<0) throw new FactorException(plusGcd); // factor!
		// no factor exception -> no success
	}
	
	private String getAString(Collection<AQPair> aqPairs) {
		String str = "";
		for (AQPair aqPair : aqPairs) {
			str += aqPair.getA() + "*";
		}
		return str.substring(0, str.length()-1); // remove last "*"
	}
	
	private String getQString(Collection<AQPair> aqPairs) {
		String str = "";
		for (AQPair aqPair : aqPairs) {
			str += aqPair.getQ() + "*";
		}
		return str.substring(0, str.length()-1); // remove last "*"
	}
	
	@Override
	public String toString() {
		return "FactorTest(" + N + ")";
	}
	
//	@Override
//	protected void finalize() {
//		LOG.debug("release " + this);
//	}
}
