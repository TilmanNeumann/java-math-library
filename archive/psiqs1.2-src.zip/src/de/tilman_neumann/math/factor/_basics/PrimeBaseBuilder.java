/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * This file is part of the PSIQS package version 01 from 2016-01-07, 
 * developed by Tilman Neumann, Edemissen, Germany.
 * 
 * Use and redistribution of PSIQS are free for non-commercial purposes, as long as this
 * header is not modified or removed. Any commercial usage of the whole or parts
 * of PSIQS requires the written consent of the author.
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

package de.tilman_neumann.math.factor._basics;

import java.math.BigInteger;

import org.apache.log4j.Logger;

import de.tilman_neumann.math.base.bigint.JacobiSymbol;
import de.tilman_neumann.math.base.smallint.SmallPrimesGenerator31;

import static de.tilman_neumann.math.base.bigint.BigIntConstants.*;
import static org.junit.Assert.*;

/**
 * Fly-weight prime base builder.
 * This class is stateless and instantiation is very cheap; thus it does not need to be passed as argument.
 * 
 * computeReducedPrimeBase() methods return the 2 and only odd primes with Legendre(kN|p)>0, i.e. such that kN is a quadratic residue (mod p).
 * For the Legendre symbol, Euler's formula with a fast modPow() implementation is used.
 * 
 * @author Tilman Neumann
 */
public class PrimeBaseBuilder {
	private static final Logger LOG = Logger.getLogger(PrimeBaseBuilder.class);
	private static final boolean DEBUG = false;
	
	private static final int RAW_PRIMEBASE_SIZE = 500000;

	/** the first RAW_PRIMEBASE_SIZE primes */
	private static final int[] RAW_PRIMES_ARRAY = new int[RAW_PRIMEBASE_SIZE];
	/** quite accurate ln(p) values */
	private static final float[] RAW_LNP_ARRAY = new float[RAW_PRIMEBASE_SIZE];
	
	static {
		// set up precomputed unfiltered prime base: the first RAW_PRIMEBASE_SIZE primes
		SmallPrimesGenerator31 smallPrimesGenerator = new SmallPrimesGenerator31();
		RAW_PRIMES_ARRAY[0] = smallPrimesGenerator.nextPrime(); // 2 is added always
		assertEquals(2, RAW_PRIMES_ARRAY[0]);
		for (int i=1; i<RAW_PRIMEBASE_SIZE; i++) {
			int p = smallPrimesGenerator.nextPrime();
			RAW_PRIMES_ARRAY[i] = p;
			// quite accurate ln(p)
			RAW_LNP_ARRAY[i] = (float) Math.log(p);
		}
	}
	
	private JacobiSymbol jacobiEngine = new JacobiSymbol();
	
	public PrimeBaseBuilder() {
		//assertEquals(3, RAW_PRIMES_ARRAY[1]);
	}
	
	public int[] getRawPrimesArray() {
		return RAW_PRIMES_ARRAY;
	}
	
	/**
	 * Find the index of the first raw prime greater than x, using binary search.
	 * @param x
	 * @return index or -1 if there is no such element
	 */
	public int getIndexOfFirstRawPrimeGreaterThan(int x) {
		if (RAW_PRIMES_ARRAY[RAW_PRIMEBASE_SIZE-1] <= x) return -1; // there is no entry greater than x
		int left = 0;
		int right = RAW_PRIMEBASE_SIZE-1;
		int median;
		do {
			median = (left+right)>>1; // floor
			if (RAW_PRIMES_ARRAY[median] <= x) {
				// the tested element was too small, the result must have a higher index
				left = median + 1;
			} else {
				// the tested element was not too small, it could be right or too big
				right = median;
			}
		} while (left!=right);
		return left;
	}

	/**
	 * Find the index<primeBaseSize of the first entry of primesArray greater than x, using binary search.
	 * @param primesArray the array to search in
	 * @param primeBaseSize the valid number of entries in primesArray
	 * @param x
	 * @return index or -1 if there is no such element
	 */
	public int getIndexOfFirstPrimeGreaterThan(int[] primesArray, int primeBaseSize, int x) {
		if (primesArray[primeBaseSize-1] <= x) return -1; // there is no entry greater than x
		int left = 0;
		int right = primeBaseSize-1;
		int median;
		do {
			median = (left+right)>>1; // floor
			if (primesArray[median] <= x) {
				// the tested element was too small, the result must have a higher index
				left = median + 1;
			} else {
				// the tested element was not too small, it could be right or too big
				right = median;
			}
		} while (left!=right);
		return left;
	}

	/**
	 * Compute a reduced prime base containing the 2 and odd primes p with Jacobi(kN|p)==1.
	 * 
	 * @param kN has to be a quadratic residue modulo all p
	 * @param primeBaseSize the wanted number of primes
	 * @param primesArray is filled with the primes p satisfying Jacobi(kN|p)==1
	 */
	public void computeReducedPrimeBase(BigInteger kN, int primeBaseSize, int[] primesArray) {
		computeReducedPrimeBase(kN, primeBaseSize, primesArray, null, null, 1);
	}

	/**
	 * Compute a reduced prime base containing the 2 and odd primes p with Jacobi(kN|p)==1.
	 * 
	 * @param kN has to be a quadratic residue modulo all p
	 * @param primeBaseSize the wanted number of primes
	 * @param primesArray is filled with the primes p satisfying Jacobi(kN|p)==1
	 * @param primesArray_big if not null then this array is filled with the p in BigInteger
	 */
	public void computeReducedPrimeBase(BigInteger kN, int primeBaseSize, int[] primesArray, BigInteger[] primesArray_big) {
		computeReducedPrimeBase(kN, primeBaseSize, primesArray, primesArray_big, null, 1);
	}

	/**
	 * Compute a reduced prime base containing the 2 and odd primes p with Jacobi(kN|p)==1.
	 * Computes log(p) values to logBase 2 if a non-null logPArray is passed, too.
	 * 
	 * @param kN has to be a quadratic residue modulo all p
	 * @param primeBaseSize the wanted number of primes
	 * @param primesArray is filled with the primes p satisfying Jacobi(kN|p)==1
	 * @param primesArray_big if not null then this array is filled with the p in BigInteger
	 * @param logPArray if not null then this array is filled with approximate log(p) for all p, in the given logBase
	 * @param logBase the base of the wanted logarithm of log(p) values
	 */
	public void computeReducedPrimeBase(BigInteger kN, int primeBaseSize, int[] primesArray, BigInteger[] primesArray_big, byte[] logPArray, float logBase) {
		// conversion factor for ln(p) values
		float ln_logBase = (float) Math.log(logBase);
		// the 2 is always added
		primesArray[0] = 2;
		if (primesArray_big!=null) primesArray_big[0] = TWO;
		if (logPArray!=null) logPArray[0] = (byte) (RAW_LNP_ARRAY[0]/ln_logBase + 0.5);
		// odd primes
		int count = 1;
		for (int i=1; i<RAW_PRIMEBASE_SIZE; i++) {
			int p = RAW_PRIMES_ARRAY[i];
			int jacobi = jacobiEngine.jacobiSymbol(kN, p);
			if (DEBUG) {
				BigInteger p_big = BigInteger.valueOf(p);
				if (jacobi<-1 || jacobi>1) LOG.debug("kN=" + kN + ", p=" + p + " -> legendre=" + jacobi);
				assertTrue(p_big.isProbablePrime(20));
			}
			// Q(x) = A(x)^2 - kN can only be divisible by p with Legendre(kN|p) >= 0.
			// It is important to add p with Legendre(kN|p) == 0, too! Otherwise we would not find such p during trial division.
			// On the other hand, to make a factor test here in that case it makes no sense,
			// because it is typically caused by k, and we will find such factors during trial division anyway.
			if (jacobi>=0) {
				// kN is a quadratic residue mod p (or not coprime)
				primesArray[count] = p;
				// if they are not null, then fill the other arrays, too
				if (primesArray_big!=null) primesArray_big[count] = BigInteger.valueOf(p);
				if (logPArray!=null) logPArray[count] = (byte) (RAW_LNP_ARRAY[i]/ln_logBase + 0.5);
				if (++count == primeBaseSize) break;
			}
		}
		if (count < primeBaseSize) throw new IllegalStateException("the precomputed 'raw prime base' is too small!");
	}
}
