/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * This file is part of the PSIQS package version 01 from 2016-01-07, 
 * developed by Tilman Neumann, Edemissen, Germany.
 * 
 * Use and redistribution of PSIQS are free for non-commercial purposes, as long as this
 * header is not modified or removed. Any commercial usage of the whole or parts
 * of PSIQS requires the written consent of the author.
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

package de.tilman_neumann.math.factor._basics;

import java.math.BigInteger;

import org.apache.log4j.Logger;

/**
 * A reused buffer to store big factors temporarily during trial division.
 * @author Tilman Neumann
 */
public class SortedBigIntegerArray {
	@SuppressWarnings("unused")
	private static final Logger LOG = Logger.getLogger(SortedBigIntegerArray.class);
	
	private BigInteger[] factors;
	private byte[] exponents;
	private int size;
	
	public SortedBigIntegerArray() {
		this.factors = new BigInteger[10];
		this.exponents = new byte[10];
	}
	
	/**
	 * reset() must be called before using for a new Q.
	 */
	public void reset() {
		this.size = 0;
	}
	
	public void add(BigInteger factor) {
		//LOG.debug("add big factor " + factor);
		if (size>0) {
			// find position: for short lists a linear search is ok.
			int insertPosition = 0;
			for (; insertPosition<size; insertPosition++) {
				if (factor.compareTo(factors[insertPosition])<=0) break;
			}
			if (insertPosition<size) {
				if (factor.equals(factors[insertPosition])) {
					// the factor exists already -> just increment exponent
					exponents[insertPosition]++;
					return;
				}
				// the new factor that must be inserted before some other content.
				// -> shift the elements bigger than factor:
				for (int i=size-1; i>=insertPosition; i--) {
					factors[i+1] = factors[i];
					exponents[i+1] = exponents[i];
				}
				// and add the new factor
				factors[insertPosition] = factor;
				exponents[insertPosition] = 1;
				size++;
				return;
			}
			// insertPosition==size -> add as new last element
			factors[size] = factor;
			exponents[size] = 1;
			size++;
			return;
		}
		// size is still 0
		factors[0] = factor;
		exponents[0] = 1;
		size = 1;
	}
	
	public int size() {
		return size;
	}
	
	public BigInteger[] copyFactors() {
		BigInteger[] copy = new BigInteger[size];
		System.arraycopy(factors, 0, copy, 0, size);
		return copy;
	}
	
	public byte[] copyExponents() {
		byte[] copy = new byte[size];
		System.arraycopy(exponents, 0, copy, 0, size);
		return copy;
	}
	
	public String toString() {
		if (size==0) return "(empty)";
		String str = "";
		for (int i=0; i<size; i++) {
			str += factors[i] + "^" + exponents[i] + " * ";
		}
		return str.substring(0, str.length()-3);
	}
}
