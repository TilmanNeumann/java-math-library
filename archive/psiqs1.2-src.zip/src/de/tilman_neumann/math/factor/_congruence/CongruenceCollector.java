/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * This file is part of the PSIQS package version 01 from 2016-01-07, 
 * developed by Tilman Neumann, Edemissen, Germany.
 * 
 * Use and redistribution of PSIQS are free for non-commercial purposes, as long as this
 * header is not modified or removed. Any commercial usage of the whole or parts
 * of PSIQS requires the written consent of the author.
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

package de.tilman_neumann.math.factor._congruence;

import java.math.BigInteger;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import de.tilman_neumann.math.factor.FactorException;
import de.tilman_neumann.math.factor._basics.FactorTest;

/**
 * Base class for congruence collectors.
 * @author Tilman Neumann
 */
abstract public class CongruenceCollector {
	@SuppressWarnings("unused")
	private static final Logger LOG = Logger.getLogger(CongruenceCollector.class);
	
	/** smooth congruences */
	protected ArrayList<SmoothCongruence> smoothCongruences;
	/** factor tester */
	private FactorTest factorTest;

	/**
	 * @return algorithm name
	 */
	abstract public String getName();
	
	/**
	 * Initialize congruence collector for a new N.
	 * @param N
	 */
	public void initialize(BigInteger N, FactorTest factorTest) {
		smoothCongruences = new ArrayList<SmoothCongruence>();
		this.factorTest = factorTest;
	}
	
	/**
	 * Add a new partial or smooth congruence.
	 * @param aqPair
	 * @return true if a smooth congruence was added
	 * @throws FactorException
	 */
	abstract public boolean add(AQPair aqPair) throws FactorException;

	/**
	 * Add smooth congruence.
	 * @param smoothCongruence
	 * @return true if a smooth congruence was added
	 * @throws FactorException
	 */
	protected boolean addSmooth(SmoothCongruence smoothCongruence) throws FactorException {
		if (smoothCongruence.isExactSquare()) {
			// we found a square congruence!
			factorTest.testForFactor(smoothCongruence.getAQPairs());
			// no FactorException -> the square congruence was improper -> drop it
			return false;
		}
		// no square -> add
		smoothCongruences.add(smoothCongruence);
		return true;
	}
	
	/**
	 * @return number of smooth congruences found so far.
	 */
	public int getSmoothCongruenceCount() {
		return smoothCongruences.size();
	}

	public ArrayList<SmoothCongruence> getSmoothCongruences() {
		return smoothCongruences;
	}
	
	abstract public int getPerfectSmoothCount();
	
	abstract public int getSmoothFromPartialCount();
	
	abstract public int getPartialCongruenceCount();
	
	public String getReportString() {
		return "found " + smoothCongruences.size() + " smooth congruences (" + getPerfectSmoothCount() + " perfect, " + getSmoothFromPartialCount() + " from partials) and " + getPartialCongruenceCount() + " partials";
	}
	
	/**
	 * Release memory after a factorization.
	 */
	public void cleanUp() {
		smoothCongruences = null;
		factorTest = null;
	}
}