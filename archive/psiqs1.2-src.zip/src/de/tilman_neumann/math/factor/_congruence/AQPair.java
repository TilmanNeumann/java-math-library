/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * This file is part of the PSIQS package version 01 from 2016-01-07, 
 * developed by Tilman Neumann, Edemissen, Germany.
 * 
 * Use and redistribution of PSIQS are free for non-commercial purposes, as long as this
 * header is not modified or removed. Any commercial usage of the whole or parts
 * of PSIQS requires the written consent of the author.
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

package de.tilman_neumann.math.factor._congruence;

import java.math.BigInteger;
import java.util.Set;

import de.tilman_neumann.types.SortedMultiset;

/**
 * Interface for elementary congruences A^2 == Q (mod kN).
 * @author Tilman Neumann
 */
public interface AQPair {

	public abstract BigInteger getA();

	public abstract BigInteger getQ();

	/**
	 * @return all Q-factors with exponents.
	 * This method usually only called for the null vectors tested in the smooth solver;
	 * but then it is needed for a whole bunch of AQPairs.
	 */
	public abstract SortedMultiset<BigInteger> getQFactors();

	/**
	 * @return a copy of the set of small factors contained in Q with odd exponent.
	 * This method is called about twice on average for each smooth congruence.
	 */
	public abstract Set<Integer> getOddExpSmallFactors();

	/**
	 * @return a copy of the set of big factors contained in Q with odd exponent.
	 * This method is called once for each AQPair.
	 */
	public abstract Set<BigInteger> getOddExpBigFactors();

	public abstract int hashCode();

	public abstract boolean equals(Object obj);

	public abstract String toString();
}