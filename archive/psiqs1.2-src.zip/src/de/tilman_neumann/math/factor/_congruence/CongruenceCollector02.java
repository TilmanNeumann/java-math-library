/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * This file is part of the PSIQS package version 01 from 2016-01-07, 
 * developed by Tilman Neumann, Edemissen, Germany.
 * 
 * Use and redistribution of PSIQS are free for non-commercial purposes, as long as this
 * header is not modified or removed. Any commercial usage of the whole or parts
 * of PSIQS requires the written consent of the author.
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

package de.tilman_neumann.math.factor._congruence;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

import org.apache.log4j.Logger;

import de.tilman_neumann.math.factor.FactorException;
import de.tilman_neumann.math.factor._basics.FactorTest;
import de.tilman_neumann.math.factor._matrixSolver.MatrixSolver01;
import de.tilman_neumann.math.factor._matrixSolver.PartialSolverWrapper;

/**
 * Collects smooth and partial congruences, and assembles partials to smooth congruences on-the-fly.
 * 
 * Version 02: Partials may have any number of big factors.
 * 
 * @author Tilman Neumann
 */
public class CongruenceCollector02 extends CongruenceCollector {
	private static final Logger LOG = Logger.getLogger(CongruenceCollector02.class);
	private static final boolean DEBUG = false;

	/** 
	 * A map from big factors with odd exp to partial congruences.
	 * Here we need a 1:n relation because one partial can have several big factors;
	 * thus one big factor may be contained in many distinct partials.
	 */
	private HashMap<BigInteger, ArrayList<PartialCongruence>> oddExpBigFactors_2_partialCongruences; // here HashMap is faster than TreeMap or LinkedHashMap
	/** A wrapper for the solver used to create smooth congruences from partials */
	private PartialSolverWrapper partialSolverWrapper;

	// statistics
	private int perfectSmoothCount, smoothFromPartialCount;

	/**
	 * Unique constructor.
	 */
	public CongruenceCollector02() {
		this.partialSolverWrapper = new PartialSolverWrapper(new MatrixSolver01<BigInteger>(2));
	}

	@Override
	public String getName() {
		return "cc02";
	}

	@Override
	public void initialize(BigInteger N, FactorTest factorTest) {
		super.initialize(N, factorTest);
		oddExpBigFactors_2_partialCongruences = new HashMap<BigInteger, ArrayList<PartialCongruence>>();
		partialSolverWrapper.initialize(N, factorTest);
		this.perfectSmoothCount = 0;
		this.smoothFromPartialCount = 0;
	}

	@Override
	public boolean add(AQPair aqPair) throws FactorException {
		if (DEBUG) LOG.debug("partial aqPair = " + aqPair);
		Set<BigInteger> oddExpBigFactors = aqPair.getOddExpBigFactors();
		int oddExpBigFactorsCount = oddExpBigFactors.size();
		if (oddExpBigFactorsCount==0) {
			// no big factors with odd exponent -> we found a perfectly smooth congruence A_i^2 == Q_i+1 (mod N)
			SmoothCongruence smoothCongruence = new SmoothCongruence(aqPair);
			boolean added = this.addSmooth(smoothCongruence);
			if (added) {
				if (DEBUG) LOG.debug("Found new smooth congruence " + smoothCongruence + " --> #smooth = " + smoothCongruences.size() + ", #partials = " + getPartialCongruenceCount());
				perfectSmoothCount++;
				return true;
			}
			return false; // not added
		}
		
		// otherwise we have a new partial congruence
		PartialCongruence newPartial = new PartialCongruence(oddExpBigFactors, aqPair);
		// check if we can assemble a smooth congruence with the new partial.
		// first collect all partials that are somehow related to the new partial via big factors:
		HashSet<PartialCongruence> relatedPartials = findRelatedPartials(oddExpBigFactors); // oddExpBigFactors is not modified in the method
		if (DEBUG) LOG.debug("#relatedPartials = " + relatedPartials.size());
		if (relatedPartials.size()>0) {
			// We found some "old" partials that share at least one big factor with the new partial.
			// Since relatedPartials is a set, we can not get duplicate AQ-pairs.
			relatedPartials.add(newPartial);
			// Solve partial congruence equation system
			ArrayList<SmoothCongruence> foundSmooths = partialSolverWrapper.solve(relatedPartials); // throws FactorException
			if (foundSmooths.size()>0) {
				// We found one or more smooths from the new partial
				int addedCount = 0;
				for (SmoothCongruence foundSmooth : foundSmooths) {
					if (addSmooth(foundSmooth)) addedCount++; // increment counter if foundSmooth was really added
				}
				if (addedCount>0) {
					if (DEBUG) {
						if (oddExpBigFactorsCount>1) {
							// for big N we can find smooths from 2-partials
							LOG.debug("Found " + addedCount + " smooth congruences from " + oddExpBigFactorsCount + "-partial! --> #smooth = " + smoothCongruences.size() + ", #partials = " + getPartialCongruenceCount());
						} else {
							LOG.info("Found " + addedCount + " smooths from new partial! --> #smooth = " + smoothCongruences.size() + ", #partials = " + getPartialCongruenceCount());
						}
					}
					smoothFromPartialCount += addedCount;
					return true;
				}
				return false;
				// Not adding the new partial is sufficient to keep the old partials linear independent,
				// which is required to avoid duplicate solutions.
			}
		}
		
		// we were not able to construct a smooth congruence with the new partial, so just keep the partial:
		if (DEBUG) LOG.debug("add new partial to collection");
		addPartial(newPartial);
		if (DEBUG) LOG.debug("Found new partial relation " + aqPair + " --> #smooth = " + smoothCongruences.size() + ", #partials = " + getPartialCongruenceCount());
		return false; // no smooth added
	}
	
	/**
	 * Find "old" partials related to a new partial.
	 * The oddExpBigFactors remain unaltered!
	 * 
	 * @param oddExpBigFactors the big factors with odd exponent of the new partial
	 * @return set of related partial congruences
	 */
	private HashSet<PartialCongruence> findRelatedPartials(Set<BigInteger> oddExpBigFactors) {
		HashSet<BigInteger> bigFactorsAlreadyUsed = new HashSet<BigInteger>();
		HashSet<PartialCongruence> relatedPartials = new HashSet<PartialCongruence>(); // we need a set to avoid adding the same partial more than once
		while (oddExpBigFactors.size()>0) {
			if (DEBUG) LOG.debug("oddExpBigFactors = " + oddExpBigFactors);
			Set<BigInteger> nextFactors = new HashSet<BigInteger>();
			for (BigInteger oddExpBigFactor : oddExpBigFactors) {
				bigFactorsAlreadyUsed.add(oddExpBigFactor);
				ArrayList<PartialCongruence> partialList = oddExpBigFactors_2_partialCongruences.get(oddExpBigFactor);
				if (partialList!=null && partialList.size()>0) {
					for (PartialCongruence relatedPartial : partialList) {
						relatedPartials.add(relatedPartial);
						for (BigInteger nextFactor : relatedPartial.getOddExpFactors()) {
							if (!bigFactorsAlreadyUsed.contains(nextFactor)) nextFactors.add(nextFactor);
						}
					}
				}
			}
			oddExpBigFactors = nextFactors;
		}
		return relatedPartials;
	}
	
	private void addPartial(PartialCongruence newPartial) {
		for (BigInteger oddExpBigFactor : newPartial.getOddExpFactors()) {
			ArrayList<PartialCongruence> partialCongruenceList = oddExpBigFactors_2_partialCongruences.get(oddExpBigFactor);
			if (partialCongruenceList==null) partialCongruenceList = new ArrayList<PartialCongruence>();
			partialCongruenceList.add(newPartial);
			oddExpBigFactors_2_partialCongruences.put(oddExpBigFactor, partialCongruenceList);
		}
	}
	
	@SuppressWarnings("unused")
	private void dropPartial(PartialCongruence partial) {
		for (BigInteger oddExpBigFactor : partial.getOddExpFactors()) {
			ArrayList<PartialCongruence> partialCongruenceList = oddExpBigFactors_2_partialCongruences.get(oddExpBigFactor);
			partialCongruenceList.remove(partial);
			if (partialCongruenceList.size()==0) {
				// partialCongruenceList is empty now -> drop the whole entry
				oddExpBigFactors_2_partialCongruences.remove(oddExpBigFactor);
			}
		}
	}

	@Override
	public int getPerfectSmoothCount() {
		return perfectSmoothCount;
	}

	@Override
	public int getSmoothFromPartialCount() {
		return smoothFromPartialCount;
	}

	@Override
	public int getPartialCongruenceCount() {
		return oddExpBigFactors_2_partialCongruences.size();
	}
	
	@Override
	public void cleanUp() {
		super.cleanUp();
		partialSolverWrapper.cleanUp();
		oddExpBigFactors_2_partialCongruences = null;
	}
}
