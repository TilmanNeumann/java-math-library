/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * This file is part of the PSIQS package version 01 from 2016-01-07, 
 * developed by Tilman Neumann, Edemissen, Germany.
 * 
 * Use and redistribution of PSIQS are free for non-commercial purposes, as long as this
 * header is not modified or removed. Any commercial usage of the whole or parts
 * of PSIQS requires the written consent of the author.
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

package de.tilman_neumann.math.factor._congruence;

import java.math.BigInteger;
import java.util.HashSet;
import java.util.Set;

import org.apache.log4j.Logger;

import de.tilman_neumann.math.factor._basics.SortedBigIntegerArray;
import de.tilman_neumann.math.factor._basics.SortedIntegerArray;
import de.tilman_neumann.types.SortedMultiset;
import de.tilman_neumann.types.SortedMultiset_TreeMapImpl;

/**
 * An <em>elementary</em> smooth or partially smooth congruence A^2 == Q (mod kN).
 * Elementary means that only one (A,Q) pair is involved.
 * 
 * This data structure should be as lean as possible, because for big N we may collect millions of partials.
 * Use the JVM argument -XX:+PrintGC to analyze the garbage collection load.
 * 
 * We could drop the full prime factorizations if we use a direct computation of sqrt(Q-product) in class FactorTest;
 * but since the Q-products can be very big, the direct computation of the sqrt is expensive. The current solution performs better.
 * 
 * oddExpBigFactors are required once for each AQPair, and oddExpSmallFactors only once or twice for each smooth congruence;
 * therefore it is legitimate and faster to compute them just in time when they are requested, and save some memory by the way.
 * 
 * @author Tilman Neumann
 */
public class AQPair01 implements AQPair {
	@SuppressWarnings("unused")
	private static final Logger LOG = Logger.getLogger(AQPair01.class);
	
	private BigInteger A;
	private BigInteger Q;
	
	// factors of Q (not necessarily complete prime factorization)
	/** small factors of Q that were found */
	private int[] smallFactors;
	private short[] smallFactorExponents;
	private BigInteger[] bigFactors;
	private byte[] bigFactorExponents;
	
	/** AQ-pairs never change -> compute hashCode only once */
	private int hashCode;
	
	/**
	 * Partial constructor; the Q-factors still need to be set later.
	 * @param A
	 * @param Q
	 */
	public AQPair01(BigInteger A, BigInteger Q) {
		this.A = A;
		this.Q = Q;
		// precompute hashCode
		this.hashCode = 31 * (31 + A.hashCode()) + Q.hashCode();
	}
	
	/**
	 * Full constructor.
	 * @param A
	 * @param Q
	 * @param smallFactors
	 * @param bigFactors
	 */
	public AQPair01(BigInteger A, BigInteger Q, SortedIntegerArray smallFactors, SortedBigIntegerArray bigFactors) {
		this(A, Q);
		setQFactors(smallFactors, bigFactors);
	}

	@Override
	public BigInteger getA() {
		return A;
	}

	@Override
	public BigInteger getQ() {
		return Q;
	}

	/**
	 * Set factors of Q.
	 * @param smallFactors
	 * @param smallFactorCount
	 * @param bigFactors
	 * @param bigFactorCount
	 */
	public void setQFactors(SortedIntegerArray smallFactors, SortedBigIntegerArray bigFactors) {
		// copy small factors
		this.smallFactors = smallFactors.copyFactors();
		this.smallFactorExponents = smallFactors.copyExponents();
		// same with big factors
		this.bigFactors = bigFactors.copyFactors();
		this.bigFactorExponents = bigFactors.copyExponents();
	}

	@Override
	// TODO use BigFactorsBuffer !
	public SortedMultiset<BigInteger> getQFactors() {
		SortedMultiset<BigInteger> allFactors = new SortedMultiset_TreeMapImpl<BigInteger>();
		for (int i=0; i<smallFactors.length; i++) {
			allFactors.add(BigInteger.valueOf(smallFactors[i]), smallFactorExponents[i]);
		}
		for (int i=0; i<bigFactors.length; i++) {
			allFactors.add(bigFactors[i], bigFactorExponents[i]);
		}
		return allFactors;
	}

	@Override
	public Set<Integer> getOddExpSmallFactors() {
		Set<Integer> result = new HashSet<Integer>();
		for (int i=0; i<smallFactors.length; i++) {
			if ((smallFactorExponents[i]&1)==1) result.add(smallFactors[i]);
		}
		return result;
	}
	
	@Override
	public Set<BigInteger> getOddExpBigFactors() {
		Set<BigInteger> result = new HashSet<BigInteger>();
		for (int i=0; i<bigFactors.length; i++) {
			if ((bigFactorExponents[i]&1)==1) result.add(bigFactors[i]);
		}
		return result;
	}

	/**
	 * hashCode() and equals() must be based on A and Q to avoid duplicates.
	 */
	@Override
	public int hashCode() {
		//LOG.debug("hashCode()");
		return hashCode;
	}

	/**
	 * hashCode() and equals() must be based on A and Q to avoid duplicates.
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		// equal objects must have the same hashCode
		if (obj == null || this.hashCode!=obj.hashCode()) return false;
		if (getClass() != obj.getClass()) return false;
		AQPair other = (AQPair) obj;
		return this.A.equals(other.getA()) && this.Q.equals(other.getQ());
	}

	@Override
	public String toString() {
		String str = "A=" + A + ", Q=" + Q + " = ";
		if (smallFactors.length>0) {
			for (int i=0; i<smallFactors.length; i++) {
				str += smallFactors[i];
				int exp = smallFactorExponents[i];
				if (exp>1) str += "^" + exp;
				str += " * ";
			}
		}
		if (bigFactors.length>0) {
			for (int i=0; i<bigFactors.length; i++) {
				str += bigFactors[i];
				int exp = bigFactorExponents[i];
				if (exp>1) str += "^" + exp;
				str += " * ";
			}
		}
		if (smallFactors.length>0 || bigFactors.length>0) str = str.substring(0, str.length()-3); // remove last " * "
		return str;
	}
	
//	@Override
//	protected void finalize() {
//		LOG.debug("release " + this);
//	}
}
