/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * This file is part of the PSIQS package version 01 from 2016-01-07, 
 * developed by Tilman Neumann, Edemissen, Germany.
 * 
 * Use and redistribution of PSIQS are free for non-commercial purposes, as long as this
 * header is not modified or removed. Any commercial usage of the whole or parts
 * of PSIQS requires the written consent of the author.
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

package de.tilman_neumann.math.factor._congruence;

import java.util.HashSet;
import java.util.Set;

import org.apache.log4j.Logger;

/**
 * A smooth congruence.
 * @author Tilman Neumann
 */
public class SmoothCongruence implements Congruence<Integer> {
	@SuppressWarnings("unused")
	private static final Logger LOG = Logger.getLogger(SmoothCongruence.class);

	private Set<Integer> oddExpElements;
	private Set<AQPair> aqPairs;
	/** congruences never change; therefore we must compute the hashCode only once. */
	private int hashCode;

	/**
	 * Constructor from a single AQ-pair.
	 * @param aqPair
	 */
	public SmoothCongruence(AQPair aqPair) {
		this.oddExpElements = aqPair.getOddExpSmallFactors();
		this.aqPairs = new HashSet<AQPair>(1);
		aqPairs.add(aqPair);
		this.hashCode = aqPair.hashCode();
	}

	/**
	 * Constructor from several AQ-pairs.
	 * @param aqPairs
	 */
	public SmoothCongruence(Set<AQPair> aqPairs) {
		this.oddExpElements = new HashSet<Integer>();
		for (AQPair aqPair : aqPairs) {
			Set<Integer> oddExpSmallFactors = aqPair.getOddExpSmallFactors();
			// add via xor
			for (Integer oddExpSmallFactor : oddExpSmallFactors) {
				if (!oddExpElements.remove(oddExpSmallFactor)) oddExpElements.add(oddExpSmallFactor);
			}
		}
		this.aqPairs = aqPairs;
		this.hashCode = aqPairs.hashCode();
	}
	
	@Override
	public Set<Integer> getOddExpFactors() {
		return oddExpElements;
	}

	public Set<AQPair> getAQPairs() {
		return aqPairs;
	}

	public boolean isExactSquare() {
		return oddExpElements.size()==0;
	}

	@Override
	public int hashCode() {
		return hashCode;
	}
	
	@Override
	public boolean equals(Object o) {
		// equal objects must have the same hashCode
		if (o==null || this.hashCode!=o.hashCode()) return false;
		if (!(o instanceof SmoothCongruence)) return false;
		SmoothCongruence other = (SmoothCongruence) o;
		return this.aqPairs.equals(other.aqPairs);
	}

	@Override
	public String toString() {
		String str = "[oddExpFactors = " + oddExpElements + ", aqPairs = ";
		for (AQPair aqPair : aqPairs) {
			str += aqPair.toString() + ", ";
		}
		return str.substring(0, str.length()-2) + "]";
	}
	
//	@Override
//	protected void finalize() {
//		LOG.debug("release " + this);
//	}
}
