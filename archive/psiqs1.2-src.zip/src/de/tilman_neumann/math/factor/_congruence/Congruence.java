/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * This file is part of the PSIQS package version 01 from 2016-01-07, 
 * developed by Tilman Neumann, Edemissen, Germany.
 * 
 * Use and redistribution of PSIQS are free for non-commercial purposes, as long as this
 * header is not modified or removed. Any commercial usage of the whole or parts
 * of PSIQS requires the written consent of the author.
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

package de.tilman_neumann.math.factor._congruence;

import java.util.Set;

/**
 * A congruence from 1 or more AQ-pairs, where the prime factors of Q
 * with odd exponent have already been filtered out.
 * 
 * @author Tilman Neumann
 * 
 * @param ME_T class of LinAlg-matrix elements
 */
public interface Congruence<ME_T extends Comparable<ME_T>> {
	
	/**
	 * @return set of factors of type ME_T that this congruence has with odd exponent.
	 */
	Set<ME_T> getOddExpFactors();

	/**
	 * @return AQ-pairs
	 */
	Set<AQPair> getAQPairs();
}
