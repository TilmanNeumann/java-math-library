/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * This file is part of the PSIQS package version 01 from 2016-01-07, 
 * developed by Tilman Neumann, Edemissen, Germany.
 * 
 * Use and redistribution of PSIQS are free for non-commercial purposes, as long as this
 * header is not modified or removed. Any commercial usage of the whole or parts
 * of PSIQS requires the written consent of the author.
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

package de.tilman_neumann.math.factor._congruence;

import java.math.BigInteger;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

import org.apache.log4j.Logger;

import de.tilman_neumann.math.factor.FactorException;
import de.tilman_neumann.math.factor._basics.FactorTest;

/**
 * Collects smooth and partial congruences, and assembles partials to smooth congruences on-the-fly.
 * 
 * Version 01: Uses only AQ-pairs with 0 or 1 big factor. This works fine with AuxFactorizerLWA.
 * 
 * @author Tilman Neumann
 */
public class CongruenceCollector01 extends CongruenceCollector {
	private static final Logger LOG = Logger.getLogger(CongruenceCollector01.class);
	private static final boolean DEBUG = false;
	
	/** 
	 * A map from big factors with odd exp to AQ-pairs of partial congruences.
	 * We only need a 1:1 correspondence, because when a second AQ-pair with the same big factor is found,
	 * then the two partials together are converted into a smooth congruence; the second partial is not stored here.
	 */
	private HashMap<BigInteger, AQPair> oddExpBigFactors_2_partialAQPairs; // here HashMap is faster than TreeMap or LinkedHashMap

	// statistics
	private int perfectSmoothCount, smoothFromPartialCount;
	
	@Override
	public String getName() {
		return "cc01";
	}
	
	@Override
	public void initialize(BigInteger N, FactorTest factorTest) {
		super.initialize(N, factorTest);
		oddExpBigFactors_2_partialAQPairs = new HashMap<BigInteger, AQPair>();
		this.perfectSmoothCount = 0;
		this.smoothFromPartialCount = 0;
	}

	@Override
	public boolean add(AQPair aqPair) throws FactorException {
		if (DEBUG) LOG.debug("new partial aqPair = " + aqPair);
		Set<BigInteger> oddExpBigFactors = aqPair.getOddExpBigFactors();
		int oddExpBigFactorCount = oddExpBigFactors.size();
		if (oddExpBigFactorCount==0) {
			// no big factors with odd exponent -> we found a perfectly smooth congruence A_i^2 == Q_i+1 (mod N)
			SmoothCongruence smoothCongruence = new SmoothCongruence(aqPair);
			boolean added = this.addSmooth(smoothCongruence);
			if (added) {
				if (DEBUG) LOG.debug("Found new smooth congruence " + smoothCongruence + " --> #smooth = " + smoothCongruences.size() + ", #partials = " + oddExpBigFactors_2_partialAQPairs.size());
				perfectSmoothCount++;
				return true;
			}
			return false;
		}
		
		if (oddExpBigFactorCount>1) {
			// this version can only handle congruences with 1 big prime -> drop that AQ-pair
			return false;
		}
		
		// otherwise we have a new partial congruence with 1 big factor.
		BigInteger oddExpBigFactor = oddExpBigFactors.iterator().next();
		AQPair otherAQPair = oddExpBigFactors_2_partialAQPairs.get(oddExpBigFactor);
		if (otherAQPair!=null && !aqPair.equals(otherAQPair)) {
			// we have two partials with the same big factor, and they are not exactly the same.
			// -> we found a smooth congruence from partials!
			Set<AQPair> aqPairs = new HashSet<AQPair>(3);
			aqPairs.add(aqPair);
			aqPairs.add(otherAQPair);
			// Construct smooth congruence from set of partials:
			// Note that the "old" involved partials should not be removed !!
			// The smooth congruence was only achieved with the new partial,
			// not adding it is sufficient to avoid redundant solutions in the future.
			SmoothCongruence smoothCongruence = new SmoothCongruence(aqPairs);
			boolean added = this.addSmooth(smoothCongruence);
			if (added) {
				if (DEBUG) LOG.debug("Found new smooth congruence from partial " + smoothCongruence + " --> #smooth = " + smoothCongruences.size() + ", #partials = " + oddExpBigFactors_2_partialAQPairs.size());
				smoothFromPartialCount++;
				return true;
			}
			return false;
		}
		
		// we were not able to construct a smooth congruence with the new partial, so just add it:
		if (DEBUG) LOG.debug("add new partial to collection");
		oddExpBigFactors_2_partialAQPairs.put(oddExpBigFactor, aqPair);
		if (DEBUG) LOG.debug("Found new partial relation " + aqPair + " --> #smooth = " + smoothCongruences.size() + ", #partials = " + oddExpBigFactors_2_partialAQPairs.size());
		return false; // no smooth added
	}

	@Override
	public int getPerfectSmoothCount() {
		return perfectSmoothCount;
	}

	@Override
	public int getSmoothFromPartialCount() {
		return smoothFromPartialCount;
	}

	@Override
	public int getPartialCongruenceCount() {
		return oddExpBigFactors_2_partialAQPairs.size();
	}
	
	@Override
	public void cleanUp() {
		super.cleanUp();
		oddExpBigFactors_2_partialAQPairs = null;
	}
}
