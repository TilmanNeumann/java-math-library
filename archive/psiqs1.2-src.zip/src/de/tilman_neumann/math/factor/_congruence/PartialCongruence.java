/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * This file is part of the PSIQS package version 01 from 2016-01-07, 
 * developed by Tilman Neumann, Edemissen, Germany.
 * 
 * Use and redistribution of PSIQS are free for non-commercial purposes, as long as this
 * header is not modified or removed. Any commercial usage of the whole or parts
 * of PSIQS requires the written consent of the author.
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

package de.tilman_neumann.math.factor._congruence;

import java.math.BigInteger;
import java.util.HashSet;
import java.util.Set;

import org.apache.log4j.Logger;

/**
 * A partial congruence.
 * @author Tilman Neumann
 */
public class PartialCongruence implements Congruence<BigInteger> {
	@SuppressWarnings("unused")
	private static final Logger LOG = Logger.getLogger(PartialCongruence.class);

	private Set<BigInteger> oddExpElements;
	private AQPair aqPair;
	/** congruences never change; therefore we must compute the hashCode only once. */
	private int hashCode;
	
	public PartialCongruence(Set<BigInteger> oddExpElements, AQPair aqPair) {
		this.oddExpElements = oddExpElements;
		this.aqPair = aqPair;
		this.hashCode = aqPair.hashCode();
	}
	
	@Override
	public Set<BigInteger> getOddExpFactors() {
		return oddExpElements;
	}
	
	public Set<AQPair> getAQPairs() {
		Set<AQPair> aqPairSet = new HashSet<AQPair>(1);
		aqPairSet.add(aqPair);
		return aqPairSet;
	}

	@Override
	public int hashCode() {
		return hashCode;
	}
	
	@Override
	public boolean equals(Object o) {
		// equal objects must have the same hashCode
		if (o==null || this.hashCode!=o.hashCode()) return false;
		if (!(o instanceof PartialCongruence)) return false;
		PartialCongruence other = (PartialCongruence) o;
		return this.aqPair.equals(other.aqPair);
	}

	@Override
	public String toString() {
		return "[oddExpFactors = " + oddExpElements + ", aqPair = " + aqPair.toString() + "]";
	}
	
//	@Override
//	protected void finalize() {
//		LOG.debug("release " + this);
//	}
}
