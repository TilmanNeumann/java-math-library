/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * This file is part of the PSIQS package version 01.02 from 2016-01-17, 
 * developed by Tilman Neumann, Edemissen, Germany.
 * 
 * Use and redistribution of PSIQS are free for non-commercial purposes, as long as this
 * header is not modified or removed. Any commercial usage of the whole or parts
 * of PSIQS requires the written consent of the author.
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

package de.tilman_neumann.math.factor;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

import org.apache.log4j.Logger;

import de.tilman_neumann.math.factor._congruence.*;
import de.tilman_neumann.math.factor._matrixSolver.*;
import de.tilman_neumann.math.factor.cfrac.*;
import de.tilman_neumann.math.factor.cfrac.tdiv.*;
import de.tilman_neumann.math.factor.pollardRho.*;
import de.tilman_neumann.math.factor.psiqs.*;
import de.tilman_neumann.math.factor.qs.*;
import de.tilman_neumann.math.factor.qs.tdiv.*;
import de.tilman_neumann.math.factor.qs.sieve.*;
import de.tilman_neumann.math.factor.squfof.*;
import de.tilman_neumann.math.factor.tdiv.*;
import de.tilman_neumann.math.factor.psiqs.PSIQS;
import de.tilman_neumann.math.base.bigint.sequence.*;
import de.tilman_neumann.util.ConfigUtil;
import de.tilman_neumann.util.TimeUtil;

import static de.tilman_neumann.math.base.bigint.BigIntConstants.*;

/**
 * Main class to compare the performance of factor algorithms.
 * @author Tilman Neumann
 */
public class FactorizerTest {
	private static final Logger LOG = Logger.getLogger(FactorizerTest.class);

	// algorithm options
	private static final int PRIME_TEST_BITS = 20;
	/** number of test numbers */
	private static final int N_COUNT = 10000;
	/** the bit size of N to start with */
	private static final int START_BITS = 30;
	/** the increment in bit size from test set to test set */
	private static final int INCR_BITS = 5;
	/** maximum number of bits to test (no maximum if null) */
	private static final Integer MAX_BITS = 80;
	/** each algorithm is run REPEATS times for each input in order to reduce GC influence on timings */
	private static final int REPEATS = 1;

	/** algorithms to compare */
	private static final SingleFactorFinder[] ALGORITHMS = new SingleFactorFinder[] {
		// Trial division:
		// * TDiv31Preload is the best algorithm overall for N <= 2^27
		// * TDiv_PPGen2 is the best BigInteger version
//		new TDiv_PPGen2(PRIME_TEST_BITS),
//		new TDiv63(PRIME_TEST_BITS),
//		new TDiv31(PRIME_TEST_BITS),
//		new TDiv31Preload(PRIME_TEST_BITS),

		// PollardRho:
		// * never the best algorithm
		// * Best BigInteger version is PollardRho02
//		new PollardRho02(PRIME_TEST_BITS),

		// SquFoF variants
		// * SquFoF31 is the best algorithm overall for N = 2^28...2^42, SquFoF63 for N = 2^43...2^68
		// * SquFoF01_maxI is the best BigInteger version
		// * best multiplier sequence = 1680 * {squarefree sequence}
		// * best stopping criterion = O(5.th root(N))
//		new SquFoF01_maxI(PRIME_TEST_BITS, new SquarefreeSequence(1), 4, 5.65685425F), // standard configuration, with stopping criterion from [Gower/Wagstaff]
//		new SquFoF01_maxI(PRIME_TEST_BITS, new SquarefreeSequence(1680), 4, 5.65685425F), // better multiplier
//		new SquFoF01_maxI(PRIME_TEST_BITS, new SquarefreeSequence(1), 5, 1), // better stopping criterion
//		new SquFoF01_maxI(PRIME_TEST_BITS, new SquarefreeSequence(1680), 5, 1), // best configuration
//		new SquFoF03_maxI(PRIME_TEST_BITS, new SquarefreeSequence(1680), 5, 1), // with queue
//		new SquFoF(PRIME_TEST_BITS),
//		new SquFoF63_02(PRIME_TEST_BITS, 1, 4, 5.65685425F),
		new SquFoF63_02(PRIME_TEST_BITS, 1680, 4, 5.65685425F),
//		new SquFoF63_02(PRIME_TEST_BITS, 1, 5, 1.5F),
		new SquFoF63_02(PRIME_TEST_BITS, 1680, 5, 1.5F),
		new SquFoF63_02(PRIME_TEST_BITS, ExplicitMultipliers.GW, 4, 5.65685425F),
		new SquFoF63_02(PRIME_TEST_BITS, ExplicitMultipliers.EVEN_AND_GW, 4, 5.65685425F),
		new SquFoF63_02(PRIME_TEST_BITS, ExplicitMultipliers.GW, 5, 1.5F),
		new SquFoF63_02(PRIME_TEST_BITS, ExplicitMultipliers.EVEN_AND_GW, 5, 1.5F),
//		new SquFoF63(PRIME_TEST_BITS), // best algorithm for N = 2^43...2^68 (freezes at some N > 2^90)
//		new SquFoF31(PRIME_TEST_BITS), // best algorithm for N = 2^28...2^42 (freezes at bigger arguments)

		// CFrac
		// * never the best algorithm: SquFoF63 is better for N <= 70 bit, SIQS is better for N >= 65 bits
		// * the best multiplier is 1 here
		// * stopRoot, stopMult: if big enough, then a second k is rarely needed; (5, 1.5) is good
		// * TDiv_CF01, cc01 is best for N < 80 bits
//		/* very small N */ new CFrac(PRIME_TEST_BITS, new SquarefreeSequence(1), true, 5, 2, 0.294F, 0.215F, new TDiv_CF01(PRIME_TEST_BITS), new CongruenceCollector01(), 10, new MatrixSolver01<Integer>(2)),
//		/* small N */ new CFrac(PRIME_TEST_BITS, new SquarefreeSequence(1), true, 5, 1.5F, 0.294F, 0.215F, new TDiv_CF01(PRIME_TEST_BITS), new CongruenceCollector01(), 10, new MatrixSolver01<Integer>(2)),
//		/* big N */ new CFrac(PRIME_TEST_BITS, new SquarefreeSequence(1), true, 5, 1.5F, 0.255F, 0.253F, new TDiv_CF03(PRIME_TEST_BITS, 28), new CongruenceCollector02(), 10, new MatrixSolver01<Integer>(2)),
//		new CFrac63(PRIME_TEST_BITS, new SquarefreeSequence(1), true, 5, 1.5F, 0.275F, 0.22F, new TDiv_CF63_01(PRIME_TEST_BITS), new CongruenceCollector01(), 10, new MatrixSolver01<Integer>(2)),
//		new CFrac63(PRIME_TEST_BITS, new SquarefreeSequence(1), true, 5, 1.5F, 0.25F, 0.25F, new TDiv_CF63_03(PRIME_TEST_BITS, 28), new CongruenceCollector02(), 10, new MatrixSolver01<Integer>(2)),

		// Basic QS:
//		new QS(PRIME_TEST_BITS, 0.35F, 0.84F, new BasicQSPolyBuilder01(new SquarefreeSequence(1)), new Sieve04b(1, 0.17F, 1.4427F, 1), new TDiv_QS02(PRIME_TEST_BITS, 0.18F), new CongruenceCollector01(), 10, new MatrixSolver01<Integer>(2)),
//		new QS(PRIME_TEST_BITS, 0.355F, 0.84F, new BasicQSPolyBuilder01(new SquarefreeSequence(1)), new Sieve04b(1, 0.17F, 1.4427F, 1), new TDiv_QS03(PRIME_TEST_BITS, 0.18F), new CongruenceCollector02(), 10, new MatrixSolver01<Integer>(2)),

		// MPQS:
//		new QS(PRIME_TEST_BITS, 0.325F, 0.54F, new MPQSPolyBuilder01(3), new Sieve04b(1, 0.17F, 1.4427F, 1), new TDiv_QS02(PRIME_TEST_BITS, 0.18F), new CongruenceCollector01(), 10, new MatrixSolver01<Integer>(2)),
//		new QS(PRIME_TEST_BITS, 0.325F, 0.54F, new MPQSPolyBuilder01(3), new Sieve04b(1, 0.17F, 1.4427F, 1), new TDiv_QS03(PRIME_TEST_BITS, 0.18F), new CongruenceCollector02(), 10, new MatrixSolver01<Integer>(2)),

		// SIQS:
		// TDiv_QS02 is better than TDiv_QS01, TDiv_QS03+CC02 is better than TDiv_QS02+CC01 for N >= 200 bit
		// Sieve 04b is marginally better than 04
		// sieve.T > 0.18 gives a heavy work load for TDiv
		// sieve.initializerStyle=1 is best
//		new QS(PRIME_TEST_BITS, 0.32F, 0.42F, new SIQSPolyBuilder01(3, new AParamGenerator01(), 2), new Sieve04b(1, 0.16F, 1.4427F, 1), new TDiv_QS02(PRIME_TEST_BITS, 0.18F), new CongruenceCollector01(), 10, new MatrixSolver01<Integer>(2)),
//		new QS(PRIME_TEST_BITS, 0.32F, 0.42F, new SIQSPolyBuilder01(3, new AParamGenerator01(), 2), new Sieve04b(1, 0.16F, 1.4427F, 1), new TDiv_QS03(PRIME_TEST_BITS, 0.18F), new CongruenceCollector02(), 10, new MatrixSolver01<Integer>(2)),

		// Multi-threaded SIQS:
		// * faster than single-threaded SIQS for N >= 97 bits
		// * may need a lot of memory with big numberOfThreads
		// * the bigger maxRestExp_sieve and maxRestExp_tdiv are, the more partials are collected.
		//   this is good as long as enough memory is available.
//		new PSIQS(PRIME_TEST_BITS, 0.315F, 0.39F, null, 0.17F, 1.4427F, 0.185F, 4),

		// Combination of best algorithms for all factor argument sizes
//		new CombinedFactorAlgorithm(PRIME_TEST_BITS, 4),
	};
	
	private static void testRange(int bits) {
		BigInteger N_min = ONE.shiftLeft(bits-1);
		// find N-set for square tests
		//ArrayList NSet = TestsetGenerator.generate(bits, N_COUNT);
		ArrayList<BigInteger> NSet = TestsetGenerator.generate(bits, N_COUNT);
		LOG.info("Test N with " + bits + " bits, i.e. N >= " + N_min);
		
		// take 3 timings for each algorithm to be quite sure that one timing is not falsified by garbage collection
		TreeMap<Long, List<SingleFactorFinder>> ms_2_algorithms = new TreeMap<Long, List<SingleFactorFinder>>();
		for (int i=0; i<REPEATS; i++) {
			for (SingleFactorFinder algorithm : ALGORITHMS) {
				// exclude special size implementations
				String algName = algorithm.getName();
				//if (bits<60 && algName.startsWith("SIQS")) continue; // unstable for smaller N
				if (bits>63 && algName.equals("Alpern's SQUFOF")) continue; // long implementation
				if (bits>63 && algName.startsWith("TDiv63")) continue; // long implementation
				if (bits>42 && algName.equals("SquFoF31")) continue; // int implementation
				if (bits>31 && algName.startsWith("TDiv31")) continue; // int implementation
				if (bits>31 && algName.startsWith("PollardRho31")) continue; // long implementation
				
				int failCount = 0;
				long startTimeMillis = System.currentTimeMillis();
				for (BigInteger N : NSet) {
					BigInteger factor = algorithm.findSingleFactor(N);
					// test correctness
					if (factor==null || factor.equals(ZERO) || factor.equals(ONE) || factor.mod(N).equals(ZERO)) {
						//LOG.error("FactorAlgorithm " + algorithm.getName() + " did not find a factor of N=" + N + ", it returned " + factor);
						failCount++;
					} else {
						// not null, not trivial -> test division
						BigInteger[] test = N.divideAndRemainder(factor);
						if (!test[1].equals(ZERO)) {
							//LOG.error("FactorAlgorithm " + algorithm.getName() + " returned " + factor + ", but this is not a factor of N=" + N);
							failCount++;
						}
					}
				}
				long endTimeMillis = System.currentTimeMillis();
				long duration = endTimeMillis - startTimeMillis; // duration in ms
				//LOG.debug("algorithm " + algName + " finished test set with " + bits + " bits");
				List<SingleFactorFinder> algList = ms_2_algorithms.get(duration);
				if (algList==null) algList = new ArrayList<SingleFactorFinder>();
				algList.add(algorithm);
				ms_2_algorithms.put(duration, algList);
				if (failCount>0) {
					LOG.error("FactorAlgorithm " + algorithm.getName() + " failed at " + failCount + "/" + N_COUNT + " test numbers...");
				}
			}
		}
		
		// log best algorithms first
		int rank=1;
		for (long ms : ms_2_algorithms.keySet()) {
			List<SingleFactorFinder> algList = ms_2_algorithms.get(ms);
			int j=0;
			for (SingleFactorFinder algorithm : algList) {
				String durationStr = TimeUtil.timeStr(ms);
				LOG.info("#" + rank + ": Algorithm " + algorithm.getName() + " took " + durationStr);
				j++;
			}
			rank += j;
		}
	}

	/**
	 * Test factor algorithms for growing N-sets and report timings after each N-set.
	 * @param args ignored
	 */
	public static void main(String[] args) {
    	ConfigUtil.initProject();
		int bits = START_BITS;
		while (true) {
			// test N with the given number of bits, i.e. 2^(bits-1) <= N <= (2^bits)-1
			testRange(bits);
			bits += INCR_BITS;
			if (MAX_BITS!=null && bits > MAX_BITS) break;
		}
	}
}
