/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * This file is part of the PSIQS package version 01 from 2016-01-07, 
 * developed by Tilman Neumann, Edemissen, Germany.
 * 
 * Use and redistribution of PSIQS are free for non-commercial purposes, as long as this
 * header is not modified or removed. Any commercial usage of the whole or parts
 * of PSIQS requires the written consent of the author.
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

package de.tilman_neumann.math.factor.psiqs;

import java.math.BigInteger;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import de.tilman_neumann.math.base.bigint.ModularSqrt;
import de.tilman_neumann.math.base.bigint.PurePowerTest;
import de.tilman_neumann.math.factor.FactorAlgorithmBase;
import de.tilman_neumann.math.factor.FactorException;
import de.tilman_neumann.math.factor._basics.FactorTest;
import de.tilman_neumann.math.factor._basics.PrimeBaseBuilder;
import de.tilman_neumann.math.factor._congruence.AQPair;
import de.tilman_neumann.math.factor._congruence.CongruenceCollector;
import de.tilman_neumann.math.factor._congruence.CongruenceCollector02;
import de.tilman_neumann.math.factor._matrixSolver.MatrixSolver01;
import de.tilman_neumann.math.factor._matrixSolver.SmoothSolverWrapper;
import de.tilman_neumann.math.factor.qs.AParamGenerator01;
import de.tilman_neumann.math.factor.qs.MultiplierFinder;

import static de.tilman_neumann.math.base.bigint.BigIntConstants.*;
import static org.junit.Assert.*;

/**
 * Multi-threaded SIQS.
 * 
 * This is the fastest factor algorithm in this package; hence it was stripped from all profiling and progress information gathering.
 * 
 * @author Tilman Neumann
 */
public class PSIQS extends FactorAlgorithmBase {
	private static final Logger LOG = Logger.getLogger(PSIQS.class);
	private static final boolean DEBUG = false;
	
	// explicit GC control
	private static long lastGcMillis;

	private int primeTestBits;
	private int numberOfThreads;
	
	// pure power test
	private PurePowerTest powerTest = new PurePowerTest();

	// Knuth-Schroeppel algorithm
	private MultiplierFinder multiplierFinder = new MultiplierFinder();

	// prime base configuration
	private PrimeBaseBuilder primeBaseBuilder = new PrimeBaseBuilder();
	private float C;
	private float logBaseAdjust = 2;

	// a-param generator configuration
	private Integer wantedQCount; // null -> automatic choice
	private int qCount; // the realized qCount

	// engine to compute the modular sqrt's t with t^2==kN (mod p) for all p
	private ModularSqrt modularSqrtEngine = new ModularSqrt();

	// sieve configuration
	private float sieveArrayMult;
	private float maxRestExp_sieve;
	private float pMinMult;
	// tdiv configuration 
	private float maxRestExp_tDiv;
	
	// collects the congruences we find
	private CongruenceCollector congruenceCollector;
	// extra congruences to have a bigger chance that the equation system solves. the likelihood is >= 1-2^(extraCongruences+1)
	private int extraCongruences;
	// A wrapper for the solver used for smooth congruence equation systems
	private SmoothSolverWrapper solverWrapper;

	/**
	 * Standard constructor.
	 * @param primeTestBits
	 * @param C multiplier for prime base size
	 * @param sieveArrayMult multiplier for sieve array size
	 * @param wantedQCount hypercube dimension (null for automatic selection)
	 * @param maxRestExp_sieve
	 * @param pMinMult
	 * @param maxRestExp_tDiv
	 * @param numberOfThreads
	 */
	public PSIQS(int primeTestBits, float C, float sieveArrayMult, Integer wantedQCount, float maxRestExp_sieve, float pMinMult, float maxRestExp_tDiv, int numberOfThreads) {
		super(primeTestBits);
		this.primeTestBits = primeTestBits;
		this.C = C;
		this.sieveArrayMult = sieveArrayMult;
		this.wantedQCount = wantedQCount;
		this.maxRestExp_sieve = maxRestExp_sieve;
		this.pMinMult = pMinMult;
		this.maxRestExp_tDiv = maxRestExp_tDiv;
		this.numberOfThreads = numberOfThreads;
		this.congruenceCollector = new CongruenceCollector02();
		this.extraCongruences = 10;
		this.solverWrapper = new SmoothSolverWrapper(new MatrixSolver01<Integer>(2));
		lastGcMillis = System.currentTimeMillis();
	}

	@Override
	public String getName() {
		return "PSIQS(C=" + C + ", sieveArrayMult=" + sieveArrayMult + ", qCount=" + qCount + ", maxRestExp_sieve=" + maxRestExp_sieve + ", pMinMult=" + pMinMult + ", maxRestExp_tDiv=" + maxRestExp_tDiv + ", " + numberOfThreads + " threads)";
	}
	
	/**
	 * Test the current N.
	 * @return factor, or null if no factor was found.
	 */
	public BigInteger findSingleFactor(BigInteger N) {
		// the quadratic sieve does not work for pure powers; check that first:
		PurePowerTest.Result purePower = powerTest.test(N);
		if (purePower!=null) {
			// N is indeed a pure power -> return a factor that is about sqrt(N)
			return purePower.base.pow(purePower.exponent>>1);
		}
		
		// no pure power, run quadratic sieve
		double N_dbl = N.doubleValue();
		// compute prime base size
		double lnN = Math.log(N_dbl);
		double lnlnN = Math.log(lnN);
		double lnNPow = 0.5; // heuristics for quadratic sieve
		double lnTerm = Math.pow(lnN, lnNPow) * Math.pow(lnlnN, 1-lnNPow); // we want that the exponents of lnN and lnlnN sum to 1
		double primeBaseSize_dbl = Math.exp(lnTerm * C);
		if (primeBaseSize_dbl > Integer.MAX_VALUE) throw new IllegalStateException("primeBaseSize=" + primeBaseSize_dbl + " is too big for int!");
		int primeBaseSize = Math.max(10, (int) primeBaseSize_dbl); // min. size for very small N
		int[] primesArray = new int[primeBaseSize];
		BigInteger[] primesArray_big = new BigInteger[primeBaseSize];
		byte[] logPArray = new byte[primeBaseSize];
		// the number of congruences we need to find before we try to solve the smooth congruence equation system:
		// we want: #equations = #variables + some extra congruences
		int requiredSmoothCongruenceCount = primeBaseSize + extraCongruences;

		// compute rough sieve array size estimate
		double proposedSieveArraySize = Math.exp(lnTerm * sieveArrayMult);

		// compute multiplier k for N using Knuth-Schroeppel
		int k = multiplierFinder.computeMultiplier(N, primeBaseSize, 3);
		BigInteger kN = BigInteger.valueOf(k).multiply(N);
		
		// Create the reduced prime base for kN:
		float logBase = computeLogBase(lnN, kN, proposedSieveArraySize);
		primeBaseBuilder.computeReducedPrimeBase(kN, primeBaseSize, primesArray, primesArray_big, logPArray, logBase);

		// adjust the sieve array size to a multiple of 256 and such that each p has at least one solution in the sieve array
		int maxPrime = primesArray[primeBaseSize-1];
		int adjustedSieveArraySize = adjustSieveArraySize(proposedSieveArraySize, maxPrime);
		if (DEBUG) LOG.debug("proposedSieveArraySize = " + (long)proposedSieveArraySize + ", maxPrime = " + maxPrime + ", adjusted sieveArraySize = " + adjustedSieveArraySize);

		// compute the modular sqrt's t with t^2 == kN (mod p) for all p
		int[] tArray = computeTArray(kN, primeBaseSize, primesArray, primesArray_big);

		// initialize a-param generator
		AParamGenerator01 apg = new AParamGenerator01(wantedQCount);
		apg.initialize(k, N, kN, primeBaseSize, primesArray, adjustedSieveArraySize);
		qCount = apg.getQCount();
		
		// initialize congruence collector and matrix solver
		FactorTest factorTest = new FactorTest(N);
		this.congruenceCollector.initialize(N, factorTest);
		this.solverWrapper.initialize(N, factorTest);

		// create empty synchronized AQ-pair buffer, used to pass AQ-pairs from "sieve threads" to the main thread
		AQPairBuffer aqPairBuffer = new AQPairBuffer();

		PSIQSThread[] threadArray = new PSIQSThread[numberOfThreads];
		// create and run threads
		for (int threadIndex=0; threadIndex<numberOfThreads; threadIndex++) {
			threadArray[threadIndex] = new PSIQSThread(N_dbl, kN, primeBaseSize, primesArray, primesArray_big, logPArray, logBase, tArray, 
													   adjustedSieveArraySize, maxRestExp_sieve, pMinMult, maxRestExp_tDiv, primeTestBits,
													   apg, aqPairBuffer, threadIndex);
			threadArray[threadIndex].start();
		}

		try {
			while (true) { // as long as we didn't find a factor
				// wait for new data
				ArrayList<AQPair> newAQPairs;
				synchronized (aqPairBuffer) {
					while (true) {
						try {
							aqPairBuffer.wait(); // is woken up by notify() after new data has been added to the buffer
							//LOG.debug("Control thread got notified about new data");
							break;
						} catch (InterruptedException ie) {
							// ignore
						}
					}
					// get new data (must be synchronized)
					newAQPairs = aqPairBuffer.removeAll();
				}
				//LOG.debug("add " + newAQPairs.size() + " new AQ-pairs to CC");
				// Add new data to the congruenceCollector and eventually run the matrix solver.
				for (AQPair aqPair : newAQPairs) {
					boolean addedSmooth = congruenceCollector.add(aqPair);
					if (addedSmooth && congruenceCollector.getSmoothCongruenceCount() >= requiredSmoothCongruenceCount) {
						// try to solve equation system:
						// It seems to be a good idea to block the other threads while the solver is running...
						//LOG.debug("#smooths = " + congruenceCollector.getSmoothCongruenceCount() + ", #requiredSmooths = " + requiredSmoothCongruenceCount);
						synchronized (aqPairBuffer) {
							solverWrapper.solve(congruenceCollector.getSmoothCongruences()); // throws FactorException
						}
						// no factor exception -> extend equation system and continue searching smooth congruences
						requiredSmoothCongruenceCount += extraCongruences;
					}
				}
			}
		} catch (FactorException fe) {
			// now we have found a factor.
			BigInteger factor = fe.getFactor();
			//LOG.debug("N=" + N + ": found factor " + factor);
			// kill all threads & release memory
			// the latter improves the accuracy of timings when several algorithms are tested in parallel
			for (int threadIndex=0; threadIndex<numberOfThreads; threadIndex++) {
				killThread(threadArray[threadIndex]);
				threadArray[threadIndex] = null; // dropping the threads releases all data held be them
			}
			congruenceCollector.cleanUp();
			solverWrapper.cleanUp();
			// trigger full GC ? At this place it is fast and useful because a lot of stuff has been released.
			if (System.currentTimeMillis()-lastGcMillis > 5000) {
				System.gc();
				lastGcMillis = System.currentTimeMillis();
			}
			// return factor
			return factor;
		}
	}
	
	private float computeLogBase(double lnN, BigInteger kN, double proposedSieveArraySize) {
		double lnM = Math.log(proposedSieveArraySize);
		double lnkN = Math.log(kN.doubleValue());
		float estimatedT = 0.2F;
		double minLnPSum = lnM + lnkN/2 - 0.5 - estimatedT*lnN;
		double lnLogBase = minLnPSum / (128/logBaseAdjust); // normalization with logBaseAdjust=2 works fine; the exact value does not matter
		float logBase = (float) Math.exp(lnLogBase);
		//LOG.debug("minLnPSum = " + minLnPSum + ", estimated log base = " + logBase);
		return logBase;
	}
	
	private int adjustSieveArraySize(double proposedSieveArraySize, int maxPrime) {
		// we want a sieveArraySize that
		// a) is greater/equals maxPrime, so that there is always at least one x-solution inside the sieve array
		// b) has (sieveArraySize + maxPrime) < 2^31 to avoid integer overflow
		// c) is a multiple of 256
		if (proposedSieveArraySize < maxPrime) proposedSieveArraySize = maxPrime; // assure a)
		double tooBig = (proposedSieveArraySize+maxPrime) - ((1L<<31)-1); // check b)
		if (tooBig > 0) proposedSieveArraySize -= tooBig; // assure b)
		// finally find a multiple of 256 still satisfying b)
		long adjustedSieveArraySize = (((long) proposedSieveArraySize+255)>>8)<<8; // multiple of 256
		if (adjustedSieveArraySize+maxPrime>=(1L<<31)) adjustedSieveArraySize -= 256; // re-assure b)
		return (int) adjustedSieveArraySize;
	}
	
	/**
	 * For all primes p in the prime base, find the modular sqrt's of kN (mod p), i.e. the t such that t^2 == kN (mod p).
	 */
	private int[] computeTArray(BigInteger kN, int primeBaseSize, int[] primesArray, BigInteger[] primesArray_big) {
		int[] tArray = new int[primeBaseSize];
		// special treatment for p[0]=2 (always contained in prime base)
		tArray[0] = kN.and(ONE).intValue();
		if (DEBUG) assertEquals(BigInteger.valueOf(tArray[0]).pow(2).mod(TWO), kN.mod(TWO));
		// odd primes
		for (int i = 1; i<primeBaseSize; i++) {
			// Tonelli_Shanks requires Legendre(kN|p)==1, 0 is not ok. But this is easy to "heal":
			// Since p is prime, Legendre(kN|p)==0 means that kN is a multiple of p.
			// Thus t^2 == kN == 0 (mod p) and the modular sqrt t is 0, too.
			if (kN.mod(primesArray_big[i]).equals(ZERO)) {
				tArray[i] = 0;
			} else {
				tArray[i] = modularSqrtEngine.Tonelli_Shanks(kN, primesArray[i]);
			}
			//if (primesArray[i]==3) LOG.debug("p=3 -> t=" + tArray[i]);
		}
		return tArray;
	}

	private void killThread(Thread t) {
    	while (t.isAlive()) {
			t.interrupt();
    		try {
    			t.join();
    		} catch (InterruptedException e) {
    			// ignore
    		}
    	}
	}
}
