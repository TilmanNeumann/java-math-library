/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * This file is part of the PSIQS package version 01 from 2016-01-07, 
 * developed by Tilman Neumann, Edemissen, Germany.
 * 
 * Use and redistribution of PSIQS are free for non-commercial purposes, as long as this
 * header is not modified or removed. Any commercial usage of the whole or parts
 * of PSIQS requires the written consent of the author.
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

package de.tilman_neumann.math.factor.psiqs;

import java.math.BigInteger;

import org.apache.log4j.Logger;

import de.tilman_neumann.math.factor.qs.AParamGenerator;
import de.tilman_neumann.math.factor.qs.Poly;
import de.tilman_neumann.math.factor.qs.SIQSPoly01;

import static de.tilman_neumann.math.base.bigint.BigIntConstants.*;
import static org.junit.Assert.*;

/**
 * A builder for SIQS polynomials for the multi-threaded SIQS version.
 * 
 * This class does not implement the PolyBuilder interface, because in the parallel case, several things must not be computed for each thread.
 * 
 * @author Tilman Neumann
 */
public class PSIQSPolyBuilder {
	private static final Logger LOG = Logger.getLogger(PSIQSPolyBuilder.class);
	private static final boolean DEBUG = false;
	
	private int primeBaseSize;
	private BigInteger a;
	private BigInteger b;
	private BigInteger kN;
	
	// prime base: is computed only once
	private int[] primesArray;
	private BigInteger[] primesArray_big;
	private byte[] logPArray;
	private float logBase;

	/** the modular sqrt's t with t^2==kN (mod p) for all p */
	private int[] tArray;

	/** generator for a-parameters */
	private AParamGenerator aParamGenerator;
	
	/** the actual number of factors of the a-parameter for given kN */
	private int qCount;
	/** indices of the prime base elements that are the factors of a */
	private int[] qIndexArray;
	/** and the factors themselves */
	private int[] qArray;
	/** the number of b-values we can have for one a */
	private int maxBIndex;
	/** the number of b-values already used */
	private int bIndex;
	/** basic Bl required to compute b */
	private BigInteger[] B2Array;
	
	// solution arrays
	private int[] ainvpArray;
	private int[][] Bainv2Array;
	private int[] x1Array;
	private int[] x2Array;
	
	private SIQSPoly01 poly;
	private int polyCount;

	/**
	 * Full constructor.
	 * @param aParamGenerator a single a-paramater generator object that creates a-params for all threads
	 */
	public PSIQSPolyBuilder(AParamGenerator aParamGenerator) {
		this.aParamGenerator = aParamGenerator;
	}

	public String getName() {
		return "PSIQSPoly(" + aParamGenerator.getName() + ")";
	}

	public void initialize(BigInteger kN, int primeBaseSize, int[] primesArray, BigInteger[] primesArray_big, byte[] logPArray,
						   float logBase, int[] tArray) {
		
		this.kN = kN;
		this.primeBaseSize = primeBaseSize;
		this.primesArray = primesArray;
		this.primesArray_big = primesArray_big;
		this.logPArray = logPArray;
		this.logBase = logBase;
		this.tArray = tArray;
		this.ainvpArray = new int[primeBaseSize];
		this.x1Array = new int[primeBaseSize];
		this.x2Array = new int[primeBaseSize];
		
		// set bIndex=maxBIndex=0 to indicate that the first polynomial is wanted
		this.bIndex = this.maxBIndex = 0;
		this.polyCount = 0;
	}
	
	public Poly nextPolynomial() {
		if (bIndex==maxBIndex) {
			// Incrementing bIndex would exceed the maximum value -> we need a new a-parameter.
			// Find a new a-parameter and its q_l-set:
			this.getNextAParameter();
			maxBIndex = 1<<(qCount-1); // 2^(qCount-1)
			// compute the first b
			this.computeFirstBParameter();
			//LOG.debug("first a=" + a + ", b=" + b);
			bIndex = 1;
			
			// compute ainvp[] and Bainv2[][]
			this.computeAinvp();
			this.computeBainv2();

			// compute solution arrays for a and first b
			this.computeFirstXArrays();
			// create first polynomial
			boolean hasNewPrimeBase = (polyCount == 0);
			poly = new SIQSPoly01(qArray, a, b, kN, hasNewPrimeBase, primeBaseSize, primesArray, primesArray_big, logPArray, logBase, x1Array, x2Array);
		} else {
			// compute the next b-parameter:
			// the v with 2^v || 2*i in [Contini97] is the exponent at which 2*i contains the 2, and here we have bIndex instead "i":
			int v = Integer.numberOfTrailingZeros(bIndex<<1);
			int ceilTerm = bIndex/(1<<v) + 1; // ceil(bIndex/2^v)
			boolean isEven = (ceilTerm%2==0); // if isEven then (-1)^ceilTerm == +1
			computeNextBParameter(v, isEven);
			poly.setNextBParameter(b);
			if (DEBUG) {
				// the asserts must be done before bIndex is incremented
				assertTrue(0<v && v<qCount); // exact
				assertTrue((2*bIndex) % Math.pow(2, v) == 0);
				assertTrue((2*bIndex) % Math.pow(2, v+1) > 0);
			}
			bIndex++;
			//LOG.debug("a=" + a + ": " + bIndex + ".th b=" + b + ", c=" + c);

			// Update solution arrays: 
			// Since only the array-content is modified, the x-arrays in poly are updated implicitly.
			// This approach would work in a multi-threaded SIQS implementation too, if we create a new thread for each new a-parameter.
			// Note that fix prime divisors depend only on a and k -> they do not change at a new b-parameter.
			computeNextXArrays(v, isEven);
		}
		polyCount++;
		//LOG.debug("N=" + N + ", polyCount=" + polyCount + ": b = " + b);
		return poly;
	}

	/**
	 * Computation of a-parameters must be synchronized.
	 */
	private void getNextAParameter() {
		synchronized (aParamGenerator) {
			this.a = aParamGenerator.computeNextAParameter();
			this.qCount = aParamGenerator.getQCount();
			this.qArray = aParamGenerator.getQArray();
			this.qIndexArray = aParamGenerator.getQIndexArray();
		}
		if (polyCount==0) {
			//LOG.debug("allocate Bainv2["+primeBaseSize+"]["+qCount+"]");
			this.B2Array = new BigInteger[qCount+1]; // one more element required because used indices start at 1
			this.Bainv2Array = new int[primeBaseSize][qCount]; // full initialization
		}
	}
	
	/**
	 * Compute the B-array and the first b-parameter b1.
	 */
	private void computeFirstBParameter() {
		// compute 2*B_l[] and the first b; the notation is mostly following [Contini97]
		this.b = ZERO;
		// The entries in 2*B_l[] = B2Array are stored at Contini's original indices l=1..s to save one "-1" operation in later steps.
		//LOG.debug("qCount = " + qCount + ", qArray = " + Arrays.toString(qArray) + ", a = " + a);
		for (int l=1; l<=qCount; l++) {
			int ql = qArray[l-1]; // q-indices start at 0
			int qIndex = qIndexArray[l-1];
			int t = tArray[qIndex];
			BigInteger ql_big = BigInteger.valueOf(ql);
			BigInteger a_div_ql = a.divide(ql_big); // exact
			// the modular inverse is small enough to fit into int, but for the product below we need long precision
			long a_div_ql_modInv_ql = a_div_ql.modInverse(ql_big).longValue();
			int gamma = (int) ((t*a_div_ql_modInv_ql) % ql);
			if (gamma > (ql>>1)) gamma = ql - gamma; // take the smaller choice of gamma
			BigInteger Bl = a_div_ql.multiply(BigInteger.valueOf(gamma));
			if (DEBUG) {
				assertTrue(Bl.compareTo(ZERO) >= 0);
				assertEquals(ZERO, Bl.multiply(Bl).subtract(kN).mod(ql_big));
			}
			B2Array[l] = Bl.shiftLeft(1); // store 2 * B_l in B2[1]...B2[s]
			b = b.add(Bl);
			// WARNING: In contrast to the description in [Contini p.10, 2nd paragraph],
			// WARNING: b must not be computed (mod a) !
		}
		if (DEBUG) assertEquals(ZERO, b.multiply(b).subtract(kN).mod(a)); // we have b^2 == kN (mod a)
	}
	
	/**
	 * Compute the ainvp[] required for Bainv2[][].
	 */
	private void computeAinvp() { // performance-critical !
		for (int i=primeBaseSize-1; i>=0; i--) {
			BigInteger p_big = primesArray_big[i];
			if (a.mod(p_big).equals(ZERO)) {
				ainvpArray[i] = 0; // use ainvpArray[i] == 0 to indicate that a is divisible by p
			} else {
				// a is not divisible by p -> the modular inverse exists
				ainvpArray[i] = a.modInverse(p_big).intValue();
			}
		}
	}

	/**
	 * Compute the Bainv2[][] required to compute next b's and next x-arrays.
	 */
	private void computeBainv2() { // performance-critical !
		for (int i=primeBaseSize-1; i>=0; i--) {
			int ainvp = ainvpArray[i];
			if (ainvp != 0) {
				// the modular inverse (1/a) mod p exists
				int p = primesArray[i];
				BigInteger p_big = primesArray_big[i];
				for (int j=qCount-1; j>0; j--) { // Contini's j=1...s-1
					// Bainv2 = 2 * B_j * (1/a) mod p.
					// the B_j must be BigInteger; therefore it is difficult to speed-improve this:
					//Bainv2Array[i][j] = B2Array[j].multiply(ainvp_big).mod(p_big).intValue();
					// But for bigger N the following statement seems to be faster:
					Bainv2Array[i][j] = (int) ((B2Array[j].mod(p_big).longValue() * ainvp) % p);
					if (DEBUG) {
						int Bainv2 = Bainv2Array[i][j];
						assertTrue(0<=Bainv2 && Bainv2<primesArray[i]);
					}
				}
			}
		}
	}
	
	/**
	 * Compute the smallest non-negative solutions x_1,2 of (ax+b)^2-kN == 0 (mod p)
	 * for the first b-parameter and for all p in the prime base.
	 * 
	 * The q_l are marked with a "-1" entry in x1Array and x2Array.
	 */
	private void computeFirstXArrays() {
		for (int i=primeBaseSize-1; i>=0; i--) {
			// make ainvp long to have long precision in the products below
			long ainvp = ainvpArray[i];
			if (ainvp > 0) {
				// a is not divisible by p
				int p = primesArray[i];
				int t = tArray[i];
				int bModP = b.mod(primesArray_big[i]).intValue();
				// x1 = (1/a)* (+t - b) (mod p)
				int t_minus_b_modP = t - bModP;
				if (t_minus_b_modP < 0) t_minus_b_modP += p;
				x1Array[i] = (int) ((ainvp * t_minus_b_modP) % p);
				if (t>0) {
					// there is a second solution x2 = (1/a)* (-t - b) (mod p)
					int minus_t_minus_b_modP = p -t - bModP;
					if (minus_t_minus_b_modP < 0) minus_t_minus_b_modP += p;
					x2Array[i] = (int) ((ainvp * minus_t_minus_b_modP) % p);
					if (DEBUG) {
						//LOG.debug("t=" + t  + ", p=" + p + ", minus_t_minus_b_modP = " + minus_t_minus_b_modP);
						assertTrue(0<=minus_t_minus_b_modP && minus_t_minus_b_modP<p);
					}
				} else {
					// only one solution
					x2Array[i] = x1Array[i];
				}
				if (DEBUG) {
					BigInteger p_big = primesArray_big[i];
					int x1 = x1Array[i];
					assertTrue(0<=t_minus_b_modP && t_minus_b_modP<p);
					assertEquals(kN.mod(p_big), a.multiply(BigInteger.valueOf(x1)).add(b).pow(2).mod(p_big));
					int x2 = x2Array[i];
					assertEquals(kN.mod(p_big), a.multiply(BigInteger.valueOf(x2)).add(b).pow(2).mod(p_big));
					if (x1<0 || x2<0) LOG.debug("p=" + p + ", ainvp=" + ainvp + ": x1 = " + x1 + ", x2 = " + x2);
				}
			} else {
				// the modular inverse (1/a) mod p does not exist!
				// So p divides a, and a = q1*...q_s -> the current p is one of the q_l and divides any Q(x).
				// Now one could sieve with these values too, to check if p divides Q(x)/a:
				// "Q(x)/a is divisible by q_l if and only if x == -c*(1/2b) mod q_l" [Contini, footnote on p. 10]
				// However, this would mean that we have to compute a modular inverse in the next-poly-initialization,
				// which we want to have as fast as possible. So it feels as if sieving with the q_l does not pay out.
				
				// We do not want to sieve with the q_l, and we need a special treatment in trial division
				// -> mark the q_l in the x-solution arrays with "-1":
				x1Array[i] = x2Array[i] = -1;
				
				if (DEBUG) {
					// Show that p is in qArray
					boolean isInQArray = false;
					for (int qIndex : qIndexArray) {
						if (qIndex == i) {
							isInQArray = true;
							break;
						}
					}
					assertTrue(isInQArray);
				}
			} // end if (ainvp == 0)
		} // end_for (primes)
	}

	/**
	 * Compute the next b-parameter.
	 * @param v gray code
	 * @param isEven true if ceil(bIndex/2^v) is even
	 */
	private void computeNextBParameter(int v, boolean isEven) {
		BigInteger two_Bv = B2Array[v]; // get 2*Bv
		if (isEven) {
			this.b = b.add(two_Bv); // b = b + 2*Bv
		} else {
			this.b = b.subtract(two_Bv); // b = b - 2*Bv
		}
		// WARNING: In contrast to the description in [Contini p.10, 2nd paragraph],
		// WARNING: b must not be computed (mod a) !
		if (DEBUG) assertEquals(ZERO, b.multiply(b).subtract(kN).mod(a)); // we have b^2 == kN (mod a)
	}
	
	/**
	 * Update the entries of the solution arrays for the next b-parameter.
	 * @param v gray code, with v in [1, ..., qCount-1]
	 * @param isEven true if ceil(bIndex/2^v) is even
	 */
	private void computeNextXArrays(int v, boolean isEven) { // performance-critical !
		// update solution arrays
		for (int i=primeBaseSize-1; i>=0; i--) {
			if (ainvpArray[i]>0) {
				// a is not divisible by p
				int p = primesArray[i];
				int Bainv2 = Bainv2Array[i][v];
				// WARNING: The correct case distinction depending on the sign of (-1)^ceil(bIndex/2^v)
				// WARNING: is just the opposite of [Contini, table p.14, last 2 lines]
				if (isEven) { // it is surely faster to evaluate isEven outside the loop; but it is less elegant and the performance advantage is negligible.
					// (-1)^ceil(bIndex/2^v) == +1
					// in this case Bainv2 is subtracted -> we have to deal with possibly negative intermediate results
					int x1 = x1Array[i] - Bainv2;
					if (x1<0) x1 += p; // now x1 should be non-negative
					//LOG.debug("Bainv2 = " + Bainv2 + ", p = " + p + ", x1 = " + x1);
					x1Array[i] = x1; // (mod p) is not necessary here
					int x2 = x2Array[i] - Bainv2;
					if (x2<0) x2 += p; // now x2 should be non-negative
					x2Array[i] = x2; // (mod p) is not necessary here
				} else {
					// (-1)^ceil(bIndex/2^v) == -1
					int x1 = x1Array[i] + Bainv2; // Bainv2 >= 0
					if (x1 >= p) x1 -= p; // (mod p) is not required here
					x1Array[i] = x1;
					int x2 = x2Array[i] + Bainv2;
					if (x2 >= p) x2 -= p; // (mod p) is not required here
					x2Array[i] = x2;
				}
				if (DEBUG) {
					int x1 = x1Array[i];
					int x2 = x2Array[i];
					assertTrue(0 <= x1 && x1 < p);
					assertTrue(0 <= x2 && x2 < p);
					BigInteger p_big = BigInteger.valueOf(p);
					assertEquals(kN.mod(p_big), a.multiply(BigInteger.valueOf(x1)).add(b).pow(2).mod(p_big));
					assertEquals(kN.mod(p_big), a.multiply(BigInteger.valueOf(x2)).add(b).pow(2).mod(p_big));
					if (x1<0 || x2<0) LOG.debug("p=" + p + ", Bainv2=" + Bainv2 + ": x1 = " + x1 + ", x2 = " + x2);
				}
			}
			// else: ainvp == 0 -> the modular inverse (1/a) mod p does not exist, p|a, p is one of the q_l.
			// We do not want to sieve with the q_l -> just keep the "-1" entries in the x-solution arrays.
		} // end for (primes)
	}
}
