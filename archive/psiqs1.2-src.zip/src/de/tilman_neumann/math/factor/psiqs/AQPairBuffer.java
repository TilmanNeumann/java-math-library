/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * This file is part of the PSIQS package version 01 from 2016-01-07, 
 * developed by Tilman Neumann, Edemissen, Germany.
 * 
 * Use and redistribution of PSIQS are free for non-commercial purposes, as long as this
 * header is not modified or removed. Any commercial usage of the whole or parts
 * of PSIQS requires the written consent of the author.
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

package de.tilman_neumann.math.factor.psiqs;

import java.util.ArrayList;
import java.util.Collection;

import de.tilman_neumann.math.factor._congruence.AQPair;

/**
 * A synchronized buffer used to pass AQ-pairs from sieve threads to the control thread.
 * @author Tilman Neumann
 */
public class AQPairBuffer {
	private static final int INITIAL_BUFFER_SIZE = 100;
	
	private ArrayList<AQPair> aqPairs;
	public AQPairBuffer() {
		this.aqPairs = new ArrayList<AQPair>(INITIAL_BUFFER_SIZE);
	}
	
	public void addAll(Collection<AQPair> newAQPairs) {
		synchronized(this) { // block write from other threads and read access from control thread
			aqPairs.addAll(newAQPairs);
			this.notify(); // notify control thread about incoming data
		}
	}
	
	// this method must be synchronized externally on this to block write access
	public ArrayList<AQPair> removeAll() {
		ArrayList<AQPair> ret = aqPairs;
		aqPairs = new ArrayList<AQPair>(INITIAL_BUFFER_SIZE);
		return ret;
	}
}
