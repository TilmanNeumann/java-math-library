/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * This file is part of the PSIQS package version 01 from 2016-01-07, 
 * developed by Tilman Neumann, Edemissen, Germany.
 * 
 * Use and redistribution of PSIQS are free for non-commercial purposes, as long as this
 * header is not modified or removed. Any commercial usage of the whole or parts
 * of PSIQS requires the written consent of the author.
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

package de.tilman_neumann.math.factor.psiqs;

import java.math.BigInteger;
import java.util.List;

import de.tilman_neumann.math.factor._congruence.AQPair;
import de.tilman_neumann.math.factor.qs.AParamGenerator;
import de.tilman_neumann.math.factor.qs.Poly;
import de.tilman_neumann.math.factor.qs.sieve.Sieve;
import de.tilman_neumann.math.factor.qs.sieve.Sieve04b;
import de.tilman_neumann.math.factor.qs.tdiv.TDiv_QS;
import de.tilman_neumann.math.factor.qs.tdiv.TDiv_QS03;

/**
 * A sieve/trial division thread for the parallel SIQS implementation (PSIQS).
 * @author Tilman Neumann
 */
public class PSIQSThread extends Thread {

	private int adjustedSieveArraySize;
	
	private PSIQSPolyBuilder polyBuilder;
	private Sieve sieve;
	private TDiv_QS auxFactorizer;
	private AQPairBuffer aqPairBuffer;

	public PSIQSThread(double N_dbl, BigInteger kN, int primeBaseSize, int[] primesArray, BigInteger[] primesArray_big, byte[] logPArray,
					   float logBase, int[] tArray, int adjustedSieveArraySize, float maxRestExp_sieve, float pMinMult, float maxRestExp_tDiv, 
					   int primeTestBits, AParamGenerator apg, AQPairBuffer aqPairBuffer, int threadIndex) {
		
		// set thread name
		super("T-" + threadIndex);
		
		// create and initialize sub-algorithms
		this.polyBuilder = new PSIQSPolyBuilder(apg); // apg is the same object for all threads -> a-parameter generation is synchronized on it
		polyBuilder.initialize(kN, primeBaseSize, primesArray, primesArray_big, logPArray, logBase, tArray);
		this.sieve = new Sieve04b(1, maxRestExp_sieve, pMinMult, 1);
		sieve.initialize(N_dbl, primeBaseSize, false);
		this.auxFactorizer = new TDiv_QS03(primeTestBits, maxRestExp_tDiv);
		auxFactorizer.initialize(N_dbl, primeBaseSize);
		// synchronized buffer to pass AQ-pairs to the main thread -> the same object for all threads
		this.aqPairBuffer = aqPairBuffer;
		// store other parameters required in run()
		this.adjustedSieveArraySize = adjustedSieveArraySize;
	}
	
	public void run() {
		while (!Thread.currentThread().isInterrupted()) {
			// create new polynomial Q(x)
			Poly poly = polyBuilder.nextPolynomial();

			// run sieve and get the sieve locations x where Q(x) is sufficiently smooth
			List<Integer> smoothXList = sieve.sieve(poly, adjustedSieveArraySize);
			//LOG.debug("Sieve found " + smoothXList.size() + " Q(x) smooth enough to be passed to trial division.");

			// trial division stage: produce AQ-pairs
			List<AQPair> aqPairs = auxFactorizer.testList(poly, smoothXList);
			//LOG.debug("Trial division found " + aqPairs.size() + " Q(x) smooth enough for a congruence.");

			if (aqPairs.size()>0) {
				// add all congruences synchronized and notify control thread
				aqPairBuffer.addAll(aqPairs);
			}
		}
	}
}
