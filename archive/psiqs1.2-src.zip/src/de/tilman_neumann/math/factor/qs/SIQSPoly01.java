/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * This file is part of the PSIQS package version 01 from 2016-01-07, 
 * developed by Tilman Neumann, Edemissen, Germany.
 * 
 * Use and redistribution of PSIQS are free for non-commercial purposes, as long as this
 * header is not modified or removed. Any commercial usage of the whole or parts
 * of PSIQS requires the written consent of the author.
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

package de.tilman_neumann.math.factor.qs;

import java.math.BigInteger;

import org.apache.log4j.Logger;

/**
 * SIQS polynomial:
 * Q(x) = A(x)^2 - kN, k constant, A(x) = a*x+b,
 * a = q1*...*q_s ~ sqrt(2*kN)/sieveArraySize, 
 * q_l primes from the prime base (which implies kN a quadratic residue mod q_l for all l),
 * and b<a a modular square root of kN mod a.
 * 
 * @author Tilman Neumann
 */
public class SIQSPoly01 implements Poly {
	@SuppressWarnings("unused")
	private static final Logger LOG = Logger.getLogger(SIQSPoly01.class);
	
	private BigInteger a, b, kN;
	
	// prime base
	private boolean hasNewPrimeBase;
	private int[] primesArray;
	private BigInteger[] primesArray_big;
	private byte[] logPArray;
	private float logBase;

	private int[] qArray;

	private int[] x1Array;
	private int[] x2Array;

	/**
	 * Full constructor.
	 * @param qArray the q's whose product gives the a-parameter
	 * @param a the a-parameter of the SIQS polynomial
	 * @param b the b-parameter
	 * @param kN
	 * @param hasNewPrimeBase
	 * @param primeBaseSize
	 * @param primesArray prime base computed in PolyBuilder
	 * @param primesArray_big
	 * @param logPArray
	 * @param logBase
	 * @param x1Array
	 * @param x2Array
	 */
	public SIQSPoly01(int[] qArray, BigInteger a, BigInteger b, BigInteger kN, boolean hasNewPrimeBase, int primeBaseSize, int[] primesArray,
					  BigInteger[] primesArray_big, byte[] logPArray, float logBase, int[] x1Array, int[] x2Array) {

		this.qArray = qArray;
		this.a = a;
		this.b = b;
		this.kN = kN;
		this.hasNewPrimeBase = hasNewPrimeBase;
		this.primesArray = primesArray;
		this.primesArray_big = primesArray_big;
		this.logPArray = logPArray;
		this.logBase = logBase;
		this.x1Array = x1Array;
		this.x2Array = x2Array;
	}

	/**
	 * Re-initialize with a new b-parameter.
	 * @param b the new b
	 */
	public void setNextBParameter(BigInteger b) {
		this.b = b;
	}

	@Override
	public BigInteger getkN() {
		return kN;
	}

	@Override
	public BigInteger getAParameter() {
		return a;
	}

	@Override
	public boolean hasNewPrimeBase() {
		return hasNewPrimeBase;
	}

	@Override
	public int[] getPrimesArray() {
		return primesArray;
	}

	@Override
	public BigInteger[] getPrimesArray_big() {
		return primesArray_big;
	}

	@Override
	public byte[] getLogPArray() {
		return logPArray;
	}

	@Override
	public float getLogBase() {
		return logBase;
	}

	@Override
	public int[] getX1Array() {
		return x1Array;
	}

	@Override
	public int[] getX2Array() {
		return x2Array;
	}

	@Override
	public BigInteger[] computeAandQ(int x) {
		BigInteger A = a.multiply(BigInteger.valueOf(x)).add(b); // A(x) = a*x+b
		return new BigInteger[] {A, A.multiply(A).subtract(kN)}; // Q(x) = A(x)^2 - kN
	}
	
	@Override
	public int[] getPrimeBaseElementsDividingAnyQ() {
		return qArray;
	}
	
	@Override
	public BigInteger[] getNonPrimeBaseElementsDividingAnyQ() {
		// in SIQS there are no divisors outside the prime base that divide all Q(x)
		return null;
	}
}
