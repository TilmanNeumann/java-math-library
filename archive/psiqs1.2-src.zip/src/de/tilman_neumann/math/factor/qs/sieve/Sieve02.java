/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * This file is part of the PSIQS package version 01 from 2016-01-07, 
 * developed by Tilman Neumann, Edemissen, Germany.
 * 
 * Use and redistribution of PSIQS are free for non-commercial purposes, as long as this
 * header is not modified or removed. Any commercial usage of the whole or parts
 * of PSIQS requires the written consent of the author.
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

package de.tilman_neumann.math.factor.qs.sieve;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import de.tilman_neumann.math.factor.qs.Poly;

/**
 * Sieve implementation that sieves on positive and negative x-values.
 * 
 * @author Tilman Neumann
 */
public class Sieve02 implements Sieve {
	@SuppressWarnings("unused")
	private static final Logger LOG = Logger.getLogger(Sieve02.class);

	/** basic building block for fast zero-initialization of sieve array */
	private static final byte[] ZERO_ARRAY_256 = new byte[256];

	private int sieveBoundStyle;
	private float T;
	private float lnN;
	private int primeBaseSize;
	
	private byte[] sieve_logPSumArray, sieve_logPSumArray_neg;
	private Integer lastSieveArraySize;
	
	// timings
	private boolean profile;
	private long initDuration, sieveDuration, collectDuration;
	
	public Sieve02(int sieveBoundStyle, float T) {
		this.sieveBoundStyle = sieveBoundStyle;
		this.T = T;
	}
	
	@Override
	public String getName() {
		return "sieve02(" + sieveBoundStyle + ", " + T + ")";
	}
	
	@Override
	public void initialize(double N_dbl, int primeBaseSize, boolean profile) {
		this.lnN = (float) Math.log(N_dbl);
		this.primeBaseSize = primeBaseSize;
		this.lastSieveArraySize = null; // indicate that allocating the sieve arrays is required
		// profiling
		this.profile = profile;
		initDuration = 0;
		sieveDuration = 0;
		collectDuration = 0;
	}

	@Override
	public List<Integer> sieve(Poly poly, int sieveArraySize) {
		long t0 = System.currentTimeMillis();
		this.initializeSieveArray(sieveArraySize);
		long t1 = System.currentTimeMillis();
		if (profile) initDuration += (t1-t0);

		int[] primesArray = poly.getPrimesArray();
		byte[] ldPArray = poly.getLogPArray();
		int[] x1Array = poly.getX1Array();
		int[] x2Array = poly.getX2Array();

		// sieve with p[0]=2: here we use only solution x1
		//assertEquals(1, ldPArray[0]);
		int x1min = x1Array[0];
		if (x1min > -1) { // sieve with this solution
			byte logP = ldPArray[0];
			for (int x1=x1min; x1<sieveArraySize; x1+=2) {
				sieve_logPSumArray[x1] += logP;
			}
			// same for the neg.x array
			for (int x1_neg=2-x1min; x1_neg<sieveArraySize; x1_neg+=2) {
				sieve_logPSumArray_neg[x1_neg] += logP;
			}
		}
		// sieve with odd primes
		for (int i=1; i<primeBaseSize; i++) {
			// solution x1
			x1min = x1Array[i];
			if (x1min > -1) { // sieve with this solution
				int p = primesArray[i];
				byte logP = ldPArray[i];
				for (int x1=x1min; x1<sieveArraySize; x1+=p) {
					sieve_logPSumArray[x1] += logP;
				}
				for (int x1_neg=p-x1min; x1_neg<sieveArraySize; x1_neg+=p) {
					sieve_logPSumArray_neg[x1_neg] += logP;
				}
				// solution x2
				int x2min = x2Array[i];
				// with MPQS we never get x2min==x1min, but with QS it can happen if Legendre(kN|p)==0 -> t=0
				if (x2min != x1min) {
					for (int x2=x2min; x2<sieveArraySize; x2+=p) {
						sieve_logPSumArray[x2] += logP;
					}
					for (int x2_neg=p-x2min; x2_neg<sieveArraySize; x2_neg+=p) {
						sieve_logPSumArray_neg[x2_neg] += logP;
					}
				} // else x2min==x1min -> do not sieve with the same x twice
			}
		}
		long t2 = System.currentTimeMillis();
		if (profile) sieveDuration += (t2-t1);

		// compute sieve bound in natural logarithm & convert to the actual logBase:
		float logBase = poly.getLogBase();
		double minLnPSum = computeSieveBound(poly, primesArray[primeBaseSize-1], sieveArraySize);
		int minLogPSum = (int) (minLnPSum / Math.log(logBase)); // floor
		//LOG.debug("minLnPSum = " + minLnPSum + ", minLogPSum = " + minLogPSum);
		// collect results
		List<Integer> smoothXList = new ArrayList<Integer>();
		// let the sieve entry counter x run down to 0 is much faster because of the simpler exit condition
		for (int x=sieveArraySize-1; x>=0; x--) {
			if (sieve_logPSumArray[x] >= minLogPSum) { // x is positive
				// Q is sufficiently smooth to be passed to trial division!
				smoothXList.add(x);
			}
			if (sieve_logPSumArray_neg[x] >= minLogPSum) {
				// Q(-x) is sufficiently smooth to be passed to trial division!
				smoothXList.add(-x);
			}
		} // end for (x)
		if (profile) collectDuration += (System.currentTimeMillis()-t2);
		return smoothXList;
	}
	
	private double computeSieveBound(Poly poly, int maxPrime, int sieveArraySize) {
		BigInteger kN = poly.getkN();
		BigInteger a = poly.getAParameter();
		double lnkN = Math.log(kN.doubleValue());
		double lna = Math.log(a.doubleValue());
		double lnM = Math.log(sieveArraySize);
		double lnPMax = Math.log(maxPrime);
		switch (sieveBoundStyle) {
		case 0: {
			double lnQdivAEstimate = lnkN - lna; // |Q(x)| <= kN, thus ld(|Q(x)|/a) <= ld(kN) - ld(a)
			double lnMaxAllowedRest = T * lnN; // my choice
			return lnQdivAEstimate - lnMaxAllowedRest;
		} case 1: {
			double lnQdivAEstimate = lnM + lnkN/2 - 0.5; // [Contini], [Pomerance], [Silverman] etc.
			double lnMaxAllowedRest = T * lnN; // my choice
			return lnQdivAEstimate - lnMaxAllowedRest;
		} case 2: {
			double lnQdivAEstimate = lnkN - lna; // |Q(x)| <= kN, thus ld(|Q(x)|/a) <= ld(kN) - ld(a)
			double lnMaxAllowedRest = T * lnPMax; // [Silverman]
			return lnQdivAEstimate - lnMaxAllowedRest;
		} case 3: {
			double lnQdivAEstimate = lnM + lnkN/2 - 0.5; // [Contini], [Pomerance], [Silverman] etc.
			double lnMaxAllowedRest = T * lnPMax; // [Silverman]
			return lnQdivAEstimate - lnMaxAllowedRest;
		} default: throw new IllegalStateException("Unsupported sieveBoundStyle = " + sieveBoundStyle);
		}
	}
	
	/**
	 * Initialize the sieve array(s) with zeros.
	 * @param sieveArraySize
	 */
	private void initializeSieveArray(int sieveArraySize) {
		// The arrays are allocated lazily at the first call of this method for some N
		// to conform with basic QS, which adjusts the sieve array size in nextPoly().
		// If the sieve array size does not change in subsequent invocations, then System.arraycopy() is used,
		// which is by far the fastest choice. This also prepares the way to initialize the sieve array with values other than 0.
		// The copying procedure requires that sieveArraySize is a multiple of 256.
		if (lastSieveArraySize==null || sieveArraySize>lastSieveArraySize) {
			sieve_logPSumArray = new byte[sieveArraySize];
			sieve_logPSumArray_neg = new byte[sieveArraySize];
			lastSieveArraySize = Integer.valueOf(sieveArraySize);
		} else {
			// overwrite existing arrays with zeros. we know that sieve array size is a multiple of 256
			System.arraycopy(ZERO_ARRAY_256, 0, sieve_logPSumArray, 0, 256);
			int filled = 256;
			int unfilled = sieveArraySize-filled;
			while (unfilled>0) {
				int fillNext = Math.min(unfilled, filled);
				System.arraycopy(sieve_logPSumArray, 0, sieve_logPSumArray, filled, fillNext);
				filled += fillNext;
				unfilled = sieveArraySize-filled;
			}
			System.arraycopy(sieve_logPSumArray, 0, sieve_logPSumArray_neg, 0, sieveArraySize);
		}
	}

	@Override
	public String getProfilingReport() {
		return "init=" + initDuration + "ms, sieve=" + sieveDuration + "ms, collect=" + collectDuration + "ms";
	}
	
	@Override
	public void cleanUp() {
		sieve_logPSumArray = null;
		sieve_logPSumArray_neg = null;
	}
}
