/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * This file is part of the PSIQS package version 01 from 2016-01-07, 
 * developed by Tilman Neumann, Edemissen, Germany.
 * 
 * Use and redistribution of PSIQS are free for non-commercial purposes, as long as this
 * header is not modified or removed. Any commercial usage of the whole or parts
 * of PSIQS requires the written consent of the author.
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

package de.tilman_neumann.math.factor.qs.tdiv;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import de.tilman_neumann.math.factor._basics.SortedBigIntegerArray;
import de.tilman_neumann.math.factor._basics.SortedIntegerArray;
import de.tilman_neumann.math.factor._congruence.AQPair;
import de.tilman_neumann.math.factor._congruence.AQPair01;
import de.tilman_neumann.math.factor.qs.Poly;

import static de.tilman_neumann.math.base.bigint.BigIntConstants.*;
import static org.junit.Assert.*;

/**
 * A trial division engine where partials can only have a single big factor.
 * 
 * Division is carried out with BigIntegers.
 * 
 * @author Tilman Neumann
 */
public class TDiv_QS01 implements TDiv_QS {
	private static final Logger LOG = Logger.getLogger(TDiv_QS01.class);
	private static final boolean DEBUG = false;
	
	private float T;
	private Poly poly;
	private BigInteger aParam;
	/** Q is sufficiently smooth if the unfactored Q_rest is smaller than this bound depending on N */
	private double maxUnfactoredRest;

	// prime base
	private int[] primesArray;
	private BigInteger[] primesArray_big;
	private int primeBaseSize;
	
	/** the indices of the primes found to divide Q in pass 1 */
	private int[] pass2PrimeIndices = new int[100];

	 // smallest solutions of Q(x) == A(x)^2 (mod p)
	private int[] x1Array, x2Array;
	
	// result: two arrays that are reused, their content is _copied_ to AQ-pairs
	private SortedIntegerArray smallFactors = new SortedIntegerArray();
	private SortedBigIntegerArray bigFactors = new SortedBigIntegerArray();
	
	// statistics
	private long testCount, sufficientSmoothCount;
	
	public TDiv_QS01(int primeTestBits, float T) {
		this.T = T;
	}

	@Override
	public String getName() {
		return "TDiv01(" + T + ")";
	}

	@Override
	public void initialize(double N_dbl, int primeBaseSize) {
		this.primeBaseSize = primeBaseSize; // do not use primesArray.length !
		// compute the biggest unfactored rest where some Q is considered smooth enough for a congruence.
		this.maxUnfactoredRest = Math.pow(N_dbl, T);
		// statistics
		this.testCount = 0;
		this.sufficientSmoothCount = 0;
	}

	@Override
	public List<AQPair> testList(Poly poly, List<Integer> xList) {
		// initialize some variables
		this.poly = poly;
		this.aParam = poly.getAParameter();
		this.primesArray = poly.getPrimesArray();
		this.primesArray_big = poly.getPrimesArray_big();
		this.x1Array = poly.getX1Array();
		this.x2Array = poly.getX2Array();
		
		// do trial division with sieve result
		ArrayList<AQPair> aqPairs = new ArrayList<AQPair>();
		for (int x : xList) {
			smallFactors.reset();
			bigFactors.reset();
			testCount++;
			BigInteger[] AandQ = poly.computeAandQ(x);
			BigInteger Q = AandQ[1];
			if (test(Q, x)) {
				// Q(x) was found sufficiently smooth to be considered a (partial) congruence
				BigInteger A = AandQ[0];
				AQPair aqPair = new AQPair01(A, Q, smallFactors, bigFactors);
				if (DEBUG) {
					LOG.debug("Found AQ-pair " + aqPair);
					BigInteger kN = poly.getkN();
					assertEquals(A.multiply(A).mod(kN), Q.mod(kN));
				}
				aqPairs.add(aqPair);
				sufficientSmoothCount++;
			}
		}
		return aqPairs;
	}
	
	private boolean test(BigInteger Q, int x) {
		// sign
		BigInteger Q_rest = Q;
		if (Q.signum() < 0) {
			smallFactors.add(-1);
			Q_rest = Q.negate();
		}
		
		// Remove multiples of 2
		int lsb = Q_rest.getLowestSetBit();
		if (lsb > 0) {
			for (int i=0; i<lsb; i++) {
				smallFactors.add(2);
			}
			Q_rest = Q_rest.shiftRight(lsb);
		}

		if (aParam.compareTo(ONE)>0) {
			// Remove non-prime base elements dividing any Q(x):
			// This is only used by MPQS, where the fix factor of any Q(x) is a=q^2:
			BigInteger[] fixBigQDivisors = poly.getNonPrimeBaseElementsDividingAnyQ();
			if (fixBigQDivisors!=null && fixBigQDivisors.length>0) {
				BigInteger fixDivisor = fixBigQDivisors[0];
				bigFactors.add(fixDivisor);
				bigFactors.add(fixDivisor);
				BigInteger div[] = Q_rest.divideAndRemainder(aParam);
				Q_rest = div[0];
				if (DEBUG) {
					assertEquals(1, fixBigQDivisors.length);
					assertEquals(aParam, fixDivisor.multiply(fixDivisor));
					assertEquals(ZERO, div[1]); // remainder == 0
				}
			}
	
			// Remove prime base elements dividing any Q(x):
			// This is only used in SIQS, where the fix factor is a = q1*...*q_s.
			int[] fixSmallQDivisors = poly.getPrimeBaseElementsDividingAnyQ();
			if (fixSmallQDivisors!=null && fixSmallQDivisors.length>0) {
				// Pass 1: Remove a single occurence of all q_l
				for (int fixDivisor : fixSmallQDivisors) {
					smallFactors.add(fixDivisor);
				}
				Q_rest = Q_rest.divide(aParam);
				// Pass 2: Remove further occurences:
				BigInteger[] div;
				for (int fixDivisor : fixSmallQDivisors) {
					BigInteger fixDivisor_big = BigInteger.valueOf(fixDivisor);
					// divide as often as possible
					while (true) {
						div = Q_rest.divideAndRemainder(fixDivisor_big);
						if (div[1].compareTo(ZERO)>0) break; // rest > 0 -> we are finished with the current q_l
						// else the division was exact
						smallFactors.add(fixDivisor);
						Q_rest = div[0];
					}
				}
			}
		}
		//LOG.debug("Q_rest = " + Q_rest);
		if (Q_rest.equals(ONE)) return true; // perfectly smooth
		
		// Pass 1: test solution arrays.
		// Starting at the biggest prime base elements is faster because then Q_rest is reduced quicker in pass2.
		int pass2IndexCount = 0;
		BigInteger pass1DivisorProduct = ONE;
		for (int pIndex = primeBaseSize-1; pIndex > 0; pIndex--) { // p[0]=2 was already tested
			int x1 = x1Array[pIndex];
			if (x1 > -1) {
				int p = primesArray[pIndex];
				int xModP = x % p;
				if (xModP<0) xModP += p; // make remainder non-negative for negative x
				if (DEBUG) {
					if (xModP<0) LOG.debug("x=" + x + ", p=" + p + " -> x % p = " + xModP + ", x1 = " + x1 + ", x2 = " + x2Array[pIndex]);
					assertTrue(0<=xModP && xModP<p);
				}
				if (xModP==x1 || xModP==x2Array[pIndex]) {
					// p divides Q(x)
					if (DEBUG) assertEquals(ZERO, Q_rest.mod(primesArray_big[pIndex]));
					smallFactors.add(p);
					pass1DivisorProduct = pass1DivisorProduct.multiply(primesArray_big[pIndex]);
					pass2PrimeIndices[pass2IndexCount++] = pIndex;
				}
			}
		}
		
		if (pass1DivisorProduct.compareTo(ONE)>0) {
			// remove first occurences of all divisors at once:
			Q_rest = Q_rest.divide(pass1DivisorProduct);
			if (Q_rest.equals(ONE)) return true;
	
			// Pass 2: remove further occurrences of the p_i that were found to divide Q
			BigInteger div[];
			for (int pass2Index = 0; pass2Index < pass2IndexCount; pass2Index++) {
				int pIndex = pass2PrimeIndices[pass2Index];
				BigInteger pBig = primesArray_big[pIndex];
				while (true) {
					div = Q_rest.divideAndRemainder(pBig);
					if (div[1].compareTo(ZERO)>0) break;
					smallFactors.add(primesArray[pIndex]);
					Q_rest = div[0];
					if (Q_rest.equals(ONE)) return true;
				}
			}
		}
		
		// trial division was not sufficient to factor Q completely.
		// the remaining Q is either a prime > maxPrime, or a composite > maxPrime^2.
		if (Q_rest.doubleValue() >= maxUnfactoredRest) return false; // Q is not sufficiently smooth
		
		// Q is sufficiently smooth
		if (DEBUG) LOG.debug("Sufficient smooth big factor = " + Q_rest);
		bigFactors.add(Q_rest);
		return true;
	}
	
	@Override
	public String getReportString() {
		float percentage = ((int) (0.5F + sufficientSmoothCount*10000 / (float) testCount)) / 100F; // 2 after-comma digits
		return "tested " + testCount + " smooth-candidates and let " + sufficientSmoothCount + " (" + percentage + "%) pass";
	}
	
	@Override
	public void cleanUp() {
		poly = null;
		primesArray = null;
		primesArray_big = null;
		x1Array = null;
		x2Array = null;
	}
}
