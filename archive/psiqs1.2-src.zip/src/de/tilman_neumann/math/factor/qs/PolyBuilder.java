/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * This file is part of the PSIQS package version 01 from 2016-01-07, 
 * developed by Tilman Neumann, Edemissen, Germany.
 * 
 * Use and redistribution of PSIQS are free for non-commercial purposes, as long as this
 * header is not modified or removed. Any commercial usage of the whole or parts
 * of PSIQS requires the written consent of the author.
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

package de.tilman_neumann.math.factor.qs;

import java.math.BigInteger;

import de.tilman_neumann.math.factor.FactorException;

/**
 * Interface for polynomial builders.
 * @author Tilman Neumann
 */
public interface PolyBuilder {

	/**
	 * @return the name of this polynomial builder
	 */
	String getName();

	/**
	 * Initialize the polynomial builder for a new N.
	 * @param N
	 * @param primeBaseSize
	 * @param proposedSieveArraySize
	 */
	void initialize(BigInteger N, int primeBaseSize, double proposedSieveArraySize, boolean profile);

	/**
	 * Compute a new polynomial.
	 * @return
	 * @throws FactorException
	 */
	Poly nextPolynomial() throws FactorException;

	/**
	 * @return the adjusted sieve array size.
	 * Adjustment is necessary for small N to assure that the sieve array is bigger than maxPrime;
	 * otherwise there might be smallest x-solutions lying outside the sieve array,
	 * forcing us to do additional checks in the sieve.
	 */
	int getAdjustedSieveArraySize();

	/**
	 * @return number of polynomials created yet
	 */
	int getPolyCount();

	/**
	 * @return description of the durations of the individual sub-phases
	 */
	String getProfilingReport();
	
	/**
	 * Release memory after a factorization.
	 */
	void cleanUp();
}
