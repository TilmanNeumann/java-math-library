/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * This file is part of the PSIQS package version 01 from 2016-01-07, 
 * developed by Tilman Neumann, Edemissen, Germany.
 * 
 * Use and redistribution of PSIQS are free for non-commercial purposes, as long as this
 * header is not modified or removed. Any commercial usage of the whole or parts
 * of PSIQS requires the written consent of the author.
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

package de.tilman_neumann.math.factor.qs.sieve;

import java.util.List;

import de.tilman_neumann.math.factor.qs.Poly;

/**
 * Interface for sieve algorithms.
 * @author Tilman Neumann
 */
public interface Sieve {
	
	/**
	 * @return the name of this sieve algorithm
	 */
	String getName();
	
	/**
	 * Initialize for a new N.
	 * @param N_dbl
	 * @param primeBaseSize
	 * @param profile get phase timings?
	 */
	void initialize(double N_dbl, int primeBaseSize, boolean profile);
	
	/**
	 * Do the sieving.
	 * @param poly polynomial having x-solution arrays
	 * @param sieveArraySize 
	 * @return list of sieve locations x where Q(x) is smooth enough to be passed to trial division
	 */
	List<Integer> sieve(Poly poly, int sieveArraySize);

	/**
	 * @return description of the durations of the individual sub-phases
	 */
	String getProfilingReport();
	
	/**
	 * Release memory after a factorization.
	 */
	void cleanUp();
}
