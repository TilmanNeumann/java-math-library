/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * This file is part of the PSIQS package version 01 from 2016-01-07, 
 * developed by Tilman Neumann, Edemissen, Germany.
 * 
 * Use and redistribution of PSIQS are free for non-commercial purposes, as long as this
 * header is not modified or removed. Any commercial usage of the whole or parts
 * of PSIQS requires the written consent of the author.
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

package de.tilman_neumann.math.factor.qs.tdiv;

import java.math.BigInteger;
import java.util.Arrays;

import org.apache.log4j.Logger;

import de.tilman_neumann.util.ConfigUtil;

import static de.tilman_neumann.math.base.bigint.BigIntConstants.*;
import static org.junit.Assert.*;

/**
 * A very limited unsigned big integer implementation well suited for trial division.
 * 
 * Using this class greatly reduces the number of intermediate objects created during trial division.
 * 
 * Performance seems to be slightly better than BigInteger.divide() (which implements Knuth division algorithm).
 * 
 * @author Tilman Neumann
 */
public class UnsignedBigInt {
	private static final Logger LOG = Logger.getLogger(UnsignedBigInt.class);
	private static final boolean DEBUG = false;
	
	private static final BigInteger UNSIGNED_INT_MASK_BIG = BigInteger.valueOf(0xFFFFFFFFL);

	private int intLength;
	private int[] intArray;
	/** a buffer to compute quotients */
	private int[] quotientArray;
	
	/**
	 * Constructor from BigInteger.
	 * The buffers must be big enough to represent N. They are re-used all the time to reduces the number of newly allocated objects
	 * and hence the garbage collector load.
	 * 
	 * @param N
	 * @param buf1 an int[] big enough to represent N
	 * @param buf2 another int[] big enough to represent N
	 */
	public UnsignedBigInt(BigInteger N, int[] buf1, int[] buf2) {
		int bits = N.bitLength(); // e.g. N=3 has 2 bits
		this.intLength = (bits+31)>>5; // round up
		
		// bytes in big-endian order, i.e. the most significant byte is at index 0
		byte[] bytes = N.toByteArray();
		// convert byte[] to unsigned int[]
		this.intArray = buf1; // not 0-initialized
		for (int i=intLength-1; i>=0; i--) intArray[i] = 0;
		//LOG.debug("#bytes = " + bytes.length + ", #ints = " + intLength);
		int i=0, j=0;
		for (int bPos=bytes.length-1; bPos>=0; bPos--) {
			int b = bytes[bPos] & 0xFF;
			intArray[i] |= b<<(j<<3);
			if (++j==4) {
				if (++i == intLength) {
					// The most significant byte of N.toByteArray() has a sign bit, which is 0 for unsigned integers.
					// But it may lead to another byte! -> skip that one...
					//LOG.debug("i has reached maximum value " + i);
					break;
				}
				j = 0;
			}
		}
		
		if (DEBUG) {
			// compare with slower but safer implementation
			int[] intArrayFromNShifts = new int[intLength];
			for (int i2=0; i2<intLength; i2++) {
				intArrayFromNShifts[i2] = N.and(UNSIGNED_INT_MASK_BIG).intValue();
				N = N.shiftRight(32);
			}
			assertTrue(Arrays.equals(intArrayFromNShifts, intArray));
		}
		
		this.quotientArray = buf2;
	}
	
	public boolean isOne() {
		if (intLength==0 || intArray[0]!=1) return false;
		for (int i=intLength-1; i>0; i--) {
			if (intArray[i]!=0) return false;
		}
		return true;
	}
	
    /**
     * Divide this by the given divisor if the division is exact, else do nothing.
     * @param divisor
     * @return remainder
     */
    public int mutableDivideByInt_ifExact(final int divisor) {
    	// 1. We can not have intLength==0 because we only do exact divisions.
    	// 2. It seems to be slightly favorable to treat the case intLength==1 first.
    	// 3. A special treatment of intLength==2 does not pay out.
    	if (intLength==1) {
    		long dividend = intArray[0] & 0xFFFFFFFFL;
    		long quot = dividend / divisor;
    		// rem = dividend % divisor is faster than dividend - quot*divisor (figured out in experiments with 100 N)
     		int rem = (int) (dividend % divisor);
    		if (rem == 0) {
    			intArray[0] = (int) quot;
    		}
			return rem;
    	}

    	// intLength > 1
        long rem = 0;
        long divisor_long = divisor & 0xFFFFFFFFL;
        long currentDividend, quot;
        for (int i = intLength-1; i >= 0; i--) {
            currentDividend = (rem << 32) | (intArray[i] & 0xFFFFFFFFL);
            quot = currentDividend / divisor_long;
    		// rem = currentDividend % divisor_long is faster than currentDividend - quot*divisor_long (figured out in experiments with 100 N)
            rem = currentDividend % divisor_long;
            //if (DEBUG) {
            //	assertTrue(currentDividend >= 0);
            //	assertTrue(quot <= 0xFFFFFFFFL);
            //}
            quotientArray[i] = (int) (quot & 0xFFFFFFFFL);
        }

        if (rem == 0) {
        	// division was exact
        	int[] tmpArray = this.intArray;
        	this.intArray = quotientArray;
        	this.quotientArray = tmpArray;
            // determine new intLength
            for (int i = intLength-1; i >= 0; i--) {
            	if (intArray[i]!=0) break;
            	intLength--;
            }
        }
        return (int) rem;
    }

    public boolean equals(Object o) {
    	if (o==null || !(o instanceof UnsignedBigInt)) return false;
    	UnsignedBigInt other = (UnsignedBigInt) o;
    	if (intLength!=other.intLength) return false;
    	for (int i=intLength-1; i>=0; i--) {
    		if (intArray[i]!=other.intArray[i]) return false;
    	}
    	return true;
    }
    
	public BigInteger toBigInteger() {
		//LOG.debug("intLength = " + intLength);
		if (intLength==0) return ZERO;
		if (intLength==1) return BigInteger.valueOf(intArray[0] & 0xFFFFFFFFL);
		// For intLength==2 we already need byte[], because intArray[1]<<32 could be a negative long
		int byteLength = intLength<<2;
		byte[] bytes = new byte[byteLength+1]; // add one extra-byte to assure that there is a zero sign-bit
		for (int i = 0; i < intLength; i++) {
			long digit = intArray[i] & 0xFFFFFFFFL; // the long mask avoids negative values
			int bPos = byteLength - (i<<2);
			bytes[bPos] = (byte) (digit & 0xFF);
			bytes[--bPos] = (byte) (digit / 0x100 & 0xFF);
			bytes[--bPos] = (byte) (digit / 0x10000 & 0xFF);
			bytes[--bPos] = (byte) (digit / 0x1000000 & 0xFF);
		}
		BigInteger N = new BigInteger(bytes);
		
		if (DEBUG) {
			// compare with slower but safer implementation
			BigInteger NfromShifts = BigInteger.valueOf(intArray[intLength-1] & 0xFFFFFFFFL);
			for (int i=intLength-2; i>=0; i--) {
				NfromShifts = NfromShifts.shiftLeft(32).add(BigInteger.valueOf(intArray[i] & 0xFFFFFFFFL));
			}
			assertEquals(NfromShifts, N);
		}
		return N;
	}

	public String toString() {
		return this.toBigInteger().toString();
	}
	
	// test
	public static void main(String[] args) {
		ConfigUtil.initProject();
		
		// test conversion
		int[] buf1 = new int[50], buf2 = new int[50];
		for (BigInteger N=ZERO; N.compareTo(THOUSAND)<=0; N=N.add(ONE)) {
			UnsignedBigInt int31 = new UnsignedBigInt(N, buf1, buf2);
			BigInteger N2 = int31.toBigInteger();
			LOG.debug("N=" + N + ", N2=" + N2);
			assertEquals(N, N2);
		}
	}
}
