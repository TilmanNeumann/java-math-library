/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * This file is part of the PSIQS package version 01 from 2016-01-07, 
 * developed by Tilman Neumann, Edemissen, Germany.
 * 
 * Use and redistribution of PSIQS are free for non-commercial purposes, as long as this
 * header is not modified or removed. Any commercial usage of the whole or parts
 * of PSIQS requires the written consent of the author.
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

package de.tilman_neumann.math.factor.qs.sieve;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import de.tilman_neumann.math.factor.qs.Poly;

/**
 * Sieve implementation that sieves on positive and negative x-values.
 * 
 * Version 03:
 * -> The smallest primes are not used for sieving.
 *    A prime p makes an overall contribution proportional to log(p)/p to the sieve array,
 *    but the runtime of sieving with a prime p is proportional to sieveArraySize/p.
 *    Thus sieving with small primes is less effective, and skipping them improves performance.
 * -> Let counters run down -> simpler termination condition
 * -> Faster zero-initialization of sieve array with System.arrayCopy().
 * -> use byte[] for sieve array.
 * -> a few more optimizations
 * 
 * Version 04:
 * -> Initialize sieve array such that a sieve hit is achieved if (logPSum & 0x80) != 0,
 *    and then use the or-trick in sieve:collect.
 * -> precompute minSolutionCounts for all p
 * -> add two p at once to two sieve locations using longs
 *    [Sengupta/Das 2013: "Use of SIMD-Based Data Parallelism to Speed up Sieving in Integer-Factoring Algorithms"]
 * -> allocate sieveArray with 'maxPrime' extra entries to save size checks
 * 
 * @author Tilman Neumann
 */
public class Sieve04 implements Sieve {
	@SuppressWarnings("unused")
	private static final Logger LOG = Logger.getLogger(Sieve04.class);

	/**
	 * How to compute the initializer value:
	 * 0: no contribution from small primes.
	 * 1: contribution without prime powers -> clearly the best choice!
	 * 2: corrected contribution without prime powers
	 * 3: contribution with prime powers
	 */
	private int initializerStyle;
	/** How to compute the logPSum threshold value */
	private int sieveBoundStyle;
	private float T;
	private float lnN;
	private int primeBaseSize;
	private float pMinMult;
	private int pMinIndex;
	
	// precomputed stuff
	private int[] minSolutionCounts;
	private long[] ppArray;
	
	/** basic building block for fast initialization of sieve array */
	private byte[] initializer = new byte[256];

	// sieve array
	private byte[] sieve_logPSumArray, sieve_logPSumArray_neg;
	private Integer lastSieveArraySize;
	private int lastMaxPrime;

	// timings
	private boolean profile;
	private long initDuration, sieveDuration, collectDuration;

	public Sieve04(int sieveBoundStyle, float T, float pMinMult, int initializerStyle) {
		this.sieveBoundStyle = sieveBoundStyle;
		this.T = T;
		this.pMinMult = pMinMult;
		this.initializerStyle = initializerStyle;
	}
	
	@Override
	public String getName() {
		return "sieve04(" + sieveBoundStyle + ", " + T + ", " + pMinMult + ", " + initializerStyle + ")";
	}
	
	@Override
	public void initialize(double N_dbl, int primeBaseSize, boolean profile) {
		this.lnN = (float) Math.log(N_dbl);
		this.primeBaseSize = primeBaseSize;
		this.ppArray = new long[primeBaseSize];
		this.minSolutionCounts = new int[primeBaseSize];
		this.pMinIndex = Math.max(1, (int) (pMinMult * Math.log(primeBaseSize))); // avoid p[0]==2; the case was removed in the sieve method
		this.lastSieveArraySize = null; // indicate that allocating the sieve arrays is required
		// profiling
		this.profile = profile;
		initDuration = 0;
		sieveDuration = 0;
		collectDuration = 0;
	}

	@Override
	public List<Integer> sieve(Poly poly, int sieveArraySize) {
		long t0 = System.currentTimeMillis();
		int[] primesArray = poly.getPrimesArray();
		// compute sieve bound in natural logarithm & convert to the actual logBase:
		float logBase = poly.getLogBase();
		double lnLogBase = Math.log(logBase);
		int maxPrime = primesArray[primeBaseSize-1];
		double minLnPSum = computeSieveBound(poly, maxPrime, sieveArraySize);
		int minLogPSum = (int) (minLnPSum / lnLogBase); // floor
		//LOG.debug("minLnPSum = " + minLnPSum + ", minLogPSum = " + minLogPSum);
		if (poly.hasNewPrimeBase()) {
			computePPArray(primesArray);
			computeMinSolutionCounts(primesArray, sieveArraySize);
			computeInitializer(primesArray, minLogPSum, lnLogBase);
		}
		this.initializeSieveArray(sieveArraySize, maxPrime);
		long t1 = System.currentTimeMillis();
		if (profile) initDuration += (t1-t0);

		// Sieve with odd primes:
		// The sieve array size has been chosen > maxPrime,
		// so that for each prime there is at least one x-solution inside the sieve array.
		// This saves us some extra checks.
		byte[] logPArray = poly.getLogPArray();
		int[] x1Array = poly.getX1Array();
		int[] x2Array = poly.getX2Array();
		int i, x1, x2, j;
		long x1_x1_neg, x2_x2_neg;
		for (i=primeBaseSize-1; i>=pMinIndex; i--) {
			if ((x1 = x1Array[i]) != -1) { // sieve with this p (x1 = x2 = -1 happens only in SIQS)
				final int p = primesArray[i];
				final byte logP = logPArray[i];
				// [Sengupta/Das 2013] use the vector operations provided by SSE/AVX extensions to add p to several x-solutions at once.
				// In Java, the SIMD registers can not be used explicitly; instead, since Java 8 the JVM tries to vectorize
				// "suitably formulated" loop instructions; unfortunately, having if-branches in a loop seems to bar vectorization.
				// Nevertheless we can use their "trick" to do two integer additions in one long-addition; that's what pp is needed for.
				final long pp = ppArray[i];
				x1_x1_neg = (((long)x1)<<32) | (p-x1); // x1_neg = p-x1
				if ((x2 = x2Array[i]) != x1) { // two x-solutions
					x2_x2_neg = (((long)x2)<<32) | (p-x2); // x2_neg = p-x2
					//LOG.debug("p=" + p + ", x1=" + x1 + ", x2=" + x2);
					// the biggest sieve location may be out off array bounds, but we allocated the arrays somewhat bigger to save the size checks
					for (j=minSolutionCounts[i]; j>=0; j--, x1_x1_neg+=pp, x2_x2_neg+=pp) {
						sieve_logPSumArray    [(int)(x1_x1_neg>>32)          ] += logP;
						sieve_logPSumArray_neg[(int)(x1_x1_neg & 0xFFFFFFFFL)] += logP;
						sieve_logPSumArray    [(int)(x2_x2_neg>>32)          ] += logP;
						sieve_logPSumArray_neg[(int)(x2_x2_neg & 0xFFFFFFFFL)] += logP;
					}
				} else {
					// only one x-solution
					//LOG.debug("p=" + p + ", x1=" + x1);
					for (j=minSolutionCounts[i]; j>=0; j--, x1_x1_neg+=pp) {
						sieve_logPSumArray    [(int)(x1_x1_neg>>32)          ] += logP;
						sieve_logPSumArray_neg[(int)(x1_x1_neg & 0xFFFFFFFFL)] += logP;
					}
				} // end if (x2 == x1)
			} // end if (x1 > -1)
		} // end for (p)
		long t2 = System.currentTimeMillis();
		if (profile) sieveDuration += (t2-t1);

		// collect results
		List<Integer> smoothXList = new ArrayList<Integer>();
		// let the sieve entry counter x run down to 0 is much faster because of the simpler exit condition
		for (int x=sieveArraySize-1; x>=0; ) {
			// Unfortunately, in Java we can not cast byte[] to int[] or long[].
			// So we have to use 'or'. More than 4 'or's do not pay out.
			if (((sieve_logPSumArray[x] | sieve_logPSumArray_neg[x--]
	            | sieve_logPSumArray[x] | sieve_logPSumArray_neg[x--]) & 0x80) != 0) {
				// at least one of the tested Q(x), Q(-x) is sufficiently smooth to be passed to trial division!
				if (sieve_logPSumArray    [x+1] < 0) smoothXList.add(  x+1);
				if (sieve_logPSumArray    [x+2] < 0) smoothXList.add(  x+2);
				if (sieve_logPSumArray_neg[x+1] < 0) smoothXList.add(-(x+1));
				if (sieve_logPSumArray_neg[x+2] < 0) smoothXList.add(-(x+2));
			}
		} // end for (x)
		if (profile) collectDuration += (System.currentTimeMillis()-t2);
		return smoothXList;
	}

	private void computePPArray(int[] primesArray) {
		int i;
		for (i=primeBaseSize-1; i>=pMinIndex; i--) {
			final int p = primesArray[i];
			ppArray[i] = (((long)p)<<32) | p;
		}
	}
	
	private void computeMinSolutionCounts(int[] primesArray, int sieveArraySize) {
		// The minimum number of x-solutions in the sieve array is floor(sieveArraySize/p).
		// E.g. for p=3, sieveArraySize=8 there are solutions (0, 3, 6), (1, 4, 7), (2, 5)  <-- 8 is not in sieve array anymore
		// -> minSolutionCount = 2
		// However if x1min=0 then x1_neg = p and we would get an ArrayIndexOutOfBoundsException at the last sieve location.
		// To solve that problem we compute minSolutionCount = floor((sieveArraySize-1)/p)
		int sieveArraySize_m1 = sieveArraySize-1;
		int i;
		for (i=primeBaseSize-1; i>=pMinIndex; i--) {
			minSolutionCounts[i] = sieveArraySize_m1/primesArray[i];
		}
	}

	private double computeSieveBound(Poly poly, int maxPrime, int sieveArraySize) {
		BigInteger kN = poly.getkN();
		BigInteger a = poly.getAParameter();
		double lnkN = Math.log(kN.doubleValue());
		double lna = Math.log(a.doubleValue());
		double lnM = Math.log(sieveArraySize);
		double lnPMax = Math.log(maxPrime);
		switch (sieveBoundStyle) {
		case 0: {
			double lnQdivAEstimate = lnkN - lna; // |Q(x)| <= kN, thus ld(|Q(x)|/a) <= ld(kN) - ld(a)
			double lnMaxAllowedRest = T * lnN; // my choice
			return lnQdivAEstimate - lnMaxAllowedRest;
		} case 1: {
			double lnQdivAEstimate = lnM + lnkN/2 - 0.5; // [Contini], [Pomerance], [Silverman] etc.
			double lnMaxAllowedRest = T * lnN; // my choice
			return lnQdivAEstimate - lnMaxAllowedRest;
		} case 2: {
			double lnQdivAEstimate = lnkN - lna; // |Q(x)| <= kN, thus ld(|Q(x)|/a) <= ld(kN) - ld(a)
			double lnMaxAllowedRest = T * lnPMax; // [Silverman]
			return lnQdivAEstimate - lnMaxAllowedRest;
		} case 3: {
			double lnQdivAEstimate = lnM + lnkN/2 - 0.5; // [Contini], [Pomerance], [Silverman] etc.
			double lnMaxAllowedRest = T * lnPMax; // [Silverman]
			return lnQdivAEstimate - lnMaxAllowedRest;
		} default: throw new IllegalStateException("Unsupported sieveBoundStyle = " + sieveBoundStyle);
		}
	}

	/**
	 * Compute the initializer value according to initializerStyle, and fill the initializerArray with that value.
	 * @param primesArray a new prime base
	 * @param minLogPSum
	 * @param lnLogBase
	 */
	private void computeInitializer(int[] primesArray, int minLogPSum, double lnLogBase) {
		// compute contribution of small primes
		double logSmallPSum = 0;
		switch (initializerStyle) {
		case 0: {
			break; // no contribution from small primes
		} case 1: {
			// contribution from small primes, not counting powers
			for (int i=pMinIndex-1; i>=0; i--) {
				int p = primesArray[i];
				logSmallPSum += Math.log(p) / (lnLogBase*p);
			}
			break;
		} case 2: {
			// contribution from small primes, not counting powers, correction
			for (int i=pMinIndex-1; i>=0; i--) {
				int p = primesArray[i];
				logSmallPSum += Math.log(p) / (lnLogBase*(p-1));
			}
			break;
		} case 3: {
			// contribution from small primes, counting powers
			for (int i=pMinIndex-1; i>=0; i--) {
				int p = primesArray[i];
				logSmallPSum += p*Math.log(p) / (lnLogBase*(p-1)*(p-1));
			}
			break;
		} default: throw new IllegalArgumentException("Unsupported initializerStyle = " + initializerStyle);
		}
		// compute initializerValue, rounded
		byte initializerValue = (byte) (128 - minLogPSum + logSmallPSum + 0.5);
		//LOG.debug("initializerValue = " + initializerValue);
		
		// fill initializer with that value
		for (int i=255; i>=0; i--) initializer[i] = initializerValue;
	}

	/**
	 * Initialize the sieve array(s) with zeros.
	 * @param sieveArraySize
	 */
	private void initializeSieveArray(int sieveArraySize, int maxPrime) {
		// The arrays are allocated lazily at the first call of this method for some N.
		// to conform with basic QS, which adjusts the sieve array size in nextPoly().
		// If the sieve array size does not change in subsequent invocations, then System.arraycopy() is used,
		// which is by far the fastest choice. This also prepares the way to initialize the sieve array with values other than 0.
		// The copying procedure requires that sieveArraySize is a multiple of 256.
		if (lastSieveArraySize==null || (sieveArraySize+maxPrime)>(lastSieveArraySize+lastMaxPrime)) {
			sieve_logPSumArray = new byte[sieveArraySize + maxPrime];
			sieve_logPSumArray_neg = new byte[sieveArraySize + maxPrime];
			lastSieveArraySize = Integer.valueOf(sieveArraySize); // object required for null condition
			lastMaxPrime = maxPrime;
		}
		// overwrite existing arrays with initializer. we know that sieve array size is a multiple of 256
		System.arraycopy(initializer, 0, sieve_logPSumArray, 0, 256);
		int filled = 256;
		int unfilled = sieveArraySize-filled;
		while (unfilled>0) {
			int fillNext = Math.min(unfilled, filled);
			System.arraycopy(sieve_logPSumArray, 0, sieve_logPSumArray, filled, fillNext);
			filled += fillNext;
			unfilled = sieveArraySize-filled;
		}
		System.arraycopy(sieve_logPSumArray, 0, sieve_logPSumArray_neg, 0, sieveArraySize);
	}
	
	@Override
	public String getProfilingReport() {
		return "init=" + initDuration + "ms, sieve=" + sieveDuration + "ms, collect=" + collectDuration + "ms";
	}
	
	@Override
	public void cleanUp() {
		sieve_logPSumArray = null;
		sieve_logPSumArray_neg = null;
	}
}
