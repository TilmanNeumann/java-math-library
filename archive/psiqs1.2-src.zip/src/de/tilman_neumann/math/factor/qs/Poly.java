/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * This file is part of the PSIQS package version 01 from 2016-01-07, 
 * developed by Tilman Neumann, Edemissen, Germany.
 * 
 * Use and redistribution of PSIQS are free for non-commercial purposes, as long as this
 * header is not modified or removed. Any commercial usage of the whole or parts
 * of PSIQS requires the written consent of the author.
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

package de.tilman_neumann.math.factor.qs;

import java.math.BigInteger;

/**
 * The quadratic polynomial class used by QS.
 * @author Tilman Neumann
 */
public interface Poly {
	/**
	 * @return kN
	 */
	BigInteger getkN();

	/**
	 * @return the a-parameter
	 */
	BigInteger getAParameter();

	/**
	 * @return true if the prime base has changed, compared to the last polynomial
	 */
	boolean hasNewPrimeBase();
	
	/**
	 * @return the chosen prime base (int).
	 */
	int[] getPrimesArray();
	
	/**
	 * @return the chosen prime base (BigInteger).
	 */
	BigInteger[] getPrimesArray_big();
	
	/**
	 * @return log(p) for each p in the chosen prime base.
	 */
	byte[] getLogPArray();

	/**
	 * The base of the logarithm of log(p) values.
	 */
	float getLogBase();
	
	/**
	 * @return solutions x1 = +t -b mod p
	 */
	int[] getX1Array();

	/**
	 * @return solutions x2 = -t -b mod p
	 */
	int[] getX2Array();

	/**
	 * @param x
	 * @return [A(x), Q(x)]
	 */
	BigInteger[] computeAandQ(int x);
	
	/**
	 * @return all prime base elements that divide any Q(x).
	 * In SIQS, these are the q_l whose product gives the a-parameter.
	 * MPQS does not have such elements and returns null.
	 */
	int[] getPrimeBaseElementsDividingAnyQ();
	
	/**
	 * @return all primes not in the prime base that divide any Q(x).
	 * SIQS does not have such elements and returns null.
	 * MPQS has one such element, the q such that a=q^2.
	 */
	BigInteger[] getNonPrimeBaseElementsDividingAnyQ();
}
