/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * This file is part of the PSIQS package version 01 from 2016-01-07, 
 * developed by Tilman Neumann, Edemissen, Germany.
 * 
 * Use and redistribution of PSIQS are free for non-commercial purposes, as long as this
 * header is not modified or removed. Any commercial usage of the whole or parts
 * of PSIQS requires the written consent of the author.
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

package de.tilman_neumann.math.factor.qs;

import java.math.BigInteger;

/**
 * Interface for generators that produce the leading coefficient <code>a</code> of the quadratic polynomial
 * Q(x) = (a*x+b)^2 - kN used by SIQS.</br></br>
 * 
 * The a-parameter in SIQS is chosen as a product of primes from the prime base: <code>a = q1 * ... * q_s</code>.
 * Its value should be roughly a ~ sqrt(2*k*N)/M, where M is the sieve array size, such that |Q(x)|
 * is about the same at x=+M and x=-M, and |Q(x)| <= kN for all x.
 * 
 * The quality of the a-generator is crucial for both stability and performance of SIQS.
 * 
 * @author Tilman Neumann
 */
public interface AParamGenerator {

	String getName();
	
	void initialize(int k, BigInteger N, BigInteger kN, int primeBaseSize, int[] primesArray, int sieveArraySize);
	
	BigInteger computeNextAParameter();
	
	int getQCount();
	
	int[] getQIndexArray();
	
	int[] getQArray();
	
	/**
	 * Release memory after a factorization.
	 */
	void cleanUp();
}
