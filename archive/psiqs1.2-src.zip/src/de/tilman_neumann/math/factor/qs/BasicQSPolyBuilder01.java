/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * This file is part of the PSIQS package version 01 from 2016-01-07, 
 * developed by Tilman Neumann, Edemissen, Germany.
 * 
 * Use and redistribution of PSIQS are free for non-commercial purposes, as long as this
 * header is not modified or removed. Any commercial usage of the whole or parts
 * of PSIQS requires the written consent of the author.
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

package de.tilman_neumann.math.factor.qs;

import java.math.BigInteger;

import org.apache.log4j.Logger;

import de.tilman_neumann.math.base.bigint.ModularSqrt;
import de.tilman_neumann.math.base.bigint.SqrtInt;
import de.tilman_neumann.math.base.bigint.sequence.IntegerSequence;
import de.tilman_neumann.math.factor.FactorException;
import de.tilman_neumann.math.factor._basics.PrimeBaseBuilder;

import static de.tilman_neumann.math.base.bigint.BigIntConstants.*;
import static org.junit.Assert.*;

/**
 * A builder for standard QS polynomials Q(x) = A(x)^2 - kN, A(x) = x+b, b=ceil(sqrt(kN)).
 * 
 * The only option to switch polynomials in basic QS is choosing a new k. But since this is quite expensive,
 * optimizing parameters typically leads to settings where switching polynomial rarely happens.
 * 
 * @author Tilman Neumann
 */
public class BasicQSPolyBuilder01 implements PolyBuilder {
	private static final Logger LOG = Logger.getLogger(BasicQSPolyBuilder01.class);
	private static final boolean DEBUG = false;

	private IntegerSequence<BigInteger> kSequence;
	private int kCount;
	private BigInteger N, k, kN, floor_sqrt_kN, ceil_sqrt_kN;
	private int primeBaseSize;
	private double proposedSieveArraySize;
	private int adjustedSieveArraySize;
	
	// prime base, is recomputed for each k (each new polynomial)
	private PrimeBaseBuilder primeBaseBuilder = new PrimeBaseBuilder();
	private int[] primesArray;
	private BigInteger[] primesArray_big;
	private byte[] logPArray;
	private float logBase;
	
	/** the modular sqrt's t with t^2==kN (mod p) for all p */
	private int[] tArray;

	private int[] x1Array;
	private int[] x2Array;

	private ModularSqrt modularSqrtEngine = new ModularSqrt();

	/**
	 * Full constructor.
	 * @param kSequence multiplier generator
	 */
	public BasicQSPolyBuilder01(IntegerSequence<BigInteger> kSequence) {
		this.kSequence = kSequence;
	}
	
	@Override
	public String getName() {
		return "BasicQSPoly01(" + kSequence.getName() + ")";
	}

	@Override
	public void initialize(BigInteger N, int primeBaseSize, double proposedSieveArraySize, boolean profile) {
		this.N = N;
		this.primeBaseSize = primeBaseSize;
		this.primesArray = new int[primeBaseSize];
		this.primesArray_big = new BigInteger[primeBaseSize];
		this.logPArray = new byte[primeBaseSize];
		this.tArray = new int[primeBaseSize];
		this.x1Array = new int[primeBaseSize];
		this.x2Array = new int[primeBaseSize];
		this.proposedSieveArraySize = proposedSieveArraySize;
		// for each new N start again with the first k
		kCount = 0;
		kSequence.reset(N);
	}

	@Override
	public Poly nextPolynomial() throws FactorException {
		// get a new k, return immediately if kN is square
		boolean isSquare;
		do {
			k = kSequence.next();
			this.kN = k.multiply(N);
			kCount++;
			if (DEBUG) LOG.debug("N=" + N + ": k=" + k + ", kN=" + kN);
			isSquare = false;
			BigInteger[] iSqrt = SqrtInt.iSqrt(kN);
			this.floor_sqrt_kN = iSqrt[0];
			this.ceil_sqrt_kN = iSqrt[1];
			if (floor_sqrt_kN.equals(ceil_sqrt_kN)) {
				if (DEBUG) LOG.debug("kN = " + kN + " is exact square " + floor_sqrt_kN + "^2");
				BigInteger gcd = N.gcd(floor_sqrt_kN);
				if (gcd.compareTo(ONE)>0 && gcd.compareTo(N)<0) throw new FactorException(gcd);
				// otherwise N divides k -> get another k
				isSquare = true;
			}
		} while (isSquare);
		// Create the reduced prime base for kN:
		computeLogBase(proposedSieveArraySize);
		primeBaseBuilder.computeReducedPrimeBase(kN, primeBaseSize, primesArray, primesArray_big, logPArray, logBase);
		// adjust the sieve array size to a multiple of 256 and such that each p has at least one solution in the sieve array
		int maxPrime = primesArray[primeBaseSize-1];
		adjustedSieveArraySize = adjustSieveArraySize(proposedSieveArraySize, maxPrime);
		//LOG.debug("maxPrime=" + maxPrime + ", sieve array size was adjusted from " + proposedSieveArraySize + " to " + adjustedSieveArraySize);
		// compute solutions array
		this.computeTArray();
		this.computeXArrays();
		// return poly with new k
		return new BasicQSPoly01(N, kN, ceil_sqrt_kN, true, primeBaseSize, primesArray, primesArray_big, logPArray, logBase, x1Array, x2Array);
	}

	private void computeLogBase(double proposedSieveArraySize) {
		double lnM = Math.log(proposedSieveArraySize);
		double lnkN = Math.log(kN.doubleValue());
		double lnN = Math.log(N.doubleValue());
		float estimatedT = 0.2F;
		double minLnPSum = lnM + lnkN/2 - 0.5 - estimatedT*lnN;
		double lnLogBase = minLnPSum / (128/2.0); // normalization with 2.0 works fine; the exact value does not matter
		this.logBase = (float) Math.exp(lnLogBase);
		//LOG.debug("minLnPSum = " + minLnPSum + ", estimated log base = " + logBase);
	}
	
	private int adjustSieveArraySize(double proposedSieveArraySize, int maxPrime) {
		// we want a sieveArraySize that
		// a) is greater/equals maxPrime, so that there is always at least one x-solution inside the sieve array
		// b) has (sieveArraySize + maxPrime) < 2^31 to avoid integer overflow
		// c) is a multiple of 256
		if (proposedSieveArraySize < maxPrime) proposedSieveArraySize = maxPrime; // assure a)
		double tooBig = (proposedSieveArraySize+maxPrime) - ((1L<<31)-1); // check b)
		if (tooBig > 0) proposedSieveArraySize -= tooBig; // assure b)
		// finally find a multiple of 256 still satisfying b)
		long adjustedSieveArraySize = (((long) proposedSieveArraySize+255)>>8)<<8; // multiple of 256
		if (adjustedSieveArraySize+maxPrime>=(1L<<31)) adjustedSieveArraySize -= 256; // re-assure b)
		return (int) adjustedSieveArraySize;
	}

	/**
	 * For all primes p in the prime base, find the modular sqrt's of kN (mod p), i.e. the t such that t^2 == kN (mod p).
	 */
	private void computeTArray() {
		// special treatment for p[0]=2 (always contained in prime base)
		tArray[0] = kN.and(ONE).intValue();
		if (DEBUG) assertEquals(BigInteger.valueOf(tArray[0]).pow(2).mod(TWO), kN.mod(TWO));
		// odd primes
		for (int i = 1; i<primeBaseSize; i++) {
			// Tonelli_Shanks requires Legendre(kN|p)==1, 0 is not ok. But this is easy to "heal":
			// Since p is prime, Legendre(kN|p)==0 means that kN is a multiple of p.
			// Thus t^2 == kN == 0 (mod p) and the modular sqrt t is 0, too.
			if (kN.mod(primesArray_big[i]).equals(ZERO)) {
				tArray[i] = 0;
			} else {
				tArray[i] = modularSqrtEngine.Tonelli_Shanks(kN, primesArray[i]);
			}
			//if (primesArray[i]==3) LOG.debug("p=3 -> t=" + tArray[i]);
		}
	}

	private void computeXArrays() {
		// initialize solution arrays for all p:
		for (int i=0; i<primeBaseSize; i++) {
			int p = primesArray[i];
			BigInteger pBig = primesArray_big[i];
			int ceil_sqrt_kN_modP = ceil_sqrt_kN.mod(pBig).intValue();
			int t = tArray[i]; // t is already modulo p
			// x1 = +t - b (mod p)
			int x1 = t - ceil_sqrt_kN_modP;
			if (x1 < 0) x1 += p;
			x1Array[i] = x1;
			// x2 = -t - b (mod p)
			int x2 = -t - ceil_sqrt_kN_modP;
			if (t>0) x2 += p;
			if (x2 < 0) x2 += p;
			x2Array[i] = x2;
			if (DEBUG) {
				assertTrue(0<=t && t<p);
				assertTrue(0 <= x1 && x1 < p);
				assertTrue(0 <= x2 && x2 < p);
				assertEquals(BigInteger.valueOf(t).subtract(ceil_sqrt_kN).mod(pBig).intValue(), x1);
				LOG.debug("t=" + t + ", b=" + ceil_sqrt_kN_modP + ", p=" + p + "-> x2 = -t-b (mod p) = " + x2);
				assertEquals(BigInteger.valueOf(t).negate().subtract(ceil_sqrt_kN).mod(pBig).intValue(), x2);
			}
		}
	}

	@Override
	public int getAdjustedSieveArraySize() {
		return adjustedSieveArraySize;
	}

	@Override
	public int getPolyCount() {
		return kCount;
	}

	@Override
	public String getProfilingReport() {
		return null; // not implemented
	}
	
	@Override
	public void cleanUp() {
		primesArray = null;
		primesArray_big = null;
		logPArray = null;
		tArray = null;
		x1Array = null;
		x2Array = null;
	}
}
