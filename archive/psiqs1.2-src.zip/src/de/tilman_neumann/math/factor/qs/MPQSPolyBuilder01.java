/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * This file is part of the PSIQS package version 01 from 2016-01-07, 
 * developed by Tilman Neumann, Edemissen, Germany.
 * 
 * Use and redistribution of PSIQS are free for non-commercial purposes, as long as this
 * header is not modified or removed. Any commercial usage of the whole or parts
 * of PSIQS requires the written consent of the author.
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

package de.tilman_neumann.math.factor.qs;

import java.math.BigInteger;
import java.util.HashSet;

import org.apache.log4j.Logger;

import de.tilman_neumann.math.base.bigint.JacobiSymbol;
import de.tilman_neumann.math.base.bigint.ModularSqrt;
import de.tilman_neumann.math.base.bigint.Roots;
import de.tilman_neumann.math.factor.FactorException;
import de.tilman_neumann.math.factor._basics.PrimeBaseBuilder;

import static de.tilman_neumann.math.base.bigint.BigIntConstants.*;
import static org.junit.Assert.*;

/**
 * A builder for MPQS polynomials.
 * @author Tilman Neumann
 */
public class MPQSPolyBuilder01 implements PolyBuilder {
	private static final Logger LOG = Logger.getLogger(MPQSPolyBuilder01.class);
	private static final boolean DEBUG = false;

	/**
	 * How to compute the b-parameter:
	 * 0 = simple formula doing arithmetics (mod p^2)
	 * 1 = more elaborated and faster version that needs arithmetics (mod p) only
	 */
	private static final int B_COMPUTATION_STYLE = 1;

	/**
	 * How to compute the multiplier k:
	 * 0 = off, use k=1 always
	 * 1 = choose first odd, square-free k such that kN == 1 (mod 4)
	 * 2 = choose first odd, square-free k such that kN == 1 (mod 8)
	 * 3 = Knuth-Schroeppel
	 */
	private int multiplierStyle;
	private MultiplierFinder multiplierFinder = new MultiplierFinder();

	private int primeBaseSize, adjustedSieveArraySize;
	private BigInteger q, a, b;
	private int k;
	protected BigInteger N;
	protected BigInteger kN;
	
	// prime base: is computed only once
	private PrimeBaseBuilder primeBaseBuilder = new PrimeBaseBuilder();
	private int[] primesArray;
	private BigInteger[] primesArray_big;
	private byte[] logPArray;
	private float logBase;
	private HashSet<Integer> hashedPrimeBase;
	private BigInteger maxPrime_big;
	/** the modular sqrt's t with t^2==kN (mod p) for all p */
	private int[] tArray;

	private int[] x1Array;
	private int[] x2Array;

	private ModularSqrt modularSqrtEngine = new ModularSqrt();
	private JacobiSymbol jacobiEngine = new JacobiSymbol();

	private int polyCount;

	// profiling
	private boolean profile;
	private long paramDuration, xArrayDuration;

	/**
	 * Full constructor.
	 * @param multiplierStyle
	 */
	public MPQSPolyBuilder01(int multiplierStyle) {
		this.multiplierStyle = multiplierStyle;
	}

	@Override
	public String getName() {
		return "MPQSPoly01(" + multiplierStyle + ")";
	}

	@Override
	public void initialize(BigInteger N, int primeBaseSize, double proposedSieveArraySize, boolean profile) {
		this.N = N;
		this.primeBaseSize = primeBaseSize;
		this.primesArray = new int[primeBaseSize];
		this.primesArray_big = new BigInteger[primeBaseSize];
		this.logPArray = new byte[primeBaseSize];
		this.tArray = new int[primeBaseSize];
		this.x1Array = new int[primeBaseSize];
		this.x2Array = new int[primeBaseSize];

		// compute multiplier k for N according to the given style
		this.k = multiplierFinder.computeMultiplier(N, primeBaseSize, multiplierStyle);
		this.kN = BigInteger.valueOf(k).multiply(N);
		
		// Create the reduced prime base for kN:
		computeLogBase(proposedSieveArraySize);
		primeBaseBuilder.computeReducedPrimeBase(kN, primeBaseSize, primesArray, primesArray_big, logPArray, logBase);
		// maxPrime_big and the hashed prime base are used in computeParameters() to effectively check that q is not in the prime base
		maxPrime_big = primesArray_big[primeBaseSize-1];
		hashedPrimeBase = new HashSet<Integer>();
		for (int i=0; i<primeBaseSize; i++) {
			hashedPrimeBase.add(primesArray[i]);
		}
		// adjust the sieve array size to a multiple of 256 and such that each p has at least one solution in the sieve array
		int maxPrime = primesArray[primeBaseSize-1];
		adjustedSieveArraySize = adjustSieveArraySize(proposedSieveArraySize, maxPrime);
		//LOG.debug("maxPrime=" + maxPrime + ", sieve array size was adjusted from " + proposedSieveArraySize + " to " + adjustedSieveArraySize);
		// compute the t with t^2 == kN (mod p) for all p
		computeTArray(); // depends on prime base

		// find some initial q ~ sqrt(sqrt(2kN)/sieveArraySize)
		BigInteger sieveArraySize_big = BigInteger.valueOf(adjustedSieveArraySize);
		BigInteger sieveArraySizeSquare_big = sieveArraySize_big.multiply(sieveArraySize_big);
		this.q = Roots.ithRoot(kN.shiftLeft(1).divide(sieveArraySizeSquare_big), 4)[0]; // not prime yet
		this.polyCount = 0;

		// profiling
		this.profile = profile;
		this.paramDuration = 0;
		this.xArrayDuration = 0;
	}

	private void computeLogBase(double proposedSieveArraySize) {
		double lnM = Math.log(proposedSieveArraySize);
		double lnkN = Math.log(kN.doubleValue());
		double lnN = Math.log(N.doubleValue());
		float estimatedT = 0.2F;
		double minLnPSum = lnM + lnkN/2 - 0.5 - estimatedT*lnN;
		double lnLogBase = minLnPSum / (128/2.0); // normalization with 2.0 works fine; the exact value does not matter
		this.logBase = (float) Math.exp(lnLogBase);
		//LOG.debug("minLnPSum = " + minLnPSum + ", estimated log base = " + logBase);
	}
	
	private int adjustSieveArraySize(double proposedSieveArraySize, int maxPrime) {
		// we want a sieveArraySize that
		// a) is greater/equals maxPrime, so that there is always at least one x-solution inside the sieve array
		// b) has (sieveArraySize + maxPrime) < 2^31 to avoid integer overflow
		// c) is a multiple of 256
		if (proposedSieveArraySize < maxPrime) proposedSieveArraySize = maxPrime; // assure a)
		double tooBig = (proposedSieveArraySize+maxPrime) - ((1L<<31)-1); // check b)
		if (tooBig > 0) proposedSieveArraySize -= tooBig; // assure b)
		// finally find a multiple of 256 still satisfying b)
		long adjustedSieveArraySize = (((long) proposedSieveArraySize+255)>>8)<<8; // multiple of 256
		if (adjustedSieveArraySize+maxPrime>=(1L<<31)) adjustedSieveArraySize -= 256; // re-assure b)
		return (int) adjustedSieveArraySize;
	}

	@Override
	public Poly nextPolynomial() throws FactorException {
		long t0 = System.currentTimeMillis();
		computeParameters();
		//LOG.debug("N=" + N + ", polyCount=" + polyCount + ": b = " + b);
		long t1 = System.currentTimeMillis();
		if (profile) paramDuration += (t1-t0);

		// compute solution arrays and create the new polynomial
		computeXArrays();
		boolean hasNewPrimeBase = (polyCount == 0);
		MPQSPoly01 poly = new MPQSPoly01(q, a, b, kN, hasNewPrimeBase, primeBaseSize, primesArray, primesArray_big, logPArray, logBase, x1Array, x2Array);
		polyCount++;
		if (profile) xArrayDuration += (System.currentTimeMillis()-t1);
		return poly;
	}
	
	private void computeParameters() throws FactorException {
		// Find a prime q such that
		// a) q == 3 (mod 4), not required here but good for performance
		// b) kN is a quadratic residue (mod q)
		// c) q is not in the prime base
		if (DEBUG) LOG.debug("start searching for q at q=" + q);
		while (true) {
			// [Silverman 1987: "The multiple polynomial quadratic sieve", p.332]:
			// "It is sufficient for practical purposes that D be only a probable prime" (Silvermans D = our q)
			q = q.nextProbablePrime(); // TODO: faster probable prime?
			// it is not required to choose q == 3 (mod 4) but very good for performance
			if (q.and(THREE).intValue()!=3) {
				if (DEBUG) LOG.debug("q = " + q + " != 3 (mod 4) -> skip");
				continue;
			}
			if (q.compareTo(maxPrime_big)<=0 && hashedPrimeBase.contains(q.intValue())) {
				if (DEBUG) LOG.debug("q = " + q + " is contained in prime base -> skip");
				continue;
			}
			// otherwise q looks ok so far -> check if kN is a quadratic residue (mod q)
			int jacobi = jacobiEngine.jacobiSymbol(kN, q);
			if (jacobi>0) {
				// kN is quadratic residue (mod q) -> that's what we were looking for.
				if (DEBUG) LOG.debug("found q = " + q);
				break; // use this q
			}
			if (jacobi==0) {
				// q divides kN -> Since q is typically much bigger than k, this means we found a factor of N! -> test gcd
				if (DEBUG) LOG.debug("q = " + q + " divides kN -> a factor of N?");
				BigInteger gcd = N.gcd(q);
				if (gcd.compareTo(ONE)>0 && gcd.compareTo(N)<0) throw new FactorException(gcd);
			} else {
				if (DEBUG) LOG.debug("kN = " + k + " * " + N + " is not a quadratic residue (mod q), q = " + q + " -> skip");
			}
		}
		// a = q^2
		this.a = q.multiply(q);
		
		// Compute b such that b^2 == kN (mod a). this requires q == 3 (mod 4) as chosen above.
		switch (B_COMPUTATION_STYLE) {
		case 0:
			// This is the first proposition in [Pomerance 1985: The Quadratic Sieve Factoring Algorithm, p. 178]
			this.b = kN.modPow(a.subtract(q).add(TWO).shiftRight(2), a);
			break;
		case 1:
			// Faster version doing modular arithmetics (mod q) only, which is an application of lifting via Hensels lemma.
			// This approach is the second proposition in [Pomerance 1985], but not fully out-formulated there.
			// This implementation follows the detailed description in [Silverman 1987].
			// Compute b1 such that b1^2 == kN (mod q):
			BigInteger b1 = kN.modPow(q.add(ONE).shiftRight(2), q);
			// now b = b1 + x*q, x unknown
			BigInteger modInv = b1.shiftLeft(1).modInverse(q); // 1/(2b1) mod q
			BigInteger b1Square = b1.multiply(b1);
			BigInteger b2 = modInv.multiply(kN.subtract(b1Square).divide(q)).mod(q);
			this.b = b1.add(b2.multiply(q)).mod(a);
			// TODO: Actually Silverman proposed another improvement:
			// First compute b0 = (kN)^((q-3)/4) mod q, then b1 = kN * b0.
			// Then we have b0 = (1/b1) mod q, which allows to compute the modular inverse 1/(2b1) mod q easily.
			break;
		default: throw new IllegalStateException("Unknonwn b-computation style: " + B_COMPUTATION_STYLE);
		}
		if (DEBUG) assertEquals(ZERO, b.multiply(b).subtract(kN).mod(a));
	}

	/**
	 * For all primes p in the prime base, find the modular sqrt's of kN (mod p), i.e. the t such that t^2 == kN (mod p).
	 */
	private void computeTArray() {
		// special treatment for p[0]=2 (always contained in prime base)
		tArray[0] = kN.and(ONE).intValue();
		if (DEBUG) assertEquals(BigInteger.valueOf(tArray[0]).pow(2).mod(TWO), kN.mod(TWO));
		// odd primes
		for (int i = 1; i<primeBaseSize; i++) {
			// Tonelli_Shanks requires Legendre(kN|p)==1, 0 is not ok. But this is easy to "heal":
			// Since p is prime, Legendre(kN|p)==0 means that kN is a multiple of p.
			// Thus t^2 == kN == 0 (mod p) and the modular sqrt t is 0, too.
			if (kN.mod(primesArray_big[i]).equals(ZERO)) {
				tArray[i] = 0;
			} else {
				tArray[i] = modularSqrtEngine.Tonelli_Shanks(kN, primesArray[i]);
			}
			//if (primesArray[i]==3) LOG.debug("p=3 -> t=" + tArray[i]);
		}
	}

	/**
	 * Solve t=ax+b, given t^2 == kN (mod p) towards x, for all p.
	 * For each p there are exactly 2 solutions: x_1,2 = (1/a) * (+-t -b) (mod p).
	 */
	public void computeXArrays() {
		// initialize solution arrays for all p:
		for (int i=0; i<primeBaseSize; i++) {
			int p = primesArray[i];
			BigInteger pBig = primesArray_big[i];
			int t = tArray[i]; // t is already modulo p
			// q has been chosen coprime p -> the modular inverse (1/a) mod p = (1/q^2) mod p exists always,
			// and this assures that there is no p that divides all Q(x).
			BigInteger ainvp_big = a.modInverse(pBig);
			// The products below involving ainvp require long precision
			long ainvp = ainvp_big.longValue();
			int bModP = b.mod(pBig).intValue();
			if (DEBUG) {
				assertTrue(0<=t && t<p);
				assertTrue(ainvp_big.compareTo(MAX_INT)<=0);
			}
			// x1 = (1/a)* (+t - b) (mod p)
			int t_minus_b_modP = t - bModP;
			if (t_minus_b_modP < 0) t_minus_b_modP += p;
			int x1 = (int) ((ainvp * t_minus_b_modP) % p);
			x1Array[i] = x1;
			if (DEBUG) assertTrue(0<=t_minus_b_modP && t_minus_b_modP<p);
			// x2 = (1/a)* (-t - b) (mod p)
			int minus_t_minus_b_modP = p -t - bModP;
			if (minus_t_minus_b_modP < 0) minus_t_minus_b_modP += p;
			int x2 = (int) ((ainvp * minus_t_minus_b_modP) % p);
			x2Array[i] = x2;
			if (DEBUG) {
				assertTrue(0<=minus_t_minus_b_modP && minus_t_minus_b_modP<p);
				if (x1<0 || x2<0) LOG.debug("p=" + p + ", amodInvP=" + ainvp_big + ": x1 = " + x1 + ", x2 = " + x2);
			}
		}
	}

	@Override
	public int getAdjustedSieveArraySize() {
		return adjustedSieveArraySize;
	}

	@Override
	public int getPolyCount() {
		return polyCount;
	}

	@Override
	public String getProfilingReport() {
		return "params=" + paramDuration + "ms, xArrays=" + xArrayDuration + "ms";
	}
	
	@Override
	public void cleanUp() {
		primesArray = null;
		primesArray_big = null;
		hashedPrimeBase = null;
		logPArray = null;
		tArray = null;
		x1Array = null;
		x2Array = null;
	}
}
