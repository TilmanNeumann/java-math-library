/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * This file is part of the PSIQS package version 01 from 2016-01-07, 
 * developed by Tilman Neumann, Edemissen, Germany.
 * 
 * Use and redistribution of PSIQS are free for non-commercial purposes, as long as this
 * header is not modified or removed. Any commercial usage of the whole or parts
 * of PSIQS requires the written consent of the author.
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

package de.tilman_neumann.math.factor.qs.tdiv;

import java.util.List;

import de.tilman_neumann.math.factor._congruence.AQPair;
import de.tilman_neumann.math.factor.qs.Poly;

/**
 * Interface for trial division engines to find the factorization of smooth Q(x) with given x.
 * 
 * @author Tilman Neumann
 */
public interface TDiv_QS {
	
	/**
	 * @return the name of this algorithm
	 */
	public String getName();

	/**
	 * Initialize this factorizer for a new N.
	 * @param N
	 * @param primeBaseSize
	 */
	public void initialize(double N_dbl, int primeBaseSize);
	
	/**
	 * Test if Q(x) is smooth (factors completely over the prime base) or "sufficiently smooth" (factors almost over the prime base)
	 * for all x in the given list.
	 * @param poly polynomial having x-solution arrays
	 * @param xList
	 *
	 * @return the AQ-pairs where Q is at least "sufficiently smooth"
	 */
	List<AQPair> testList(Poly poly, List<Integer> xList);
	
	/**
	 * @return a description of the performed tests.
	 */
	String getReportString();
	
	/**
	 * Release memory after a factorization.
	 */
	void cleanUp();
}
