/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * This file is part of the PSIQS package version 01 from 2016-01-07, 
 * developed by Tilman Neumann, Edemissen, Germany.
 * 
 * Use and redistribution of PSIQS are free for non-commercial purposes, as long as this
 * header is not modified or removed. Any commercial usage of the whole or parts
 * of PSIQS requires the written consent of the author.
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

package de.tilman_neumann.math.factor.qs;

import java.math.BigInteger;

import org.apache.log4j.Logger;

/**
 * MPQS polynomial:
 * Q(x) = A(x)^2 - kN, k constant, A(x) = a*x+b, a = q^2 ~ sqrt(2*kN)/sieveArraySize, q prime with N a quadratic residue mod q,
 * and b<a a modular square root of N mod a -> then a divides b^2-N -> then any Q(x) is divisible by a.
 * 
 * @author Tilman Neumann
 */
public class MPQSPoly01 implements Poly {
	@SuppressWarnings("unused")
	private static final Logger LOG = Logger.getLogger(MPQSPoly01.class);
	
	private BigInteger a, b, kN;
	
	// q as an array
	private BigInteger[] fixPrimeDivisors;
	
	// prime base
	private boolean hasNewPrimeBase;
	private int[] primesArray;
	private BigInteger[] primesArray_big;
	private byte[] logPArray;
	private float logBase;
	
	private int[] x1Array;
	private int[] x2Array;

	/**
	 * Full constructor.
	 * @param q exact sqrt of a
	 * @param a the a-parameter of MPQS polynomial
	 * @param b the b-parameter
	 * @param kN
	 * @param hasNewPrimeBase
	 * @param primeBaseSize
	 * @param primesArray prime base computed in PolyBuilder
	 * @param primesArray_big
	 * @param logPArray
	 * @param logBase
	 * @param x1Array
	 * @param x2Array
	 */
	public MPQSPoly01(BigInteger q, BigInteger a, BigInteger b, BigInteger kN, boolean hasNewPrimeBase, int primeBaseSize, int[] primesArray,
			          BigInteger[] primesArray_big, byte[] logPArray, float logBase, int[] x1Array, int[] x2Array) {
		
		this.a = a;
		this.b = b;
		this.kN = kN;
		this.hasNewPrimeBase = hasNewPrimeBase;
		this.primesArray = primesArray;
		this.primesArray_big = primesArray_big;
		this.logPArray = logPArray;
		this.logBase = logBase;
		this.x1Array = x1Array;
		this.x2Array = x2Array;
		this.fixPrimeDivisors = new BigInteger[] {q};
	}

	@Override
	public BigInteger getkN() {
		return kN;
	}

	@Override
	public BigInteger getAParameter() {
		return a;
	}
	
	@Override
	public boolean hasNewPrimeBase() {
		return hasNewPrimeBase;
	}

	@Override
	public int[] getPrimesArray() {
		return primesArray;
	}

	@Override
	public BigInteger[] getPrimesArray_big() {
		return primesArray_big;
	}

	@Override
	public byte[] getLogPArray() {
		return logPArray;
	}

	@Override
	public float getLogBase() {
		return logBase;
	}
	
	@Override
	public int[] getX1Array() {
		return x1Array;
	}

	@Override
	public int[] getX2Array() {
		return x2Array;
	}

	@Override
	public BigInteger[] computeAandQ(int x) {
		BigInteger A = a.multiply(BigInteger.valueOf(x)).add(b);  // A(x) = a*x+b
		return new BigInteger[] {A, A.multiply(A).subtract(kN)}; // Q(x) = A(x)^2 - kN
	}
	
	/**
	 * @return all prime base elements that divide any Q(x).
	 * In SIQS, these are the q_l whose product gives the a-parameter.
	 * MPQS does not have such elements and returns null.
	 */
	@Override
	public int[] getPrimeBaseElementsDividingAnyQ() {
		return null;
	}
	
	/**
	 * @return all primes not in the prime base that divide any Q(x).
	 * SIQS does not have such elements and returns null.
	 * MPQS has one such element, the q such that a=q^2.
	 */
	@Override
	public BigInteger[] getNonPrimeBaseElementsDividingAnyQ() {
		return fixPrimeDivisors;
	}
}
