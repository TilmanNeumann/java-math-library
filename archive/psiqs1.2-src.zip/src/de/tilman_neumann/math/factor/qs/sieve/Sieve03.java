/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * This file is part of the PSIQS package version 01 from 2016-01-07, 
 * developed by Tilman Neumann, Edemissen, Germany.
 * 
 * Use and redistribution of PSIQS are free for non-commercial purposes, as long as this
 * header is not modified or removed. Any commercial usage of the whole or parts
 * of PSIQS requires the written consent of the author.
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

package de.tilman_neumann.math.factor.qs.sieve;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import de.tilman_neumann.math.factor.qs.Poly;

import static org.junit.Assert.*;

/**
 * Sieve implementation that sieves on positive and negative x-values.
 * 
 * Version 03:
 * -> The smallest primes are not used for sieving.
 *    A prime p makes an overall contribution proportional to log(p)/p to the sieve array,
 *    but the runtime of sieving with a prime p is proportional to sieveArraySize/p.
 *    Thus sieving with small primes is less effective, and skipping them improves performance.
 * -> Let counters run down -> simpler termination condition
 * -> Faster zero-initialization of sieve array with System.arrayCopy().
 * -> use byte[] for sieve array.
 * -> a few more optimizations
 * 
 * @author Tilman Neumann
 */
public class Sieve03 implements Sieve {
	@SuppressWarnings("unused")
	private static final Logger LOG = Logger.getLogger(Sieve03.class);
	private static final boolean DEBUG = false;

	/** basic building block for fast zero-initialization of sieve array */
	private static final byte[] ZERO_ARRAY_256 = new byte[256];
	
	private int sieveBoundStyle;
	private float T;
	private float lnN;
	private int primeBaseSize;
	private float pMinMult;
	private int pMinIndex;
	
	private byte[] sieve_logPSumArray, sieve_logPSumArray_neg;
	private Integer lastSieveArraySize;
	
	// timings
	private boolean profile;
	private long initDuration, sieveDuration, collectDuration;

	public Sieve03(int sieveBoundStyle, float T, float pMinMult) {
		this.sieveBoundStyle = sieveBoundStyle;
		this.T = T;
		this.pMinMult = pMinMult;
	}
	
	@Override
	public String getName() {
		return "sieve03(" + sieveBoundStyle + ", " + T + ", " + pMinMult + ")";
	}
	
	@Override
	public void initialize(double N_dbl, int primeBaseSize, boolean profile) {
		this.lnN = (float) Math.log(N_dbl);
		this.primeBaseSize = primeBaseSize;
		this.pMinIndex = Math.max(1, (int) (pMinMult * Math.log(primeBaseSize))); // avoid p[0]==2; the case was removed in the sieve method
		this.lastSieveArraySize = null; // indicate that allocating the sieve arrays is required
		// profiling
		this.profile = profile;
		initDuration = 0;
		sieveDuration = 0;
		collectDuration = 0;
	}

	@Override
	public List<Integer> sieve(Poly poly, int sieveArraySize) {
		long t0 = System.currentTimeMillis();
		this.initializeSieveArray(sieveArraySize);
		long t1 = System.currentTimeMillis();
		if (profile) initDuration += (t1-t0);

		// Sieve with odd primes:
		// The sieve array size has been chosen > maxPrime,
		// so that for each prime there is at least one x-solution inside the sieve array.
		// This saves us some extra checks.
		int[] primesArray = poly.getPrimesArray();
		byte[] ldPArray = poly.getLogPArray();
		int[] x1Array = poly.getX1Array();
		int[] x2Array = poly.getX2Array();
		int sieveArraySize_m1 = sieveArraySize-1;
		for (int i=pMinIndex; i<primeBaseSize; i++) {
			// solution x1
			int x1 = x1Array[i];
			if (x1 != -1) { // sieve with this p (x1 = x2 = -1 happens only in SIQS)
				int p = primesArray[i];
				byte logP = ldPArray[i];
				//LOG.debug("p=" + p + ", log(p) = " + logP);
				// The minimum number of x-solutions in the sieve array is floor(sieveArraySize/p).
				// E.g. for p=3, sieveArraySize=8 there are solutions (0, 3, 6), (1, 4, 7), (2, 5)  <-- 8 is not in sieve array anymore
				// -> minSolutionCount = 2
				// However if x1min=0 then x1_neg = p and we would get an ArrayIndexOutOfBoundsException at the last sieve location.
				// To solve that problem we compute minSolutionCount = floor((sieveArraySize-1)/p)
				int minSolutionCount = sieveArraySize_m1/p;
				int x1_neg=p-x1;
				int x2 = x2Array[i]; // solution x2
				if (x2 != x1) {
					// two x-solutions
					int x2_neg=p-x2;
					for (int j=minSolutionCount; j>0; j--, x1+=p, x1_neg+=p, x2+=p, x2_neg+=p) {
						sieve_logPSumArray[x1] += logP;
						sieve_logPSumArray_neg[x1_neg] += logP;
						sieve_logPSumArray[x2] += logP;
						sieve_logPSumArray_neg[x2_neg] += logP;
					}
					// sieve last locations
					if (x1<sieveArraySize) sieve_logPSumArray[x1] += logP;
					if (x1_neg<sieveArraySize) sieve_logPSumArray_neg[x1_neg] += logP;
					if (x2<sieveArraySize) sieve_logPSumArray[x2] += logP;
					if (x2_neg<sieveArraySize) sieve_logPSumArray_neg[x2_neg] += logP;
					if (DEBUG) {
						assertTrue(x1+p >= sieveArraySize);
						assertTrue(x1_neg+p >= sieveArraySize);
						assertTrue(x2+p >= sieveArraySize);
						assertTrue(x2_neg+p >= sieveArraySize);
					}
				} else {
					// only one x-solution
					for (int j=minSolutionCount; j>0; j--, x1+=p, x1_neg+=p) {
						sieve_logPSumArray[x1] += logP;
						sieve_logPSumArray_neg[x1_neg] += logP;
					}
					// sieve last locations
					if (x1<sieveArraySize) sieve_logPSumArray[x1] += logP;
					if (x1_neg<sieveArraySize) sieve_logPSumArray_neg[x1_neg] += logP;
					if (DEBUG) {
						assertTrue(x1+p >= sieveArraySize);
						assertTrue(x1_neg+p >= sieveArraySize);
					}
				} // end if (x2 == x1)
			} // end if (x1 > -1)
		} // end for (p)
		long t2 = System.currentTimeMillis();
		if (profile) sieveDuration += (t2-t1);

		// compute sieve bound in natural logarithm & convert to the actual logBase:
		float logBase = poly.getLogBase();
		double minLnPSum = computeSieveBound(poly, primesArray[primeBaseSize-1], sieveArraySize);
		int minLogPSum = (int) (minLnPSum / Math.log(logBase)); // floor
		//LOG.debug("minLnPSum = " + minLnPSum + ", minLogPSum = " + minLogPSum);
		// collect results
		List<Integer> smoothXList = new ArrayList<Integer>();
		// let the sieve entry counter x run down to 0 is much faster because of the simpler exit condition
		for (int x=sieveArraySize-1; x>=0; x--) {
			// Not sieving with small primes has the consequence that roughly half of the sieve array entries are 0.
			// But testing that before calling isSufficientlySmoothForTDiv() degrades performance...
			if (sieve_logPSumArray[x] >= minLogPSum) { // x is positive
				// Q is sufficiently smooth to be passed to trial division!
				smoothXList.add(x);
			}
			if (sieve_logPSumArray_neg[x] >= minLogPSum) {
				// Q(-x) is sufficiently smooth to be passed to trial division!
				smoothXList.add(-x);
			}
		} // end for (x)
		if (profile) collectDuration += (System.currentTimeMillis()-t2);
		return smoothXList;
	}

	private double computeSieveBound(Poly poly, int maxPrime, int sieveArraySize) {
		BigInteger kN = poly.getkN();
		BigInteger a = poly.getAParameter();
		double lnkN = Math.log(kN.doubleValue());
		double lna = Math.log(a.doubleValue());
		double lnM = Math.log(sieveArraySize);
		double lnPMax = Math.log(maxPrime);
		switch (sieveBoundStyle) {
		case 0: {
			double lnQdivAEstimate = lnkN - lna; // |Q(x)| <= kN, thus ld(|Q(x)|/a) <= ld(kN) - ld(a)
			double lnMaxAllowedRest = T * lnN; // my choice
			return lnQdivAEstimate - lnMaxAllowedRest;
		} case 1: {
			double lnQdivAEstimate = lnM + lnkN/2 - 0.5; // [Contini], [Pomerance], [Silverman] etc.
			double lnMaxAllowedRest = T * lnN; // my choice
			return lnQdivAEstimate - lnMaxAllowedRest;
		} case 2: {
			double lnQdivAEstimate = lnkN - lna; // |Q(x)| <= kN, thus ld(|Q(x)|/a) <= ld(kN) - ld(a)
			double lnMaxAllowedRest = T * lnPMax; // [Silverman]
			return lnQdivAEstimate - lnMaxAllowedRest;
		} case 3: {
			double lnQdivAEstimate = lnM + lnkN/2 - 0.5; // [Contini], [Pomerance], [Silverman] etc.
			double lnMaxAllowedRest = T * lnPMax; // [Silverman]
			return lnQdivAEstimate - lnMaxAllowedRest;
		} default: throw new IllegalStateException("Unsupported sieveBoundStyle = " + sieveBoundStyle);
		}
	}
	
	/**
	 * Initialize the sieve array(s) with zeros.
	 * @param sieveArraySize
	 */
	private void initializeSieveArray(int sieveArraySize) {
		// The arrays are allocated lazily at the first call of this method for some N
		// to conform with basic QS, which adjusts the sieve array size in nextPoly().
		// If the sieve array size does not change in subsequent invocations, then System.arraycopy() is used,
		// which is by far the fastest choice. This also prepares the way to initialize the sieve array with values other than 0.
		// The copying procedure requires that sieveArraySize is a multiple of 256.
		if (lastSieveArraySize==null || sieveArraySize>lastSieveArraySize) {
			sieve_logPSumArray = new byte[sieveArraySize];
			sieve_logPSumArray_neg = new byte[sieveArraySize];
			lastSieveArraySize = Integer.valueOf(sieveArraySize);
		} else {
			// overwrite existing arrays with zeros. we know that sieve array size is a multiple of 256
			System.arraycopy(ZERO_ARRAY_256, 0, sieve_logPSumArray, 0, 256);
			int filled = 256;
			int unfilled = sieveArraySize-filled;
			while (unfilled>0) {
				int fillNext = Math.min(unfilled, filled);
				System.arraycopy(sieve_logPSumArray, 0, sieve_logPSumArray, filled, fillNext);
				filled += fillNext;
				unfilled = sieveArraySize-filled;
			}
			System.arraycopy(sieve_logPSumArray, 0, sieve_logPSumArray_neg, 0, sieveArraySize);
		}
	}
	
	@Override
	public String getProfilingReport() {
		return "init=" + initDuration + "ms, sieve=" + sieveDuration + "ms, collect=" + collectDuration + "ms";
	}
	
	@Override
	public void cleanUp() {
		sieve_logPSumArray = null;
		sieve_logPSumArray_neg = null;
	}
}
