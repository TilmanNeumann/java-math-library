/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * This file is part of the PSIQS package version 01 from 2016-01-07, 
 * developed by Tilman Neumann, Edemissen, Germany.
 * 
 * Use and redistribution of PSIQS are free for non-commercial purposes, as long as this
 * header is not modified or removed. Any commercial usage of the whole or parts
 * of PSIQS requires the written consent of the author.
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

package de.tilman_neumann.math.factor.qs;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import org.apache.log4j.Logger;

import de.tilman_neumann.math.base.bigint.PurePowerTest;
import de.tilman_neumann.math.base.bigint.sequence.SquarefreeSequence;
import de.tilman_neumann.math.factor.FactorAlgorithmBase;
import de.tilman_neumann.math.factor.FactorException;
import de.tilman_neumann.math.factor._basics.FactorTest;
import de.tilman_neumann.math.factor._congruence.AQPair;
import de.tilman_neumann.math.factor._congruence.CongruenceCollector;
import de.tilman_neumann.math.factor._congruence.CongruenceCollector02;
import de.tilman_neumann.math.factor._matrixSolver.MatrixSolver;
import de.tilman_neumann.math.factor._matrixSolver.MatrixSolver01;
import de.tilman_neumann.math.factor._matrixSolver.SmoothSolverWrapper;
import de.tilman_neumann.math.factor.qs.sieve.Sieve;
import de.tilman_neumann.math.factor.qs.sieve.Sieve01;
import de.tilman_neumann.math.factor.qs.sieve.Sieve04b;
import de.tilman_neumann.math.factor.qs.tdiv.TDiv_QS;
import de.tilman_neumann.math.factor.qs.tdiv.TDiv_QS01;
import de.tilman_neumann.math.factor.qs.tdiv.TDiv_QS03;
import de.tilman_neumann.util.ConfigUtil;

import static de.tilman_neumann.math.base.bigint.BigIntConstants.*;

/**
 * Main class for single-threaded quadratic sieve implementations, supporting basic QS, MPQS and SIQS.
 * 
 * @author Tilman Neumann
 */
public class QS extends FactorAlgorithmBase {
	private static final Logger LOG = Logger.getLogger(QS.class);
	private static final boolean DEBUG = false;
	private static final boolean TEST_SIEVE = false;
	/** use PROFILE=true to generate timing informations */
	private static final boolean PROFILE = false;

	// pure power test
	private PurePowerTest powerTest = new PurePowerTest();

	// prime base configuration
	private float C;
	// polynomial builder
	private PolyBuilder polyBuilder;
	// sieve
	private float sieveArrayMult;
	private Sieve sieve;
	// trial division engine
	private TDiv_QS auxFactorizer;
	// collects the congruences we find
	private CongruenceCollector congruenceCollector;
	// extra congruences to have a bigger chance that the equation system solves. the likelihood is >= 1-2^(extraCongruences+1)
	private int extraCongruences;
	// A wrapper for the solver used for smooth congruence equation systems.
	private SmoothSolverWrapper solverWrapper;
	// statistics
	private int solverRunCount;
	private long initNDuration, initPolyDuration, sieveDuration, tdivDuration, ccStartTime, ccDuration, solverDuration;
	
	/**
	 * Standard constructor.
	 * @param primeTestBits
	 * @param C multiplier for prime base size
	 * @param sieveArrayMult multiplier for sieve array size
	 * @param polyBuilder
	 * @param sieve the sieve algorithm
	 * @param auxFactorizer
	 * @param congruenceCollector
	 * @param extraCongruences the number of surplus congruences we collect to have a greater chance that the equation system solves.
	 * @param matrixSolver matrix solver for the smooth congruence equation system
	 */
	public QS(int primeTestBits, float C, float sieveArrayMult, PolyBuilder polyBuilder, Sieve sieve, 
			  TDiv_QS auxFactorizer, CongruenceCollector congruenceCollector, int extraCongruences, MatrixSolver<Integer> matrixSolver) {
		
		super(primeTestBits);
		this.C = C;
		this.sieveArrayMult = sieveArrayMult;
		this.polyBuilder = polyBuilder;
		this.sieve = sieve;
		this.congruenceCollector = congruenceCollector;
		this.auxFactorizer = auxFactorizer;
		this.extraCongruences = extraCongruences;
		this.solverWrapper = new SmoothSolverWrapper(matrixSolver);
	}

	@Override
	public String getName() {
		return "QS(C=" + C + ", sieveArrayMult=" + sieveArrayMult + ", " + polyBuilder.getName() + ", " + sieve.getName() + ", " + auxFactorizer.getName() + ", " + congruenceCollector.getName() + ")";
	}
	
	/**
	 * Test the current N.
	 * @return factor, or null if no factor was found.
	 */
	public BigInteger findSingleFactor(BigInteger N) {
		// the quadratic sieve does not work for pure powers; check that first:
		PurePowerTest.Result purePower = powerTest.test(N);
		if (purePower!=null) {
			// N is indeed a pure power -> return a factor that is about sqrt(N)
			return purePower.base.pow(purePower.exponent>>1);
		}
		
		// no pure power, run quadratic sieve
		this.initPolyDuration = 0;
		this.sieveDuration = 0;
		this.tdivDuration = 0;
		this.ccDuration = 0;
		this.solverDuration = 0;
		this.solverRunCount = 0;
		long startTime = System.currentTimeMillis();
		
		// compute prime base size
		double N_dbl = N.doubleValue();
		double lnN = Math.log(N_dbl);
		double lnlnN = Math.log(lnN);
		double lnNPow = 0.5; // heuristics for quadratic sieve
		double lnTerm = Math.pow(lnN, lnNPow) * Math.pow(lnlnN, 1-lnNPow); // we want that the exponents of lnN and lnlnN sum to 1
		double primeBaseSize_dbl = Math.exp(lnTerm * C);
		if (primeBaseSize_dbl > Integer.MAX_VALUE) throw new IllegalStateException("primeBaseSize=" + primeBaseSize_dbl + " is too big for int!");
		int primeBaseSize = Math.max(10, (int) primeBaseSize_dbl); // min. size for very small N
		// The union of all reduced prime bases = the number of variables in the equation system.
		// This is required for basic QS only, MPQS and SIQS need only one prime base.
		HashSet<Integer> combinedPrimesSet = new HashSet<Integer>();
		// the number of congruences we need to find before we try to solve the smooth congruence equation system
		int requiredSmoothCongruenceCount = primeBaseSize + extraCongruences;

		// compute sieve array size estimate
		double proposedSieveArraySize = Math.exp(lnTerm * sieveArrayMult);
		if (DEBUG) LOG.debug("N="+N + ": primeBaseSize = " + primeBaseSize + ", proposed sieveArraySize = " + (long)proposedSieveArraySize);
		int sieveArraySize = 0; // is going to be adjusted by PolyBuilder
		
		// initialize sub-algorithms for new N
		this.polyBuilder.initialize(N, primeBaseSize, proposedSieveArraySize, PROFILE); // sets up prime base in MPQS and SIQS
		this.sieve.initialize(N_dbl, primeBaseSize, PROFILE);
		this.auxFactorizer.initialize(N_dbl, primeBaseSize);
		FactorTest factorTest = new FactorTest(N);
		this.congruenceCollector.initialize(N, factorTest);
		this.solverWrapper.initialize(N, factorTest);
		if (PROFILE) initNDuration = (System.currentTimeMillis() - startTime);

		try {
			while (true) {
				long initPolyStartTime = System.currentTimeMillis();
				// create new polynomial Q(x)
				Poly poly = polyBuilder.nextPolynomial(); // throws FactorException; sets up prime base in basic QS
				if (poly.hasNewPrimeBase()) {
					// add new reduced prime base to the combined prime base;
					// this is only required to support basic QS; MPQS and SIQS have a single, unique prime base for each N
					int[] primesArray = poly.getPrimesArray();
					for (int i=0; i<primeBaseSize; i++) combinedPrimesSet.add(primesArray[i]);
					// we want: #equations = #variables + some extra congruences
					requiredSmoothCongruenceCount = combinedPrimesSet.size() + extraCongruences;
				}
				if (PROFILE) initPolyDuration += (System.currentTimeMillis() - initPolyStartTime);
	
				// run sieve and get the sieve locations x where Q(x) is sufficiently smooth
				long sieveStartTime = System.currentTimeMillis();
				sieveArraySize = polyBuilder.getAdjustedSieveArraySize();
				if (DEBUG) LOG.debug("proposedSieveArraySize = " + (long)proposedSieveArraySize + ", maxPrime = " + poly.getPrimesArray()[primeBaseSize-1] + ", adjusted sieveArraySize = " + sieveArraySize);
				List<Integer> smoothXList = sieve.sieve(poly, sieveArraySize);
				if (PROFILE) sieveDuration += (System.currentTimeMillis() - sieveStartTime);
				//LOG.debug("Sieve found " + smoothXList.size() + " Q(x) smooth enough to be passed to trial division.");

				// trial division stage: produce AQ-pairs
				long tdivStartTime = System.currentTimeMillis();
				List<AQPair> aqPairs = this.auxFactorizer.testList(poly, smoothXList);
				if (PROFILE) tdivDuration += (System.currentTimeMillis() - tdivStartTime);
				//LOG.debug("Trial division found " + aqPairs.size() + " Q(x) smooth enough for a congruence.");
				if (TEST_SIEVE) testSieve(poly, aqPairs, sieveArraySize);

				ccStartTime = System.currentTimeMillis();
				// add all congruences
				for (AQPair aqPair : aqPairs) {
					boolean addedSmooth = congruenceCollector.add(aqPair);
					if (addedSmooth) {
						int smoothCongruenceCount = congruenceCollector.getSmoothCongruenceCount();
						if (smoothCongruenceCount >= requiredSmoothCongruenceCount) {
							// try to solve equation system
							solverRunCount++;
							long t0 = System.currentTimeMillis();
							//LOG.debug("run " + smoothSolverRunCount + ": #smooths = " + smoothCongruenceCount + ", #requiredSmooths = " + requiredSmoothCongruenceCount);
							try {
								solverWrapper.solve(congruenceCollector.getSmoothCongruences()); // throws FactorException -- here we are not interested in solution vectors
								solverDuration += (System.currentTimeMillis()-t0);
							} catch (FactorException fe) {
								solverDuration += (System.currentTimeMillis()-t0);
								//LOG.debug("run " + smoothSolverRunCount + ": found factor " + fe.getFactor());
								throw fe;
							}
							// no factor exception -> extend equation system and continue searching smooth congruences
							//LOG.debug("run " + smoothSolverRunCount + ": no factor found...");
							requiredSmoothCongruenceCount += extraCongruences;
						}
					}
				}
				if (PROFILE) ccDuration += (System.currentTimeMillis() - ccStartTime);
				if (DEBUG) {
					LOG.debug(polyBuilder.getName() + " #" + polyBuilder.getPolyCount() + ": Sieve found " + smoothXList.size() + " smooth x, tDiv let " + aqPairs.size() + " pass.");
					LOG.debug("-> Now in total we have found " + congruenceCollector.getSmoothCongruenceCount() + " / " + requiredSmoothCongruenceCount + " smooth congruences and " + congruenceCollector.getPartialCongruenceCount() + " partials.");
				}
			} // end poly
		} catch (FactorException fe) {
			if (PROFILE) {
				// add the last cc-timing that have not been added yet because of the FactorException 
				long endTime = System.currentTimeMillis();
				ccDuration += endTime - ccStartTime;
				LOG.info(getName() + ": Found factor of N=" + N + " in " + (endTime-startTime) + "ms.");
				LOG.info("    primeBaseSize = " + primeBaseSize + ", sieveArraySize = " + sieveArraySize + ", #processed polynomials = " + polyBuilder.getPolyCount());
				LOG.info("    tDiv " + auxFactorizer.getReportString());
				LOG.info("    cc " + congruenceCollector.getReportString());
				LOG.info("    #solverRuns = " + solverRunCount + ", #tested null vectors = " + solverWrapper.getTestedNullVectorCount());
				LOG.info("    Phase timings: initN=" + initNDuration + "ms, initPoly=" + initPolyDuration + "ms, sieve=" + sieveDuration + "ms, tdiv=" + tdivDuration + "ms, cc=" + (ccDuration-solverDuration) + "ms, solver=" + solverDuration + "ms");
				String polyInitSubTimings = polyBuilder.getProfilingReport();
				if (polyInitSubTimings!=null) LOG.info("    -> initPoly sub-timings: " + polyInitSubTimings);
				String sieveSubTimings = sieve.getProfilingReport();
				if (sieveSubTimings!=null) LOG.info("    -> sieve sub-timings: " + sieveSubTimings);
			} else {
				if (solverRunCount>1) LOG.info(getName() + ": Factoring N="+N + " required " + solverRunCount + " solverRuns and " + solverWrapper.getTestedNullVectorCount() + " tested null vectors");
			}
			// release memory after a factorization; this improves the accuracy of timings when several algorithms are tested in parallel
			this.cleanUp();
			// return factor
			return fe.getFactor();
		}
	}

	public void cleanUp() {
		polyBuilder.cleanUp();
		sieve.cleanUp();
		auxFactorizer.cleanUp();
		congruenceCollector.cleanUp();
		solverWrapper.cleanUp();
	}
	
	private void testSieve(Poly poly, List<AQPair> foundAQPairs, int sieveArraySize) {
		ArrayList<Integer> allXList = new ArrayList<Integer>();
		allXList.add(0);
		for (int x=1; x<sieveArraySize; x++) {
			allXList.add(x);
			allXList.add(-x);
		}
		List<AQPair> allAQPairs = this.auxFactorizer.testList(poly, allXList);
		int foundPerfectSmoothCount = 0;
		for (AQPair aqPair : foundAQPairs) {
			if (aqPair.getOddExpBigFactors().isEmpty()) foundPerfectSmoothCount++;
		}
		int allPerfectSmoothCount = 0;
		for (AQPair aqPair : allAQPairs) {
			if (aqPair.getOddExpBigFactors().isEmpty()) allPerfectSmoothCount++;
		}
		float perfectSmoothPercentage = foundPerfectSmoothCount*100 / (float) allPerfectSmoothCount;
		float partialPercentage = (foundAQPairs.size()-foundPerfectSmoothCount)*100 / (float) (allAQPairs.size()-allPerfectSmoothCount);
		LOG.debug("sieve found " + perfectSmoothPercentage + " % of perfectly smooth and " + partialPercentage + " % of partial congruences");
	}

	// Standalone test --------------------------------------------------------------------------------------------------
	
	private static final BigInteger N_MAX = THOUSAND;
	private static final boolean RUN_FOREVER = false;

	/**
	 * Test numbers:
	 * 11111111111111111111111111
	 * 5679148659138759837165981543
	 * 11111111111111111111111111155555555555111111111111111
	 */
	private static void testInput() {
		while(true) {
			try {
				LOG.info("Please insert the number to factor:");
				BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
				String input = in.readLine().trim();
				//LOG.debug("input = >" + input + "<");
				BigInteger N = new BigInteger(input);
				LOG.info("Factoring " + N + " ...");
//				QS qs = new QS(20, 0.32F, 0.42F, new SIQSPolyBuilder01(3, new AParamGenerator01(), 2), new Sieve04b(1, 0.16F, 1.4427F, 1), new TDiv_QS02(20, 0.18F), new CongruenceCollector01(), 10, new MatrixSolver01<Integer>(2));
//				QS qs = new QS(20, 0.32F, 0.42F, new SIQSPolyBuilder01(3, new AParamGenerator01(), 2), new Sieve04b(1, 0.16F, 1.4427F, 1), new TDiv_QS03(20, 0.18F), new CongruenceCollector02(), 10, new MatrixSolver01<Integer>(2));
				QS qs = new QS(20, 0.32F, 0.42F, new SIQSPolyBuilder02(3, new AParamGenerator01(), 2), new Sieve04b(1, 0.16F, 1.4427F, 1), new TDiv_QS03(20, 0.18F), new CongruenceCollector02(), 10, new MatrixSolver01<Integer>(2));
				BigInteger factor = qs.findSingleFactor(N);
				if (factor != null) {
					LOG.info("Found factor " + factor);
				} else {
					LOG.info("No factor found, another k is recommended.");
				}
			} catch (Exception ex) {
				LOG.error("Error " + ex, ex);
			}
		}
	}
	
	@SuppressWarnings("unused")
	private static void testSmall() {
		BigInteger testCount = ZERO;
		BigInteger factorCount = ZERO;
		for (BigInteger N = THREE; ; N=N.add(TWO)) {
			if (N.compareTo(N_MAX)>0 && !RUN_FOREVER) break;
			// we do not want to test primes...
			if (N.isProbablePrime(20)) continue;
			
			// now N is ok
			LOG.info("Factoring " + N + " ...");
			try {
				QS qs = new QS(20, 0.3F, 0.9F, new BasicQSPolyBuilder01(new SquarefreeSequence(1)), new Sieve01(0, 0.5F), new TDiv_QS01(20, 0.25F), new CongruenceCollector02(), 10, new MatrixSolver01<Integer>(2));
				BigInteger factor = qs.findSingleFactor(N);
				if (factor != null) {
					LOG.info("Found factor " + factor);
					factorCount = factorCount.add(ONE);
				} else {
					LOG.info("No factor found, another k is recommended.");
				}
			} catch (Exception ex) {
				LOG.error("Error " + ex, ex);
			}
			testCount = testCount.add(ONE);
		}
		LOG.info("#(factored N): " + factorCount + " of " + testCount);
	}

	/**
	 * Test of input k, N and #iterations.
	 * @param args ignored
	 */
	public static void main(String[] args) {
    	ConfigUtil.initProject();
    	testInput();
    	//testSmall();
	}
}
