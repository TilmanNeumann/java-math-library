/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * This file is part of the PSIQS package version 01 from 2016-01-07, 
 * developed by Tilman Neumann, Edemissen, Germany.
 * 
 * Use and redistribution of PSIQS are free for non-commercial purposes, as long as this
 * header is not modified or removed. Any commercial usage of the whole or parts
 * of PSIQS requires the written consent of the author.
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

package de.tilman_neumann.math.factor;

import java.math.BigInteger;

import de.tilman_neumann.types.SortedMultiset;

/**
 * Interface for factoring algorithms that deliver a full prime factorization.
 * 
 * @author Tilman Neumann
 */
public interface FactorAlgorithm {
	
	/** The best available single-threaded factor algorithm. (multi-threading may not always be wanted) */
	public static FactorAlgorithm DEFAULT = new CombinedFactorAlgorithm(20, 1);

	/**
	 * Decomposes the argument N into prime factors.
	 * The result is formally a multiset of BigIntegers, sorted bottom-up.
	 * @param N Number to factor.
	 * @return factors
	 */
	public SortedMultiset<BigInteger> factor(BigInteger N);
	
	public String getName();
}
